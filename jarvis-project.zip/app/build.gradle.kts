plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// R8 shrinking. If anything breaks only in release, set JARVIS_MINIFY=false in gradle.properties to test.
val minify: Boolean = (project.findProperty("JARVIS_MINIFY") as String?) != "false"

android {
    namespace = "com.jarvis.aiassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jarvis.aiassistant"
        minSdk = 26
        targetSdk = 35
        // Version code rises on every GitHub build so each new APK installs over the old one.
        // Keep in sync with VC in .github/workflows/build.yml (the run number itself).
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0.0"
        // SHA-256 of the official signing certificate (a public fingerprint, not a secret).
        buildConfigField("String", "OFFICIAL_CERT_SHA256", "\"fc22042017c3ebe048da6b738da9e5ec40ee0d4786881161267e450e93fac0c7\"")
        // Release tags are "build-N". The app compares N + TAG_OFFSET with its own versionCode.
        // The workflow tags the version code itself (build-123 for code 123), so the default 0 is right.
        buildConfigField("int", "TAG_OFFSET", ((project.findProperty("JARVIS_TAG_OFFSET") as String?)?.toIntOrNull() ?: 0).toString())
        // Phones are arm64; dropping the other CPU types roughly halves the APK.
        // Override with JARVIS_ABIS=arm64-v8a,armeabi-v7a,x86_64 for emulators.
        ndk { abiFilters += ((project.findProperty("JARVIS_ABIS") as String?) ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() } }
        buildConfigField("String", "REPO_OWNER", "\"shanfxr3-cmyk\"")
        buildConfigField("String", "REPO_NAME", "\"J.A.R.V.I.S.-Mobile\"")
    }

    // Same signing key on every build = updates install over the existing app.
    // The key comes from GitHub Secrets (workflow sets KEYSTORE_PATH). Without it the release build
    // falls back to the debug key so forks and local builds still work; such an APK must never be published.
    val ksPath = System.getenv("KEYSTORE_PATH")
    val hasReleaseKey = ksPath != null && file(ksPath).exists()
    if (hasReleaseKey) {
        signingConfigs {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    } else {
        logger.warn("WARNING: no release keystore. The release APK will be signed with the DEBUG key and will not update an installed official build.")
    }
    buildTypes {
        release {
            isMinifyEnabled = minify
            isShrinkResources = minify
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    // Lint is not run by assembleRelease. Run `gradle lintRelease` on purpose when you want a report.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-Xskip-metadata-version-check"  // safety net: tolerate libs built with newer Kotlin
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        // Firefox's native engine is ~130 MB uncompressed. Compressed in the APK it is far smaller to download.
        jniLibs { useLegacyPackaging = true }
        resources {
            // Licence/metadata files that only add size and can cause duplicate-file errors.
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "DebugProbesKt.bin", "/kotlin-tooling-metadata.json")
        }
    }
}

// GeckoView ("+") dragged in kotlin-stdlib 2.4.20, which Kotlin 2.0.20 cannot read. Hold every Kotlin artifact at the project version.
configurations.configureEach {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin" && requested.name.startsWith("kotlin-stdlib")) {
            useVersion(libs.versions.kotlin.get())
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.core.ktx)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.onnxruntime.android)  // openWakeWord models (WakeWord.kt)
    // Firefox's engine for the World screen (arm64 phones; same CPU filter as above). "+" = newest stable release.
    implementation("org.mozilla.geckoview:geckoview-arm64-v8a:+")
    // Chrome Custom Tabs: the World screen's "Chrome tab" engine.
    implementation("androidx.browser:browser:1.8.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")   // web search / weather (private-address guard, manual redirects)
    implementation("org.jsoup:jsoup:1.18.1")               // reads page text
    testImplementation(libs.junit)
    testImplementation("org.json:json:20240303")   // real org.json for JVM tests (Android's is a stub there)
}

// GeckoView's libraries may declare a newer compileSdk/AGP than this project uses. They still compile and run
// (we only call stable GeckoView APIs), so skip that metadata check instead of failing the build.
tasks.configureEach {
    if (name.startsWith("check") && name.endsWith("AarMetadata")) enabled = false
}
