plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// R8 shrinking. If anything breaks only in release, set JARVIS_MINIFY=false in gradle.properties to test.
val minify: Boolean = (project.findProperty("JARVIS_MINIFY") as String?) != "false"

android {
    namespace = "com.jarvis.aiassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jarvis.aiassistant"
        minSdk = 26
        targetSdk = 35
        // Version code rises on every GitHub build so each new APK installs over the old one.
        // Keep in sync with VC in .github/workflows/android.yml (run number + 100).
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "0.13.1"
        // SHA-256 of the official signing certificate (a public fingerprint, not a secret).
        buildConfigField("String", "OFFICIAL_CERT_SHA256", "\"fc22042017c3ebe048da6b738da9e5ec40ee0d4786881161267e450e93fac0c7\"")
        // Release tags are "build-N". The app compares N + TAG_OFFSET with its own versionCode.
        // The workflow tags the version code itself (build-123 for code 123), so the default 0 is right.
        buildConfigField("int", "TAG_OFFSET", ((project.findProperty("JARVIS_TAG_OFFSET") as String?)?.toIntOrNull() ?: 0).toString())
        // Phones are arm64; dropping the other CPU types roughly halves the APK.
        // Override with JARVIS_ABIS=arm64-v8a,armeabi-v7a,x86_64 for emulators.
        ndk { abiFilters += ((project.findProperty("JARVIS_ABIS") as String?) ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() } }
        buildConfigField("String", "REPO_OWNER", "\"shanfxr3-cmyk\"")
        buildConfigField("String", "REPO_NAME", "\"J.A.R.V.I.S.-Mobile\"")
    }

    // Same signing key on every build = updates install over the existing app.
    // The key comes from GitHub Secrets (workflow sets KEYSTORE_PATH). Without it the release build
    // falls back to the debug key so forks and local builds still work; such an APK must never be published.
    val ksPath = System.getenv("KEYSTORE_PATH")
    val hasReleaseKey = ksPath != null && file(ksPath).exists()
    if (hasReleaseKey) {
        signingConfigs {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    } else {
        logger.warn("WARNING: no release keystore. The release APK will be signed with the DEBUG key and will not update an installed official build.")
    }
    buildTypes {
        release {
            isMinifyEnabled = minify
            isShrinkResources = minify
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    // Lint is not run by assembleRelease. Run `gradle lintRelease` on purpose when you want a report.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            // Licence/metadata files that only add size and can cause duplicate-file errors.
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "DebugProbesKt.bin", "/kotlin-tooling-metadata.json")
        }
    }
    // Removed: androidResources { noCompress += "task" }. That was for the MediaPipe hand model,
    // and the app no longer ships any .task file.
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.core.ktx)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.onnxruntime.android)  // openWakeWord models (WakeWord.kt)
}
