plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// R8 shrinking. If hand tracking or anything else breaks only in release, set JARVIS_MINIFY=false in gradle.properties to test.
val minify: Boolean = (project.findProperty("JARVIS_MINIFY") as String?) != "false"

android {
    namespace = "com.jarvis.aiassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jarvis.aiassistant"
        minSdk = 26
        targetSdk = 35
        // Version code rises on every GitHub build so each new APK installs over the old one.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "0.9.1"
        buildConfigField("String", "OFFICIAL_CERT_SHA256", "\"fc22042017c3ebe048da6b738da9e5ec40ee0d4786881161267e450e93fac0c7\"")
        // Release tags are "build-N". The app compares N + TAG_OFFSET with its own versionCode (run number + 100).
        // If your workflow tags the version code itself (build-123 for code 123), set JARVIS_TAG_OFFSET=0 in gradle.properties;
        // if it tags the plain run number, use 100. Default 0 = tag equals versionCode.
        buildConfigField("int", "TAG_OFFSET", ((project.findProperty("JARVIS_TAG_OFFSET") as String?)?.toIntOrNull() ?: 0).toString())
        // Phones are arm64; dropping the other CPU types roughly halves the APK. Override with JARVIS_ABIS=arm64-v8a,armeabi-v7a,x86_64 for emulators.
        ndk { abiFilters += ((project.findProperty("JARVIS_ABIS") as String?) ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() } }
        buildConfigField("String", "REPO_OWNER", "\"shanfxr3-cmyk\"")
        buildConfigField("String", "REPO_NAME", "\"J.A.R.V.I.S.-Mobile\"")
    }

    // Same signing key on every build = updates install over the existing app.
    // The key comes from GitHub Secrets; without it the build falls back to the debug key.
    val ksPath = System.getenv("KEYSTORE_PATH")
    if (ksPath != null && file(ksPath).exists()) {
        signingConfigs {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            // R8 shrinks and optimises the release app. If a build ever crashes on launch, set both to false.
            isMinifyEnabled = minify
            isShrinkResources = minify
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    androidResources { noCompress += "task" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.26")   // 0.10.26+ ships 16 KB-page-aligned native libraries
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")   // 1.22+ ships 16 KB-page-aligned native libraries
}
