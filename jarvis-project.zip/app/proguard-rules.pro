# J.A.R.V.I.S. Mobile release rules.
# Names are NOT obfuscated, so crash traces from users stay readable.
-dontobfuscate
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod, SourceFile, LineNumberTable

# Wake word: ONNX Runtime talks to native code (JNI) by class and method name.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**


# MediaPipe's Graph class initialises logging and JNI helpers by name; R8 must not strip or rename them.
-keep class com.google.common.flogger.** { *; }
-dontwarn com.google.common.flogger.**
-keep class com.google.common.base.** { *; }
-keep class com.google.common.collect.** { *; }
-dontwarn com.google.common.**
-keepclasseswithmembernames class * { native <methods>; }
-keep class * extends com.google.protobuf.GeneratedMessageLite { *; }
-dontwarn javax.lang.model.**
-dontwarn javax.annotation.processing.**
-dontwarn javax.tools.**
-dontwarn autovalue.shaded.**
-dontwarn com.google.auto.value.**

# The app's own code is small and uses services, receivers and a FileProvider by name: keep it whole.
-keep class com.jarvis.aiassistant.** { *; }
