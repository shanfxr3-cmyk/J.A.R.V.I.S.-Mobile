# J.A.R.V.I.S. Voice Only release rules.
# Names are NOT obfuscated, so crash traces from users stay readable.
-dontobfuscate
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod, SourceFile, LineNumberTable

# Wake word: ONNX Runtime talks to native code (JNI) by class and method name.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**

# Hand tracking: MediaPipe tasks and the protobuf classes they load by name.
-keep class com.google.mediapipe.** { *; }
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.mediapipe.**
-dontwarn com.google.protobuf.**
-dontwarn javax.lang.model.**
-dontwarn autovalue.shaded.**

# The app's own code is small and uses services, receivers and a FileProvider by name: keep it whole.
-keep class com.jarvis.aiassistant.** { *; }
