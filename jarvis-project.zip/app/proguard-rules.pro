# J.A.R.V.I.S. Mobile release rules.
# Names are NOT obfuscated, so crash traces from users stay readable.
-dontobfuscate
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod, SourceFile, LineNumberTable

# Wake word: ONNX Runtime talks to native code (JNI) by class and method name.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
# REMOVED on purpose:
# - MediaPipe / Guava / protobuf / flogger / AutoValue rules: those libraries are no longer dependencies.
# - "-keepclasseswithmembernames class * { native <methods>; }": already in proguard-android-optimize.txt.
# - "-keep class com.jarvis.aiassistant.** { *; }": this switched R8 off for all of the app's own code.
#   Services, receivers, the Application class, the Activity and FileProvider are kept automatically from
#   AndroidManifest.xml. The app uses no reflection (JSON is parsed by hand with org.json).
#   If a release build ever crashes on launch, set JARVIS_MINIFY=false and send the stack trace.
