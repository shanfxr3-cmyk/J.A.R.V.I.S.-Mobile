# J.A.R.V.I.S. Mobile release rules.
# Names are NOT obfuscated, so crash traces from users stay readable.
-dontobfuscate
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod, SourceFile, LineNumberTable

# Wake word: ONNX Runtime talks to native code (JNI) by class and method name.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
