// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

/**
 * Cuts a growing reply into finished sentences so Jarvis can start speaking while the AI is still writing.
 * Feed it the whole text so far each time; it returns only the sentences that became complete since the last call.
 * If the text restarts, it starts again from the beginning.
 */
class SentenceCutter {
    private var seen = ""
    private var cursor = 0

    private val boundary = Regex("(?<=[.!?])\\s|\\n")

    fun feed(text: String): List<String> {
        if (!text.startsWith(seen.take(cursor.coerceAtMost(seen.length))) || text.length < cursor) cursor = 0
        seen = text
        val out = ArrayList<String>()
        while (true) {
            val m = boundary.find(text, cursor) ?: break
            val piece = text.substring(cursor, m.range.first).trim()
            cursor = m.range.last + 1
            if (piece.isNotEmpty()) out += piece
        }
        return out
    }

    /** Whatever text has not formed a finished sentence yet. */
    fun flush(): String? {
        val rest = if (cursor < seen.length) seen.substring(cursor).trim() else ""
        cursor = seen.length
        return rest.ifEmpty { null }
    }

    fun reset() { seen = ""; cursor = 0 }

    companion object {
        /** Text that may be spoken: reasoning blocks (finished or still open) removed. */
        fun visible(t: String): String =
            t.replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("(?s)<think>.*$"), "")
    }
}
