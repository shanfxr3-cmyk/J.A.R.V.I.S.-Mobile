// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import java.util.concurrent.ConcurrentHashMap

/**
 * Which model to use right now. When the model in use hits a rate limit, goes down or disappears, the next
 * one takes over and the broken one rests, so nobody waits for it twice. Different failures rest for
 * different times: a rate limit refills quickly, an outage lasts longer, a missing model will not come back.
 */
object ModelLadder {
    const val QUOTA_MS = 5L * 60_000
    const val OUTAGE_MS = 30L * 60_000
    const val MISSING_MS = 6L * 3_600_000

    private val restingUntil = ConcurrentHashMap<String, Long>()
    @Volatile internal var now: () -> Long = { System.currentTimeMillis() }

    /** The rungs in use, in order. Set by Store from Settings; falls back to the built-in six. */
    @Volatile var ladder: List<String> = DEFAULT_LADDER

    /** Gemini and Gemma ids go to Gemini; everything else to Groq. Same rule as the hub. */
    fun providerOf(m: String): String = if (Regex("^(gemini|gemma)", RegexOption.IGNORE_CASE).containsMatchIn(m.trim())) "gemini" else "groq"

    /** The model asked for, then every rung, without repeats. */
    fun order(preferred: String) = (listOf(preferred) + ladder).filter { it.isNotBlank() }.distinct()

    /** How long to rest the model after this error, or null when the error is not the model's fault. */
    fun classify(e: Throwable): Long? {
        if (e is AiHttpException) {
            when (e.code) {
                401, 403 -> return null
                429 -> return if (e.retryAfterMs > 0) e.retryAfterMs.coerceIn(5_000L, QUOTA_MS) else QUOTA_MS
                404 -> return MISSING_MS
                in 500..599 -> return OUTAGE_MS
            }
        }
        val text = (e.javaClass.simpleName + " " + (e.message ?: "") + " " + (e.cause?.message ?: "")).lowercase()
        // Status codes only count as whole numbers, so "500" inside some other number or word is not an outage.
        fun code(vararg n: Int) = n.any { Regex("(?<![0-9a-z])$it(?![0-9a-z])").containsMatchIn(text) }
        val notModel = listOf("api key", "api_key", "invalid api", "permission", "unable to resolve", "unknownhost",
            "failed to connect", "no address associated", "network is unreachable", "cancelled")
        if (notModel.any { it in text } || code(401, 403)) return null
        return when {
            listOf("rate limit", "too many requests", "quota").any { it in text } || code(429) -> QUOTA_MS
            listOf("decommission", "model_not_found", "does not exist", "no longer supported", "not found").any { it in text } || code(404) -> MISSING_MS
            listOf("unavailable", "timeout", "timed out", "overloaded", "server error").any { it in text } || code(500, 502, 503, 504) -> OUTAGE_MS
            else -> null
        }
    }

    fun rest(id: String, ms: Long) { restingUntil[id] = now() + ms }
    fun isResting(id: String) = (restingUntil[id] ?: 0L) > now()
    fun reset() = restingUntil.clear()

    /** The model to start a request on: the preferred one unless it is resting. */
    fun best(preferred: String, usable: (String) -> Boolean = { true }): String =
        order(preferred).filter(usable).let { l -> l.firstOrNull { !isResting(it) } ?: l.firstOrNull() ?: preferred }

    /** The model to try after [current] failed, or null when everything is resting. */
    fun next(current: String, preferred: String, usable: (String) -> Boolean = { true }): String? =
        order(preferred).firstOrNull { it != current && usable(it) && !isResting(it) }
}
