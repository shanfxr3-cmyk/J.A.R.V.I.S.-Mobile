// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f
private const val DOTS = 260
private const val RING_SEGS = 72
private const val MERIDIANS = 6
private const val SEG = 40

/** Pre-computed geometry plus scratch space, so drawing a frame allocates almost nothing. */
private class SphereData {
    val x = FloatArray(DOTS)
    val y = FloatArray(DOTS)
    val z = FloatArray(DOTS)
    val o = FloatArray(3)
    val path = Path()

    // Three gyroscope rings: radius, tilt around X, roll around Z, spin speed, satellite speed.
    val ringR = floatArrayOf(1.10f, 1.17f, 1.24f)
    val ringTilt = floatArrayOf(1.25f, 0.55f, -0.85f)
    val ringRoll = floatArrayOf(0.0f, 0.9f, -0.6f)
    val ringSpin = floatArrayOf(0.50f, -0.36f, 0.26f)
    val satSpeed = floatArrayOf(1.35f, -0.95f, 0.70f)

    init {
        // Fibonacci lattice: evenly spread dots over the sphere.
        val golden = PI_F * (3f - sqrt(5f))
        for (i in 0 until DOTS) {
            val yy = 1f - 2f * (i + 0.5f) / DOTS
            val rad = sqrt(1f - yy * yy)
            val phi = i * golden
            x[i] = cos(phi) * rad
            y[i] = yy
            z[i] = sin(phi) * rad
        }
    }

    /** Spin around the vertical axis, then tilt the whole thing toward the viewer. Result in [o]. */
    fun proj(px: Float, py: Float, pz: Float, cy: Float, sy: Float, ct: Float, st: Float) {
        val x1 = px * cy + pz * sy
        val z1 = -px * sy + pz * cy
        o[0] = x1
        o[1] = py * ct - z1 * st
        o[2] = py * st + z1 * ct
    }
}

/**
 * The home-screen sphere: a rotating dot-globe with a glowing core, a scanning light band,
 * three precessing rings with satellites and a slow HUD tick ring. It spins faster and ripples
 * while Jarvis is listening, thinking or speaking. It animates only while the app is visible.
 */
@Composable
fun AiSphere(modifier: Modifier = Modifier) {
    val ws = WakeService.state
    val busy = ws == WakeState.LISTENING || ws == WakeState.THINKING || ws == WakeState.SPEAKING
    val speed by animateFloatAsState(
        when (ws) { WakeState.LISTENING -> 2.2f; WakeState.THINKING -> 3.0f; WakeState.SPEAKING -> 1.8f; else -> 1f },
        tween(600), label = "sphereSpeed"
    )
    val energy by animateFloatAsState(if (busy) 1f else 0f, tween(500), label = "sphereEnergy")
    val speedNow by rememberUpdatedState(speed)
    var time by remember { mutableFloatStateOf(0f) }
    val d = remember { SphereData() }

    LaunchWhileStarted {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    time += dt * speedNow
                }
                last = now
            }
        }
    }

    Canvas(modifier) {
        val t = time
        val c = center
        val r = size.minDimension / 2.7f
        val u = 1.dp.toPx()
        val breathe = 0.5f + 0.5f * sin(t * 1.6f)

        val yaw = t * 0.42f
        val cyw = cos(yaw)
        val syw = sin(yaw)
        val tilt = -0.32f
        val ct = cos(tilt)
        val st = sin(tilt)

        // Soft halo behind everything.
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.10f + 0.10f * breathe + 0.12f * energy), Color.Transparent), c, r * 1.9f),
            r * 1.9f, c
        )
        // Glassy body, lit from the upper left.
        drawCircle(
            Brush.radialGradient(
                listOf(Cyan.copy(alpha = 0.22f), Cyan.copy(alpha = 0.06f), Color.Transparent),
                c + Offset(-r * 0.28f, -r * 0.30f), r * 1.15f
            ),
            r, c
        )
        // Core.
        val core = Color(0xFFCFFBFF)
        drawCircle(
            Brush.radialGradient(
                listOf(core.copy(alpha = 0.16f + 0.10f * breathe + 0.12f * energy), Cyan.copy(alpha = 0.10f), Color.Transparent),
                c, r * 0.6f
            ),
            r * 0.6f, c
        )

        // Rings: one half behind the sphere, the other in front.
        fun rings(front: Boolean) {
            for (k in 0 until 3) {
                val rr = d.ringR[k]
                val ca = cos(d.ringTilt[k]); val sa = sin(d.ringTilt[k])
                val cg = cos(d.ringRoll[k]); val sg = sin(d.ringRoll[k])
                val yk = t * d.ringSpin[k]
                val cyk = cos(yk); val syk = sin(yk)
                // point on the ring at angle psi, projected; result in d.o (x, y, depth)
                fun at(psi: Float) {
                    val bx = cos(psi) * rr
                    val bz = sin(psi) * rr
                    val y1 = -bz * sa
                    val z1 = bz * ca
                    d.proj(bx * cg - y1 * sg, bx * sg + y1 * cg, z1, cyk, syk, ct, st)
                }
                var px = 0f; var py = 0f; var pz = 0f
                for (i in 0..RING_SEGS) {
                    at(i * TAU / RING_SEGS)
                    val sx = c.x + d.o[0] * r * (1f + d.o[2] * 0.1f)
                    val sy = c.y + d.o[1] * r * (1f + d.o[2] * 0.1f)
                    val z = d.o[2]
                    if (i > 0 && ((z + pz) >= 0f) == front) {
                        val depth = ((z + pz) * 0.5f + 1f) * 0.5f
                        drawLine(
                            Cyan.copy(alpha = if (front) 0.30f + 0.35f * depth else 0.10f),
                            Offset(px, py), Offset(sx, sy), strokeWidth = (if (front) 1.2f else 0.8f) * u
                        )
                    }
                    px = sx; py = sy; pz = z
                }
                // Satellite
                at(t * d.satSpeed[k] + k * 2.1f)
                if ((d.o[2] >= 0f) == front) {
                    val sx = c.x + d.o[0] * r * (1f + d.o[2] * 0.1f)
                    val sy = c.y + d.o[1] * r * (1f + d.o[2] * 0.1f)
                    val a = if (front) 1f else 0.45f
                    drawCircle(Cyan.copy(alpha = 0.28f * a), 5.5f * u, Offset(sx, sy))
                    drawCircle(Color.White.copy(alpha = a), 2.2f * u, Offset(sx, sy))
                }
            }
        }

        // Back half of the dots and rings.
        val scanY = sin(t * 0.9f) * 0.95f
        fun dots(front: Boolean) {
            for (i in 0 until DOTS) {
                d.proj(d.x[i], d.y[i], d.z[i], cyw, syw, ct, st)
                val z = d.o[2]
                if ((z >= 0f) != front) continue
                val depth = (z + 1f) * 0.5f
                val dy = d.o[1] - scanY
                val scan = exp(-dy * dy * 18f)
                val a = (0.14f + 0.70f * depth * depth + 0.5f * scan).coerceAtMost(1f)
                val col = if (scan > 0.25f) lerp(Cyan, Color.White, scan) else Cyan
                val rad = (0.7f + 1.3f * depth + 1.2f * scan) * u
                drawCircle(
                    col.copy(alpha = a), rad,
                    Offset(c.x + d.o[0] * r * (1f + z * 0.1f), c.y + d.o[1] * r * (1f + z * 0.1f))
                )
            }
        }

        dots(false)
        rings(false)

        // Faint latitude / longitude grid, front hemisphere only.
        val path = d.path
        path.rewind()
        for (m in 0 until MERIDIANS) {
            val lon = m * (PI_F / MERIDIANS)
            val dx = cos(lon); val dz = sin(lon)
            var pen = false
            for (i in 0..SEG) {
                val psi = i * (TAU / SEG)
                val cp = cos(psi)
                d.proj(dx * cp, sin(psi), dz * cp, cyw, syw, ct, st)
                if (d.o[2] >= 0f) {
                    val sx = c.x + d.o[0] * r * (1f + d.o[2] * 0.1f)
                    val sy = c.y + d.o[1] * r * (1f + d.o[2] * 0.1f)
                    if (!pen) { path.moveTo(sx, sy); pen = true } else path.lineTo(sx, sy)
                } else pen = false
            }
        }
        for (lat in -2..2) {
            val y0 = lat * 0.33f
            val rad = sqrt(1f - y0 * y0)
            var pen = false
            for (i in 0..SEG) {
                val psi = i * (TAU / SEG)
                d.proj(cos(psi) * rad, y0, sin(psi) * rad, cyw, syw, ct, st)
                if (d.o[2] >= 0f) {
                    val sx = c.x + d.o[0] * r * (1f + d.o[2] * 0.1f)
                    val sy = c.y + d.o[1] * r * (1f + d.o[2] * 0.1f)
                    if (!pen) { path.moveTo(sx, sy); pen = true } else path.lineTo(sx, sy)
                } else pen = false
            }
        }
        drawPath(path, Cyan.copy(alpha = 0.16f), style = Stroke(0.8f * u))

        dots(true)
        rings(true)

        // Edge of the sphere and a thin atmosphere.
        drawCircle(Cyan.copy(alpha = 0.55f), r, c, style = Stroke(1.2f * u))
        drawCircle(Cyan.copy(alpha = 0.14f), r * 1.05f, c, style = Stroke(3f * u))

        // HUD tick ring that turns slowly, with a brighter arc running the other way.
        val tickBase = t * 0.12f
        for (i in 0 until 72) {
            val a = tickBase + i * TAU / 72f
            val major = i % 6 == 0
            val r0 = r * 1.27f
            val r1 = r0 + r * (if (major) 0.06f else 0.03f)
            drawLine(
                Cyan.copy(alpha = if (major) 0.55f else 0.22f),
                Offset(c.x + cos(a) * r0, c.y + sin(a) * r0),
                Offset(c.x + cos(a) * r1, c.y + sin(a) * r1),
                strokeWidth = (if (major) 1.3f else 0.9f) * u
            )
        }
        val ar = r * 1.245f
        drawArc(
            Cyan.copy(alpha = 0.85f), -t * 38f, 48f, false,
            Offset(c.x - ar, c.y - ar), Size(2 * ar, 2 * ar),
            style = Stroke(1.6f * u, cap = StrokeCap.Round)
        )

        // Ripple while Jarvis is working.
        if (energy > 0.01f) {
            val p = (t * 0.8f) % 1f
            drawCircle(Cyan.copy(alpha = (1f - p) * 0.35f * energy), r * (1f + 0.28f * p), c, style = Stroke(1.5f * u))
        }
    }
}
