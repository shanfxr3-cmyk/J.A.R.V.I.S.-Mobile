// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Jarvis speaks first, entirely on the phone: no AI call, no network, no tokens.
 * Calendar heads-up with travel time, full-charge and charging-habit nudges, leave/arrive home, evening summary, optional mute during meetings. Everything goes through [Speaker] (once only)
 * and a "should I speak now?" gate: quiet hours, calls, Do Not Disturb, a minimum gap and a daily cap.
 */
object Proactive {
    private const val GAP_MS = 4 * 60_000L
    private const val DAILY_MAX = 12
    private const val HOME_IN_M = 150.0
    private const val HOME_OUT_M = 250.0   // hysteresis so GPS jitter at the edge does not flip it

    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun on(c: Context) = sp(c).getBoolean("proOn", true)
    fun setOn(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("proOn", v).apply()
        // Home detection has its own location feed, so it must not depend on the hub-sharing switch.
        runCatching { if (Locator.shareOn(c) || homeWatch(c)) Locator.start(c) else Locator.stop(c) }
    }
    /** Use the drive time to an event's address (the address is looked up by the phone's own map service). */
    fun travelOn(c: Context) = sp(c).getBoolean("proTravel", true)
    fun setTravelOn(c: Context, v: Boolean) { sp(c).edit().putBoolean("proTravel", v).apply() }
    /** Mute the phone (Do Not Disturb, through Shizuku) while a calendar event is on. Off until you switch it on. */
    fun muteOn(c: Context) = sp(c).getBoolean("proMute", false)
    fun setMuteOn(c: Context, v: Boolean) { sp(c).edit().putBoolean("proMute", v).apply() }
    /** True when proactive is on and a home point exists, so the location feed must run. */
    fun homeWatch(c: Context) = on(c) && sp(c).contains("homeLat")

    // ---- pure helpers (unit tested) ----
    fun isQuiet(hour: Int, min: Int): Boolean { val m = hour * 60 + min; return m >= 23 * 60 || m < 6 * 60 + 30 }

    fun distanceM(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6_371_000.0
        val dLa = Math.toRadians(la2 - la1); val dLo = Math.toRadians(lo2 - lo1)
        val a = sin(dLa / 2) * sin(dLa / 2) + cos(Math.toRadians(la1)) * cos(Math.toRadians(la2)) * sin(dLo / 2) * sin(dLo / 2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }

    fun atHome(was: Boolean, d: Double) = if (was) d <= HOME_OUT_M else d <= HOME_IN_M

    /** Rough drive time from straight-line distance: 1.4x detour, 22 km/h average, 5 minutes to get going. */
    fun travelMinutes(distM: Double): Int = (distM * 1.4 / 1000.0 / 22.0 * 60.0).roundToInt().plus(5).coerceIn(8, 120)

    /** Leave-time warning: travel plus a 10 minute margin; 30 minutes when the distance is unknown. */
    fun leaveLead(travel: Int?): Int = if (travel == null) 30 else (travel + 10).coerceIn(15, 150)

    /** Events with a place get an earlier warning, because you have to travel. */
    fun leadMinutes(location: String, travel: Int? = null) = if (location.isBlank()) 15 else leaveLead(travel)

    fun eventLine(title: String, mins: Long, location: String, travel: Int? = null): String {
        val t = title.ifBlank { "An event" }
        val when_ = if (mins <= 1) "is starting now" else "starts in $mins minutes"
        if (location.isBlank()) return "Sir, $t $when_."
        return if (travel != null) "Sir, $t $when_, at $location. It is about $travel minutes away, so leave now."
        else "Sir, $t $when_, at $location. You may want to leave soon."
    }

    /** The hour of day you usually plug in (centre of the busiest 3-hour window), or null until there is a pattern. */
    fun usualHour(hours: List<Int>): Int? {
        if (hours.size < 5) return null
        val cnt = IntArray(24)
        hours.forEach { if (it in 0..23) cnt[it]++ }
        var best = -1; var score = 0
        for (h in 0..23) {
            val s = cnt[(h + 23) % 24] + cnt[h] + cnt[(h + 1) % 24]
            if (s > score || (s == score && best >= 0 && cnt[h] > cnt[best])) { score = s; best = h }
        }
        return if (score >= 4) best else null
    }

    // ---- the gate ----
    private fun today() = SimpleDateFormat("yyyyDDD", Locale.US).format(Date())

    private fun mayTalk(c: Context, urgent: Boolean): Boolean {
        val cal = Calendar.getInstance()
        if (isQuiet(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)) && !urgent) return false
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.mode != AudioManager.MODE_NORMAL) return false   // in a call
        val nm = c.getSystemService(NotificationManager::class.java)
        val f = runCatching { nm.currentInterruptionFilter }.getOrDefault(NotificationManager.INTERRUPTION_FILTER_ALL)
        if (f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) return false
        val p = sp(c)
        val now = System.currentTimeMillis()
        if (!urgent && now - p.getLong("proLast", 0L) < GAP_MS) return false
        val d = today()
        val n = if (p.getString("proDay", "") == d) p.getInt("proCount", 0) else 0
        if (n >= DAILY_MAX && !urgent) return false
        p.edit().putLong("proLast", now).putString("proDay", d).putInt("proCount", n + 1).apply()
        return true
    }

    private fun say(c: Context, text: String, urgent: Boolean = false): Boolean {
        if (!mayTalk(c, urgent)) return false
        Speaker.say(c, text); return true
    }

    // ---- the ticker (AlertService calls this once a minute) ----
    fun tick(c: Context) {
        runCatching { meetings(c) }   // before the switch check, so a mute we set is always lifted
        if (!on(c)) return
        runCatching { calendar(c) }
        runCatching { fullCharge(c) }
        runCatching { habit(c) }
        runCatching { evening(c) }
    }

    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    private class Ev(val id: Long, val title: String, val begin: Long, val end: Long, val loc: String)

    private fun events(c: Context, from: Long, to: Long, limit: Int): List<Ev> {
        if (!granted(c, Manifest.permission.READ_CALENDAR)) return emptyList()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { ContentUris.appendId(it, from); ContentUris.appendId(it, to) }.build()
        val out = ArrayList<Ev>()
        c.contentResolver.query(uri, arrayOf(CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.END), null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
            while (cur.moveToNext() && out.size < limit) {
                if (cur.getInt(4) == 1) continue
                out += Ev(cur.getLong(0), cur.getString(1).orEmpty(), cur.getLong(2), cur.getLong(5), cur.getString(3).orEmpty())
            }
        }
        return out
    }

    private val geoRetry = HashMap<String, Long>()

    /** Address to coordinates through the phone's own geocoder. Results (also "not found") are cached; network errors retry after 10 minutes. */
    @Suppress("DEPRECATION")
    private fun geocode(c: Context, loc: String): Pair<Double, Double>? {
        val p = sp(c)
        val k = loc.trim().lowercase().hashCode().toString()
        val lines = p.getString("proGeo", "").orEmpty().split('\n').filter { it.isNotBlank() }
        lines.firstOrNull { it.startsWith("$k|") }?.let { l ->
            val f = l.split('|')
            val la = f.getOrNull(1)?.toDoubleOrNull(); val lo = f.getOrNull(2)?.toDoubleOrNull()
            return if (la != null && lo != null) la to lo else null
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - (geoRetry[k] ?: -1_000_000L) < 600_000L) return null
        geoRetry[k] = now
        if (!android.location.Geocoder.isPresent()) return null
        val res = try { android.location.Geocoder(c, Locale.getDefault()).getFromLocationName(loc, 1) } catch (_: Throwable) { return null }
        val a = res?.firstOrNull()
        val line = if (a != null) "$k|${a.latitude}|${a.longitude}" else "$k|x|x"
        p.edit().putString("proGeo", (lines + line).takeLast(40).joinToString("\n")).apply()
        return a?.let { it.latitude to it.longitude }
    }

    private fun travelTo(c: Context, loc: String, from: android.location.Location): Int? =
        geocode(c, loc)?.let { (la, lo) -> travelMinutes(distanceM(from.latitude, from.longitude, la, lo)) }

    private fun calendar(c: Context) {
        val now = System.currentTimeMillis()
        val p = sp(c)
        val seen = p.getString("proSeen", "").orEmpty().split('\n').filter { it.isNotBlank() }.toMutableList()
        val me = if (travelOn(c)) here(c) else null
        val mute = muteOn(c) && Shell.granted()
        for (e in events(c, now, now + 160 * 60_000L, 8)) {
            val mins = (e.begin - now) / 60_000L
            if (mins < 0) continue
            val travel = if (e.loc.isNotBlank() && me != null && mins <= 150) travelTo(c, e.loc, me) else null
            if (mins > leadMinutes(e.loc, travel)) continue
            val key = "${e.id}@${e.begin}"
            if (key in seen) continue
            val line = eventLine(e.title, mins, e.loc, travel) + if (mute && mins > 1) " I will mute the phone when it starts." else ""
            if (say(c, line, urgent = mins <= 10)) {
                seen += key
                p.edit().putString("proSeen", seen.takeLast(30).joinToString("\n")).apply()
            }
        }
    }

    /** Optional: Do Not Disturb (through Shizuku) while a calendar event is on, lifted when it ends. Only our own mute is undone. */
    private fun meetings(c: Context) {
        val p = sp(c)
        val now = System.currentTimeMillis()
        val nm = c.getSystemService(NotificationManager::class.java)
        val until = p.getLong("proMuteUntil", 0L)
        if (until != 0L) {
            if (now < until) return
            val f = runCatching { nm.currentInterruptionFilter }.getOrDefault(NotificationManager.INTERRUPTION_FILTER_ALL)
            if (f != NotificationManager.INTERRUPTION_FILTER_PRIORITY || (Shell.granted() && Shell.exec("cmd notification set_dnd off").ok) || now > until + 30 * 60_000L)
                p.edit().putLong("proMuteUntil", 0L).apply()
            return
        }
        if (!on(c) || !muteOn(c) || !Shell.granted()) return
        val f = runCatching { nm.currentInterruptionFilter }.getOrDefault(NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
        if (f != NotificationManager.INTERRUPTION_FILTER_ALL) return
        val e = events(c, now - 60_000L, now + 90_000L, 5).firstOrNull { it.begin <= now + 60_000L && it.end > now && it.end - it.begin >= 10 * 60_000L } ?: return
        val key = "${e.id}@${e.begin}"
        if (p.getString("proMuteKey", "") == key) return   // already muted once for this event; do not fight a manual unmute
        if (Shell.exec("cmd notification set_dnd priority").ok)
            p.edit().putString("proMuteKey", key).putLong("proMuteUntil", minOf(e.end, now + 3 * 3_600_000L)).apply()
    }

    private fun battery(c: Context): Pair<Int, Boolean>? {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return lvl to (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0)
    }

    private fun fullCharge(c: Context) {
        val (lvl, plugged) = battery(c) ?: return
        val p = sp(c)
        if (!plugged) { if (p.getBoolean("proFull", false)) p.edit().putBoolean("proFull", false).apply(); return }
        if (lvl >= 100 && !p.getBoolean("proFull", false) && say(c, "Sir, the phone is fully charged. You can unplug it.")) p.edit().putBoolean("proFull", true).apply()
    }

    private fun plugHours(p: android.content.SharedPreferences) = p.getString("proHab", "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }

    /** Learns the hour you usually plug in (local only) and nudges once a day when it is that hour and the battery is low and unplugged. */
    private fun habit(c: Context) {
        val (lvl, plugged) = battery(c) ?: return
        val p = sp(c)
        val prev = p.getInt("proPlug", -1)
        val now = if (plugged) 1 else 0
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (prev != now) {
            p.edit().putInt("proPlug", now).apply()
            if (now == 1 && prev != -1 && lvl <= 90) p.edit().putString("proHab", (plugHours(p) + hour).takeLast(30).joinToString(",")).apply()
            return
        }
        if (plugged || lvl > 60) return
        if (usualHour(plugHours(p)) != hour) return
        val d = today()
        if (p.getString("proHabDay", "") == d) return
        if (say(c, "Sir, you usually put the phone on charge around now. Battery is at $lvl percent.")) p.edit().putString("proHabDay", d).apply()
    }

    private fun evening(c: Context) {
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.HOUR_OF_DAY) != 21 || cal.get(Calendar.MINUTE) < 30) return
        val p = sp(c)
        val d = today()
        if (p.getString("proEve", "") == d) return
        val b = battery(c)
        val tm = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val first = events(c, tm, tm + 86_400_000L, 1).firstOrNull()
        val sb = StringBuilder("Good evening, sir.")
        if (b != null) sb.append(" Battery is at ${b.first} percent").append(if (b.first < 50 && !b.second) ", so put it on charge tonight." else ".")
        if (first != null) sb.append(" Tomorrow begins with ${first.title.ifBlank { "an event" }} at ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(first.begin))}.")
        if (say(c, sb.toString())) p.edit().putString("proEve", d).apply()
    }

    // ---- home geofence (Locator calls this with each fix) ----
    fun onFix(c: Context, lat: Double, lon: Double) {
        if (!on(c)) return
        val p = sp(c)
        if (!p.contains("homeLat")) return
        val d = distanceM(lat, lon, Double.fromBits(p.getLong("homeLat", 0)), Double.fromBits(p.getLong("homeLon", 0)))
        val was = p.getInt("proAtHome", -1)
        val now = atHome(was == 1, d)
        if (was == -1) { p.edit().putInt("proAtHome", if (now) 1 else 0).apply(); return }
        if (now == (was == 1)) return
        val t = System.currentTimeMillis()
        p.edit().putInt("proAtHome", if (now) 1 else 0).also { if (!now) it.putLong("proLeftAt", t) }.apply()
        if (!now) {
            val b = battery(c)
            val next = events(c, t, t + 3 * 3_600_000L, 1).firstOrNull()
            say(c, "Leaving home, sir." + (b?.let { " Battery is at ${it.first} percent." } ?: "") +
                (next?.let { " Next up: ${it.title.ifBlank { "an event" }} at ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(it.begin))}." } ?: ""))
        } else if (t - p.getLong("proLeftAt", 0L) > 10 * 60_000L) say(c, "Welcome home, sir.")
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun here(c: Context): android.location.Location? {
        if (!Locator.fineGranted(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .filter { System.currentTimeMillis() - it.time < 15 * 60_000L }.minByOrNull { if (it.hasAccuracy()) it.accuracy else 9999f }
    }

    val tools: List<ToolDef> = listOf(
        ToolDef("set_home", "Remember the phone's current position as the person's home, for leaving/arriving announcements. Use when they say this is home.") { c, _, _ ->
            val l = here(c)
            if (l == null) "I have no recent location fix. Allow precise location for Jarvis and try again in a minute."
            else {
                sp(c).edit().putLong("homeLat", l.latitude.toBits()).putLong("homeLon", l.longitude.toBits()).putInt("proAtHome", 1).apply()
                runCatching { Locator.start(c) }.let { "Home saved. I'll tell you when you leave and when you're back." }
            }
        }
    )
}
