// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the user's jarvis-hub: starts background jobs and long-polls for things to say aloud. */
object Hub {
    @Volatile var chatUrl = BuildConfig.DEFAULT_HUB_URL.trim().trimEnd('/') + "/v1/chat/completions"
    class Event(val id: Long, val text: String)
    class Batch(val events: List<Event>, val seq: Long)

    fun base(s: Store) = s.hubUrl.trim().trimEnd('/')
    /** Only https hubs are accepted. */
    fun configured(s: Store) = base(s).startsWith("https://") && s.hubBearer.isNotBlank()

    private fun open(s: Store, path: String, read: Int): HttpURLConnection =
        (URL(base(s) + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = read
            setRequestProperty("Authorization", "Bearer " + s.hubBearer)
            setRequestProperty("User-Agent", "Jarvis/${BuildConfig.VERSION_NAME} (Android)")
        }

    fun startJob(s: Store, task: String, context: String): String {
        if (!configured(s)) return "The hub is not set up. Add its address and token in Settings under AI provider."
        return try {
            val c = open(s, "/v1/jobs", 20000)
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("task", task).put("context", context).toString().toByteArray()) }
            val code = c.responseCode
            if (code in 200..299) JSONObject(c.inputStream.bufferedReader().readText()).optString("message", "Started.")
            else "The hub refused the job (HTTP $code)."
        } catch (e: Exception) { "Could not reach the hub: ${e.message}" }
    }

    /** Waits up to ~25 seconds for new spoken events. Blocking. */
    fun events(s: Store, after: Long): Batch {
        val c = open(s, "/v1/events?after=$after", 40000)
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("hub HTTP ${c.responseCode}")
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val a = j.getJSONArray("events")
            return Batch((0 until a.length()).map { a.getJSONObject(it).let { o -> Event(o.getLong("id"), o.getString("text")) } }, j.optLong("seq", after))
        } finally { c.disconnect() }
    }

    fun watch(s: Store, topic: String, remove: Boolean): String {
        if (!configured(s)) return "The hub is not set up."
        return try {
            val c = open(s, "/v1/watch", 20000)
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("topic", topic).put("remove", remove).toString().toByteArray()) }
            if (c.responseCode in 200..299) c.inputStream.bufferedReader().readText() else "The hub refused (HTTP ${c.responseCode})."
        } catch (e: Exception) { "Could not reach the hub: ${e.message}" }
    }

    class TvCmd(val id: Long, val action: String, val arg: String)

    /** Waits up to ~25 s for TV commands that Telegram or a hub job queued for this phone. Blocking. */
    fun tvNext(s: Store, after: Long): List<TvCmd> {
        val c = open(s, "/v1/tv/next?after=$after", 40000)
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("hub HTTP ${c.responseCode}")
            val a = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("cmds")
            return (0 until a.length()).map { a.getJSONObject(it).let { o -> TvCmd(o.getLong("id"), o.getString("action"), o.optString("arg")) } }
        } finally { c.disconnect() }
    }

    fun tvResult(s: Store, id: Long, text: String) {
        try {
            val c = open(s, "/v1/tv/result", 15000)
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("id", id).put("text", text).toString().toByteArray()) }
            c.responseCode; c.disconnect()
        } catch (_: Exception) {}
    }

    /** Sends the exact position to the hub. Returns true when the hub accepted it. */
    fun sendLocation(s: Store, lat: Double, lon: Double, acc: Double): Boolean {
        if (!configured(s)) return false
        return try {
            val c = open(s, "/v1/location", 15000)
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("lat", lat).put("lon", lon).put("acc", acc).toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (_: Exception) { false }
    }

    /** Runs one of the hub's shared tools (notes, to-dos, calculator, converter, news, reminders): the same ones Telegram uses. */
    fun runTool(s: Store, name: String, args: JSONObject): String {
        if (!configured(s)) return "That needs your hub. Add its address and token in Settings under AI provider."
        return try {
            val c = open(s, "/v1/tools/run", 30000)
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("name", name).put("args", args).toString().toByteArray()) }
            if (c.responseCode in 200..299) JSONObject(c.inputStream.bufferedReader().readText()).optString("result", "Done.")
            else "The hub refused (HTTP ${c.responseCode})."
        } catch (e: Exception) { "Could not reach the hub: ${e.message}" }
    }

    private fun p(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "string", d, req)
    private fun mirrored(name: String, desc: String, params: List<ToolDef.Param>, ro: Boolean) =
        ToolDef(name, desc, params, readOnly = ro) { _, st, a -> runTool(st, name, a) }

    val tools: List<ToolDef> = listOf(
        mirrored("note", "The person's notes (shared with Telegram). action: add, list, search or delete.",
            listOf(p("action", "add, list, search or delete"), p("text", "Note text, search words, or note number for delete", false)), false),
        mirrored("todo", "The person's to-do list (shared with Telegram). action: add, list, done or delete.",
            listOf(p("action", "add, list, done or delete"), p("text", "Item text, or its number for done/delete", false)), false),
        mirrored("calculator", "Exact arithmetic: + - * / ^ %, brackets, sqrt, sin, log, 20% of 450, etc.",
            listOf(p("expression", "The expression")), true),
        mirrored("convert", "Convert units (length, mass, volume, speed, area, data, time, temperature) and currencies (live daily rates).",
            listOf(p("value", "Number"), p("from", "From unit or currency, e.g. km, kg, C, USD"), p("to", "To unit or currency")), true),
        mirrored("news", "Latest news headlines with links. Empty topic gives top headlines.", listOf(p("topic", "Topic, or empty", false)), true),
        mirrored("remind_me", "Set a reminder after a delay (minutes from now); it is spoken once, on the phone if it is connected, otherwise on Telegram.",
            listOf(p("minutes", "Minutes from now, as a number"), p("text", "What to remind about")), false),
        mirrored("schedule_task", "Schedule a spoken reminder at a clock time, once or repeating.",
            listOf(p("when", "Time like 8pm or 20:30"), p("repeat", "once, daily, weekdays, or a weekday like mon", false), p("text", "What to remind about")), false),
        ToolDef("watch_topic", "Keep an eye on a news topic; Jarvis speaks an alert aloud when something notable appears (checked on the hub every few hours).",
            listOf(ToolDef.Param("topic", "string", "Topic to watch"))) { _, st, a -> watch(st, a.optString("topic").take(80), false) },
        ToolDef("unwatch_topic", "Stop watching a topic.", listOf(ToolDef.Param("topic", "string", "Topic text to stop"))) { _, st, a -> watch(st, a.optString("topic").take(80), true) },
        ToolDef("background_task", "Run a long job (research, comparison, monitoring) on the hub and speak the result aloud on this phone when done, even if locked. " +
            "Use when the person says things like 'research X and tell me when done'. Give the full job description.",
            listOf(ToolDef.Param("task", "string", "Complete description of the job"))) { _, st, a ->
            val ctx = "User: ${st.userName}. City: ${st.city}. Facts: ${st.memories.joinToString("; ")}"
            startJob(st, a.optString("task").take(1500), ctx)
        }
    )
}

/** Speaks text aloud from anywhere (alarm, job, service), screen on or off, one item at a time. */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private val q = java.util.ArrayDeque<String>()
    private var busy = false
    private var voice: Voice? = null

    private var lastText = ""
    private var lastAt = 0L

    fun say(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val app = ctx.applicationContext
        main.post {
            // Once only: the same line arriving again within two minutes (two paths, a retry) is dropped, also if it is already queued.
            val now = android.os.SystemClock.elapsedRealtime()
            if ((t == lastText && now - lastAt < 120_000L) || q.contains(t)) return@post
            lastText = t; lastAt = now
            q.add(t); next(app)
        }
    }

    private fun next(app: Context) {
        if (busy) return
        val t = q.poll() ?: return
        busy = true
        val wl = (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:speak").apply { acquire(180_000L) }
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val focus = if (Build.VERSION.SDK_INT >= 26) AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).build() else null
        if (focus != null) runCatching { am.requestAudioFocus(focus) }
        WakeService.hold(true)   // the wake-word listener must not hear Jarvis talking
        Store.get(app).addMessage(false, t)
        Overlay.note(t)
        val v = voice ?: Voice(app).also { voice = it }
        v.speak(t) {
            if (focus != null) runCatching { am.abandonAudioFocusRequest(focus) }
            WakeService.hold(false)
            runCatching { if (wl.isHeld) wl.release() }
            busy = false
            main.postDelayed({ next(app) }, 400)
        }
    }
}

/**
 * Always-on foreground service: long-polls the hub and speaks what it sends (briefings, finished jobs, alerts),
 * and speaks low-battery warnings. Works with the screen locked.
 */
class AlertService : Service() {
    @Volatile private var alive = false
    private var lastWarn = 100
    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val st = Store.get(c)
            if (!st.battWarn) return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val s = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL
            if (charging || lvl > 25) { lastWarn = 100; return }
            val step = if (lvl <= 5) 5 else if (lvl <= 10) 10 else if (lvl <= 20) 20 else 100
            if (step < lastWarn) {
                lastWarn = step
                Speaker.say(c, if (step <= 10) "Sir, battery is critically low at $lvl percent. Please plug in the charger." else "Sir, battery is at $lvl percent. You may want to charge soon.")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis_alerts", "Spoken alerts", NotificationManager.IMPORTANCE_MIN).apply { setShowBadge(false) })
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "jarvis_alerts").setSmallIcon(R.drawable.ic_stat_jarvis).setContentTitle("Jarvis is on standby")
            .setContentText("Ready to speak alerts").setOngoing(true).setContentIntent(open).build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or (if (Locator.fineGranted(this)) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
                try { startForeground(7300, n, type) }
                catch (_: Throwable) { startForeground(7300, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }   // location type refused: stay alive without it
            } else startForeground(7300, n)
        } catch (_: Throwable) { stopSelf(); return START_NOT_STICKY }
        Locator.start(this)
        if (!alive) {
            alive = true
            registerReceiver(battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            Thread { loop() }.also { it.name = "hub-events"; it.isDaemon = true; it.start() }
            Thread { tvLoop() }.also { it.name = "hub-tv"; it.isDaemon = true; it.start() }
        }
        return START_STICKY
    }

    private fun loop() {
        val store = Store.get(applicationContext)
        val sp = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        var after = sp.getLong("hubSeq", -1L)
        var wait = 5000L
        while (alive) {
            try {
                if (!store.alertsOn || !Hub.configured(store)) { Thread.sleep(30_000); continue }
                val b = Hub.events(store, after)
                wait = 5000L
                if (after < 0) { after = b.seq }   // first run: skip old events, only speak new ones
                else b.events.forEach { if (it.id > after) { after = it.id; sp.edit().putLong("hubSeq", after).commit(); Speaker.say(applicationContext, it.text) } }
                sp.edit().putLong("hubSeq", after).apply()
            } catch (_: InterruptedException) { return } catch (_: Throwable) {
                try { Thread.sleep(wait) } catch (_: InterruptedException) { return }
                wait = (wait * 2).coerceAtMost(60_000L)
            }
        }
    }

    /** Runs TV commands that arrive from the hub (Telegram "/tv home"). Idle unless a TV is paired. */
    private fun tvLoop() {
        val store = Store.get(applicationContext)
        var after = 0L
        var wait = 5000L
        while (alive) {
            try {
                if (!Hub.configured(store) || !Tv.configured(applicationContext)) { Thread.sleep(30_000); continue }
                val cmds = Hub.tvNext(store, after)
                wait = 5000L
                for (c in cmds) {
                    after = maxOf(after, c.id)
                    Hub.tvResult(store, c.id, Tv.run(applicationContext, c.action, c.arg))
                }
            } catch (_: InterruptedException) { return } catch (_: Throwable) {
                try { Thread.sleep(wait) } catch (_: InterruptedException) { return }
                wait = (wait * 2).coerceAtMost(60_000L)
            }
        }
    }

    override fun onDestroy() { alive = false; Locator.stop(this); runCatching { unregisterReceiver(battery) }; super.onDestroy() }

    companion object {
        fun wanted(s: Store) = s.battWarn || (s.alertsOn && Hub.configured(s))
        /** Starts the service if any spoken alert is switched on. Safe to call often. */
        fun sync(ctx: Context) {
            val app = ctx.applicationContext
            val s = Store.get(app)
            try {
                if (wanted(s)) app.startForegroundService(Intent(app, AlertService::class.java))
                else app.stopService(Intent(app, AlertService::class.java))
            } catch (_: Throwable) {}
        }
    }
}
