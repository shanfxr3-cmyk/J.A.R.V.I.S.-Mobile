// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** ElevenLabs text-to-speech. Blocking: call off the main thread. Writes an mp3 file. */
object ElevenTts {
    const val DEFAULT_MODEL = "eleven_flash_v2_5"
    val MODELS = listOf(
        Triple("eleven_flash_v2_5", "Flash v2.5", "Default. Fastest and cheapest, best for spoken replies."),
        Triple("eleven_turbo_v2_5", "Turbo v2.5", "Balanced speed and quality."),
        Triple("eleven_multilingual_v2", "Multilingual v2", "Higher quality, slower, uses more credits.")
    )

    fun migrate(m: String?): String = if (m.isNullOrBlank()) DEFAULT_MODEL else m.trim()

    fun synth(key: String, voiceId: String, model: String, text: String, out: File) {
        val body = JSONObject().put("text", text).put("model_id", migrate(model))
        val vid = URLEncoder.encode(voiceId.trim(), "UTF-8")
        val c = URL("https://api.elevenlabs.io/v1/text-to-speech/$vid?output_format=mp3_44100_128").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("xi-api-key", key.trim())
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "audio/mpeg")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Throwable) { null }
                throw RuntimeException(
                    when (code) {
                        401 -> "ElevenLabs rejected the API key or its permissions. ${err ?: ""}".trim()
                        402 -> "ElevenLabs: this voice or model needs a paid plan."
                        404 -> "ElevenLabs: voice ID not found."
                        422 -> "ElevenLabs: voice ID or model ID not valid. ${err ?: ""}".trim()
                        429 -> "ElevenLabs: too many requests or out of credits."
                        else -> "ElevenLabs error $code ${err ?: ""}".trim()
                    }
                )
            }
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (out.length() < 100) throw RuntimeException("ElevenLabs returned no audio.")
        } finally { c.disconnect() }
    }
}
