package com.jarvis.aiassistant.holo

import kotlin.math.PI
import kotlin.math.sin

internal const val TAU = (2.0 * PI).toFloat()
private const val LUT_N = 2048
private const val LUT_MASK = LUT_N - 1
private const val LUT_SCALE = LUT_N / TAU

/** Shared sine table; every per-frame trig call is a masked array read. */
internal object Lut {
    private val s = FloatArray(LUT_N) { kotlin.math.sin(it * TAU / LUT_N) }
    fun sin(a: Float): Float = s[(a * LUT_SCALE).toInt() and LUT_MASK]
    fun cos(a: Float): Float = s[((a * LUT_SCALE).toInt() + LUT_N / 4) and LUT_MASK]
}

/** Zero-padded decimal into a CharArray. Returns the next offset. */
internal fun putInt(buf: CharArray, off: Int, value: Int, digits: Int): Int {
    var v = if (value < 0) 0 else value
    var i = off + digits - 1
    while (i >= off) { buf[i] = '0' + (v % 10); v /= 10; i-- }
    return off + digits
}

internal fun putStr(buf: CharArray, off: Int, s: CharArray): Int {
    System.arraycopy(s, 0, buf, off, s.size)
    return off + s.size
}
