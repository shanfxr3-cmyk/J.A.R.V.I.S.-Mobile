// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Jarvis' eyes and fingers. Reads the screen, taps, types, swipes, pinches, presses system buttons,
 * takes screenshots and magnifies. Only acts when a tool asks it to; it never acts on its own.
 */
class ScreenService : AccessibilityService() {
    class Item(val node: AccessibilityNodeInfo, val label: String, val kind: String, val r: Rect) {
        fun line(i: Int) = "[$i] $kind ${label.take(70)} @${r.centerX()},${r.centerY()}"
    }

    companion object {
        @Volatile var inst: ScreenService? = null
        @Volatile var pkg: String = ""
        @Volatile var cls: String = ""
        val running get() = inst != null
    }

    @Volatile var last: List<Item> = emptyList()

    override fun onServiceConnected() {
        inst = this
        if (Build.VERSION.SDK_INT >= 26) runCatching {
            accessibilityButtonController.registerAccessibilityButtonCallback(object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) {
                    startActivity(Intent(this@ScreenService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("voice", true))
                }
            })
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString().orEmpty()
            if (p.isNotEmpty() && p != "com.android.systemui") { pkg = p; cls = e.className?.toString().orEmpty() }
        }
    }

    override fun onInterrupt() {}
    override fun onKeyEvent(event: KeyEvent): Boolean = try { Control.keyHook?.invoke(event) ?: false } catch (_: Throwable) { false }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }

    // ---------- reading ----------

    fun root(): AccessibilityNodeInfo? = rootInActiveWindow ?: windows.firstNotNullOfOrNull { it.root }

    /** Visible, meaningful elements of the current screen. The list index is what tap refers to. */
    fun snapshot(): List<Item> {
        val rt = root()
        val out = ArrayList<Item>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || out.size >= 300 || depth > 40) return
            if (n.isVisibleToUser) {
                val text = (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.replace('\n', ' ')?.trim().orEmpty()
                val kind = when {
                    n.isEditable -> "input"
                    n.isCheckable -> if (n.isChecked) "check(on)" else "check(off)"
                    n.isClickable -> "btn"
                    n.isScrollable -> "scroll"
                    else -> "text"
                }
                val label = text.ifEmpty { if (kind == "text") "" else n.viewIdResourceName?.substringAfter(":id/").orEmpty() }
                if (label.isNotEmpty() || kind == "input" || kind == "scroll") {
                    val r = Rect(); n.getBoundsInScreen(r)
                    out += Item(n, label, if (n.isEnabled) kind else "$kind(disabled)", r)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(rt, 0)
        last = out
        return out
    }

    fun find(text: String): Item? {
        val t = text.trim().lowercase()
        if (t.isEmpty()) return null
        val items = last
        return items.firstOrNull { it.label.lowercase() == t && it.kind.startsWith("btn") }
            ?: items.firstOrNull { it.label.lowercase() == t }
            ?: items.firstOrNull { it.label.lowercase().contains(t) && (it.kind.startsWith("btn") || it.kind.startsWith("check") || it.kind == "input") }
            ?: items.firstOrNull { it.label.lowercase().contains(t) }
    }

    // ---------- acting ----------

    fun click(item: Item): Boolean {
        val n = item.node
        if (!n.refresh()) return false
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent; d++
        }
        return tapAt(item.r.centerX().toFloat(), item.r.centerY().toFloat(), 50)
    }

    private fun dispatch(strokes: List<GestureDescription.StrokeDescription>): Boolean {
        val b = GestureDescription.Builder()
        strokes.forEach { b.addStroke(it) }
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ok.set(true); latch.countDown() }
            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
        }
        if (!dispatchGesture(b.build(), cb, null)) return false
        latch.await(8, TimeUnit.SECONDS)
        return ok.get()
    }

    private fun stroke(x1: Float, y1: Float, x2: Float, y2: Float, start: Long, dur: Long): GestureDescription.StrokeDescription {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        return GestureDescription.StrokeDescription(p, start, dur.coerceAtLeast(1))
    }

    fun tapAt(x: Float, y: Float, dur: Long) = dispatch(listOf(stroke(x, y, x, y, 0, dur)))
    fun doubleTap(x: Float, y: Float) = dispatch(listOf(stroke(x, y, x, y, 0, 40), stroke(x, y, x, y, 140, 40)))
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) = dispatch(listOf(stroke(x1, y1, x2, y2, 0, dur)))

    /** Two fingers moving apart (out) or together (in) around the point. */
    fun pinch(cx: Float, cy: Float, out: Boolean): Boolean {
        val near = 60f; val far = 320f
        val a = if (out) near else far; val z = if (out) far else near
        return dispatch(listOf(stroke(cx - a, cy, cx - z, cy, 0, 450), stroke(cx + a, cy, cx + z, cy, 0, 450)))
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    /** Types into the focused field (or the first field on screen). */
    fun type(text: String, replace: Boolean, submit: Boolean): String? {
        val rt = root() ?: return "There is no screen to type into."
        var target = rt.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null) {
            fun first(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (n == null) return null
                if (n.isEditable && n.isVisibleToUser) return n
                for (i in 0 until n.childCount) first(n.getChild(i))?.let { return it }
                return null
            }
            target = first(rt)
        }
        if (target == null) return null
        val base = if (replace || target.isShowingHintText) "" else target.text?.toString().orEmpty()
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text) }
        if (!target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return null
        if (submit) {
            val done = Build.VERSION.SDK_INT >= 30 && target.performAction(android.R.id.accessibilityActionImeEnter)
            if (!done && Shell.granted()) Shell.exec("input keyevent 66")
        }
        return "Typed."
    }

    /** Takes a screenshot with the accessibility API (Android 11+). Returns the saved file or null. */
    fun screenshot(): File? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        val bmp = AtomicReference<Bitmap?>(null)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                runCatching {
                    val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                    bmp.set(hw?.copy(Bitmap.Config.ARGB_8888, false))
                    r.hardwareBuffer.close()
                }
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(8, TimeUnit.SECONDS)
        val b = bmp.get() ?: return null
        val dir = getExternalFilesDir("Pictures") ?: filesDir
        val f = File(dir, "jarvis_${System.currentTimeMillis()}.png")
        return runCatching { f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; f }.getOrNull()
    }

    /** Screen magnification. scale 1 resets. */
    fun magnify(scale: Float, x: Float?, y: Float?): Boolean {
        val m = magnificationController
        if (scale <= 1f) return m.reset(true)
        val ok = m.setScale(scale.coerceIn(1.1f, 8f), true)
        if (x != null && y != null) m.setCenter(x, y, true)
        return ok
    }
}
