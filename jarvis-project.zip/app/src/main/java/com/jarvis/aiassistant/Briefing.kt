// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Morning briefing and topic watching. Everything here is READ-ONLY: the AI may look things up (weather, web)
 * but is never given a tool that acts on the phone. A clock alarm wakes the app, which hands the work to a
 * network job so a slow web search is not cut off.
 */
object Briefing {
    private const val ACT_BRIEF = "com.jarvis.aiassistant.BRIEF"
    private const val ACT_WATCH = "com.jarvis.aiassistant.WATCH"
    private const val CHANNEL = "jarvis_brief"
    const val WATCH_EVERY_MS = 6L * 3_600_000
    const val NOTHING_NEW = "NOTHING_NEW"

    /** Next time the clock shows hour:min after [from]. */
    fun nextOccurrence(from: Long, hour: Int, min: Int): Long {
        val c = Calendar.getInstance().apply { timeInMillis = from; set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun pi(ctx: Context, act: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, BriefingReceiver::class.java).setAction(act), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** Sets or clears both alarms to match the settings. Safe to call often. */
    fun reschedule(ctx: Context, store: Store) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = ctx.applicationContext
        try {
            if (store.briefOn && store.apiKey.isNotBlank()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextOccurrence(System.currentTimeMillis(), store.briefHour, store.briefMin), pi(c, ACT_BRIEF, 71))
            else am.cancel(pi(c, ACT_BRIEF, 71))
            if (store.watches.isNotEmpty() && store.apiKey.isNotBlank()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + WATCH_EVERY_MS, pi(c, ACT_WATCH, 72))
            else am.cancel(pi(c, ACT_WATCH, 72))
        } catch (_: Throwable) {}
    }

    internal fun startJob(ctx: Context, kind: String) {
        val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val extras = android.os.PersistableBundle().apply { putString("kind", kind) }
        js.schedule(JobInfo.Builder(if (kind == "brief") 81 else 82, ComponentName(ctx, BriefingJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setExtras(extras).setOverrideDeadline(60_000).build())
    }

    fun onAlarm(ctx: Context, action: String?) {
        val store = Store.get(ctx)
        when (action) {
            ACT_BRIEF -> startJob(ctx, "brief")
            ACT_WATCH -> startJob(ctx, "watch")
        }
        reschedule(ctx, store)   // the next alarm is always set from here, so a missed one never ends the chain
    }

    private fun run(ctx: Context, store: Store, prompt: String): String? {
        val sys = Assistant.systemPrompt(store) + " This is an unattended run: you may only look things up. Reply in plain spoken sentences."
        return try {
            Agent.run(ctx, store, sys, listOf("user" to prompt), ToolMode.READ_ONLY, null, null) {}
        } catch (_: Exception) { null }
    }

    /** Runs a briefing or the watch check, posts notifications, and returns when done. Blocking. */
    fun work(ctx: Context, kind: String) {
        val store = Store.get(ctx)
        if (store.apiKey.isBlank() || !Legal.isAccepted(store)) return
        if (kind == "brief") {
            val text = run(ctx, store, "Give me my morning briefing now: a greeting, today's date, the weather" +
                (if (store.city.isNotBlank()) " in " + store.city else "") + ", my open tasks, and one short headline for each topic I watch. Keep it to about six sentences.") ?: return
            store.addMessage(false, text)
            notify(ctx, 7101, "Good morning", text)
        } else {
            val sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
            store.watches.toList().forEachIndexed { i, topic ->
                val t = run(ctx, store, "Use search_web to look for news from the last 24 hours about: $topic. " +
                    "If there is something genuinely new and notable, report it in one to three short sentences. " +
                    "If not, reply with exactly $NOTHING_NEW and nothing else.")?.trim() ?: return@forEachIndexed
                if (t.isBlank() || t.contains(NOTHING_NEW)) return@forEachIndexed
                val sig = t.hashCode().toString()
                if (sp.getString("watchSig$i", "") == sig) return@forEachIndexed   // already told them this
                sp.edit().putString("watchSig$i", sig).apply()
                store.addMessage(false, "Watching $topic: $t")
                notify(ctx, 7200 + i, "Watching: $topic", t)
            }
        }
    }

    private fun notify(ctx: Context, id: Int, title: String, text: String) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Briefings and watched topics", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(id, android.app.Notification.Builder(ctx, CHANNEL).setSmallIcon(R.drawable.ic_stat_jarvis).setContentTitle(title)
                .setContentText(text.take(100)).setStyle(android.app.Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true).build())
        } catch (_: Throwable) {}
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try { Briefing.onAlarm(context.applicationContext, intent?.action) } catch (_: Throwable) {}
    }
}

class BriefingJob : JobService() {
    @Volatile private var worker: Thread? = null
    override fun onStartJob(params: JobParameters): Boolean {
        val kind = params.extras.getString("kind") ?: "brief"
        worker = Thread {
            try { Briefing.work(applicationContext, kind) } catch (_: Throwable) {}
            jobFinished(params, false)
        }.also { it.name = "briefing"; it.start() }
        return true
    }
    override fun onStopJob(params: JobParameters): Boolean { worker?.interrupt(); return false }
}
