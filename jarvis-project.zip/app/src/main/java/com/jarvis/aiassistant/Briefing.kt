// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Morning briefing and topic watching. Everything here is READ-ONLY: the AI may look things up (weather, web)
 * but is never given a tool that acts on the phone. A clock alarm wakes the app, which hands the work to a
 * network job so a slow web search is not cut off.
 */
object Briefing {
    private const val ACT_BRIEF = "com.jarvis.aiassistant.BRIEF"
    private const val ACT_WATCH = "com.jarvis.aiassistant.WATCH"
    private const val CHANNEL = "jarvis_brief"
    const val WATCH_EVERY_MS = 6L * 3_600_000
    const val NOTHING_NEW = "NOTHING_NEW"

    /** Next time the clock shows hour:min after [from]. */
    fun nextOccurrence(from: Long, hour: Int, min: Int): Long {
        val c = Calendar.getInstance().apply { timeInMillis = from; set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun pi(ctx: Context, act: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, BriefingReceiver::class.java).setAction(act), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** Sets or clears the morning alarm to match the settings. Uses an alarm-clock alarm so it fires on time even in Doze. */
    fun reschedule(ctx: Context, store: Store) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = ctx.applicationContext
        try {
            am.cancel(pi(c, ACT_WATCH, 72))
            if (store.briefOn) {
                val at = nextOccurrence(System.currentTimeMillis(), store.briefHour, store.briefMin)
                val show = PendingIntent.getActivity(c, 73, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, ACT_BRIEF, 71))
            } else am.cancel(pi(c, ACT_BRIEF, 71))
        } catch (_: Throwable) {}
    }

    internal fun startJob(ctx: Context, kind: String) {
        val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val extras = android.os.PersistableBundle().apply { putString("kind", kind) }
        js.schedule(JobInfo.Builder(if (kind == "brief") 81 else 82, ComponentName(ctx, BriefingJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setExtras(extras).setOverrideDeadline(60_000).build())
    }

    fun onAlarm(ctx: Context, action: String?) {
        val st = Store.get(ctx)
        reschedule(ctx, st)   // line up tomorrow's briefing first
        if (action == ACT_BRIEF && st.briefOn) startJob(ctx, "brief")
    }

    private fun run(ctx: Context, store: Store, prompt: String): String? {
        val sys = Assistant.systemPrompt(store) + " This is an unattended run: you may only look things up. Reply in plain spoken sentences."
        return try {
            Agent.run(ctx, store, sys, listOf("user" to prompt), ToolMode.READ_ONLY, null, null) {}
        } catch (_: Exception) { null }
    }

    /** Builds the morning briefing and SPEAKS it (screen on or off). Blocking. */
    fun work(ctx: Context, kind: String) {
        val store = Store.get(ctx)
        if (kind != "brief" || store.apiKey.isBlank() || !Legal.isAccepted(store)) return
        val text = run(ctx, store, "Give me my morning briefing now: a greeting, today's date, the weather" +
            (if (store.city.isNotBlank()) " in " + store.city else "") + ", my calendar for today and my open tasks. About five short sentences.") ?: return
        Speaker.say(ctx, text)
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try { Briefing.onAlarm(context.applicationContext, intent?.action) } catch (_: Throwable) {}
    }
}

class BriefingJob : JobService() {
    @Volatile private var worker: Thread? = null
    override fun onStartJob(params: JobParameters): Boolean {
        val kind = params.extras.getString("kind") ?: "brief"
        worker = Thread {
            try { Briefing.work(applicationContext, kind) } catch (_: Throwable) {}
            jobFinished(params, false)
        }.also { it.name = "briefing"; it.start() }
        return true
    }
    override fun onStopJob(params: JobParameters): Boolean { worker?.interrupt(); return false }
}
