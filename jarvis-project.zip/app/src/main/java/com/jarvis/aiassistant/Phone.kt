// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.provider.CalendarContract
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps the last few notifications in memory only (never saved) so the person can ask "what did I miss?". */
class JarvisNotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString().orEmpty()
        val text = (e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text"))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { sbn.packageName }
        synchronized(recent) { recent.addFirst("$app: $title - ${text.take(160)}"); while (recent.size > 25) recent.removeLast() }
    }
    companion object { val recent = java.util.ArrayDeque<String>() }
}

object Phone {
    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    val RUNTIME = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.ACCESS_COARSE_LOCATION)

    val tools: List<ToolDef> = listOf(
        ToolDef("open_app", "Open an app installed on the phone by its name (for example YouTube, Maps, WhatsApp, Camera).",
            listOf(ToolDef.Param("name", "string", "App name"))) { c, _, a ->
            val want = a.optString("name").trim().lowercase()
            if (want.length < 2) "Which app?" else {
                val pm = c.packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                val hit = apps.firstOrNull { it.first.lowercase() == want } ?: apps.firstOrNull { it.first.lowercase().startsWith(want) }
                    ?: apps.firstOrNull { it.first.lowercase().contains(want) }
                val li = hit?.let { pm.getLaunchIntentForPackage(it.second) }
                if (hit == null || li == null) "I could not find an app called ${a.optString("name")}."
                else try { c.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Opened ${hit.first}." } catch (e: Throwable) { "Could not open it: ${e.message}" }
            }
        },
        ToolDef("read_calendar", "Read the person's calendar events for today and the next few days.",
            listOf(ToolDef.Param("days", "integer", "How many days ahead, 1 to 14", false)), readOnly = true) { c, _, a ->
            if (!granted(c, Manifest.permission.READ_CALENDAR)) "Calendar permission is not granted. Ask the person to open the Jarvis app and allow it."
            else {
                val days = a.optInt("days", 1).coerceIn(1, 14)
                val now = System.currentTimeMillis()
                val end = now + days * 86_400_000L
                val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { android.content.ContentUris.appendId(it, now); android.content.ContentUris.appendId(it, end) }.build()
                val fmt = SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault())
                val out = ArrayList<String>()
                c.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY),
                    null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
                    while (cur.moveToNext() && out.size < 15) {
                        val loc = cur.getString(2).orEmpty()
                        out += (if (cur.getInt(3) == 1) "All day" else fmt.format(Date(cur.getLong(1)))) + ": " + cur.getString(0).orEmpty() + if (loc.isNotBlank()) " at $loc" else ""
                    }
                }
                if (out.isEmpty()) "No events in the next $days day(s)." else out.joinToString("\n")
            }
        },
        ToolDef("read_notifications", "Read the most recent notifications the phone received (apps, titles, short text).", readOnly = false) { c, _, _ ->
            val on = android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners").orEmpty().contains(c.packageName)
            if (!on) "Notification access is off. Use open_settings with page notification_access so the person can enable Jarvis."
            else synchronized(JarvisNotifListener.recent) { if (JarvisNotifListener.recent.isEmpty()) "No new notifications since Jarvis started listening." else JarvisNotifListener.recent.take(12).joinToString("\n") }
        },
        ToolDef("get_location", "Where the person is right now (approximate place name).", readOnly = true) { c, _, _ ->
            if (!granted(c, Manifest.permission.ACCESS_COARSE_LOCATION)) "Location permission is not granted. Ask the person to open the Jarvis app and allow it."
            else try {
                val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
                if (loc == null) "No location fix yet. Try again in a moment."
                else {
                    val place = runCatching { Geocoder(c, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull() }.getOrNull()
                    val name = listOfNotNull(place?.subLocality, place?.locality, place?.countryName).joinToString(", ")
                    (if (name.isNotBlank()) "Near $name. " else "") + "Coordinates %.3f, %.3f.".format(loc.latitude, loc.longitude)
                }
            } catch (e: Throwable) { "Could not get the location: ${e.message}" }
        }
    )
}
