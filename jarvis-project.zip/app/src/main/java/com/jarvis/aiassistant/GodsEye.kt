// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Runs the real God's Eye View server on the phone with the bundled Node.
 * The app files come from assets/gev/gev-bundle.zip (built by the "Get God's Eye View" workflow) and are
 * unpacked into the app's private folder. assets/gev/gev-launcher.mjs starts the unchanged server code without Vite.
 */
object GodsEye {
    const val PORT = 4173
    const val URL_BASE = "http://127.0.0.1:4173"
    private const val ASSET_ZIP = "gev/gev-bundle.zip"
    private const val ASSET_LAUNCHER = "gev/gev-launcher.mjs"
    // Files the user or the server wrote that must survive an update of the bundle.
    private val KEEP = listOf(".env", ".gev-cache", ".gev-logs")

    private val lock = Any()
    private val startLock = Any()
    @Volatile private var process: Process? = null

    /** OFF, STARTING, RUNNING, ERROR. Read by the globe screen and the service. */
    var status by mutableStateOf("OFF")
    /** One short line for the person: what is happening or what went wrong. */
    var statusMsg by mutableStateOf("")
    private val logLines = ArrayDeque<String>()

    fun appDir(ctx: Context) = File(ctx.filesDir, "gev/app")

    fun hasBundle(ctx: Context): Boolean = try { ctx.assets.open(ASSET_ZIP).use { true } } catch (_: Throwable) { false }

    fun isRunning(): Boolean = process?.isAlive == true

    fun log(): String = synchronized(logLines) { logLines.joinToString("\n") }

    fun addLog(line: String) = synchronized(logLines) {
        logLines.addLast(line)
        while (logLines.size > 300) logLines.removeFirst()
    }

    private fun stamp(ctx: Context): String = try {
        ctx.assets.openFd(ASSET_ZIP).use { "zip-${it.length}" }
    } catch (_: Throwable) {
        // The asset is stored compressed on this build, so its size is not known cheaply: use the app version.
        "ver-" + (try { @Suppress("DEPRECATION") ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode } catch (_: Throwable) { 0 })
    }

    private fun copyLauncher(ctx: Context, dir: File) {
        dir.mkdirs()
        ctx.assets.open(ASSET_LAUNCHER).use { i -> File(dir, "gev-launcher.mjs").outputStream().use { o -> i.copyTo(o) } }
    }

    /** Unpacks the bundle when it is new or changed. Returns a short report. */
    fun install(ctx: Context): String {
        if (!hasBundle(ctx)) return "No God's Eye View bundle in this build.\nRun the \"Get God's Eye View\" workflow once, then run \"Android build\" again."
        synchronized(lock) {
            val dir = appDir(ctx)
            val marker = File(dir, ".bundle-stamp")
            val want = stamp(ctx)
            if (marker.isFile && marker.readText() == want && File(dir, "dist/index.html").isFile) {
                copyLauncher(ctx, dir)
                return "Already unpacked ($want)."
            }
            stop()
            val t0 = System.currentTimeMillis()
            val fresh = File(dir.parentFile, "app.new")
            fresh.deleteRecursively(); fresh.mkdirs()
            val root = fresh.canonicalPath + File.separator
            var files = 0; var bytes = 0L
            ctx.assets.open(ASSET_ZIP).buffered().use { raw ->
                ZipInputStream(raw).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val out = File(fresh, e.name)
                        if (!out.canonicalPath.startsWith(root)) continue // never write outside the target folder
                        if (e.isDirectory) { out.mkdirs(); continue }
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> bytes += zin.copyTo(o) }
                        files++
                    }
                }
            }
            if (!File(fresh, "dist/index.html").isFile) { fresh.deleteRecursively(); return "Unpack failed: dist/index.html is missing in the bundle." }
            for (k in KEEP) { val old = File(dir, k); if (old.exists()) old.renameTo(File(fresh, k)) }
            copyLauncher(ctx, fresh)
            File(fresh, ".bundle-stamp").writeText(want)
            dir.deleteRecursively()
            if (!fresh.renameTo(dir)) return "Unpack failed: could not move the new files into place."
            return "Unpacked $files files, ${bytes / 1_000_000} MB in ${(System.currentTimeMillis() - t0) / 1000} s ($want)."
        }
    }

    /** Starts the server (unpacking first when needed). Returns a short report. */
    fun start(ctx: Context): String = synchronized(startLock) { startLocked(ctx) }

    private fun startLocked(ctx: Context): String {
        if (!NodeRuntime.isBundled(ctx)) { fail("Node is not bundled in this build."); return "Node is not bundled in this build." }
        if (isRunning()) { status = "RUNNING"; statusMsg = ""; return "Already running on $URL_BASE." }
        status = "STARTING"; statusMsg = if (File(appDir(ctx), ".bundle-stamp").isFile) "Starting the server..." else "Unpacking the first time (about 125 MB)..."
        val report = install(ctx)
        status = "STARTING"
        val dir = appDir(ctx)
        if (!File(dir, "gev-launcher.mjs").isFile || !File(dir, "dist/index.html").isFile) { fail(report); return report }
        copyLauncher(ctx, dir)
        statusMsg = "Starting the server..."
        return try {
            val pb = ProcessBuilder(listOf(NodeRuntime.binary(ctx).absolutePath, "gev-launcher.mjs"))
            pb.directory(dir)
            pb.environment().putAll(NodeRuntime.env(ctx))
            pb.environment()["PORT"] = PORT.toString()
            pb.environment()["HOST"] = "127.0.0.1"
            pb.redirectErrorStream(true)
            synchronized(logLines) { logLines.clear() }
            val p = pb.start()
            process = p
            Thread {
                try { p.inputStream.bufferedReader().forEachLine { addLog(it) } } catch (_: Throwable) {}
                val code = try { p.waitFor() } catch (_: Throwable) { -1 }
                addLog("[jarvis] server process ended, exit code $code")
                // Only a process that is still the current one ended by itself; stop() clears it first.
                if (process === p) { process = null; fail("The server stopped (exit code $code).") }
            }.also { it.name = "gev-log"; it.start() }
            // Wait for the launcher's own health route instead of guessing.
            val deadline = System.currentTimeMillis() + 40_000
            while (System.currentTimeMillis() < deadline) {
                if (!p.isAlive) { val m = "Server exited right away. See Log."; fail(m); return "$report\n$m" }
                if (get("/gev-health", 1500).first == 200) { status = "RUNNING"; statusMsg = ""; return "$report\nServer is up on $URL_BASE." }
                Thread.sleep(500)
            }
            val m = "Server started but did not answer within 40 s. See Log."
            fail(m)
            "$report\n$m"
        } catch (e: Throwable) {
            val m = "Could not start the server: ${e.javaClass.simpleName}: ${e.message}"
            fail(m)
            m
        }
    }

    private fun fail(msg: String) { status = "ERROR"; statusMsg = msg }

    fun stop() {
        val p = process
        process = null // cleared first, so the log thread knows this stop was on purpose
        p?.let { try { it.destroy(); if (!it.waitFor(3, TimeUnit.SECONDS)) it.destroyForcibly() } catch (_: Throwable) {} }
        status = "OFF"; statusMsg = ""
    }

    /** Returns (HTTP status or -1, first part of the body or the error). */
    fun get(path: String, timeoutMs: Int = 8000, maxBody: Int = 4000): Pair<Int, String> = try {
        val c = URL(URL_BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs; c.readTimeout = timeoutMs; c.instanceFollowRedirects = false
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val body = stream?.use { val b = it.readBytes(); String(b, 0, minOf(b.size, maxBody), Charsets.UTF_8) } ?: ""
        c.disconnect()
        code to body
    } catch (e: Throwable) { -1 to "${e.javaClass.simpleName}: ${e.message}" }

    /** Basic checks: health, the page, the API rules. */
    fun check(): String {
        if (!isRunning()) return "Server is not running."
        val sb = StringBuilder()
        val h = get("/gev-health")
        sb.appendLine("health: HTTP ${h.first}")
        try {
            val j = JSONObject(h.second)
            sb.appendLine("  ok=${j.optBoolean("ok")} node=${j.optString("node")} up=${j.optInt("uptime")}s dist=${j.optBoolean("distPresent")}")
            sb.appendLine("  routes mounted: ${j.optJSONArray("mounts")?.length() ?: 0}")
            val f = j.optJSONArray("failures")
            if (f != null && f.length() > 0) for (i in 0 until f.length()) sb.appendLine("  FAILED: ${f.getString(i)}")
        } catch (_: Throwable) { sb.appendLine("  (not JSON) ${h.second.take(200)}") }
        val page = get("/", 8000, 400000)
        sb.appendLine("page /: HTTP ${page.first}, ${page.second.length} chars${if (page.second.contains("<html", true)) ", looks like HTML" else ""}")
        sb.appendLine("unknown api: HTTP ${get("/api/nothing").first} (expect 404)")
        sb.appendLine("google token: HTTP ${get("/api/google/tiles-token").first} (expect 204)")
        sb.appendLine("provider settings: HTTP ${get("/api/setup/status").first} (expect 200)")
        sb.appendLine("wrong host: " + try {
            val c = URL(URL_BASE + "/").openConnection() as HttpURLConnection
            c.setRequestProperty("Host", "evil.example"); c.connectTimeout = 3000; c.readTimeout = 3000
            "HTTP ${c.responseCode} (expect 403)"
        } catch (e: Throwable) { "refused (${e.javaClass.simpleName})" })
        return sb.toString()
    }

    /** Calls every mounted route once with GET and counts the answers. It shows the routes answer, not that data is right. */
    fun routeCheck(): String {
        if (!isRunning()) return "Server is not running."
        val h = get("/gev-health", 5000, 200000)
        val mounts = try { JSONObject(h.second).getJSONArray("mounts").let { a -> (0 until a.length()).map { a.getString(it) } } } catch (_: Throwable) { return "Could not read the route list: ${h.second.take(200)}" }
        val paths = mounts.filter { it != "/api" && it != "/mcp" && !it.endsWith("/keys") }
        val pool = Executors.newFixedThreadPool(4)
        val results = java.util.Collections.synchronizedList(mutableListOf<Pair<String, Int>>())
        paths.forEach { p -> pool.execute { results.add(p to get(p, 12000, 300).first) } }
        pool.shutdown()
        pool.awaitTermination(120, TimeUnit.SECONDS)
        val byClass = results.groupBy { when { it.second in 200..299 -> "2xx answered"; it.second in 400..499 -> "4xx needs input or a key"; it.second in 500..599 -> "5xx upstream or server error"; else -> "no answer" } }
        val sb = StringBuilder("${paths.size} routes called once (GET, no parameters).\n")
        for ((k, v) in byClass.toSortedMap()) sb.appendLine("$k: ${v.size}")
        sb.appendLine()
        results.sortedBy { it.first }.forEach { sb.appendLine("${it.second}  ${it.first}") }
        return sb.toString()
    }
}

/** Developer section under the Node test: install, start, check and stop the God's Eye View server. */
@Composable
fun GodsEyeTestSection() {
    val ctx = LocalContext.current.applicationContext
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun run(label: String, work: () -> String) {
        busy = true; text = "$label..."
        Thread {
            val r = try { work() } catch (e: Throwable) { "${e.javaClass.simpleName}: ${e.message}" }
            android.os.Handler(android.os.Looper.getMainLooper()).post { text = r; busy = false }
        }.start()
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("GOD'S EYE VIEW SERVER", color = Green, fontSize = 13.sp)
        Text(
            if (GodsEye.hasBundle(ctx)) "Bundle found in the app. Server ${if (GodsEye.isRunning()) "running" else "stopped"}."
            else "No bundle in this build. Run \"Get God's Eye View\", then \"Android build\".",
            color = if (GodsEye.hasBundle(ctx)) Dim else Amber, fontSize = 12.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { run("Unpacking") { GodsEye.install(ctx) } }) { Text("Unpack") }
            Button(enabled = !busy, onClick = { run("Starting (up to 40 s)") { GodsEye.start(ctx) } }) { Text("Start") }
            Button(enabled = !busy, onClick = { run("Stopping") { GodsEyeService.stop(ctx); GodsEye.stop(); "Stopped." } }) { Text("Stop") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { run("Checking") { GodsEye.check() } }) { Text("Check") }
            Button(enabled = !busy, onClick = { run("Calling every route (up to 2 min)") { GodsEye.routeCheck() } }) { Text("Routes") }
            Button(enabled = !busy, onClick = { text = GodsEye.log().ifEmpty { "(log is empty)" } }) { Text("Log") }
        }
        if (text.isNotEmpty()) Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
    }
}
