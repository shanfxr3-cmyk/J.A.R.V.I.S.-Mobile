// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.io.File
import java.security.MessageDigest

/** Signature checks: is a downloaded update signed by the same key as the installed app. */
object Integrity {
    private fun sha(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    @Suppress("DEPRECATION")
    private fun hashes(info: android.content.pm.PackageInfo?): List<String> {
        if (info == null) return emptyList()
        val sigs: Array<Signature>? = if (Build.VERSION.SDK_INT >= 28) {
            val si = info.signingInfo
            if (si == null) null else if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
        } else {
            info.signatures
        }
        return sigs?.map { sha(it.toByteArray()) } ?: emptyList()
    }

    @Suppress("DEPRECATION")
    fun own(ctx: Context): List<String> = try {
        val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        hashes(ctx.packageManager.getPackageInfo(ctx.packageName, flag))
    } catch (_: Throwable) {
        emptyList()
    }

    @Suppress("DEPRECATION")
    fun apk(ctx: Context, f: File): List<String> = try {
        val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        hashes(ctx.packageManager.getPackageArchiveInfo(f.absolutePath, flag))
    } catch (_: Throwable) {
        emptyList()
    }

    /** True when the downloaded APK is signed by the same key as the installed app. */
    fun sameSigner(ctx: Context, f: File): Boolean {
        val mine = own(ctx)
        val theirs = apk(ctx, f)
        return mine.isNotEmpty() && theirs.any { it in mine }
    }
}
