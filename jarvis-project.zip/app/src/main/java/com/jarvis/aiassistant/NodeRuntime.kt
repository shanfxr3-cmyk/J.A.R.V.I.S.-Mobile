// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Runs the Node.js binary that is packaged inside the APK as lib/arm64-v8a/libnode.so.
 * Android lets an app execute files that live in its native library folder, so nothing is installed separately.
 * The binary and its libraries come from the "Get Node for Android" workflow and are added by the Android build workflow.
 */
object NodeRuntime {
    fun binary(ctx: Context): File = File(ctx.applicationInfo.nativeLibraryDir, "libnode.so")

    fun isBundled(ctx: Context): Boolean = binary(ctx).isFile

    private val CERT_DIRS = listOf("/apex/com.android.conscrypt/cacerts", "/system/etc/security/cacerts")
    private val PEM = Regex("-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\\r\\n]+?-----END CERTIFICATE-----")

    /**
     * Node (built with OpenSSL) needs one file holding the trusted HTTPS certificates. Android keeps them as
     * many separate files named in an older format that OpenSSL does not look up, so this joins them into one
     * file the first time and then refreshes it weekly.
     */
    fun caBundle(ctx: Context): File {
        val f = File(File(ctx.filesDir, "node-home").apply { mkdirs() }, "ca-bundle.pem")
        val fresh = f.isFile && f.length() > 10_000 && System.currentTimeMillis() - f.lastModified() < 7L * 24 * 3600 * 1000
        if (fresh) return f
        try {
            val seen = LinkedHashSet<String>()
            for (d in CERT_DIRS) {
                File(d).listFiles()?.forEach { c ->
                    try { PEM.findAll(c.readText()).forEach { seen.add(it.value.replace("\r", "").trim()) } } catch (_: Throwable) {}
                }
            }
            if (seen.isNotEmpty()) {
                val tmp = File(f.parentFile, "ca-bundle.tmp")
                tmp.writeText(seen.joinToString("\n") + "\n")
                tmp.renameTo(f)
            }
        } catch (_: Throwable) {}
        return f
    }

    /** Home, temp and cache folders for Node (Android has no /tmp or $HOME for apps). */
    fun env(ctx: Context): Map<String, String> {
        val home = File(ctx.filesDir, "node-home").apply { mkdirs() }
        val tmp = File(ctx.cacheDir, "node-tmp").apply { mkdirs() }
        val ca = caBundle(ctx)
        val m = mutableMapOf(
            "HOME" to home.absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "LD_LIBRARY_PATH" to ctx.applicationInfo.nativeLibraryDir,
            "NODE_OPTIONS" to ""
        )
        if (ca.isFile) {
            m["SSL_CERT_FILE"] = ca.absolutePath
            m["NODE_EXTRA_CA_CERTS"] = ca.absolutePath
        }
        return m
    }

    /** Runs node with [args] and returns everything it printed (stdout and stderr), or a clear failure text. */
    fun run(ctx: Context, args: List<String>, timeoutSec: Long = 40): String {
        val bin = binary(ctx)
        if (!bin.isFile) return "Node is not bundled in this build.\nExpected: ${bin.absolutePath}\nRun the \"Get Node for Android\" workflow once, then run \"Android build\" again."
        return try {
            val pb = ProcessBuilder(listOf(bin.absolutePath) + args)
            pb.environment().putAll(env(ctx))
            pb.redirectErrorStream(true)
            val p = pb.start()
            val sb = StringBuilder()
            val reader = Thread { try { p.inputStream.bufferedReader().forEachLine { sb.appendLine(it) } } catch (_: Throwable) {} }
            reader.start()
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                reader.join(1000)
                return sb.toString() + "\nTIMEOUT after ${timeoutSec}s (killed)."
            }
            reader.join(2000)
            sb.toString() + "\nexit code ${p.exitValue()}"
        } catch (e: Throwable) {
            "Could not start Node: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    // Prints what matters for the real server: version, filesystem, local HTTP, fetch, DNS, HTTPS, zlib, crypto, WebAssembly.
    private val SELF_TEST = """
const out = [];
const log = (s) => out.push(s);
log('node ' + process.version + ' ' + process.platform + '/' + process.arch);
try { const c = process.env.SSL_CERT_FILE; log('ca bundle: ' + (c && require('fs').existsSync(c) ? require('fs').statSync(c).size + ' bytes' : 'MISSING')); } catch (e) { log('ca bundle: FAIL ' + e.message); }
log('v8 ' + process.versions.v8 + ' | openssl ' + process.versions.openssl + ' | icu ' + process.versions.icu);
const home = process.env.HOME;
try { require('fs').writeFileSync(home + '/t.txt', 'ok'); log('fs write: ok'); } catch (e) { log('fs write: FAIL ' + e.message); }
try { require('zlib').gzipSync('x'); log('zlib: ok'); } catch (e) { log('zlib: FAIL ' + e.message); }
try { require('crypto').createHash('sha256').update('a').digest('hex'); log('crypto: ok'); } catch (e) { log('crypto: FAIL ' + e.message); }
try { new WebAssembly.Module(new Uint8Array([0,97,115,109,1,0,0,0])); log('wasm: ok'); } catch (e) { log('wasm: FAIL ' + e.message); }
try { log('cpus: ' + require('os').availableParallelism()); } catch (e) { log('cpus: FAIL ' + e.message); }
const http = require('http');
const srv = http.createServer((q, r) => r.end('pong')).listen(0, '127.0.0.1', async () => {
  try {
    const r = await fetch('http://127.0.0.1:' + srv.address().port + '/');
    log('localhost http+fetch: ' + (await r.text()));
  } catch (e) { log('localhost http+fetch: FAIL ' + e.message); }
  try {
    const r = await fetch('https://api.github.com/', { headers: { 'User-Agent': 'jarvis-node-test' }, signal: AbortSignal.timeout(15000) });
    log('internet https: HTTP ' + r.status);
  } catch (e) { log('internet https: FAIL ' + e.message + (e.cause ? ' / ' + e.cause.message : '')); }
  srv.close();
  console.log(out.join('\n'));
});
"""

    fun selfTest(ctx: Context): String = run(ctx, listOf("-e", SELF_TEST))
}

/** Developer screen: proves the bundled Node runs on this phone. Opened from About. */
@Composable
fun NodeTestScreen() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenHeader("NODE TEST", "Is the bundled Node.js running on this phone?")
        Text(
            if (NodeRuntime.isBundled(ctx)) "Node binary found in the app." else "Node binary NOT found in this build.",
            color = if (NodeRuntime.isBundled(ctx)) Green else Amber, fontSize = 13.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                busy = true; text = "Running..."
                Thread {
                    val r = NodeRuntime.run(ctx.applicationContext, listOf("-v"))
                    android.os.Handler(android.os.Looper.getMainLooper()).post { text = r; busy = false }
                }.start()
            }) { Text("Node version") }
            Button(enabled = !busy, onClick = {
                busy = true; text = "Running self test (up to 40 s)..."
                Thread {
                    val r = NodeRuntime.selfTest(ctx.applicationContext)
                    android.os.Handler(android.os.Looper.getMainLooper()).post { text = r; busy = false }
                }.start()
            }) { Text("Full self test") }
        }
        if (text.isNotEmpty()) Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
        Text("Send a screenshot of this screen back if anything says FAIL.", color = Dim, fontSize = 11.sp)
    }
}
