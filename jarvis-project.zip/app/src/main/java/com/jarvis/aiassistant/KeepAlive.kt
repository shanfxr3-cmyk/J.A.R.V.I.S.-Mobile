// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * 24/7 support. A watchdog alarm checks every ~15 minutes that the wake-word service is alive.
 * If Android blocks restarting the microphone service from the background (it does after a
 * reboot on Android 14+), a "Resume Jarvis" notification is shown; one tap brings it back.
 */
object KeepAlive {
    const val ACTION_CHECK = "com.jarvis.aiassistant.KEEPALIVE_CHECK"
    private const val RESUME_CHANNEL = "jarvis_resume_quiet"
    private const val RESUME_ID = 8
    private const val INTERVAL_MS = 15 * 60 * 1000L

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 20, Intent(ctx, KeepAliveReceiver::class.java).setAction(ACTION_CHECK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun schedule(ctx: Context, delayMs: Long = INTERVAL_MS) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delayMs, pending(ctx))
        } catch (_: Throwable) {
        }
    }

    fun cancel(ctx: Context) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx))
        } catch (_: Throwable) {
        }
        clearResume(ctx)
    }

    fun notificationsOn(ctx: Context): Boolean =
        androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun micGranted(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Bring the listener back if it should be running but isn't. Safe to call from a receiver. */
    fun check(ctx: Context) {
        val st = Store.get(ctx)
        if (!st.wakeWanted || !st.keepAlive || !Legal.isAccepted(st)) return
        if (st.initFails >= 3 && !WakeService.running) {
            // The listener failed to start 3 times in a row: stop hammering (downloads, mic flicker, battery).
            // The person can turn it on again in Settings, which resets the counter.
            schedule(ctx, 6 * 60 * 60 * 1000L)
            return
        }
        if (WakeService.running) {
            clearResume(ctx)
        } else if (micGranted(ctx)) {
            try {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, WakeService::class.java).setAction(WakeService.ACTION_REVIVE)
                )
            } catch (_: Throwable) {
                postResume(ctx)
            }
        }
        schedule(ctx)
    }

    fun postResume(ctx: Context) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                try { nm.deleteNotificationChannel("jarvis_resume") } catch (_: Throwable) {}
                nm.createNotificationChannel(NotificationChannel(RESUME_CHANNEL, "Resume Jarvis", NotificationManager.IMPORTANCE_LOW))
            }
            val open = PendingIntent.getActivity(
                ctx, 21, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, RESUME_CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_jarvis)
                .setContentTitle("Jarvis stopped listening")
                .setContentText("Tap to bring \"Hey Jarvis\" back.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .build()
            nm.notify(RESUME_ID, n)
        } catch (_: Throwable) {
        }
    }

    fun clearResume(ctx: Context) {
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(RESUME_ID)
        } catch (_: Throwable) {
        }
    }
}

/** Watchdog alarm target (not exported). */
class KeepAliveReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == KeepAlive.ACTION_CHECK) KeepAlive.check(context.applicationContext)
    }
}

/** Runs after a phone restart or after the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val a = intent?.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            KeepAlive.check(context.applicationContext)
        }
    }
}
