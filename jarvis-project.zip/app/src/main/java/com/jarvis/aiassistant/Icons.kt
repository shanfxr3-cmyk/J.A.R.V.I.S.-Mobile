// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Small built-in line icons (no icon library needed). */
enum class Ic { Home, Chat, Memory, Settings, Tasks, Tools, Holo, Globe, Mic, Voice, Wake, Power, Info, Data, Key, User, Back, Chevron }

@Composable
fun HudIcon(ic: Ic, modifier: Modifier = Modifier, tint: Color = Cyan, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension / 24f
        val w = 1.8f * s
        val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun o(x: Float, y: Float) = Offset(x * s, y * s)
        fun sz(a: Float, b: Float) = Size(a * s, b * s)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, o(x1, y1), o(x2, y2), w, StrokeCap.Round)
        fun Path.m(x: Float, y: Float) = moveTo(x * s, y * s)
        fun Path.l(x: Float, y: Float) = lineTo(x * s, y * s)
        fun path(block: Path.() -> Unit) = drawPath(Path().apply(block), tint, style = st)
        when (ic) {
            Ic.Home -> {
                path { m(3f, 11f); l(12f, 3f); l(21f, 11f) }
                path { m(5f, 10f); l(5f, 20f); l(19f, 20f); l(19f, 10f) }
            }
            Ic.Chat -> {
                drawRoundRect(tint, o(3f, 4f), sz(18f, 13f), CornerRadius(3f * s), style = st)
                path { m(8f, 17f); l(8f, 21f); l(12f, 17f) }
            }
            Ic.Memory -> {
                drawRoundRect(tint, o(6f, 6f), sz(12f, 12f), CornerRadius(2f * s), style = st)
                for (v in listOf(9f, 12f, 15f)) {
                    line(v, 3f, v, 6f); line(v, 18f, v, 21f)
                    line(3f, v, 6f, v); line(18f, v, 21f, v)
                }
            }
            Ic.Settings -> {
                line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 20f, 17f)
                drawCircle(tint, 2.2f * s, o(9f, 7f), style = st)
                drawCircle(tint, 2.2f * s, o(15f, 12f), style = st)
                drawCircle(tint, 2.2f * s, o(8f, 17f), style = st)
            }
            Ic.Tasks -> {
                drawRoundRect(tint, o(4f, 4f), sz(16f, 16f), CornerRadius(3f * s), style = st)
                path { m(8f, 12f); l(11f, 15f); l(16f, 9f) }
            }
            Ic.Tools -> {
                for ((x, y) in listOf(4f to 4f, 14f to 4f, 4f to 14f, 14f to 14f))
                    drawRoundRect(tint, o(x, y), sz(6f, 6f), CornerRadius(1.5f * s), style = st)
            }
            Ic.Holo -> {
                path { m(12f, 3f); l(20f, 7.5f); l(20f, 16.5f); l(12f, 21f); l(4f, 16.5f); l(4f, 7.5f); l(12f, 3f) }
                line(12f, 12f, 12f, 21f); line(12f, 12f, 4f, 7.5f); line(12f, 12f, 20f, 7.5f)
            }
            Ic.Globe -> {
                drawCircle(tint, 9f * s, o(12f, 12f), style = st)
                drawOval(tint, o(8f, 3f), sz(8f, 18f), style = st)
                line(3f, 12f, 21f, 12f)
            }
            Ic.Mic -> {
                drawRoundRect(tint, o(9f, 3f), sz(6f, 11f), CornerRadius(3f * s), style = st)
                drawArc(tint, 0f, 180f, false, o(6f, 7f), sz(12f, 10f), style = st)
                line(12f, 17f, 12f, 21f); line(8f, 21f, 16f, 21f)
            }
            Ic.Voice -> {
                path { m(4f, 9f); l(8f, 9f); l(13f, 5f); l(13f, 19f); l(8f, 15f); l(4f, 15f); l(4f, 9f) }
                drawArc(tint, -45f, 90f, false, o(9f, 7f), sz(10f, 10f), style = st)
                drawArc(tint, -45f, 90f, false, o(6f, 4f), sz(16f, 16f), style = st)
            }
            Ic.Wake -> {
                line(5f, 10f, 5f, 14f); line(8.5f, 6f, 8.5f, 18f); line(12f, 3f, 12f, 21f)
                line(15.5f, 7f, 15.5f, 17f); line(19f, 10f, 19f, 14f)
            }
            Ic.Power -> {
                drawArc(tint, -60f, 300f, false, o(5f, 5f), sz(14f, 14f), style = st)
                line(12f, 3f, 12f, 11f)
            }
            Ic.Info -> {
                drawCircle(tint, 9f * s, o(12f, 12f), style = st)
                line(12f, 11f, 12f, 17f)
                drawCircle(tint, 1.2f * s, o(12f, 7.5f))
            }
            Ic.Data -> {
                drawOval(tint, o(5f, 4f), sz(14f, 5f), style = st)
                line(5f, 6.5f, 5f, 17.5f); line(19f, 6.5f, 19f, 17.5f)
                drawArc(tint, 0f, 180f, false, o(5f, 9.5f), sz(14f, 5f), style = st)
                drawArc(tint, 0f, 180f, false, o(5f, 15f), sz(14f, 5f), style = st)
            }
            Ic.Key -> {
                drawCircle(tint, 4f * s, o(8f, 15f), style = st)
                line(11f, 12f, 20f, 3f); line(17f, 6f, 19f, 8f); line(14f, 9f, 16f, 11f)
            }
            Ic.User -> {
                drawCircle(tint, 4f * s, o(12f, 8f), style = st)
                drawArc(tint, 180f, 180f, false, o(5f, 13f), sz(14f, 12f), style = st)
            }
            Ic.Back -> path { m(15f, 5f); l(8f, 12f); l(15f, 19f) }
            Ic.Chevron -> path { m(9f, 5f); l(16f, 12f); l(9f, 19f) }
        }
    }
}
