// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import java.io.File
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech-to-text (Android SpeechRecognizer) and text-to-speech (Android TextToSpeech). Use from the main thread. */
class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var pending: Pair<String, () -> Unit>? = null
    private var doneCb: (() -> Unit)? = null
    private var sr: SpeechRecognizer? = null
    private var player: MediaPlayer? = null
    @Volatile private var gen = 0
    var lastError: String? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                try {
                    tts?.language = Locale.getDefault()
                    tts?.setPitch(0.9f)
                } catch (_: Throwable) {}
                ready = true
                main.post { pending?.let { p -> pending = null; speakAndroid(p.first, p.second) } }
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishSpeak() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finishSpeak() }
            override fun onError(utteranceId: String?, errorCode: Int) { finishSpeak() }
        })
    }

    private fun finishSpeak() {
        main.post { val cb = doneCb; doneCb = null; cb?.invoke() }
    }

    private fun clean(t: String) = t.replace(Regex("[*#`]"), "").trim().take(3500)

    fun speak(text: String, onDone: () -> Unit) {
        val t = clean(text)
        if (t.isBlank()) { onDone(); return }
        val st = Store.get(ctx)
        if (st.fishKey.isNotBlank() && st.fishVoice.isNotBlank()) {
            val my = ++gen
            val key = st.fishKey; val vid = st.fishVoice; val model = st.fishModel
            Thread {
                try {
                    val f = File(ctx.cacheDir, "fish_$my.mp3")
                    FishTts.synth(key, vid, model, t, f)
                    main.post { if (my == gen) playFile(f, my, onDone) else f.delete() }
                } catch (e: Throwable) {
                    lastError = e.message
                    main.post { if (my == gen) speakAndroid(t, onDone) }
                }
            }.start()
            return
        }
        speakAndroid(t, onDone)
    }

    private fun playFile(f: File, my: Int, onDone: () -> Unit) {
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_ASSISTANT).build())
            mp.setDataSource(f.absolutePath)
            val end = {
                if (player === mp) player = null
                try { mp.release() } catch (_: Throwable) {}
                f.delete()
                if (my == gen) onDone()
            }
            mp.setOnCompletionListener { end() }
            mp.setOnErrorListener { _, _, _ -> end(); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Throwable) {
            lastError = e.message
            f.delete()
            onDone()
        }
    }

    private fun speakAndroid(t: String, onDone: () -> Unit) {
        if (!ready) {
            pending = t to onDone
            // No TTS engine / slow init: do not stall a voice conversation.
            main.postDelayed({
                if (!ready) { val p = pending; pending = null; p?.second?.invoke() }
            }, 5000)
            return
        }
        doneCb = onDone
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() {
        gen++
        doneCb = null
        pending = null
        try { player?.release() } catch (_: Throwable) {}
        player = null
        try { tts?.stop() } catch (_: Throwable) {}
    }

    fun stopListening() {
        val r = sr
        sr = null
        try { r?.cancel(); r?.destroy() } catch (_: Throwable) {}
    }

    /** onFail(message, retryable). */
    fun listen(onPartial: (String) -> Unit, onResult: (String) -> Unit, onFail: (String, Boolean) -> Unit) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Speech recognition is not available. Install or enable the Google app.", false)
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                if (sr !== r) return
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onPartial(t)
            }
            override fun onResults(results: Bundle?) {
                if (sr !== r) return
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                main.post { if (sr === r) { sr = null; try { r.destroy() } catch (_: Throwable) {} } }
                if (t.isNullOrBlank()) onFail("Didn't catch that.", true) else onResult(t)
            }
            override fun onError(error: Int) {
                if (sr !== r) return
                main.post { if (sr === r) { sr = null; try { r.destroy() } catch (_: Throwable) {} } }
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onFail("Didn't catch that.", true)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> onFail("Recognizer busy, try again.", true)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> onFail("Microphone permission denied.", false)
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        onFail("Speech service needs an internet connection.", false)
                    else -> onFail("Speech error ($error).", false)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        r.startListening(i)
    }

    fun destroy() {
        stopListening()
        stopSpeaking()
        try { tts?.shutdown() } catch (_: Throwable) {}
        tts = null
    }
}
