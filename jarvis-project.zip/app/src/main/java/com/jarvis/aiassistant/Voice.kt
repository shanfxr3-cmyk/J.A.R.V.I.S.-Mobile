// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import java.io.File
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech-to-text (Android SpeechRecognizer) and text-to-speech (Android TextToSpeech). Use from the main thread. */
class Voice(private val ctx: Context) {
    companion object {
        /** After a Fish Audio failure, use the phone voice for a few minutes instead of retrying before every reply. */
        @Volatile private var fishFailUntil = 0L
        fun resetFishFailure() { fishFailUntil = 0L }
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var pending: Pair<String, () -> Unit>? = null
    private var doneCb: (() -> Unit)? = null
    private var sr: SpeechRecognizer? = null
    private var player: MediaPlayer? = null
    @Volatile private var gen = 0
    var lastError: String? = null
    /** True when the phone has no working text-to-speech engine. */
    @Volatile var ttsMissing = false
        private set

    init {
        // Leftover audio from interrupted playback (only old files, so another Voice's live files are safe).
        try {
            val cutoff = System.currentTimeMillis() - 10 * 60_000L
            ctx.cacheDir.listFiles { f -> f.name.startsWith("fish_") && f.lastModified() < cutoff }?.forEach { it.delete() }
        } catch (_: Throwable) {}
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                ttsMissing = true
                lastError = "No text-to-speech engine installed or it failed to start."
                main.post { pending?.let { p -> pending = null; p.second() } }
            } else {
                try {
                    tts?.language = Locale.getDefault()
                    tts?.setPitch(0.9f)
                } catch (_: Throwable) {}
                ready = true
                main.post { pending?.let { p -> pending = null; speakAndroid(p.first, p.second) } }
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishSpeak() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finishSpeak() }
            override fun onError(utteranceId: String?, errorCode: Int) { finishSpeak() }
        })
    }

    private fun finishSpeak() {
        main.post { val cb = doneCb; doneCb = null; cb?.invoke() }
    }

    private fun clean(t: String) = t
        .replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("(?s)<think>.*$"), "")
        .replace(Regex("[*#`]"), "").trim().take(3500)

    /** Short first piece (fast start), then pieces of whole sentences. */
    private fun splitForTts(t: String): List<String> {
        val sentences = t.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (s in sentences) {
            if (cur.isNotEmpty() && cur.length + s.length > 300) { out.add(cur.toString()); cur.clear() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(s)
            if (out.isEmpty() && cur.length >= 40) { out.add(cur.toString()); cur.clear() }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return if (out.isEmpty()) listOf(t) else out
    }

    /** Fish Audio speech made sentence by sentence: playback starts after the first piece, the rest is made while it plays. */
    private inner class FishJob(
        val my: Int, val parts: List<String>, val onDone: () -> Unit,
        val synth: (String, File) -> Unit
    ) {
        private val q = java.util.ArrayDeque<File>()
        private var playing = false
        private var synthFinished = false
        private var failedAt = -1
        private var ended = false

        fun start() {
            Thread {
                for ((i, p) in parts.withIndex()) {
                    if (my != gen) return@Thread
                    val f = File(ctx.cacheDir, "fish_${my}_$i.mp3")
                    try {
                        synth(p, f)
                    } catch (e: Throwable) {
                        f.delete()
                        lastError = e.message
                        fishFailUntil = SystemClock.elapsedRealtime() + 5 * 60_000L
                        main.post { failedAt = i; synthFinished = true; pump() }
                        return@Thread
                    }
                    main.post { if (my == gen) { q.add(f); pump() } else f.delete() }
                }
                main.post { synthFinished = true; pump() }
            }.also { it.name = "fish-tts"; it.start() }
        }

        fun pump() {
            if (ended) return
            if (my != gen) { q.forEach { it.delete() }; q.clear(); ended = true; return }
            if (playing) return
            val f = q.poll()
            if (f != null) { playing = true; playFile(f, my) { playing = false; pump() }; return }
            if (!synthFinished) return
            ended = true
            if (failedAt >= 0) { speakAndroid(parts.drop(failedAt).joinToString(" "), onDone); return }
            onDone()
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        val t = clean(text)
        if (t.isBlank()) { onDone(); return }
        val st = Store.get(ctx)
        val cloudOk = SystemClock.elapsedRealtime() >= fishFailUntil
        if (cloudOk && st.elevenKey.isNotBlank() && st.elevenVoice.isNotBlank()) {
            val my = ++gen
            val k = st.elevenKey; val v = st.elevenVoice; val m = st.elevenModel
            FishJob(my, splitForTts(t), onDone) { p, f -> ElevenTts.synth(k, v, m, p, f) }.start()
            return
        }
        if (cloudOk && st.fishKey.isNotBlank() && st.fishVoice.isNotBlank()) {
            val my = ++gen
            val k = st.fishKey; val v = st.fishVoice; val m = st.fishModel
            FishJob(my, splitForTts(t), onDone) { p, f -> FishTts.synth(k, v, m, p, f) }.start()
            return
        }
        speakAndroid(t, onDone)
    }

    private fun playFile(f: File, my: Int, onDone: () -> Unit) {
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_ASSISTANT).build())
            mp.setDataSource(f.absolutePath)
            val end = {
                if (player === mp) player = null
                runCatching { mp.release() }
                f.delete()
                if (my == gen) onDone()
            }
            mp.setOnCompletionListener { end() }
            mp.setOnErrorListener { _, _, _ -> end(); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Throwable) {
            lastError = e.message
            f.delete()
            onDone()
        }
    }

    private fun speakAndroid(t: String, onDone: () -> Unit) {
        if (ttsMissing) { onDone(); return }
        if (!ready) {
            pending = t to onDone
            // Slow init: do not stall a voice conversation.
            main.postDelayed({
                if (!ready) { val p = pending; pending = null; p?.second?.invoke() }
            }, 5000)
            return
        }
        doneCb = onDone
        val my = ++gen
        val rc = try { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis") ?: TextToSpeech.ERROR } catch (_: Throwable) { TextToSpeech.ERROR }
        if (rc != TextToSpeech.SUCCESS) {
            lastError = "Text-to-speech refused to speak (code $rc)."
            doneCb = null
            onDone()
            return
        }
        // Safety net: if the engine never reports completion, carry on instead of freezing.
        val limit = 8000L + t.length * 120L
        main.postDelayed({
            if (gen == my && doneCb != null) {
                lastError = "Text-to-speech timed out."
                val cb = doneCb; doneCb = null
                runCatching { tts?.stop() }
                cb?.invoke()
            }
        }, limit.coerceAtMost(180_000L))
    }

    // ---- Streaming speech: speak each finished sentence while the AI is still writing the rest. ----
    private val sq = java.util.ArrayDeque<String>()
    private var sToken = 0
    private var sBusy = false
    private var sEnded = false
    private var sDone: (() -> Unit)? = null
    /** True while a streamed reply is still being spoken or is waiting for more sentences. */
    val streaming: Boolean get() = sDone != null

    /** Begin a streamed reply. onDone runs after streamEnd() once everything has been spoken (not when interrupted). */
    fun streamStart(onDone: () -> Unit) {
        stopSpeaking()
        sq.clear(); sBusy = false; sEnded = false
        sDone = onDone
    }

    fun streamAdd(sentence: String) {
        if (sDone == null) return
        val c = clean(sentence)
        if (c.isBlank()) return
        sq.add(c)
        streamPump()
    }

    fun streamEnd() {
        if (sDone == null) return
        sEnded = true
        streamPump()
    }

    private fun streamPump() {
        if (sBusy) return
        val cb = sDone ?: return
        if (sq.isEmpty()) {
            if (sEnded) { sDone = null; cb() }
            return
        }
        // Everything that queued up while the last piece was playing goes out together (smoother, fewer gaps).
        val text = sq.joinToString(" ")
        sq.clear()
        sBusy = true
        val tok = sToken
        speak(text) { if (tok == sToken) { sBusy = false; streamPump() } }
    }

    fun stopSpeaking() {
        sToken++; sq.clear(); sBusy = false; sEnded = false; sDone = null
        gen++
        doneCb = null
        pending = null
        runCatching { player?.release() }
        player = null
        runCatching { tts?.stop() }
    }

    fun stopListening() {
        val r = sr
        sr = null
        runCatching { r?.cancel(); r?.destroy() }
    }

    /** onFail(message, retryable). */
    fun listen(onPartial: (String) -> Unit, onResult: (String) -> Unit, onFail: (String, Boolean) -> Unit) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Speech recognition is not available. Install or enable the Google app.", false)
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                if (sr !== r) return
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onPartial(t)
            }
            override fun onResults(results: Bundle?) {
                if (sr !== r) return
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                main.post { if (sr === r) { sr = null; try { r.destroy() } catch (_: Throwable) {} } }
                if (t.isNullOrBlank()) onFail("Didn't catch that.", true) else onResult(t)
            }
            override fun onError(error: Int) {
                if (sr !== r) return
                main.post { if (sr === r) { sr = null; try { r.destroy() } catch (_: Throwable) {} } }
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onFail("Didn't catch that.", true)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> onFail("Recognizer busy, try again.", true)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> onFail("Microphone permission denied.", false)
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        onFail("Speech service needs internet (or install an offline speech pack for your language in the Google app).", false)
                    else -> onFail("Speech error ($error).", false)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)   // used when an offline pack is installed
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        r.startListening(i)
    }

    fun destroy() {
        stopListening()
        stopSpeaking()
        main.removeCallbacksAndMessages(null)
        runCatching { tts?.shutdown() }
        tts = null
    }
}
