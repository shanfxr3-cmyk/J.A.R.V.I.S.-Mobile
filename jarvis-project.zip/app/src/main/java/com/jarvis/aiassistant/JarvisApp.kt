// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Application

/** Loads saved data and opens the Keystore on a background thread, so the first screen does not wait for it. */
class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            try { Store.get(applicationContext) } catch (_: Throwable) {}
        }.also { it.name = "warmup"; it.start() }
    }
}
