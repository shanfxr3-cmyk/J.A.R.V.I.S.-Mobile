// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Application
import android.app.NotificationManager
import java.io.File

/** Loads saved data and opens the Keystore on a background thread, so the first screen does not wait for it. */
class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            try { Store.get(applicationContext) } catch (_: Throwable) {}
            removeOldData()
        }.also { it.name = "warmup"; it.start() }
    }

    /** Deletes files, settings and the notification channel that an older version left on the phone after an update. */
    private fun removeOldData() {
        try { File(filesDir, "gev").deleteRecursively() } catch (_: Throwable) {}
        try { File(filesDir, "node-home").deleteRecursively() } catch (_: Throwable) {}
        try { File(cacheDir, "node-tmp").deleteRecursively() } catch (_: Throwable) {}
        try { deleteSharedPreferences("gev_ui") } catch (_: Throwable) {}
        try { getSystemService(NotificationManager::class.java)?.deleteNotificationChannel("jarvis_gev") } catch (_: Throwable) {}
    }
}
