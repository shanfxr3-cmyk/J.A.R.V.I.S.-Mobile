// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Starts the God's Eye View server inside Termux through Termux's own "run command" service. */
object TermuxRunner {
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val TERMUX = "com.termux"
    private const val HOME = "/data/data/com.termux/files/home"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"

    // The [v] trick stops pgrep from matching this very shell. If the server is already up, do nothing,
    // so a second tap never starts a second copy that would eat more memory.
    private const val SCRIPT =
        "if pgrep -f 'node.*[v]ite' >/dev/null 2>&1; then echo already running; " +
        "else termux-wake-lock; cd \"\$HOME/gods-eye-view\" && exec npm run dev >> \"\$HOME/gev.log\" 2>&1; fi"

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(TERMUX, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** For a button tap: asks for the Termux permission the first time, otherwise starts the server. */
    fun startOrAsk(ctx: Context): String {
        if (installed(ctx) && !hasPermission(ctx) && ctx is android.app.Activity) {
            androidx.core.app.ActivityCompat.requestPermissions(ctx, arrayOf(PERMISSION), 41)
            return "Allow the Termux permission, then tap again."
        }
        return start(ctx)
    }

    /** Returns a short sentence to show or speak. */
    fun start(ctx: Context): String {
        if (!installed(ctx)) return "Termux is not installed on this phone."
        if (!hasPermission(ctx)) {
            return "I need the Run commands in Termux permission. Open the Tools screen and tap Start World server, or allow it in Android settings under this app's permissions."
        }
        return try {
            val i = Intent("com.termux.RUN_COMMAND")
                .setClassName(TERMUX, "com.termux.app.RunCommandService")
                .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
                .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", SCRIPT))
                .putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
                .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            ContextCompat.startForegroundService(ctx, i)
            "Starting the world server in Termux. Give it about 20 seconds, then open the World screen."
        } catch (e: Exception) {
            "Could not start Termux: ${e.message ?: "unknown error"}. In Termux, check that allow-external-apps is set to true."
        }
    }
}
