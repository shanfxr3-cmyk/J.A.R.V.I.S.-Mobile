// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Audio tap for cloud voices (Fish Audio and ElevenLabs play as mp3 through MediaPlayer). A live FFT of the player's
 * audio session feeds [SpeechLevel], so the visualizer follows the real voice. Needs the microphone permission the app
 * already asks for; when Android refuses, the visualizer falls back to a synthetic speech envelope.
 */
class PlaybackTap private constructor(private val viz: android.media.audiofx.Visualizer) {
    fun release() {
        runCatching { viz.setEnabled(false) }
        runCatching { viz.setDataCaptureListener(null, 0, false, false) }
        runCatching { viz.release() }
    }

    companion object {
        fun attach(mp: android.media.MediaPlayer): PlaybackTap? = try {
            val v = android.media.audiofx.Visualizer(mp.audioSessionId)
            val range = android.media.audiofx.Visualizer.getCaptureSizeRange()
            v.setCaptureSize(512.coerceIn(range[0], range[1]))
            v.setDataCaptureListener(object : android.media.audiofx.Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: android.media.audiofx.Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(visualizer: android.media.audiofx.Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) SpeechLevel.pushFft(fft)
                }
            }, android.media.audiofx.Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            SpeechLevel.synthetic = false
            PlaybackTap(v)
        } catch (_: Throwable) {
            SpeechLevel.synthetic = true
            null
        }
    }
}

/** Fish Audio text-to-speech. Blocking: call off the main thread. Returns an mp3 file. */
object FishTts {
    const val DEFAULT_MODEL = "s2.1-pro-free"
    val MODELS = listOf(
        Triple("s2.1-pro-free", "S2.1 Pro (free)", "Primary. Free for testing; Fish may change or end the free tier."),
        Triple("s2-pro", "S2 Pro", "Higher quality, uses credits.")
    )

    /** S1 is being retired by Fish Audio: move any saved S1 choice to the default. */
    fun migrate(m: String?): String = if (m.isNullOrBlank() || m.trim() == "s1") DEFAULT_MODEL else m.trim()

    fun synth(key: String, voiceId: String, model: String, text: String, out: File) {
        val body = JSONObject()
            .put("text", text)
            .put("format", "mp3")
            .put("mp3_bitrate", 128)
            .put("latency", "normal")
        if (voiceId.isNotBlank()) body.put("reference_id", voiceId.trim())
        val c = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer ${key.trim()}")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("model", migrate(model))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Throwable) { null }
                throw RuntimeException(
                    when (code) {
                        401 -> "Fish Audio rejected the API key."
                        402 -> "Fish Audio: out of credits."
                        404 -> "Fish Audio: voice ID not found."
                        else -> "Fish Audio error $code ${err ?: ""}".trim()
                    }
                )
            }
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (out.length() < 100) throw RuntimeException("Fish Audio returned no audio.")
        } finally { c.disconnect() }
    }
}
