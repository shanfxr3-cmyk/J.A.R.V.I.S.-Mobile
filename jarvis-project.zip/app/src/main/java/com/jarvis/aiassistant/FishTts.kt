package com.jarvis.aiassistant

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Fish Audio text-to-speech. Blocking: call off the main thread. Returns an mp3 file. */
object FishTts {
    const val DEFAULT_MODEL = "s2.1-pro-free"
    val MODELS = listOf(
        Triple("s2.1-pro-free", "S2.1 Pro (free)", "Primary. Free tier model."),
        Triple("s2-pro", "S2 Pro", "Higher quality, uses credits."),
        Triple("s1", "S1", "Previous generation.")
    )

    fun synth(key: String, voiceId: String, model: String, text: String, out: File) {
        val body = JSONObject()
            .put("text", text)
            .put("format", "mp3")
            .put("mp3_bitrate", 128)
            .put("latency", "normal")
        if (voiceId.isNotBlank()) body.put("reference_id", voiceId.trim())
        val c = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer ${key.trim()}")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("model", model.trim().ifEmpty { DEFAULT_MODEL })
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                val err = try { c.errorStream?.bufferedReader()?.readText()?.take(200) } catch (_: Throwable) { null }
                throw RuntimeException(
                    when (code) {
                        401 -> "Fish Audio rejected the API key."
                        402 -> "Fish Audio: out of credits."
                        404 -> "Fish Audio: voice ID not found."
                        else -> "Fish Audio error $code ${err ?: ""}".trim()
                    }
                )
            }
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (out.length() < 100) throw RuntimeException("Fish Audio returned no audio.")
        } finally { c.disconnect() }
    }
}
