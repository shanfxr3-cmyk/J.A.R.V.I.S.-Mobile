// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private fun open(ctx: android.content.Context, i: Intent) {
    try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
}

/** Default assistant, floating bar, quick tile / widget hints and the app lock. */
@Composable
fun SystemPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    SubHeader("PHONE INTEGRATION", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Default assistant", color = Color.White)
            Note("Make Jarvis the app your power or home button opens (Android calls it the digital assistant app). It opens Jarvis ready to listen. It does not read your screen.")
            HudBtn("Choose in Android settings", Modifier.fillMaxWidth()) {
                open(ctx, Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            }
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Floating bar", color = Color.White, modifier = Modifier.weight(1f))
                HudSwitch(store.overlayOn, { on ->
                    store.setOverlay(on)
                    if (on && !Overlay.allowed(ctx)) open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName)))
                })
            }
            Note("After the wake word, show a small bar over your current app instead of opening Jarvis. Needs Android's \"display over other apps\" permission. The bar cannot be tapped.")
            if (store.overlayOn && !Overlay.allowed(ctx)) Text("Permission not granted yet.", color = Amber)
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val ok = AppLock.available(ctx)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("App lock", color = Color.White, modifier = Modifier.weight(1f))
                HudSwitch(store.appLock, { on -> if (!on || ok) store.setAppLock(on) })
            }
            Note(if (ok) "Ask for fingerprint, face or your screen lock when the app opens or after 30 seconds away. Also hides the app in the Recents screen. Replies to the wake word are not locked."
                 else "Needs Android 11 or newer with a fingerprint, face or screen lock set up on this phone.")
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Shortcuts", color = Color.White)
            Note("Quick Settings tile: swipe down, tap the pencil or edit icon and drag Jarvis in. Home-screen widget: long-press the home screen, Widgets, Jarvis.")
        }
    }
}
