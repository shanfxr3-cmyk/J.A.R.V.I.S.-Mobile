// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject
import java.io.File

/**
 * Phone control: the AI sees the screen through accessibility and acts through accessibility and Shizuku.
 * Reading tools run freely. Acting tools ask first unless [free] is on; risky ones (see each `danger`) always ask in chat and never run by voice.
 */
object Control {
    /** Mirror of Store.controlFree so ToolMode can read it without a Context. */
    @Volatile var free: Boolean = false
    /** Optional hook for hardware key events the accessibility service sees (return true to swallow). */
    @Volatile var keyHook: ((KeyEvent) -> Boolean)? = null

    private const val NEED_SHIZUKU = "Shizuku is not running or Jarvis is not allowed in it. Ask the person to open Jarvis Settings, Phone control."
    private const val NEED_ACCESS = "Accessibility is off. Ask the person to open Jarvis Settings, Phone control, and turn it on."

    /** Called when Shizuku appears or the person allows Jarvis. Quietly repairs access. */
    fun onShizukuChange(ctx: Context) {
        Thread {
            runCatching {
                val store = Store.get(ctx)
                if (!store.controlAuto || !Shell.granted()) return@runCatching
                if (store.controlGrantedVer != BuildConfig.VERSION_CODE) {
                    Shell.grantAll(ctx)
                    store.markControlGranted(BuildConfig.VERSION_CODE)
                } else if (!ScreenService.running) {
                    Shell.enableAccessibility(ctx)
                }
                Unit
            }
        }.also { it.name = "control-heal"; it.start() }
    }

    private fun s(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "string", d, req)
    private fun i(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "integer", d, req)
    private fun b(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "boolean", d, req)
    private fun e(n: String, d: String, v: List<String>, req: Boolean = true) = ToolDef.Param(n, "string", d, req, v)
    private fun askOf(label: String): (JSONObject) -> String = { a -> "$label ${a.toString().take(180)}?" }

    private fun shOk(cmd: String): Boolean = Shell.granted() && Shell.exec(cmd).ok
    private fun sh(cmd: String, ok: String = "Done."): String {
        if (!Shell.granted()) return NEED_SHIZUKU
        val r = Shell.exec(cmd)
        return if (r.ok) ok else "Failed: " + r.text().take(200).ifBlank { "exit ${r.code}" }
    }

    // ---------- reading ----------

    private fun status(c: Context): String {
        val x = Shell.snapshot(c)
        return "Shizuku: " + (if (!x.installed) "not installed" else if (!x.running) "not running" else if (!x.granted) "running, Jarvis not allowed" else if (x.uid == 0) "ready (root)" else "ready (shell)") +
            ". Accessibility: " + (if (x.a11yBound) "on" else "off") +
            ". Write-secure-settings: " + (if (x.secure) "yes" else "no") + ". Foreground app: " + foreground().ifBlank { "unknown" } + "."
    }

    private fun foreground(): String {
        if (ScreenService.pkg.isNotBlank()) return ScreenService.pkg
        if (!Shell.granted()) return ""
        val r = Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -2")
        return Regex("([a-zA-Z0-9_.]+)/").find(r.out)?.groupValues?.get(1).orEmpty()
    }

    private fun screenRead(a: JSONObject): String {
        val sv = ScreenService.inst ?: return NEED_ACCESS
        val items = sv.snapshot()
        if (items.isEmpty()) return "The screen shows nothing readable (lock screen, a protected app, or still loading). App: ${ScreenService.pkg}."
        val q = a.optString("query").trim().lowercase()
        val sb = StringBuilder("App: ${ScreenService.pkg}\n")
        for ((idx, it) in items.withIndex()) {
            if (q.isNotEmpty() && !it.label.lowercase().contains(q)) continue
            sb.append(it.line(idx)).append('\n')
            if (sb.length > 3500) { sb.append("...more; use query to narrow."); break }
        }
        return sb.toString().trim()
    }

    private fun screenshot(c: Context): String {
        if (Shell.granted()) {
            val f = "/sdcard/Pictures/Jarvis/shot_${System.currentTimeMillis()}.png"
            val r = Shell.exec("mkdir -p /sdcard/Pictures/Jarvis && screencap -p ${Shell.q(f)}")
            if (r.ok) return "Screenshot saved to $f."
        }
        val sv = ScreenService.inst ?: return NEED_ACCESS
        val f: File? = sv.screenshot()
        return if (f != null) "Screenshot saved to ${f.absolutePath}." else "Could not take a screenshot (Android 11 or newer needed, or the app blocks it)."
    }

    private fun waitFor(a: JSONObject): String {
        val secs = a.optInt("seconds", 3).coerceIn(1, 20)
        val text = a.optString("text").trim().lowercase()
        val end = System.currentTimeMillis() + secs * 1000L
        if (text.isEmpty()) { Thread.sleep(secs * 1000L); return "Waited $secs seconds." }
        val sv = ScreenService.inst ?: return NEED_ACCESS
        while (System.currentTimeMillis() < end) {
            if (sv.snapshot().any { it.label.lowercase().contains(text) }) return "Found it on screen."
            Thread.sleep(500)
        }
        return "Did not appear within $secs seconds."
    }

    private fun clipboard(c: Context): ClipboardManager = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    // ---------- acting ----------

    private fun tap(a: JSONObject): String {
        val sv = ScreenService.inst ?: return NEED_ACCESS
        val item = if (a.optString("text").isNotBlank()) { sv.snapshot(); sv.find(a.optString("text")) }
        else if (a.has("index")) sv.last.getOrNull(a.optInt("index", -1))
        else return "Give an index from screen_read or the text to tap."
        if (item == null) return "Nothing matched. Call screen_read again for fresh numbers."
        return if (sv.click(item)) "Tapped ${item.label.take(40).ifBlank { "it" }}." else "The tap did not register. Call screen_read and try again."
    }

    private fun gesture(c: Context, a: JSONObject): String {
        val dm = c.resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        fun f(k: String, d: Float) = if (a.has(k)) a.optDouble(k).toFloat() else d
        val x = f("x", w / 2); val y = f("y", h / 2)
        val dur = a.optLong("duration_ms", 0).coerceIn(0, 10_000)
        val sv = ScreenService.inst
        val xi = x.toInt(); val yi = y.toInt()
        fun sw(x1: Float, y1: Float, x2: Float, y2: Float, d: Long): Boolean =
            (sv?.swipe(x1, y1, x2, y2, d) == true) || shOk("input swipe ${x1.toInt()} ${y1.toInt()} ${x2.toInt()} ${y2.toInt()} $d")
        val t = a.optString("type")
        val ok = when (t) {
            "tap" -> (sv?.tapAt(x, y, 50) == true) || shOk("input tap $xi $yi")
            "double_tap" -> (sv?.doubleTap(x, y) == true) || (shOk("input tap $xi $yi") && shOk("input tap $xi $yi"))
            "long_press" -> { val d = if (dur > 0) dur else 800L; (sv?.tapAt(x, y, d) == true) || shOk("input swipe $xi $yi $xi $yi $d") }
            "swipe" -> sw(x, y, f("x2", x), f("y2", y), if (dur > 0) dur else 300L)
            "scroll_down" -> sw(w / 2, h * 0.75f, w / 2, h * 0.25f, if (dur > 0) dur else 400L)
            "scroll_up" -> sw(w / 2, h * 0.25f, w / 2, h * 0.75f, if (dur > 0) dur else 400L)
            "scroll_right" -> sw(w * 0.8f, h / 2, w * 0.2f, h / 2, if (dur > 0) dur else 400L)
            "scroll_left" -> sw(w * 0.2f, h / 2, w * 0.8f, h / 2, if (dur > 0) dur else 400L)
            "pinch_in" -> sv?.pinch(x, y, false) == true
            "pinch_out" -> sv?.pinch(x, y, true) == true
            else -> return "Unknown gesture."
        }
        return if (ok) "Done." else if (sv == null && !Shell.granted()) NEED_ACCESS else "The gesture did not go through."
    }

    private fun typeText(c: Context, a: JSONObject): String {
        val text = a.optString("text")
        if (text.isEmpty()) return "What should I type?"
        val replace = a.optBoolean("replace", false); val submit = a.optBoolean("submit", false)
        val viaNode = ScreenService.inst?.type(text, replace, submit)
        if (viaNode != null) return viaNode
        if (!Shell.granted()) return if (ScreenService.inst == null) NEED_ACCESS else "No text field is focused. Tap one first."
        // No usable field node: paste through the clipboard (handles any language and emoji).
        clipboard(c).setPrimaryClip(ClipData.newPlainText("jarvis", text))
        if (replace) Shell.exec("input keycombination KEYCODE_CTRL_LEFT KEYCODE_A")
        val r = Shell.exec("input keyevent 279" + if (submit) "; input keyevent 66" else "")
        return if (r.ok) "Typed." else "Failed: " + r.text().take(120)
    }

    private val GLOBAL: Map<String, Int> = mapOf(
        "back" to AccessibilityService.GLOBAL_ACTION_BACK, "home" to AccessibilityService.GLOBAL_ACTION_HOME,
        "recents" to AccessibilityService.GLOBAL_ACTION_RECENTS, "notifications" to AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS,
        "quick_settings" to AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "power_menu" to AccessibilityService.GLOBAL_ACTION_POWER_DIALOG,
        "split_screen" to AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN, "lock_screen" to 8, "screenshot" to 9,
        "dismiss_shade" to 15, "all_apps" to 14
    )
    private val GLOBAL_MIN = mapOf("lock_screen" to 28, "screenshot" to 28, "dismiss_shade" to 31, "all_apps" to 32)
    private val KEYS: Map<String, Int> = mapOf(
        "volume_up" to 24, "volume_down" to 25, "mute" to 164, "power" to 26, "enter" to 66, "delete" to 67, "forward_delete" to 112,
        "tab" to 61, "escape" to 111, "space" to 62, "search" to 84, "menu" to 82, "camera" to 27, "play_pause" to 85, "next" to 87,
        "previous" to 88, "stop" to 86, "wake" to 224, "sleep" to 223, "call_answer" to 5, "call_end" to 6, "brightness_up" to 221,
        "brightness_down" to 220, "up" to 19, "down" to 20, "left" to 21, "right" to 22, "center" to 23, "page_up" to 92, "page_down" to 93,
        "copy" to 278, "cut" to 277, "paste" to 279, "assist" to 219, "voice_assist" to 231, "app_switch" to 187, "home" to 3, "back" to 4
    )
    private val BAR = mapOf("notifications" to "expand-notifications", "quick_settings" to "expand-settings", "dismiss_shade" to "collapse")

    private fun pressKey(c: Context, a: JSONObject): String {
        val key = a.optString("key")
        val times = a.optInt("times", 1).coerceIn(1, 20)
        val code = KEYS[key]
        val g = GLOBAL[key]
        if (g == null && code == null) return "Unknown key."
        val sv = ScreenService.inst
        var done = 0
        repeat(times) {
            var ok = false
            if (g != null && sv != null && Build.VERSION.SDK_INT >= (GLOBAL_MIN[key] ?: 0)) ok = sv.global(g)
            if (!ok && BAR[key] != null) ok = shOk("cmd statusbar ${BAR[key]}")
            if (!ok && code != null) ok = shOk("input keyevent $code")
            if (!ok && key == "lock_screen") ok = shOk("input keyevent 223")
            if (!ok && code != null && code in setOf(24, 25, 164, 85, 87, 88, 86)) {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                when (code) {
                    24 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    25 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    164 -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
                    else -> {
                        val t = android.os.SystemClock.uptimeMillis()
                        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0)); am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
                    }
                }
                ok = true
            }
            if (ok) done++
            if (times > 1) Thread.sleep(150)
        }
        val said = if (times > 1) "Pressed $key $done times." else "Pressed $key."
        return if (done > 0) said else if (sv == null && !Shell.granted()) NEED_ACCESS else "That key did not work."
    }

    private fun en(on: Boolean) = if (on) "enable" else "disable"
    private fun n(on: Boolean) = if (on) 1 else 0
    private fun put(ns: String, key: String): (Boolean) -> String = { on -> "settings put $ns $key ${n(on)}" }

    private val TOGGLES: Map<String, (Boolean) -> String> = mapOf(
        "wifi" to { on: Boolean -> "svc wifi ${en(on)}" },
        "mobile_data" to { on: Boolean -> "svc data ${en(on)}" },
        "bluetooth" to { on: Boolean -> "cmd bluetooth_manager ${en(on)} || svc bluetooth ${en(on)}" },
        "airplane" to { on: Boolean -> "cmd connectivity airplane-mode ${en(on)} || (settings put global airplane_mode_on ${n(on)}; am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $on)" },
        "nfc" to { on: Boolean -> "svc nfc ${en(on)}" },
        "location" to { on: Boolean -> "cmd location set-location-enabled $on || settings put secure location_mode ${if (on) 3 else 0}" },
        "auto_rotate" to put("system", "accelerometer_rotation"),
        "battery_saver" to put("global", "low_power"),
        "dnd" to { on: Boolean -> "cmd notification set_dnd ${if (on) "priority" else "off"}" },
        "dark_mode" to { on: Boolean -> "cmd uimode night ${if (on) "yes" else "no"}" },
        "stay_awake" to { on: Boolean -> "svc power stayon $on" },
        "screen" to { on: Boolean -> "input keyevent ${if (on) 224 else 223}" },
        "adaptive_brightness" to put("system", "screen_brightness_mode"),
        "night_light" to put("secure", "night_display_activated"),
        "grayscale" to { on: Boolean -> "settings put secure accessibility_display_daltonizer_enabled ${n(on)}; settings put secure accessibility_display_daltonizer 0" },
        "invert_colors" to put("secure", "accessibility_display_inversion_enabled"),
        "high_contrast_text" to put("secure", "high_text_contrast_enabled"),
        "one_handed_mode" to put("secure", "one_handed_mode_enabled"),
        "show_touches" to put("system", "show_touches"),
        "pointer_location" to put("system", "pointer_location"),
        "touch_sounds" to put("system", "sound_effects_enabled"),
        "haptic_feedback" to put("system", "haptic_feedback_enabled"),
        "animations" to { on: Boolean -> "for k in window_animation_scale transition_animation_scale animator_duration_scale; do settings put global \$k ${n(on)}; done" },
        "dont_keep_activities" to put("global", "always_finish_activities"),
        "developer_options" to put("global", "development_settings_enabled"),
        "usb_debugging" to put("global", "adb_enabled"),
        "wireless_debugging" to put("global", "adb_wifi_enabled")
    )

    private fun deviceToggle(a: JSONObject): String {
        val k = a.optString("setting")
        val t = TOGGLES[k] ?: return "Unknown setting."
        val on = a.optBoolean("on", true)
        val r = sh(t(on), "$k ${if (on) "on" else "off"}.")
        return r
    }

    private val VALUE_KEYS = listOf(
        "brightness_percent", "screen_timeout_seconds", "font_scale", "display_density", "display_size", "refresh_rate", "animation_scale",
        "orientation", "volume_ring", "volume_alarm", "volume_notification", "volume_system", "volume_call", "volume_music"
    )

    private fun setValue(c: Context, a: JSONObject): String {
        val k = a.optString("setting")
        val v = a.optString("value").trim()
        val num = v.toDoubleOrNull()
        val reset = v.equals("reset", true)
        return when (k) {
            "brightness_percent" -> if (num == null || num !in 0.0..100.0) "Brightness is 0 to 100."
                else sh("settings put system screen_brightness_mode 0; settings put system screen_brightness ${(num * 255 / 100).toInt().coerceAtLeast(1)}", "Brightness $v percent.")
            "screen_timeout_seconds" -> if (num == null || num !in 5.0..86400.0) "Timeout is 5 to 86400 seconds."
                else sh("settings put system screen_off_timeout ${(num * 1000).toLong()}", "Screen timeout $v seconds.")
            "font_scale" -> if (num == null || num !in 0.5..2.0) "Font scale is 0.5 to 2.0." else sh("settings put system font_scale $num", "Font scale $v.")
            "display_density" -> if (reset) sh("wm density reset", "Density reset.") else if (num == null || num !in 120.0..900.0) "Density is 120 to 900, or reset."
                else sh("wm density ${num.toInt()}", "Density $v.")
            "display_size" -> if (reset) sh("wm size reset", "Size reset.") else if (!Regex("^[0-9]{3,4}x[0-9]{3,4}$").matches(v)) "Use WIDTHxHEIGHT or reset."
                else sh("wm size $v", "Size $v.")
            "refresh_rate" -> if (reset) sh("settings delete system min_refresh_rate; settings delete system peak_refresh_rate", "Refresh rate reset.")
                else if (num == null || num !in 30.0..240.0) "Refresh rate is 30 to 240, or reset."
                else sh("settings put system min_refresh_rate ${num.toInt()}; settings put system peak_refresh_rate ${num.toInt()}", "Refresh rate $v Hz.")
            "animation_scale" -> if (num == null || num !in 0.0..10.0) "Animation scale is 0 to 10."
                else sh("for k in window_animation_scale transition_animation_scale animator_duration_scale; do settings put global \$k $num; done", "Animation scale $v.")
            "orientation" -> {
                val r = mapOf("portrait" to 0, "landscape" to 1, "reverse_portrait" to 2, "reverse_landscape" to 3)[v.lowercase()]
                if (r == null) "Use portrait, landscape, reverse_portrait or reverse_landscape."
                else sh("settings put system accelerometer_rotation 0; settings put system user_rotation $r", "Orientation $v.")
            }
            else -> {
                val stream = mapOf("volume_call" to 0, "volume_system" to 1, "volume_ring" to 2, "volume_music" to 3, "volume_alarm" to 4, "volume_notification" to 5)[k]
                if (stream == null) "Unknown setting."
                else if (num == null || num !in 0.0..100.0) "Volume is 0 to 100."
                else {
                    val max = (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getStreamMaxVolume(stream)
                    sh("cmd media_session volume --stream $stream --set ${(num / 100 * max).toInt()}", "${k.removePrefix("volume_")} volume $v percent.")
                }
            }
        }
    }

    private fun pkgOf(c: Context, raw: String): String? {
        val w = raw.trim()
        if (Shell.PKG_RE.matches(w)) return w
        val pm = c.packageManager
        val apps = pm.getInstalledApplications(0).map { pm.getApplicationLabel(it).toString() to it.packageName }
        val l = w.lowercase()
        return (apps.firstOrNull { it.first.lowercase() == l } ?: apps.firstOrNull { it.first.lowercase().startsWith(l) } ?: apps.firstOrNull { it.first.lowercase().contains(l) })?.second
    }

    private val APP_DANGER = setOf("clear_data", "uninstall", "disable", "install", "grant", "revoke")

    private fun appManage(c: Context, a: JSONObject): String {
        val act = a.optString("action")
        val pm = c.packageManager
        if (act == "list") {
            val q = a.optString("package").trim().lowercase()
            val rows = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }.distinct().sortedBy { it.first.lowercase() }
                .filter { q.isEmpty() || it.first.lowercase().contains(q) || it.second.contains(q) }
            return if (rows.isEmpty()) "No matching apps." else rows.take(80).joinToString("\n") { "${it.first} (${it.second})" }
        }
        if (act == "install") {
            val path = a.optString("apk_path").trim()
            if (!path.startsWith("/") || !path.endsWith(".apk") || path.contains("..")) return "apk_path must be an absolute path to an .apk file."
            return sh("pm install -r -d -g ${Shell.q(path)}", "Installed.")
        }
        val pkg = pkgOf(c, a.optString("package")) ?: return "I could not find that app."
        val q = Shell.q(pkg)
        return when (act) {
            "launch" -> {
                val li = pm.getLaunchIntentForPackage(pkg)
                if (li != null && runCatching { c.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) "Opened $pkg."
                else sh("monkey -p $q -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1", "Opened $pkg.")
            }
            "stop" -> sh("am force-stop $q", "Stopped $pkg.")
            "clear_data" -> sh("pm clear $q", "Cleared data of $pkg.")
            "uninstall" -> sh("pm uninstall $q", "Uninstalled $pkg.")
            "disable" -> sh("pm disable-user --user 0 $q", "Disabled $pkg.")
            "enable" -> sh("pm enable $q", "Enabled $pkg.")
            "info" -> if (!Shell.granted()) NEED_SHIZUKU else Shell.exec("dumpsys package $q | grep -E 'versionName|versionCode|firstInstallTime|lastUpdateTime|targetSdk' | head -8").out.trim().ifBlank { "No info." }
            "grant", "revoke" -> {
                var p = a.optString("permission").trim()
                if (p.isEmpty()) return "Which permission?"
                if (!p.contains('.')) p = "android.permission." + p.uppercase()
                if (!Shell.PKG_RE.matches(p)) return "That is not a valid permission name."
                sh("cmd package $act $q $p", if (act == "grant") "Granted $p." else "Revoked $p.")
            }
            else -> "Unknown action."
        }
    }

    private fun powerAction(a: JSONObject): String = when (a.optString("action")) {
        "lock" -> if (ScreenService.inst?.global(8) == true || shOk("input keyevent 223")) "Locked." else NEED_ACCESS
        "screen_on" -> sh("input keyevent 224", "Screen on.")
        "screen_off" -> sh("input keyevent 223", "Screen off.")
        "reboot" -> sh("svc power reboot || reboot", "Rebooting. Shizuku has to be started again afterwards.")
        "shutdown" -> sh("reboot -p || svc power shutdown", "Shutting down.")
        else -> "Unknown power action."
    }

    private fun openUrl(c: Context, a: JSONObject): String {
        val u = a.optString("url").trim()
        if (!Regex("^(https?|geo|mailto|market|tel|sms)[:].{2,}", RegexOption.IGNORE_CASE).matches(u) || u.length > 2000) return "That is not a link I can open."
        return try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Opened." } catch (e: Throwable) { "Could not open it: ${e.message}" }
    }

    private fun magnify(a: JSONObject): String {
        val sv = ScreenService.inst ?: return NEED_ACCESS
        val sc = a.optDouble("scale", 1.0).toFloat()
        val x = if (a.has("x")) a.optDouble("x").toFloat() else null
        val y = if (a.has("y")) a.optDouble("y").toFloat() else null
        return if (sv.magnify(sc, x, y)) (if (sc <= 1f) "Magnification off." else "Magnified.") else "Magnification is not available right now."
    }

    private fun callNumber(c: Context, a: JSONObject): String {
        val n = a.optString("number").trim()
        if (!Regex("^[+0-9 ()\\-]{3,20}$").matches(n)) return "That does not look like a phone number."
        if (c.checkSelfPermission(android.Manifest.permission.CALL_PHONE) != android.content.pm.PackageManager.PERMISSION_GRANTED) return "Calling is not allowed yet. Use Grant all in Phone control."
        return try { c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Calling $n." } catch (e: Throwable) { "Could not call: ${e.message}" }
    }

    private fun sendSms(c: Context, a: JSONObject): String {
        val n = a.optString("number").trim(); val m = a.optString("message").take(1000)
        if (!Regex("^[+0-9 ()\\-]{3,20}$").matches(n) || m.isBlank()) return "I need a valid number and a message."
        if (c.checkSelfPermission(android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return "Texting is not allowed yet. Use Grant all in Phone control."
        return try {
            @Suppress("DEPRECATION")
            val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = sm.divideMessage(m)
            if (parts.size > 1) sm.sendMultipartTextMessage(n, null, parts, null, null) else sm.sendTextMessage(n, null, m, null, null)
            "Text sent to $n."
        } catch (e: Throwable) { "Could not send: ${e.message}" }
    }

    val tools: List<ToolDef> = listOf(
        ToolDef("control_status", "Whether phone control (Shizuku and accessibility) is ready, and which app is in front.", readOnly = true) { c, _, _ -> status(c) },
        ToolDef("screen_read", "Read the phone screen now: the front app and a numbered list of visible texts, buttons, switches and fields. The numbers are used by tap.",
            listOf(s("query", "Only list items containing this text", false))) { _, _, a -> screenRead(a) },
        ToolDef("screenshot", "Save a screenshot of the screen to the Pictures/Jarvis folder and give its path.") { c, _, _ -> screenshot(c) },
        ToolDef("wait_for", "Wait for a text to appear on screen, or just wait a few seconds, before the next step.",
            listOf(s("text", "Text to wait for", false), i("seconds", "Up to 20", false))) { _, _, a -> waitFor(a) },
        ToolDef("get_clipboard", "Read the text currently on the clipboard.") { c, _, _ ->
            clipboard(c).primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(c)?.toString()?.take(3000)?.ifBlank { null } ?: "The clipboard is empty or Android hid it from Jarvis."
        },
        ToolDef("set_clipboard", "Put text on the clipboard.", listOf(s("text", "Text to copy")), control = true, ask = askOf("Copy to the clipboard:")) { c, _, a ->
            clipboard(c).setPrimaryClip(ClipData.newPlainText("jarvis", a.optString("text").take(20000))); "Copied."
        },
        ToolDef("tap", "Tap an item on screen, by its number from screen_read or by its visible text.",
            listOf(i("index", "Number from screen_read", false), s("text", "Visible text of the item", false)), control = true, ask = askOf("Tap on the screen:")) { _, _, a -> tap(a) },
        ToolDef("gesture", "Touch gestures: tap, double_tap, long_press, swipe, scroll in a direction (scroll_down shows content below), pinch_in or pinch_out. x and y default to screen centre; swipe also needs x2 and y2.",
            listOf(e("type", "Gesture", listOf("tap", "double_tap", "long_press", "swipe", "scroll_up", "scroll_down", "scroll_left", "scroll_right", "pinch_in", "pinch_out")),
                i("x", "X pixel", false), i("y", "Y pixel", false), i("x2", "End X for swipe", false), i("y2", "End Y for swipe", false), i("duration_ms", "How long", false)),
            control = true, ask = askOf("Use the screen:")) { c, _, a -> gesture(c, a) },
        ToolDef("type_text", "Type text into the focused field (or the first field on screen).",
            listOf(s("text", "Text to type"), b("replace", "Replace what is there instead of adding", false), b("submit", "Press enter afterwards", false)),
            control = true, ask = { "Type \"${it.optString("text").take(100)}\"?" }) { c, _, a -> typeText(c, a) },
        ToolDef("press_key", "Press a system button or key: back, home, recents, notifications, quick_settings, power_menu, lock_screen, screenshot, split_screen, all_apps, dismiss_shade, volume_up, volume_down, mute, enter, delete, tab, escape, arrows, media keys, call_answer, call_end, brightness_up and more.",
            listOf(e("key", "Which key", (GLOBAL.keys + KEYS.keys).toList().sorted()), i("times", "Repeat 1 to 20", false)),
            control = true, ask = askOf("Press a key:")) { c, _, a -> pressKey(c, a) },
        ToolDef("device_toggle", "Switch a phone feature on or off: Wi-Fi, mobile data, Bluetooth, airplane, NFC, location, rotation, battery saver, do not disturb, dark mode, screen, night light, colour filters, touch visuals, animations, developer options, USB and wireless debugging and more.",
            listOf(e("setting", "Which feature", TOGGLES.keys.toList()), b("on", "true for on, false for off")),
            control = true, ask = { "Switch ${it.optString("setting")} ${if (it.optBoolean("on", true)) "on" else "off"}?" }) { _, _, a -> deviceToggle(a) },
        ToolDef("set_value", "Set a number-type setting: brightness_percent, screen_timeout_seconds, font_scale, display_density, display_size (WxH), refresh_rate, animation_scale, orientation, or a volume_* stream (0-100). density, size and refresh_rate accept the value reset.",
            listOf(e("setting", "Which setting", VALUE_KEYS), s("value", "The value")),
            control = true, ask = { "Set ${it.optString("setting")} to ${it.optString("value")}?" }) { c, _, a -> setValue(c, a) },
        ToolDef("app_manage", "Manage apps: list, launch, stop, enable, info, and (asks every time) clear_data, uninstall, disable, install, grant or revoke a permission.",
            listOf(e("action", "What to do", listOf("list", "launch", "stop", "enable", "info", "clear_data", "uninstall", "disable", "install", "grant", "revoke")),
                s("package", "App name or package name (for list: a filter)", false), s("permission", "Permission for grant or revoke, e.g. CAMERA", false), s("apk_path", "Path of the .apk for install", false)),
            control = true, danger = { it.optString("action") in APP_DANGER },
            ask = { "${it.optString("action")} ${it.optString("package")}${it.optString("apk_path")} ${it.optString("permission")}?".replace("  ", " ") }) { c, _, a -> appManage(c, a) },
        ToolDef("power_action", "Lock the phone, turn the screen on or off, reboot or shut down (reboot and shutdown always ask).",
            listOf(e("action", "What to do", listOf("lock", "screen_on", "screen_off", "reboot", "shutdown"))),
            control = true, danger = { it.optString("action") == "reboot" || it.optString("action") == "shutdown" }, ask = { "Phone: ${it.optString("action")}?" }) { _, _, a -> powerAction(a) },
        ToolDef("open_url", "Open a web link, map, or mail address in the phone's own app.", listOf(s("url", "http(s), geo, mailto, market, tel or sms link")),
            control = true, ask = { "Open ${it.optString("url").take(120)}?" }) { c, _, a -> openUrl(c, a) },
        ToolDef("magnify", "Zoom the whole screen in (scale 1.1 to 8) or back out (scale 1).",
            listOf(ToolDef.Param("scale", "number", "1 resets", true), i("x", "Centre X", false), i("y", "Centre Y", false)), control = true, ask = askOf("Magnify the screen:")) { _, _, a -> magnify(a) },
        ToolDef("call_number", "Place a phone call right now.", listOf(s("number", "Phone number")), control = true, confirm = true,
            ask = { "Call ${it.optString("number")} now?" }) { c, _, a -> callNumber(c, a) },
        ToolDef("send_sms", "Send a text message right now, without opening the messaging app.", listOf(s("number", "Phone number"), s("message", "Text")), control = true, confirm = true,
            ask = { "Send a text to ${it.optString("number")}: \"${it.optString("message").take(120)}\"?" }) { c, _, a -> sendSms(c, a) },
        ToolDef("shell_exec", "Run any shell command on the phone with Shizuku's rights and return its output. Always asks.", listOf(s("command", "The command")), control = true, confirm = true,
            ask = { "Run this command? ${it.optString("command").take(200)}" }) { _, _, a ->
            val cmd = a.optString("command")
            if (cmd.isBlank()) "No command." else if (!Shell.granted()) NEED_SHIZUKU
            else Shell.exec(cmd, 30_000).let { r -> (r.text().ifBlank { "(no output)" }).take(3500) + if (r.ok) "" else "\n[exit ${r.code}]" }
        }
    )
}
