// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

private const val WORLD_KEY = "worldUrl"
private const val WORLD_DEFAULT = "http://localhost:4173"

/** Returns a safe URL or null. Plain http is only allowed for localhost (Termux); everything else must be https. */
private fun cleanWorldUrl(raw: String): String? {
    var u = raw.trim()
    if (u.isEmpty()) return null
    if (!u.contains("://")) {
        val local = u.startsWith("localhost") || u.startsWith("127.0.0.1")
        u = (if (local) "http://" else "https://") + u
    }
    val uri = try { Uri.parse(u) } catch (_: Exception) { return null }
    val host = uri.host ?: return null
    return when (uri.scheme) {
        "https" -> u
        "http" -> if (host == "localhost" || host == "127.0.0.1") u else null
        else -> null
    }
}

/**
 * God's Eye View (github.com/bilawalsidhu/gods-eye-view, MIT) shown in a WebView.
 * The web app and its key-holding proxy run elsewhere (Termux on this phone, or a hosted copy).
 * No keys are stored in this app for it.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WorldScreen(store: Store) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    var saved by remember { mutableStateOf(cleanWorldUrl(sp.getString(WORLD_KEY, WORLD_DEFAULT) ?: WORLD_DEFAULT) ?: WORLD_DEFAULT) }
    val savedNow by rememberUpdatedState(saved)
    var field by remember { mutableStateOf(saved) }
    var editing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var web by remember { mutableStateOf<WebView?>(null) }
    var pendingMic by remember { mutableStateOf<PermissionRequest?>(null) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val r = pendingMic
        pendingMic = null
        if (r != null) {
            if (ok) r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else r.deny()
        }
    }

    // Pause the page (3D rendering, timers) when the app is in the background.
    DisposableEffect(web) {
        val owner = ctx as? LifecycleOwner
        val wv = web
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> wv?.onPause()
                Lifecycle.Event.ON_RESUME -> wv?.onResume()
                else -> {}
            }
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }
    DisposableEffect(Unit) {
        onDispose {
            web?.let {
                it.stopLoading()
                (it.parent as? ViewGroup)?.removeView(it)
                it.destroy()
            }
            web = null
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ScreenHeader("WORLD", "God's Eye View. Needs its server running (Termux or hosted).")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudBtn("Reload", Modifier.weight(1f), BtnKind.Outline) { error = null; web?.loadUrl(saved) }
            HudBtn(if (editing) "Close" else "Set URL", Modifier.weight(1f), BtnKind.Outline) { editing = !editing; field = saved }
        }
        if (editing) {
            Spacer(Modifier.height(8.dp))
            HudField(field, { field = it }, "Server URL (http://localhost:4173)", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            HudBtn("Load", Modifier.fillMaxWidth()) {
                val u = cleanWorldUrl(field)
                if (u == null) {
                    error = "Use https://, or http:// only for localhost."
                } else {
                    saved = u
                    field = u
                    sp.edit().putString(WORLD_KEY, u).apply()
                    store.log("World view URL changed")
                    error = null
                    editing = false
                    web?.loadUrl(u)
                }
            }
        }
        error?.let { Text(it, color = Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        if (progress in 1..99) {
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth(progress / 100f).height(2.dp).background(Cyan))
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).also { wv ->
                        wv.setBackgroundColor(android.graphics.Color.parseColor("#050B14"))
                        wv.settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            allowFileAccess = false
                            allowContentAccess = false
                            setSupportZoom(false)
                        }
                        wv.webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                // Stay inside the app only for the configured server. Anything else opens in the browser.
                                if (request.url.host == Uri.parse(savedNow).host) return false
                                try {
                                    c.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (_: Exception) {}
                                return true
                            }

                            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                error = null
                            }

                            override fun onReceivedError(view: WebView, request: WebResourceRequest, err: WebResourceError) {
                                if (request.isForMainFrame) {
                                    error = "Can't reach $savedNow. Start the server (npm run dev in Termux), keep Termux running, then tap Reload."
                                }
                            }
                        }
                        wv.webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                progress = newProgress
                            }

                            override fun onPermissionRequest(request: PermissionRequest) {
                                // Microphone only, only for the configured server, only after Android's own mic permission.
                                val trusted = request.origin.host == Uri.parse(savedNow).host
                                val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                                val onlyMic = request.resources.all { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                                if (!trusted || !wantsMic || !onlyMic) { request.deny(); return }
                                if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                                } else {
                                    pendingMic?.deny()
                                    pendingMic = request
                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        }
                        wv.loadUrl(saved)
                        web = wv
                    }
                }
            )
        }
    }
}
