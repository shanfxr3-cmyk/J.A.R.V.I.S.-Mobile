// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

private const val WORLD_KEY = "worldUrl"
private const val WORLD_DEFAULT = "http://localhost:4173"

/** Returns a safe URL or null. Plain http is only allowed for localhost (Termux); everything else must be https. */
private fun cleanWorldUrl(raw: String): String? {
    var u = raw.trim()
    if (u.isEmpty()) return null
    if (!u.contains("://")) {
        val local = u.startsWith("localhost") || u.startsWith("127.0.0.1")
        u = (if (local) "http://" else "https://") + u
    }
    val uri = try { Uri.parse(u) } catch (_: Exception) { return null }
    val host = uri.host ?: return null
    return when (uri.scheme) {
        "https" -> u
        "http" -> if (host == "localhost" || host == "127.0.0.1") u else null
        else -> null
    }
}

/** Small translucent pill that floats over the page in fullscreen. */
@Composable
private fun FloatBtn(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .background(Bg.copy(alpha = 0.7f), shape)
            .border(1.dp, Cyan.copy(alpha = 0.6f), shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Cyan, fontSize = 11.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/**
 * God's Eye View (github.com/bilawalsidhu/gods-eye-view, MIT) shown in a WebView.
 * The web app and its key-holding proxy run elsewhere (Termux on this phone, or a hosted copy).
 * No keys are stored in this app for it.
 *
 * [full] = true: the page fills the whole screen (system bars and the bottom bar are hidden by MainActivity)
 * and only a small MENU pill floats over it. [onFull] switches between fullscreen and the normal layout.
 *
 * The WebView is deliberately NOT clipped to a rounded shape and MainActivity does not fade this screen in:
 * both force Android to draw the WebView through an offscreen layer, which leaves WebGL (the globe) black
 * while ordinary HTML still shows.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WorldScreen(store: Store, full: Boolean, onFull: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    var saved by remember { mutableStateOf(cleanWorldUrl(sp.getString(WORLD_KEY, WORLD_DEFAULT) ?: WORLD_DEFAULT) ?: WORLD_DEFAULT) }
    val savedNow by rememberUpdatedState(saved)
    val onFullNow by rememberUpdatedState(onFull)
    var field by remember { mutableStateOf(saved) }
    var editing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var web by remember { mutableStateOf<WebView?>(null) }
    var pendingMic by remember { mutableStateOf<PermissionRequest?>(null) }
    // Page-requested fullscreen (the page's own fullscreen button): the page hands us a view to show.
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    // Bumped to build a fresh WebView (after the page's renderer process died).
    var webKey by remember { mutableIntStateOf(0) }
    var dead by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    // One line about what the page sees (WebGL renderer, viewport size). Shown under MENU to diagnose a black globe.
    var info by remember { mutableStateOf<String?>(null) }
    // Last JavaScript error the page logged (any kind), so one screenshot shows why the page misbehaves.
    var jsErr by remember { mutableStateOf<String?>(null) }
    // Last few page console lines (any level), failed requests, and a deep probe of canvases/animations.
    val logs = remember { mutableStateListOf<String>() }
    var probe by remember { mutableStateOf<String?>(null) }
    fun addLog(t: String) { logs.add(t.take(120)); while (logs.size > 6) logs.removeAt(0) }
    // Engine version of this phone's Android System WebView (Chrome's engine, updated through Play Store).
    val wvVersion = remember {
        try { if (android.os.Build.VERSION.SDK_INT >= 26) WebView.getCurrentWebViewPackage()?.versionName else null } catch (_: Throwable) { null }
    }
    // Automatic retries: server in Termux not up yet (connection errors), or WebGL missing on the first try.
    var retries by remember { mutableIntStateOf(0) }
    var glRetried by remember { mutableStateOf(false) }
    // Engine: Firefox's engine (GeckoView) by default; Android System WebView as the fallback.
    var useGecko by remember { mutableStateOf(sp.getString("world_engine", "gecko") != "webview") }
    var gSession by remember { mutableStateOf<org.mozilla.geckoview.GeckoSession?>(null) }
    fun setEngine(gecko: Boolean) {
        useGecko = gecko
        sp.edit().putString("world_engine", if (gecko) "gecko" else "webview").apply()
        error = null
        progress = 0
        info = null
        jsErr = null
        probe = null
        gSession = null
        web = null
        dead = false
        webKey++
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val r = pendingMic
        pendingMic = null
        if (r != null) {
            if (ok) r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else r.deny()
        }
    }

    fun reload() {
        error = null
        if (useGecko) {
            if (gSession != null) gSession?.loadUri(saved) else setEngine(true)
            return
        }
        if (dead) {
            dead = false
            progress = 0
            web = null
            webKey++
        } else {
            web?.loadUrl(saved)
        }
    }

    // Guaranteed route: open the same server in Chrome itself (Chrome renders this page correctly).
    fun openInChrome() {
        val uri = Uri.parse(saved)
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.chrome").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Throwable) {
                error = "No browser found to open $saved."
            }
        }
    }

    // Pause the page (3D rendering, timers) when the app is in the background.
    DisposableEffect(web) {
        val owner = ctx as? LifecycleOwner
        val wv = web
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> wv?.onPause()
                Lifecycle.Event.ON_RESUME -> wv?.onResume()
                else -> {}
            }
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }

    // Back closes the page's own fullscreen first.
    BackHandler(enabled = customView != null) {
        customCb?.onCustomViewHidden()
        customCb = null
        customView = null
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().then(if (full) Modifier else Modifier.padding(12.dp))) {
            if (!full) {
                ScreenHeader("WORLD", "God's Eye View. Needs its server running (Termux or hosted).")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudBtn("Reload", Modifier.weight(1f), BtnKind.Outline) { reload() }
                    HudBtn(if (editing) "Close" else "Set URL", Modifier.weight(1f), BtnKind.Outline) { editing = !editing; field = saved }
                    HudBtn("Fullscreen", Modifier.weight(1f), BtnKind.Primary) { onFull(true) }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    HudBtn("Open in Chrome", Modifier.weight(1f), BtnKind.Outline) { openInChrome() }
                    Spacer(Modifier.width(8.dp))
                    HudBtn(if (useGecko) "Engine: Firefox" else "Engine: WebView", Modifier.weight(1f), BtnKind.Primary) { setEngine(!useGecko) }
                }
                if (editing) {
                    Spacer(Modifier.height(8.dp))
                    HudField(field, { field = it }, "Server URL (http://localhost:4173)", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    HudBtn("Load", Modifier.fillMaxWidth()) {
                        val u = cleanWorldUrl(field)
                        if (u == null) {
                            error = "Use https://, or http:// only for localhost."
                        } else {
                            saved = u
                            field = u
                            sp.edit().putString(WORLD_KEY, u).apply()
                            error = null
                            editing = false
                            if (useGecko) gSession?.loadUri(u) else if (dead) reload() else web?.loadUrl(u)
                        }
                    }
                }
                error?.let { Text(it, color = Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                info?.let { Text(it, color = Cyan, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)) }
                jsErr?.let { Text("JS: $it", color = Amber, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)) }
                probe?.let { Text(it, color = Cyan, fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp)) }
                if (logs.isNotEmpty()) Text(logs.joinToString("\n"), color = Dim, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
                if (progress in 1..99) {
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth(progress / 100f).height(2.dp).background(Cyan))
                }
            }
            // No clip() here on purpose (see the note above). A plain rectangular border is safe.
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .then(if (full) Modifier else Modifier.padding(top = 8.dp).border(1.dp, Cyan.copy(alpha = 0.35f)))
            ) {
                if (useGecko) key(webKey) {
                    GeckoPane(
                        url = saved,
                        modifier = Modifier.fillMaxSize(),
                        onSession = { gSession = it },
                        onProgress = { progress = it },
                        onFailed = { error = "Can't reach $saved. Start the server (npm run dev in Termux), keep Termux running, then tap Reload." },
                        onLoaded = { error = null },
                        onFatal = { msg ->
                            // Firefox engine could not start: use Android System WebView instead.
                            setEngine(false)
                            error = "Firefox engine failed to start ($msg). Using WebView."
                        }
                    )
                } else key(webKey) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            WebView(c).also { wv ->
                                wv.setBackgroundColor(android.graphics.Color.parseColor("#050B14"))
                                wv.overScrollMode = View.OVER_SCROLL_NEVER
                                wv.keepScreenOn = true
                                wv.isFocusable = true
                                wv.isFocusableInTouchMode = true
                                // Keep the page's renderer at foreground priority so Android does not kill it under memory pressure.
                                if (android.os.Build.VERSION.SDK_INT >= 26) {
                                    wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
                                }
                                CookieManager.getInstance().apply {
                                    setAcceptCookie(true)
                                    setAcceptThirdPartyCookies(wv, true)
                                }
                                wv.settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    mediaPlaybackRequiresUserGesture = false
                                    allowFileAccess = false
                                    allowContentAccess = false
                                    setSupportZoom(false)
                                    // Ignore the phone's font size setting: the page is laid out in fixed-size panels.
                                    textZoom = 100
                                    // Same defaults as desktop/mobile Chrome for a normal web app.
                                    javaScriptCanOpenWindowsAutomatically = false
                                    setSupportMultipleWindows(false)
                                    cacheMode = WebSettings.LOAD_DEFAULT
                                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                    loadsImagesAutomatically = true
                                    blockNetworkImage = false
                                    blockNetworkLoads = false
                                    setGeolocationEnabled(false)
                                    safeBrowsingEnabled = false
                                    // Behave like Chrome for pages that rely on <meta name="viewport">.
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    // Present as plain mobile Chrome (drop the WebView marker) so the page does not
                                    // take a reduced "embedded browser" path.
                                    userAgentString = userAgentString
                                        .replace("; wv)", ")")
                                        .replace(Regex("Version/\\d+\\.\\d+ "), "")
                                }
                                wv.webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                        // Stay inside the app only for the configured server. Anything else opens in the browser.
                                        if (request.url.host == Uri.parse(savedNow).host) return false
                                        try {
                                            c.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                        } catch (_: Exception) {}
                                        return true
                                    }

                                    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                        error = null
                                        info = null
                                        jsErr = null
                                        probe = null
                                        logs.clear()
                                    }

                                    override fun onPageFinished(view: WebView, url: String?) {
                                        if (error == null) retries = 0
                                        val major = wvVersion?.substringBefore('.')?.toIntOrNull()
                                        if (major != null && major < 120 && error == null) {
                                            error = "Android System WebView $wvVersion is old; this page needs a newer one. Update it in Play Store (search: Android System WebView), then restart."
                                        }
                                        // Re-measure: scripts that sized the globe/panels once at load get the real size.
                                        view.postDelayed({
                                            view.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null)
                                        }, 600)
                                        // Report WebGL status and viewport size.
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                "(function(){try{var c=document.createElement('canvas');" +
                                                    "var g=c.getContext('webgl2')||c.getContext('webgl');" +
                                                    "if(!g)return 'NO_WEBGL';" +
                                                    "var e=g.getExtension('WEBGL_debug_renderer_info');" +
                                                    "return (e?g.getParameter(e.UNMASKED_RENDERER_WEBGL):'webgl ok')+' | '+innerWidth+'x'+innerHeight+' @'+devicePixelRatio" +
                                                    "}catch(x){return 'ERR '+x}})()"
                                            ) { r ->
                                                val t = (r ?: "").trim('"')
                                                info = "WebView " + (wvVersion ?: "?") + " | " + t
                                                if (t.startsWith("NO_WEBGL") || t.startsWith("ERR")) {
                                                    if (!glRetried) {
                                                        glRetried = true   // one automatic fresh load
                                                        view.reload()
                                                    } else {
                                                        error = "WebGL is not available in this WebView ($t)."
                                                    }
                                                }
                                            }
                                        }, 2500)
                                        // Is requestAnimationFrame ticking? Count frames for ~1.5 s and report page visibility.
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                "window.__gevRaf=0;(function f(){window.__gevRaf++;if(window.__gevRaf<600)requestAnimationFrame(f)})();0", null
                                            )
                                        }, 3500)
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                "(function(){try{var o=[];document.querySelectorAll('canvas').forEach(function(c){" +
                                                    "var g=c.getContext('webgl2')||c.getContext('webgl');" +
                                                    "o.push('canvas '+c.width+'x'+c.height+' lost='+(g?g.isContextLost():'nogl'))});" +
                                                    "var a=document.getAnimations?document.getAnimations():[];" +
                                                    "var st={};a.forEach(function(x){st[x.playState]=(st[x.playState]||0)+1});" +
                                                    "o.push('anims '+JSON.stringify(st));" +
                                                    "o.push('reduce='+matchMedia('(prefers-reduced-motion: reduce)').matches);" +
                                                    "o.push('focus='+document.hasFocus());" +
                                                    "o.push('Cesium='+(typeof window.Cesium));" +
                                                    "return o.join(' ; ')}catch(e){return 'probe err '+e}})()"
                                            ) { r -> probe = (r ?: "").trim('"') }
                                        }, 7000)
                                        view.postDelayed({
                                            view.evaluateJavascript("document.visibilityState+' raf='+(window.__gevRaf||0)") { r ->
                                                val t = (r ?: "").trim('"')
                                                info = (info ?: "") + " | " + t
                                            }
                                        }, 5200)
                                    }

                                    override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, r: android.webkit.WebResourceResponse) {
                                        addLog("HTTP " + r.statusCode + " " + request.url.path)
                                    }

                                    override fun onReceivedError(view: WebView, request: WebResourceRequest, err: WebResourceError) {
                                        if (!request.isForMainFrame) addLog("NET " + err.description + " " + request.url.host + request.url.path)
                                        if (request.isForMainFrame) {
                                            if (retries < 4) {
                                                // The Termux server may still be starting: try again quietly.
                                                retries++
                                                view.postDelayed({ view.loadUrl(savedNow) }, 2000)
                                            } else {
                                                error = "Can't reach $savedNow. Start the server (npm run dev in Termux), keep Termux running, then tap Reload."
                                            }
                                        }
                                    }

                                    // The page's renderer died (usually the GPU or memory ran out). Without this the whole app
                                    // would be killed. Show a message; Reload builds a fresh WebView.
                                    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                                        dead = true
                                        error = "The page stopped (usually out of memory). Tap Reload."
                                        return true
                                    }
                                }
                                wv.webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView, newProgress: Int) {
                                        progress = newProgress
                                    }

                                    // Page's own fullscreen button (e.g. Cesium's). Show what the page gives us over everything.
                                    override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                                        customCb?.onCustomViewHidden()
                                        customView = view
                                        customCb = callback
                                        onFullNow(true)
                                    }

                                    override fun onHideCustomView() {
                                        customView = null
                                        customCb = null
                                    }

                                    // A graphics failure is the usual reason for a black globe, so say so instead of staying silent.
                                    override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                        addLog(m.messageLevel().name.take(1) + ": " + m.message())
                                        if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                                            val msg = m.message()
                                            jsErr = msg.take(180) + " (" + m.sourceId().substringAfterLast('/').take(30) + ":" + m.lineNumber() + ")"
                                            val gfx = listOf("webgl", "cesium", "context", "shader", "framebuffer", "render")
                                            if (gfx.any { msg.contains(it, ignoreCase = true) }) {
                                                error = "Page error: " + msg.take(160)
                                            }
                                        }
                                        return false
                                    }

                                    override fun onPermissionRequest(request: PermissionRequest) {
                                        // Microphone only, only for the configured server, only after Android's own mic permission.
                                        val trusted = request.origin.host == Uri.parse(savedNow).host
                                        val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                                        val onlyMic = request.resources.all { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                                        if (!trusted || !wantsMic || !onlyMic) { request.deny(); return }
                                        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                                        } else {
                                            pendingMic?.deny()
                                            pendingMic = request
                                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                }
                                // Do NOT load the page yet. A WebView that is not laid out has size 0x0, and the page's
                                // scripts (CesiumJS globe, first-launch panel) measure the window once at load. They then
                                // keep a 0-size canvas (black globe) and a collapsed panel. Load on the first real layout.
                                wv.onResume()
                                wv.resumeTimers()
                                // Frame pump. The page's animations and the globe run on requestAnimationFrame, which only ticks
                                // while Android keeps redrawing the WebView. Inside Compose that redraw can stop after the first
                                // frame (page frozen: collapsed panel, black globe, while timers and WebGL still work). Asking for a
                                // redraw on every display frame keeps it ticking.
                                val pump = object : Runnable {
                                    override fun run() {
                                        if (wv.isAttachedToWindow) {
                                            wv.invalidate()
                                            wv.postOnAnimation(this)
                                        }
                                    }
                                }
                                wv.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                                    override fun onViewAttachedToWindow(v: View) { v.postOnAnimation(pump) }
                                    override fun onViewDetachedFromWindow(v: View) { v.removeCallbacks(pump) }
                                })
                                var started = false
                                wv.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
                                    if (!started && r - l > 0 && b - t > 0) {
                                        started = true
                                        (v as WebView).apply { onResume(); resumeTimers(); loadUrl(savedNow) }
                                    }
                                }
                                web = wv
                            }
                        },
                        // Stop the page and release the WebView so it cannot keep the Activity alive.
                        onRelease = { wv ->
                            try {
                                wv.stopLoading()
                                (wv.parent as? ViewGroup)?.removeView(wv)
                                wv.destroy()
                            } catch (_: Throwable) {}
                            if (web === wv) web = null
                        }
                    )
                }
            }
        }

        // Fullscreen: a small MENU pill floats over the page (top-left); it expands to the actions.
        if (full && customView == null) {
            Column(Modifier.align(Alignment.TopStart).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FloatBtn(if (menuOpen) "CLOSE" else "MENU") { menuOpen = !menuOpen }
                    if (menuOpen) {
                        FloatBtn("RELOAD") { reload() }
                        FloatBtn("CHROME") { openInChrome() }
                        FloatBtn(if (useGecko) "FIREFOX" else "WEBVIEW") { setEngine(!useGecko) }
                        FloatBtn("EXIT FULLSCREEN") { onFull(false) }
                    }
                }
                error?.let {
                    Text(
                        it, color = Amber, fontSize = 11.sp,
                        modifier = Modifier.widthIn(max = 280.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(8.dp)
                    )
                }
                info?.let {
                    Text(
                        it, color = Cyan, fontSize = 11.sp,
                        modifier = Modifier.widthIn(max = 300.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(8.dp)
                    )
                }
                jsErr?.let {
                    Text(
                        "JS: $it", color = Amber, fontSize = 10.sp,
                        modifier = Modifier.widthIn(max = 300.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(8.dp)
                    )
                }
                probe?.let {
                    Text(
                        it, color = Cyan, fontSize = 9.sp,
                        modifier = Modifier.widthIn(max = 340.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(6.dp)
                    )
                }
                if (logs.isNotEmpty()) Text(
                    logs.joinToString("\n"), color = Dim, fontSize = 8.sp,
                    modifier = Modifier.widthIn(max = 340.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(6.dp)
                )
            }
            if (progress in 1..99) Box(Modifier.align(Alignment.TopStart).fillMaxWidth(progress / 100f).height(2.dp).background(Cyan))
        }

        // The page's own fullscreen view, on top of everything.
        customView?.let { v ->
            AndroidView(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                factory = { cc ->
                    FrameLayout(cc).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        (v.parent as? ViewGroup)?.removeView(v)
                        addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    }
                },
                onRelease = { fl -> fl.removeAllViews() }
            )
        }
    }
}
