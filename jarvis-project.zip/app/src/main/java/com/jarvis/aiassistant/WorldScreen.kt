// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.Locale

private class Feed<T> {
    var items by mutableStateOf<List<T>?>(null)
    var err by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
}

private fun <T> loadInto(scope: CoroutineScope, feed: Feed<T>, block: () -> List<T>, after: (List<T>) -> Unit = {}) {
    if (feed.busy) return
    feed.busy = true
    feed.err = null
    scope.launch {
        val r = withContext(Dispatchers.IO) { runCatching(block) }
        r.onSuccess { feed.items = it; after(it) }
            .onFailure { feed.err = "Could not load: ${it.message ?: "network error"}" }
        feed.busy = false
    }
}

/** Opens a web page inside the app (never in another browser or app). */
private val LocalOpen = staticCompositionLocalOf<(String) -> Unit> { {} }

private fun isWeb(url: String?) = url != null && (url.startsWith("https://") || url.startsWith("http://"))

/** Full-screen in-app browser for links, live cams and the ISS view. Stays inside Jarvis. */
@Composable
private fun WebPane(url: String, onClose: () -> Unit) {
    val holder = remember { arrayOfNulls<WebView>(1) }
    var host by remember { mutableStateOf(Uri.parse(url).host ?: "") }
    fun back() {
        val w = holder[0]
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    BackHandler { back() }
    DisposableEffect(Unit) { onDispose { try { holder[0]?.destroy() } catch (_: Throwable) {} } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudBtn("Back", kind = BtnKind.Outline) { back() }
            Text(host, Modifier.weight(1f), color = Dim, fontSize = 12.sp, fontFamily = MonoFont, maxLines = 1, overflow = TextOverflow.Ellipsis)
            HudBtn("Close", kind = BtnKind.Outline) { onClose() }
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webViewClient = object : WebViewClient() {
                        // Only web pages load, and they load here. intent:, market: and other app links are blocked.
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val u = request?.url ?: return true
                            return !(u.scheme == "https" || u.scheme == "http")
                        }
                        override fun onPageFinished(view: WebView?, u: String?) {
                            host = Uri.parse(u ?: url).host ?: host
                        }
                    }
                    loadUrl(url)
                    holder[0] = this
                }
            }
        )
    }
}

@Composable
private fun Toggle(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    HudCard(Modifier.fillMaxWidth(), pad = 10.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, color = Dim, fontSize = 11.sp)
            }
            Spacer(Modifier.width(8.dp))
            HudSwitch(checked, onChange)
        }
    }
}

@Composable
private fun Row3(title: String, sub: String, url: String? = null, accent: Color = Cyan) {
    val open = LocalOpen.current
    HudCard(Modifier.fillMaxWidth(), onClick = if (isWeb(url)) ({ open(url!!) }) else null, pad = 9.dp, accent = accent) {
        Column(Modifier.fillMaxWidth()) {
            Text(title, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Text(sub, color = Dim, fontSize = 11.sp, fontFamily = MonoFont, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun <T> FeedBody(feed: Feed<T>, empty: String, row: @Composable (T) -> Unit) {
    when {
        feed.busy && feed.items == null -> Text("Loading...", color = Dim, fontSize = 12.sp)
        feed.err != null -> Text(feed.err ?: "", color = Amber, fontSize = 12.sp)
        feed.items == null -> Text("Not loaded yet.", color = Dim, fontSize = 12.sp)
        feed.items!!.isEmpty() -> Text(empty, color = Dim, fontSize = 12.sp)
        else -> feed.items!!.take(6).forEach { row(it) }
    }
}

@Composable
private fun WindyMap(url: String) {
    val holder = remember { arrayOfNulls<WebView>(1) }
    DisposableEffect(Unit) { onDispose { try { holder[0]?.destroy() } catch (_: Throwable) {} } }
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(340.dp).clip(RoundedCornerShape(12.dp)),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                // The map may only stay on windy.com.
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val h = request?.url?.host ?: return true
                        return !(h == "windy.com" || h.endsWith(".windy.com"))
                    }
                }
                loadUrl(url)
                holder[0] = this
            }
        }
    )
}

private fun planeTag(p: Plane) = when {
    p.squawk == "7700" -> "EMERGENCY 7700"
    p.squawk == "7600" -> "RADIO FAILURE 7600"
    p.squawk == "7500" -> "HIJACK CODE 7500"
    p.mil -> "MILITARY"
    else -> "AIRCRAFT"
}

@Composable
fun WorldScreen(store: Store) {
    val ctx = LocalContext.current
    val sp = remember { WorldWatch.sp(ctx) }
    val scope = rememberCoroutineScope()

    var on by remember { mutableStateOf(sp.getBoolean("on", false)) }
    var every by remember { mutableIntStateOf(sp.getInt("every", 30)) }
    var spk by remember { mutableStateOf(sp.getBoolean("spk", true)) }
    var qOn by remember { mutableStateOf(sp.getBoolean("q", true)) }
    var qMag by remember { mutableFloatStateOf(sp.getFloat("qmag", 5.5f)) }
    var disOn by remember { mutableStateOf(sp.getBoolean("dis", true)) }
    var nwsOn by remember { mutableStateOf(sp.getBoolean("nws", false)) }
    var newsOn by remember { mutableStateOf(sp.getBoolean("news", false)) }
    var kw by remember { mutableStateOf(sp.getString("kw", "earthquake, tsunami") ?: "") }
    var airOn by remember { mutableStateOf(sp.getBoolean("air", false)) }
    var lat by remember { mutableStateOf(sp.getString("lat", "") ?: "") }
    var lon by remember { mutableStateOf(sp.getString("lon", "") ?: "") }
    var nm by remember { mutableStateOf(sp.getInt("nm", 100).toString()) }
    var aisKey by remember { mutableStateOf(Secrets.decrypt(sp.getString("aisKey", ""))) }
    var saved by remember { mutableStateOf<String?>(null) }
    var showMap by remember { mutableStateOf(false) }

    val quakes = remember { Feed<Quake>() }
    val disasters = remember { Feed<Hazard>() }
    val usAlerts = remember { Feed<Hazard>() }
    val news = remember { Feed<Article>() }
    val iss = remember { Feed<IssPos>() }
    val planes = remember { Feed<Plane>() }
    val ships = remember { Feed<Ship>() }

    fun putB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    fun loadQuakes() = loadInto(scope, quakes, { WorldWatch.quakes(qMag.toDouble()) }) { l ->
        l.firstOrNull()?.let { WorldWatch.cachePut(ctx, "quake", WorldWatch.quakeLine(it)) }
    }
    fun loadDisasters() = loadInto(scope, disasters, { WorldWatch.disasters() }) { l ->
        l.firstOrNull()?.let { WorldWatch.cachePut(ctx, "disaster", "${it.level} ${it.kind}: ${it.title}") }
    }
    fun loadNews() = loadInto(scope, news, { WorldWatch.news(kw) }) { l ->
        l.firstOrNull()?.let { WorldWatch.cachePut(ctx, "news", it.title) }
    }
    fun loadPlanes() = loadInto(scope, planes, {
        val a = WorldWatch.area(ctx)
        val e = WorldWatch.emergencies(a?.lat, a?.lon)
        val m = if (a != null) WorldWatch.military(a.lat, a.lon, a.nm) else emptyList()
        (e + m).distinctBy { it.hex + it.squawk }
    })
    fun loadShips() = loadInto(scope, ships, {
        val a = WorldWatch.area(ctx) ?: throw IOException("Save your area first.")
        val k = Secrets.decrypt(sp.getString("aisKey", ""))
        if (k.isBlank()) throw IOException("Save your free AISStream key first.")
        WorldWatch.ships(k, a.lat, a.lon, a.nm)
    })

    LaunchedEffect(Unit) {
        loadQuakes()
        loadDisasters()
        if (nwsOn) loadInto(scope, usAlerts, { WorldWatch.usAlerts() })
        if (newsOn && kw.isNotBlank()) loadNews()
        if (airOn) loadPlanes()
    }
    // ISS position refreshes while the screen is visible.
    LaunchWhileStarted {
        while (true) {
            loadInto(scope, iss, { listOf(WorldWatch.iss()) })
            delay(15000)
        }
    }

    var webUrl by remember { mutableStateOf<String?>(null) }
    webUrl?.let { u ->
        WebPane(u) { webUrl = null }
        return
    }
    val openIn: (String) -> Unit = { if (isWeb(it)) webUrl = it }

    val area = WorldWatch.area(ctx)
    val mapLat = area?.lat ?: 20.0
    val mapLon = area?.lon ?: 0.0
    val mapZoom = if (area != null) 5 else 2

    CompositionLocalProvider(LocalOpen provides openIn) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ScreenHeader("WORLD WATCH", "Free public data. Nothing is sent except normal requests to each service.")

        // ---- Background alerts
        SectionTitle("BACKGROUND ALERTS")
        Toggle("Alert me in the background", "Checks the feeds you switch on below and sends a notification for anything new. Notifications must be allowed for this app.", on) {
            on = it; putB("on", it)
            if (it) { WorldWatch.schedule(ctx, 60_000L); store.log("World Watch alerts on") } else { WorldWatch.cancel(ctx); store.log("World Watch alerts off") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 60).forEach { m ->
                HudButton("Every $m min", Modifier.weight(1f), active = every == m) {
                    every = m; sp.edit().putInt("every", m).apply()
                    if (on) WorldWatch.schedule(ctx)
                }
            }
        }
        Toggle("Speak alerts", "Jarvis says new alerts aloud when the wake word listener is waiting.", spk) { spk = it; putB("spk", it) }
        Text("Android may delay checks to save battery, so alerts are not instant. Each switch below also decides what is checked.", color = Dim, fontSize = 11.sp)

        // ---- My area
        SectionTitle("MY AREA")
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Used for flights, military aircraft, ships and the weather map. Stays on this phone; the coordinates are sent to the flight and ship services you use.", color = Dim, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudField(lat, { lat = it }, "Latitude", Modifier.weight(1f))
                    HudField(lon, { lon = it }, "Longitude", Modifier.weight(1f))
                }
                HudField(nm, { nm = it.filter { c -> c.isDigit() }.take(3) }, "Radius, nautical miles (10 to 250)", Modifier.fillMaxWidth())
                HudField(aisKey, { aisKey = it }, "AISStream key (free, for ships)", Modifier.fillMaxWidth(), secret = true)
                HudBtn("Save area and key", Modifier.fillMaxWidth()) {
                    val la = lat.trim().toDoubleOrNull()
                    val lo = lon.trim().toDoubleOrNull()
                    if (lat.isNotBlank() && (la == null || la !in -90.0..90.0)) { saved = "Latitude must be between -90 and 90."; return@HudBtn }
                    if (lon.isNotBlank() && (lo == null || lo !in -180.0..180.0)) { saved = "Longitude must be between -180 and 180."; return@HudBtn }
                    val enc = Secrets.encrypt(aisKey.trim())
                    sp.edit().putString("lat", lat.trim()).putString("lon", lon.trim())
                        .putInt("nm", (nm.toIntOrNull() ?: 100).coerceIn(10, 250))
                        .putString("aisKey", if (aisKey.isBlank()) "" else (enc ?: "")).apply()
                    saved = if (aisKey.isNotBlank() && enc == null) "Area saved. The key could not be stored securely, so it was not saved." else "Saved."
                    store.log("World Watch area saved")
                }
                saved?.let { Text(it, color = if (it == "Saved.") Green else Amber, fontSize = 12.sp) }
            }
        }

        // ---- Earthquakes
        SectionTitle("EARTHQUAKES (USGS)")
        Toggle("Earthquake alerts", "Worldwide, last 24 hours.", qOn) { qOn = it; putB("q", it) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(4.5f, 5.5f, 6.5f).forEach { m ->
                HudButton("M$m+", Modifier.weight(1f), active = qMag == m) {
                    qMag = m; sp.edit().putFloat("qmag", m).apply(); loadQuakes()
                }
            }
        }
        FeedBody(quakes, "No earthquakes at this size in the last 24 hours.") { q ->
            Row3("M${"%.1f".format(Locale.US, q.mag)}  ${q.place}", WorldWatch.ago((System.currentTimeMillis() - q.time) / 60000) + " ago", q.url, if (q.mag >= 6.0) Danger else Cyan)
        }

        // ---- Disasters and weather
        SectionTitle("DISASTERS AND WEATHER")
        Toggle("Global disaster alerts (GDACS)", "Orange and red cyclones, floods, volcanoes, wildfires, tsunamis.", disOn) { disOn = it; putB("dis", it) }
        FeedBody(disasters, "No orange or red disaster alerts right now.") { h ->
            Row3("${h.level.uppercase(Locale.ROOT)}  ${h.kind}: ${h.title}", h.where_, null, if (h.level.equals("Red", true)) Danger else Amber)
        }
        Toggle("US severe weather (NOAA)", "Severe and extreme alerts. United States only.", nwsOn) {
            nwsOn = it; putB("nws", it)
            if (it) loadInto(scope, usAlerts, { WorldWatch.usAlerts() })
        }
        if (nwsOn) FeedBody(usAlerts, "No severe US alerts right now.") { h -> Row3(h.title, h.where_, null, Amber) }

        // ---- News
        SectionTitle("NEWS WATCH (GDELT)")
        Toggle("Keyword news alerts", "Looks at the last hour of world news in 100+ languages.", newsOn) {
            newsOn = it; putB("news", it)
            if (it && kw.isNotBlank()) loadNews()
        }
        HudField(kw, { kw = it; sp.edit().putString("kw", it).apply() }, "Keywords, separated by commas", Modifier.fillMaxWidth())
        HudBtn("Check news now", Modifier.fillMaxWidth(), BtnKind.Outline) { loadNews() }
        if (news.items != null || news.err != null || news.busy) {
            FeedBody(news, "Nothing new for those keywords in the last hour.") { a -> Row3(a.title, a.domain, a.url) }
        }

        // ---- ISS
        SectionTitle("INTERNATIONAL SPACE STATION")
        HudCard(Modifier.fillMaxWidth()) {
            val p = iss.items?.firstOrNull()
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (p != null) {
                    Text("Lat ${"%.2f".format(Locale.US, p.lat)}  Lon ${"%.2f".format(Locale.US, p.lon)}", fontFamily = MonoFont, fontSize = 13.sp)
                    Text("${p.altKm.toInt()} km up, ${p.kmh.toInt()} km/h, ${p.visibility}", color = Dim, fontSize = 11.sp)
                } else Text(iss.err ?: "Loading...", color = if (iss.err != null) Amber else Dim, fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudBtn("Live view", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.youtube.com/results?search_query=ISS+live+earth+view+NASA") }
            HudBtn("Track on map", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.n2yo.com/?s=25544") }
        }

        // ---- Weather map
        SectionTitle("LIVE WEATHER MAP (WINDY)")
        HudBtn(if (showMap) "Close map" else "Open wind map", Modifier.fillMaxWidth(), BtnKind.Outline) { showMap = !showMap }
        if (showMap) WindyMap(WorldWatch.windyUrl(mapLat, mapLon, mapZoom))

        // ---- Flights
        SectionTitle("FLIGHTS (ADSB.LOL)")
        Toggle("Aircraft alerts", "Emergency codes 7700 and 7500 (within 300 nm of your area, or worldwide with no area) and military aircraft inside your radius.", airOn) { airOn = it; putB("air", it) }
        HudBtn("Scan now", Modifier.fillMaxWidth(), BtnKind.Outline) { loadPlanes() }
        if (planes.items != null || planes.err != null || planes.busy) {
            FeedBody(planes, "No emergency or military aircraft found.") { p ->
                val d = if (p.distNm >= 0) "${p.distNm.toInt()} nm away" else ""
                Row3("${planeTag(p)}  ${p.call.ifBlank { p.hex }} ${p.type}".trim(), "$d  alt ${p.alt}".trim(), "https://globe.adsb.lol/?icao=${p.hex}", if (p.squawk == "7700" || p.squawk == "7500") Danger else Amber)
            }
        }
        Text("Community-run ADS-B data. Aircraft that do not broadcast or are not in range of a receiver will not appear.", color = Dim, fontSize = 11.sp)

        // ---- Ships
        SectionTitle("SHIPS (AISSTREAM)")
        HudBtn("Listen for ships in my area", Modifier.fillMaxWidth(), BtnKind.Outline) { loadShips() }
        if (ships.items != null || ships.err != null || ships.busy) {
            FeedBody(ships, "No ships reported in your area during the listen window.") { s ->
                val a = WorldWatch.area(ctx)
                val d = if (a != null) "${WorldWatch.distNm(a.lat, a.lon, s.lat, s.lon).toInt()} nm away" else ""
                Row3(s.name, "MMSI ${s.mmsi}  $d".trim())
            }
            if ((ships.items?.size ?: 0) > 6) Text("${ships.items!!.size} ships seen. Showing the nearest 6.", color = Dim, fontSize = 11.sp)
        }
        Text("Needs a free key from aisstream.io. It listens for about 8 seconds each time, so it is manual only, not a background alert.", color = Dim, fontSize = 11.sp)

        // ---- Cams and radio
        SectionTitle("LIVE CAMS AND RADIO")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudBtn("Windy webcams", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.windy.com/webcams") }
            HudBtn("YouTube live cams", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.youtube.com/results?search_query=live+cam&sp=EgJAAQ%253D%253D") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudBtn("EarthCam", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.earthcam.com") }
            HudBtn("LiveATC radio", Modifier.weight(1f), BtnKind.Outline) { openIn("https://www.liveatc.net") }
        }
        Text("These open inside Jarvis. Only cameras their owners publish are included.", color = Dim, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
    }
    }
}
