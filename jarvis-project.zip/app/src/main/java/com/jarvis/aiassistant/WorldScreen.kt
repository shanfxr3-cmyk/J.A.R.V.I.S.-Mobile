// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

private const val WORLD_KEY = "worldUrl"
private const val WORLD_DEFAULT = "http://localhost:4173"

/** Returns a safe URL or null. Plain http is only allowed for localhost (Termux); everything else must be https. */
private fun cleanWorldUrl(raw: String): String? {
    var u = raw.trim()
    if (u.isEmpty()) return null
    if (!u.contains("://")) {
        val local = u.startsWith("localhost") || u.startsWith("127.0.0.1")
        u = (if (local) "http://" else "https://") + u
    }
    val uri = try { Uri.parse(u) } catch (_: Exception) { return null }
    val host = uri.host ?: return null
    return when (uri.scheme) {
        "https" -> u
        "http" -> if (host == "localhost" || host == "127.0.0.1") u else null
        else -> null
    }
}

/** Small translucent pill that floats over the page in fullscreen. */
@Composable
private fun FloatBtn(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .background(Bg.copy(alpha = 0.7f), shape)
            .border(1.dp, Cyan.copy(alpha = 0.6f), shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Cyan, fontSize = 11.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/**
 * God's Eye View (github.com/bilawalsidhu/gods-eye-view, MIT) shown in a WebView.
 * The web app and its key-holding proxy run elsewhere (Termux on this phone, or a hosted copy).
 * No keys are stored in this app for it.
 *
 * [full] = true: the page fills the whole screen (system bars and the bottom bar are hidden by MainActivity)
 * and only a small MENU pill floats over it. [onFull] switches between fullscreen and the normal layout.
 *
 * The WebView is deliberately NOT clipped to a rounded shape and MainActivity does not fade this screen in:
 * both force Android to draw the WebView through an offscreen layer, which leaves WebGL (the globe) black
 * while ordinary HTML still shows.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WorldScreen(store: Store, full: Boolean, onFull: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    var saved by remember { mutableStateOf(cleanWorldUrl(sp.getString(WORLD_KEY, WORLD_DEFAULT) ?: WORLD_DEFAULT) ?: WORLD_DEFAULT) }
    val savedNow by rememberUpdatedState(saved)
    val onFullNow by rememberUpdatedState(onFull)
    var field by remember { mutableStateOf(saved) }
    var editing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var web by remember { mutableStateOf<WebView?>(null) }
    var pendingMic by remember { mutableStateOf<PermissionRequest?>(null) }
    // Page-requested fullscreen (the page's own fullscreen button): the page hands us a view to show.
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    // Bumped to build a fresh WebView (after the page's renderer process died).
    var webKey by remember { mutableIntStateOf(0) }
    var dead by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val r = pendingMic
        pendingMic = null
        if (r != null) {
            if (ok) r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else r.deny()
        }
    }

    fun reload() {
        error = null
        if (dead) {
            dead = false
            progress = 0
            web = null
            webKey++
        } else {
            web?.loadUrl(saved)
        }
    }

    // Pause the page (3D rendering, timers) when the app is in the background.
    DisposableEffect(web) {
        val owner = ctx as? LifecycleOwner
        val wv = web
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> wv?.onPause()
                Lifecycle.Event.ON_RESUME -> wv?.onResume()
                else -> {}
            }
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }

    // Back closes the page's own fullscreen first.
    BackHandler(enabled = customView != null) {
        customCb?.onCustomViewHidden()
        customCb = null
        customView = null
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().then(if (full) Modifier else Modifier.padding(12.dp))) {
            if (!full) {
                ScreenHeader("WORLD", "God's Eye View. Needs its server running (Termux or hosted).")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudBtn("Reload", Modifier.weight(1f), BtnKind.Outline) { reload() }
                    HudBtn(if (editing) "Close" else "Set URL", Modifier.weight(1f), BtnKind.Outline) { editing = !editing; field = saved }
                    HudBtn("Fullscreen", Modifier.weight(1f), BtnKind.Primary) { onFull(true) }
                }
                if (editing) {
                    Spacer(Modifier.height(8.dp))
                    HudField(field, { field = it }, "Server URL (http://localhost:4173)", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    HudBtn("Load", Modifier.fillMaxWidth()) {
                        val u = cleanWorldUrl(field)
                        if (u == null) {
                            error = "Use https://, or http:// only for localhost."
                        } else {
                            saved = u
                            field = u
                            sp.edit().putString(WORLD_KEY, u).apply()
                            store.log("World view URL changed")
                            error = null
                            editing = false
                            if (dead) reload() else web?.loadUrl(u)
                        }
                    }
                }
                error?.let { Text(it, color = Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                if (progress in 1..99) {
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth(progress / 100f).height(2.dp).background(Cyan))
                }
            }
            // No clip() here on purpose (see the note above). A plain rectangular border is safe.
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .then(if (full) Modifier else Modifier.padding(top = 8.dp).border(1.dp, Cyan.copy(alpha = 0.35f)))
            ) {
                key(webKey) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            WebView(c).also { wv ->
                                wv.setBackgroundColor(android.graphics.Color.parseColor("#050B14"))
                                wv.overScrollMode = View.OVER_SCROLL_NEVER
                                wv.settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    mediaPlaybackRequiresUserGesture = false
                                    allowFileAccess = false
                                    allowContentAccess = false
                                    setSupportZoom(false)
                                    // Behave like Chrome for pages that rely on <meta name="viewport">.
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    // Present as plain mobile Chrome (drop the WebView marker) so the page does not
                                    // take a reduced "embedded browser" path.
                                    userAgentString = userAgentString
                                        .replace("; wv)", ")")
                                        .replace(Regex("Version/\\d+\\.\\d+ "), "")
                                }
                                wv.webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                        // Stay inside the app only for the configured server. Anything else opens in the browser.
                                        if (request.url.host == Uri.parse(savedNow).host) return false
                                        try {
                                            c.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                        } catch (_: Exception) {}
                                        return true
                                    }

                                    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                        error = null
                                    }

                                    override fun onReceivedError(view: WebView, request: WebResourceRequest, err: WebResourceError) {
                                        if (request.isForMainFrame) {
                                            error = "Can't reach $savedNow. Start the server (npm run dev in Termux), keep Termux running, then tap Reload."
                                        }
                                    }

                                    // The page's renderer died (usually the GPU or memory ran out). Without this the whole app
                                    // would be killed. Show a message; Reload builds a fresh WebView.
                                    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                                        dead = true
                                        error = "The page stopped (usually out of memory). Tap Reload."
                                        return true
                                    }
                                }
                                wv.webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView, newProgress: Int) {
                                        progress = newProgress
                                    }

                                    // Page's own fullscreen button (e.g. Cesium's). Show what the page gives us over everything.
                                    override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                                        customCb?.onCustomViewHidden()
                                        customView = view
                                        customCb = callback
                                        onFullNow(true)
                                    }

                                    override fun onHideCustomView() {
                                        customView = null
                                        customCb = null
                                    }

                                    // A graphics failure is the usual reason for a black globe, so say so instead of staying silent.
                                    override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                        if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR &&
                                            m.message().contains("webgl", ignoreCase = true)
                                        ) {
                                            error = "Page graphics (WebGL) error: " + m.message().take(140)
                                        }
                                        return false
                                    }

                                    override fun onPermissionRequest(request: PermissionRequest) {
                                        // Microphone only, only for the configured server, only after Android's own mic permission.
                                        val trusted = request.origin.host == Uri.parse(savedNow).host
                                        val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                                        val onlyMic = request.resources.all { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                                        if (!trusted || !wantsMic || !onlyMic) { request.deny(); return }
                                        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                                        } else {
                                            pendingMic?.deny()
                                            pendingMic = request
                                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                }
                                wv.loadUrl(saved)
                                web = wv
                            }
                        },
                        // Stop the page and release the WebView so it cannot keep the Activity alive.
                        onRelease = { wv ->
                            try {
                                wv.stopLoading()
                                (wv.parent as? ViewGroup)?.removeView(wv)
                                wv.destroy()
                            } catch (_: Throwable) {}
                            if (web === wv) web = null
                        }
                    )
                }
            }
        }

        // Fullscreen: a small MENU pill floats over the page (top-left); it expands to the actions.
        if (full && customView == null) {
            Column(Modifier.align(Alignment.TopStart).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FloatBtn(if (menuOpen) "CLOSE" else "MENU") { menuOpen = !menuOpen }
                    if (menuOpen) {
                        FloatBtn("RELOAD") { reload() }
                        FloatBtn("EXIT FULLSCREEN") { onFull(false) }
                    }
                }
                error?.let {
                    Text(
                        it, color = Amber, fontSize = 11.sp,
                        modifier = Modifier.widthIn(max = 280.dp).background(Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp)).padding(8.dp)
                    )
                }
            }
            if (progress in 1..99) Box(Modifier.align(Alignment.TopStart).fillMaxWidth(progress / 100f).height(2.dp).background(Cyan))
        }

        // The page's own fullscreen view, on top of everything.
        customView?.let { v ->
            AndroidView(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                factory = { cc ->
                    FrameLayout(cc).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        (v.parent as? ViewGroup)?.removeView(v)
                        addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    }
                },
                onRelease = { fl -> fl.removeAllViews() }
            )
        }
    }
}
