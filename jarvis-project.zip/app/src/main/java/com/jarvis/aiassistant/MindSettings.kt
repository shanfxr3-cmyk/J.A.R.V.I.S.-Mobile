// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Personality, custom instructions and the list of things Jarvis remembers. */
@Composable
fun MindPage(store: Store, onBack: () -> Unit) {
    var instr by remember { mutableStateOf(store.instructions) }
    var city by remember { mutableStateOf(store.city) }
    var pers by remember { mutableStateOf(store.personality) }
    SubHeader("PERSONALITY AND MEMORY", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Note("Pick how Jarvis talks.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("classic" to "CLASSIC", "concise" to "CONCISE", "friendly" to "FRIENDLY").forEach { (k, label) ->
                    HudButton(label, Modifier.weight(1f), pers == k) { pers = k; store.setMind(instr, pers, city) }
                }
            }
            Note("Your own instructions, for example: call me boss, keep answers short, I am vegetarian. They never override safety rules or confirmations.")
            HudField(instr, { instr = it.take(600) }, "Custom instructions", Modifier.fillMaxWidth())
            Note("Saved city for weather. Only the city name is sent, never your location.")
            HudField(city, { city = it }, "City", Modifier.fillMaxWidth())
            HudBtn("Save", Modifier.fillMaxWidth()) { store.setMind(instr, pers, city) }
        }
    }
    SectionTitle("REMEMBERED (" + store.memories.size + ")")
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Note("Say \"remember that ...\" or \"forget ...\" any time. Stored on this phone only.")
            if (store.memories.isEmpty()) Note("Nothing yet.")
            store.memories.toList().forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m, color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    HudBtn("Forget", kind = BtnKind.Outline) { store.forgetMemory(m) }
                }
            }
            if (store.memories.isNotEmpty()) HudBtn("Forget everything", Modifier.fillMaxWidth(), BtnKind.Danger) { store.clearMemories() }
        }
    }
}

/** Morning briefing and watched topics. Both are read-only: they look things up and notify, they never act. */
@Composable
fun BriefPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var h by remember { mutableStateOf(store.briefHour.toString()) }
    var m by remember { mutableStateOf("%02d".format(store.briefMin)) }
    var topic by remember { mutableStateOf("") }
    SubHeader("BRIEFING AND WATCH", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Morning briefing", color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.weight(1f))
                HudSwitch(store.briefOn, { on ->
                    store.setBrief(on, h.toIntOrNull() ?: store.briefHour, m.toIntOrNull() ?: store.briefMin); Briefing.reschedule(ctx, store)
                })
            }
            Note("A notification with the weather for your saved city, your tasks and headlines for watched topics. Needs an AI key and notifications allowed. Android may deliver it a few minutes late to save battery.")
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudField(h, { h = it.filter(Char::isDigit).take(2) }, "Hour (0-23)", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                HudField(m, { m = it.filter(Char::isDigit).take(2) }, "Minute", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                HudBtn("Save") { store.setBrief(store.briefOn, h.toIntOrNull() ?: 7, m.toIntOrNull() ?: 0); Briefing.reschedule(ctx, store) }
            }
        }
    }
    SectionTitle("WATCHED TOPICS (" + store.watches.size + "/5)")
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Note("About every 6 hours Jarvis searches the news for each topic and notifies you only if something new happened. Each check uses your AI key. You can also say: watch the Mars mission.")
            store.watches.toList().forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t, color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.weight(1f))
                    HudBtn("Stop", kind = BtnKind.Outline) { store.removeWatch(t); Briefing.reschedule(ctx, store) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudField(topic, { topic = it }, "Add a topic", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                HudBtn("Add") { if (store.addWatch(topic)) { topic = ""; Briefing.reschedule(ctx, store) } }
            }
        }
    }
}
