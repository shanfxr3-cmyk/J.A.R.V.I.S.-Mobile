// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Optional lock: fingerprint, face or the phone's screen lock (Android 11+). Uses the system's own prompt. */
object AppLock {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    const val GRACE_MS = 30_000L

    fun available(ctx: Context): Boolean = Build.VERSION.SDK_INT >= 30 && try {
        ctx.getSystemService(BiometricManager::class.java).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Throwable) { false }

    /** Locked again after the app has been away longer than the grace period. */
    fun shouldRelock(awayMs: Long) = awayMs > GRACE_MS

    fun prompt(ctx: Context, onOk: () -> Unit, onFail: (String) -> Unit) {
        try {
            val p = BiometricPrompt.Builder(ctx).setTitle("Unlock J.A.R.V.I.S.").setAllowedAuthenticators(AUTH).build()
            p.authenticate(CancellationSignal(), ctx.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { onOk() }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { onFail(errString?.toString().orEmpty()) }
            })
        } catch (e: Throwable) { onFail(e.message ?: "Could not open the unlock prompt.") }
    }
}

@Composable
fun LockScreen(note: String?, onUnlock: () -> Unit) {
    LaunchedEffect(Unit) { onUnlock() }
    Column(Modifier.fillMaxSize().background(Bg).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("J.A.R.V.I.S. IS LOCKED", color = Cyan, fontFamily = HudFont, fontSize = 16.sp)
        if (!note.isNullOrBlank()) Text(note, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        HudBtn("Unlock", Modifier.padding(top = 16.dp)) { onUnlock() }
    }
}
