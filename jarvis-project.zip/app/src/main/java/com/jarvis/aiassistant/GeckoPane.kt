package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.FrameLayout
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

/** One Firefox engine (GeckoRuntime) for the whole app. Android allows only one per process. */
object GeckoEngine {
    @Volatile private var rt: GeckoRuntime? = null

    fun runtime(ctx: Context): GeckoRuntime {
        rt?.let { return it }
        synchronized(this) {
            rt?.let { return it }
            val settings = GeckoRuntimeSettings.Builder()
                // The page is built from fixed-size panels: ignore the phone's font size setting.
                .automaticFontSizeAdjustment(false)
                .build()
            val created = GeckoRuntime.create(ctx.applicationContext, settings)
            rt = created
            return created
        }
    }
}

/**
 * The World page rendered by Firefox's engine (GeckoView) instead of Android System WebView.
 * Same web standards as desktop Firefox; WebGL (CesiumJS globe), animations and the microphone work.
 *
 * [onSession] hands the live session to the caller (for reload / load another address) and null when released.
 * [onFatal] is called if the engine could not start, so the caller can fall back to WebView.
 */
@Composable
fun GeckoPane(
    url: String,
    modifier: Modifier,
    onSession: (GeckoSession?) -> Unit,
    onProgress: (Int) -> Unit,
    onFailed: () -> Unit,
    onLoaded: () -> Unit,
    onFatal: (String) -> Unit
) {
    val urlNow by rememberUpdatedState(url)
    val onSessionNow by rememberUpdatedState(onSession)
    val onProgressNow by rememberUpdatedState(onProgress)
    val onFailedNow by rememberUpdatedState(onFailed)
    val onLoadedNow by rememberUpdatedState(onLoaded)
    val onFatalNow by rememberUpdatedState(onFatal)

    // Android's own microphone permission, asked only when the page really wants the microphone.
    var pendingAndroid by remember { mutableStateOf<GeckoSession.PermissionDelegate.Callback?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val cb = pendingAndroid
        pendingAndroid = null
        if (cb != null) { if (ok) cb.grant() else cb.reject() }
    }
    val micLauncherNow by rememberUpdatedState(micLauncher)

    AndroidView(
        modifier = modifier,
        factory = { c ->
            val holder = FrameLayout(c)
            val main = Handler(Looper.getMainLooper())
            try {
                val runtime = GeckoEngine.runtime(c)
                val session = GeckoSession()
                var attempts = 0

                session.progressDelegate = object : GeckoSession.ProgressDelegate {
                    override fun onPageStart(session: GeckoSession, url: String) {
                        onProgressNow(1)
                    }

                    override fun onProgressChange(session: GeckoSession, progress: Int) {
                        onProgressNow(progress)
                    }

                    override fun onPageStop(session: GeckoSession, success: Boolean) {
                        onProgressNow(100)
                        if (success) {
                            attempts = 0
                            onLoadedNow()
                        } else if (attempts < 4) {
                            // The Termux server may still be starting: try again quietly.
                            attempts++
                            main.postDelayed({ session.loadUri(urlNow) }, 2000)
                        } else {
                            onFailedNow()
                        }
                    }
                }

                session.contentDelegate = object : GeckoSession.ContentDelegate {
                    override fun onCrash(session: GeckoSession) {
                        // The page process crashed: start the page again.
                        main.post { session.loadUri(urlNow) }
                    }

                    override fun onKill(session: GeckoSession) {
                        main.post { session.loadUri(urlNow) }
                    }
                }

                session.permissionDelegate = object : GeckoSession.PermissionDelegate {
                    override fun onAndroidPermissionsRequest(
                        session: GeckoSession,
                        permissions: Array<out String>?,
                        callback: GeckoSession.PermissionDelegate.Callback
                    ) {
                        val wantsMic = permissions?.contains(Manifest.permission.RECORD_AUDIO) == true
                        val onlyMic = permissions?.all { it == Manifest.permission.RECORD_AUDIO } == true
                        if (!wantsMic || !onlyMic) { callback.reject(); return }
                        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            callback.grant()
                        } else {
                            pendingAndroid = callback
                            micLauncherNow.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }

                    override fun onMediaPermissionRequest(
                        session: GeckoSession,
                        uri: String,
                        video: Array<GeckoSession.PermissionDelegate.MediaSource>?,
                        audio: Array<GeckoSession.PermissionDelegate.MediaSource>?,
                        callback: GeckoSession.PermissionDelegate.MediaCallback
                    ) {
                        // Microphone only, and only for the configured server.
                        val trusted = try { Uri.parse(uri).host == Uri.parse(urlNow).host } catch (_: Throwable) { false }
                        val mic = audio?.firstOrNull()
                        if (trusted && mic != null && (video == null || video.isEmpty())) {
                            callback.grant(null as GeckoSession.PermissionDelegate.MediaSource?, mic)
                        } else {
                            callback.reject()
                        }
                    }
                }

                session.open(runtime)
                val view = GeckoView(c)
                view.keepScreenOn = true
                view.setSession(session)
                holder.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
                session.loadUri(urlNow)
                onSessionNow(session)
            } catch (t: Throwable) {
                main.post { onFatalNow((t.message ?: t.javaClass.simpleName).take(160)) }
            }
            holder
        },
        onRelease = { holder ->
            try {
                for (i in 0 until holder.childCount) {
                    (holder.getChildAt(i) as? GeckoView)?.releaseSession()?.close()
                }
                holder.removeAllViews()
            } catch (_: Throwable) {}
            onSessionNow(null)
        }
    )
}
