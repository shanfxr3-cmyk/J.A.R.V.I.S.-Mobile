package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HoloScreen() {
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("HOLOGRAPHIC CONTROL", "3D ENGINE: NOT BUILT YET")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("3D engine: offline (Phase 3)", color = Amber, fontSize = 14.sp)
                Text("Camera tracking: not implemented (Phase 4)", color = Dim, fontSize = 13.sp)
                Text("Gesture control: not implemented (Phase 5)", color = Dim, fontSize = 13.sp)
            }
        }
    }
}
