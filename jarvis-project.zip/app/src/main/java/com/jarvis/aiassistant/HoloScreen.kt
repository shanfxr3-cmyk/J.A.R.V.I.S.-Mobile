package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlin.math.min

private val Orange = Color(0xFFFFA630)

@Composable
private fun HoloBtn(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 8.dp) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Orange else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

@Composable
private fun HandOverlay(ts: TrackState, modifier: Modifier) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(50); tick++ } }
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val refresh = tick
        val d = ts.data ?: return@Canvas
        val s = min(size.width / d.imgW, size.height / d.imgH)
        val ox = (size.width - d.imgW * s) / 2f
        val oy = (size.height - d.imgH * s) / 2f
        for (h in d.hands) {
            fun pt(i: Int) = Offset(ox + h[i].x * d.imgW * s, oy + h[i].y * d.imgH * s)
            if (h.size < 21) continue
            for ((a, b) in HAND_CONNECTIONS) drawLine(Cyan, pt(a), pt(b), strokeWidth = 2f)
            for (i in 0 until 21) drawCircle(if (i == 4 || i == 8) Orange else Color.White, 4f, pt(i))
        }
    }
}

@Composable
fun HoloScreen() {
    val ctx = LocalContext.current
    val st = remember { HoloState() }
    val glView = remember { HoloGLView(ctx, st) }
    val ts = remember { TrackState() }
    val tracker = remember { HandTracker(ctx.applicationContext, ts) }
    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val act = ctx as? ComponentActivity
    var tracking by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }

    DisposableEffect(act, glView) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) glView.onPause()
            else if (e == Lifecycle.Event.ON_RESUME) glView.onResume()
        }
        act?.lifecycle?.addObserver(obs)
        onDispose {
            act?.lifecycle?.removeObserver(obs)
            glView.onPause()
            tracker.stop()
        }
    }

    // Camera and detector run only while `tracking` is true.
    LaunchedEffect(tracking, front) {
        if (tracking && act != null) tracker.start(act, previewView, front) else tracker.stop()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { ts.error = null; tracking = true }
        else ts.error = "Camera permission denied. Allow it in Android app settings to use hand tracking."
    }

    var tick by remember { mutableIntStateOf(0) }
    var showHelp by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(150); tick++ } }
    @Suppress("UNUSED_VARIABLE") val refresh = tick

    val data = ts.data
    val pinch = if (data != null && data.hands.isNotEmpty()) pinchRatio(data.hands[0], data.imgW, data.imgH) else -1f

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                Text("HOLOGRAPHIC CONTROL", color = Dim, fontSize = 11.sp)
                if (st.rendered) Text("3D ENGINE: ONLINE - ${st.fps} FPS", color = Green, fontSize = 11.sp)
                else Text("3D ENGINE: STARTING", color = Amber, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                val active = ts.status == "CAMERA ACTIVE"
                Text("CAMERA TRACKING: ${ts.status}", color = if (active) Green else if (ts.status == "ERROR") Color(0xFFFF5555) else Dim, fontSize = 10.sp)
                Text(
                    if (active) "HANDS DETECTED: ${ts.handCount} (${ts.fps}/s)" else "HAND DETECTION: N/A",
                    color = if (active && ts.handCount > 0) Green else Dim, fontSize = 10.sp
                )
                Text("GESTURE CONTROL: TOUCH ONLY", color = Amber, fontSize = 10.sp)
            }
        }
        st.error?.let { Text("3D error: $it", color = Color(0xFFFF5555), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        ts.error?.let { Text(it, color = Color(0xFFFF5555), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())
            Column(Modifier.align(Alignment.TopEnd).padding(8.dp), horizontalAlignment = Alignment.End) {
                Text("ROTATION: X ${st.rotX.toInt()} / Y ${(((st.rotY % 360f) + 360f) % 360f).toInt()}", color = Green, fontSize = 11.sp)
                Text("SCALE: ${(st.scale * 100).toInt()}%", color = Green, fontSize = 11.sp)
                Text("VIEW: ${if (st.inside) "INTERIOR" else "EXTERIOR"}", color = Green, fontSize = 11.sp)
                if (ts.status == "CAMERA ACTIVE") {
                    Text("CONFIDENCE: ${if (ts.handCount > 0) "${(ts.confidence * 100).toInt()}%" else "--"}", color = Green, fontSize = 11.sp)
                    Text("PINCH: ${if (pinch < 0f) "--" else if (pinch < 0.35f) "YES" else "NO"}", color = if (pinch in 0f..0.35f) Orange else Green, fontSize = 11.sp)
                }
            }
            if (tracking) {
                val shape = RoundedCornerShape(8.dp)
                Box(
                    Modifier.align(Alignment.TopStart).padding(8.dp).size(width = 120.dp, height = 160.dp)
                        .clip(shape).background(Color.Black).border(1.dp, Cyan, shape)
                ) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    HandOverlay(ts, Modifier.fillMaxSize())
                    Text("DIAGNOSTIC", color = Cyan, fontSize = 9.sp, modifier = Modifier.padding(4.dp))
                }
            }
            if (showHelp) {
                HudCard(Modifier.align(Alignment.BottomCenter).padding(8.dp)) {
                    Column {
                        Text("DRAG: rotate", fontSize = 12.sp)
                        Text("PINCH: zoom", fontSize = 12.sp)
                        Text("TWO FINGERS: move", fontSize = 12.sp)
                        Text("DOUBLE-TAP: reset", fontSize = 12.sp)
                        Text("CORE: fly inside the sphere", fontSize = 12.sp)
                        Text("Hand tracking shows landmarks only. Hands do not move the sphere until Phase 5.", fontSize = 11.sp, color = Amber)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn(if (tracking) "STOP HAND TRACKING" else "START HAND TRACKING", tracking, Modifier.weight(2f)) {
                if (tracking) {
                    tracking = false
                } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    ts.error = null
                    tracking = true
                } else {
                    permLauncher.launch(Manifest.permission.CAMERA)
                }
            }
            HoloBtn(if (front) "CAM: FRONT" else "CAM: BACK", false, Modifier.weight(1f)) { front = !front }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn("GESTURES", showHelp, Modifier.weight(1f)) { showHelp = !showHelp }
            HoloBtn(if (st.autoSpin) "ROTATE: ON" else "ROTATE: OFF", st.autoSpin, Modifier.weight(1f)) { st.autoSpin = !st.autoSpin }
            HoloBtn("INSPECT", st.scale > 1.8f, Modifier.weight(1f)) { st.scale = if (st.scale > 1.8f) 1f else 2.2f }
            HoloBtn(if (st.inside) "EXIT CORE" else "CORE", st.inside, Modifier.weight(1f)) { st.inside = !st.inside }
            HoloBtn("RESET", false, Modifier.weight(1f)) { st.reset() }
        }
    }
}
