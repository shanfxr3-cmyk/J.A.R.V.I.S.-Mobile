// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas as ACanvas
import android.graphics.Paint
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import android.annotation.SuppressLint
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlin.math.min

private val Orange = Color(0xFFFFA630)
private val Red = Color(0xFFFF5555)

@Composable
private fun HoloBtn(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 8.dp) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Orange else Color.White, fontSize = 10.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

/** Skeleton overlay as a plain View: redrawn only when a new detector result arrives, no recomposition. */
@SuppressLint("ViewConstructor")
private class HandOverlayView(ctx: Context, private val ts: TrackState) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF3DE8F5.toInt(); strokeWidth = 2f * d; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val tip = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFA630.toInt(); strokeWidth = 8f * d; strokeCap = Paint.Cap.ROUND
    }
    private val lines = FloatArray(HAND_CONNECTIONS.size * 2)
    private val pts = FloatArray(LM * 2)
    private val tips = FloatArray(4)

    override fun onDraw(c: ACanvas) {
        val data = ts.data ?: return
        val s = minOf(width / data.imgW.toFloat(), height / data.imgH.toFloat())
        val ox = (width - data.imgW * s) / 2f
        val oy = (height - data.imgH * s) / 2f
        for (h in data.hands) {
            if (h.size < LM * 3) continue
            for (i in 0 until LM) {
                pts[i * 2] = ox + h[i * 3] * data.imgW * s
                pts[i * 2 + 1] = oy + h[i * 3 + 1] * data.imgH * s
            }
            var n = 0
            var k = 0
            while (k < HAND_CONNECTIONS.size) {
                val a = HAND_CONNECTIONS[k]
                val b = HAND_CONNECTIONS[k + 1]
                lines[n++] = pts[a * 2]; lines[n++] = pts[a * 2 + 1]
                lines[n++] = pts[b * 2]; lines[n++] = pts[b * 2 + 1]
                k += 2
            }
            c.drawLines(lines, line)
            c.drawPoints(pts, dot)
            tips[0] = pts[8]; tips[1] = pts[9]; tips[2] = pts[16]; tips[3] = pts[17]
            c.drawPoints(tips, tip)
        }
    }
}

@Composable
private fun Header(st: HoloState, ts: TrackState) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(250); tick++ } }
    @Suppress("UNUSED_VARIABLE") val refresh = tick
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 18.sp, fontFamily = TitleFont, letterSpacing = 0.sp, maxLines = 1, softWrap = false)
                Text("HOLOGRAPHIC CONTROL", color = Dim, fontSize = 13.sp, fontFamily = AccentFont, letterSpacing = 1.sp)
                if (st.rendered) Text("3D ENGINE: ONLINE - ${st.fps} FPS", color = Green, fontSize = 11.sp, fontFamily = HudFont)
                else Text("3D ENGINE: STARTING", color = Amber, fontSize = 11.sp, fontFamily = HudFont)
            }
            Column(horizontalAlignment = Alignment.End) {
                val active = ts.status == "CAMERA ACTIVE"
                Text("CAMERA TRACKING: ${ts.status}", color = if (active) Green else if (ts.status == "ERROR") Red else Dim, fontSize = 10.sp, fontFamily = HudFont)
                Text(
                    if (active) "HANDS: ${ts.handCount} - ${ts.fps}/s - ${ts.latency} ms - ${ts.delegate} - drop ${ts.dropped}" else "HAND DETECTION: N/A",
                    color = if (active && ts.handCount > 0) Green else Dim, fontSize = 10.sp, fontFamily = HudFont
                )
                val gOn = active && st.gestureEnabled
                Text(if (gOn) "GESTURE CONTROL: ${ts.gesture}" else "GESTURE CONTROL: TOUCH ONLY", color = if (gOn) Orange else Amber, fontSize = 10.sp, fontFamily = HudFont)
            }
        }
        st.error?.let { Text("3D error: $it", color = Red, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        ts.error?.let { Text(it, color = Red, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
    }
}

@Composable
private fun Stats(st: HoloState, ts: TrackState, modifier: Modifier) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(200); tick++ } }
    @Suppress("UNUSED_VARIABLE") val refresh = tick
    val data = ts.data
    val pinch = if (data != null && data.hands.isNotEmpty()) pinchRatio(data.hands[0], data.imgW, data.imgH) else -1f
    Column(modifier, horizontalAlignment = Alignment.End) {
        Text("ROTATION: X ${st.rotX.toInt()} / Y ${(((st.rotY % 360f) + 360f) % 360f).toInt()}", color = Green, fontSize = 11.sp, fontFamily = HudFont)
        Text("SCALE: ${(st.scale * 100).toInt()}%", color = Green, fontSize = 11.sp, fontFamily = HudFont)
        Text("VIEW: ${if (st.inside) "INTERIOR" else "EXTERIOR"}", color = Green, fontSize = 11.sp, fontFamily = HudFont)
        if (ts.status == "CAMERA ACTIVE") {
            Text("CONFIDENCE: ${if (ts.handCount > 0) "${(ts.confidence * 100).toInt()}%" else "--"}", color = Green, fontSize = 11.sp, fontFamily = HudFont)
            Text("PINCH: ${if (pinch < 0f) "--" else if (pinch < 0.4f) "YES" else "NO"}", color = if (pinch in 0f..0.4f) Orange else Green, fontSize = 11.sp, fontFamily = HudFont)
        }
    }
}

@Composable
private fun Controls(
    st: HoloState, tracking: Boolean, front: Boolean, gpu: Boolean, camView: Boolean, showHelp: Boolean,
    onTrack: () -> Unit, onFront: () -> Unit, onGpu: () -> Unit, onCamView: () -> Unit, onHelp: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(250); tick++ } }
    @Suppress("UNUSED_VARIABLE") val refresh = tick
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn(if (tracking) "STOP HAND TRACKING" else "START HAND TRACKING", tracking, Modifier.weight(1.6f), onTrack)
            HoloBtn(if (front) "CAM: FRONT" else "CAM: BACK", false, Modifier.weight(1f), onFront)
            HoloBtn(if (st.gestureEnabled) "HAND CTRL: ON" else "HAND CTRL: OFF", st.gestureEnabled, Modifier.weight(1.2f)) { st.gestureEnabled = !st.gestureEnabled }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn(if (gpu) "ACCEL: GPU" else "ACCEL: CPU", gpu, Modifier.weight(1f), onGpu)
            HoloBtn(if (camView) "CAM VIEW: ON" else "CAM VIEW: OFF", camView, Modifier.weight(1f), onCamView)
            HoloBtn(if (st.autoSpin) "ROTATE: ON" else "ROTATE: OFF", st.autoSpin, Modifier.weight(1f)) { st.autoSpin = !st.autoSpin }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn("GESTURES", showHelp, Modifier.weight(1f), onHelp)
            HoloBtn("INSPECT", st.scale > 1.8f, Modifier.weight(1f)) { st.scale = if (st.scale > 1.8f) 1f else 2.2f }
            HoloBtn(if (st.inside) "EXIT CORE" else "CORE", st.inside, Modifier.weight(1f)) { st.inside = !st.inside }
            HoloBtn("RESET", false, Modifier.weight(1f)) { st.reset() }
        }
    }
}

@Composable
fun HoloScreen() {
    val ctx = LocalContext.current
    val st = remember { HoloState() }
    val glView = remember { HoloGLView(ctx, st) }
    val ts = remember { TrackState() }
    val gc = remember { GestureController(st, ts) }
    val tracker = remember {
        HandTracker(ctx.applicationContext, ts).also { t -> t.onHands = { h, w, hh -> gc.update(h, w, hh) } }
    }
    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val overlay = remember { HandOverlayView(ctx, ts) }
    SideEffect { tracker.onFrame = { overlay.postInvalidateOnAnimation() } }
    val act = ctx as? ComponentActivity
    var tracking by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var gpu by remember { mutableStateOf(false) }   // CPU by default: the GPU delegate competes with the renderer
    var camView by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }

    DisposableEffect(act, glView) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) glView.onPause()
            else if (e == Lifecycle.Event.ON_RESUME) glView.onResume()
        }
        act?.lifecycle?.addObserver(obs)
        onDispose {
            act?.lifecycle?.removeObserver(obs)
            glView.onPause()
            tracker.stop()
        }
    }

    // Camera and detector run only while `tracking` is true.
    LaunchedEffect(tracking, front, gpu) {
        if (tracking && act != null) tracker.start(act, if (camView) previewView else null, front, gpu) else { tracker.stop(); gc.release() }
    }

    // Camera preview on/off without reloading the detector.
    LaunchedEffect(camView) { if (tracking) tracker.setPreview(if (camView) previewView else null) }

    // Safety net: if the GPU detector makes the display stutter (render rate below ~40/s for 3 s), switch to CPU.
    LaunchedEffect(tracking, gpu) {
        if (!tracking || !gpu) return@LaunchedEffect
        delay(3000)
        var bad = 0
        var last = st.frames
        while (true) {
            delay(1000)
            val now = st.frames
            if (now - last < 40) bad++ else bad = 0
            last = now
            if (bad >= 3) {
                tracker.markGpuBad()
                gpu = false
                notice = "GPU detector made the display stutter. Switched to CPU."
                break
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { ts.error = null; tracking = true }
        else ts.error = "Camera permission denied. Allow it in Android app settings to use hand tracking."
    }

    Column(Modifier.fillMaxSize()) {
        Header(st, ts)
        notice?.let { Text(it, color = Amber, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())
            Stats(st, ts, Modifier.align(Alignment.TopEnd).padding(8.dp))
            if (tracking) {
                val shape = RoundedCornerShape(8.dp)
                Box(
                    Modifier.align(Alignment.TopStart).padding(8.dp).size(width = 132.dp, height = 176.dp)
                        .clip(shape).background(Color(0xFF050B14)).border(1.dp, Cyan, shape)
                ) {
                    if (camView) AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    AndroidView(factory = { overlay }, modifier = Modifier.fillMaxSize())
                    Text("DIAGNOSTIC", color = Cyan, fontSize = 10.sp, fontFamily = HudFont, modifier = Modifier.padding(4.dp))
                }
            }
            if (showHelp) {
                HudCard(Modifier.align(Alignment.BottomCenter).padding(8.dp)) {
                    Column {
                        Text("DRAG: rotate (flick for momentum)", fontSize = 12.sp)
                        Text("PINCH: zoom   TWO FINGERS: move", fontSize = 12.sp)
                        Text("DOUBLE-TAP: reset", fontSize = 12.sp)
                        Text("HANDS (camera on):", fontSize = 12.sp, color = Orange)
                        Text("PINCH + move: move sphere", fontSize = 12.sp)
                        Text("FIST + move: rotate (release to flick)", fontSize = 12.sp)
                        Text("TWO PINCHES apart/together: scale", fontSize = 12.sp)
                        Text("Scale past 3x: enter core", fontSize = 12.sp)
                        Text("TWO FISTS 1.5s: reset", fontSize = 12.sp)
                        Text("Hold the phone 40-60 cm away so both hands fit.", fontSize = 12.sp, color = Dim)
                        Text("ACCEL CPU is the smooth default. CAM VIEW shows the camera.", fontSize = 12.sp, color = Dim)
                    }
                }
            }
        }
        Controls(
            st, tracking, front, gpu, camView, showHelp,
            onTrack = {
                if (tracking) tracking = false
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    ts.error = null; tracking = true
                } else permLauncher.launch(Manifest.permission.CAMERA)
            },
            onFront = { front = !front },
            onGpu = { if (!gpu) tracker.clearGpuBad(); gpu = !gpu },
            onCamView = { camView = !camView },
            onHelp = { showHelp = !showHelp }
        )
        Spacer(Modifier.height(4.dp))
    }
}
