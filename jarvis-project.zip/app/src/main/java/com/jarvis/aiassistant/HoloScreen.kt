package com.jarvis.aiassistant

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

private val Orange = Color(0xFFFFA630)

@Composable
private fun HoloBtn(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 8.dp) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Orange else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

@Composable
fun HoloScreen() {
    val ctx = LocalContext.current
    val st = remember { HoloState() }
    val glView = remember { HoloGLView(ctx, st) }
    val act = ctx as? ComponentActivity

    DisposableEffect(act, glView) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) glView.onPause()
            else if (e == Lifecycle.Event.ON_RESUME) glView.onResume()
        }
        act?.lifecycle?.addObserver(obs)
        onDispose {
            act?.lifecycle?.removeObserver(obs)
            glView.onPause()
        }
    }

    var tick by remember { mutableIntStateOf(0) }
    var showHelp by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(150); tick++ } }
    @Suppress("UNUSED_VARIABLE") val refresh = tick

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("HOLOGRAPHIC CONTROL", color = Dim, fontSize = 12.sp)
                if (st.rendered) Text("3D ENGINE: ONLINE - ${st.fps} FPS", color = Green, fontSize = 11.sp)
                else Text("3D ENGINE: STARTING", color = Amber, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("CAMERA TRACKING: OFF", color = Dim, fontSize = 10.sp)
                Text("HAND DETECTION: N/A", color = Dim, fontSize = 10.sp)
                Text("GESTURE CONTROL: TOUCH ONLY", color = Amber, fontSize = 10.sp)
            }
        }
        st.error?.let { Text("3D error: $it", color = Color(0xFFFF5555), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())
            Column(Modifier.align(Alignment.TopEnd).padding(8.dp), horizontalAlignment = Alignment.End) {
                Text("ROTATION: X ${st.rotX.toInt()} / Y ${(((st.rotY % 360f) + 360f) % 360f).toInt()}", color = Green, fontSize = 11.sp)
                Text("SCALE: ${(st.scale * 100).toInt()}%", color = Green, fontSize = 11.sp)
                Text("VIEW: ${if (st.inside) "INTERIOR" else "EXTERIOR"}", color = Green, fontSize = 11.sp)
                Text("PAN: ${"%.1f".format(st.panX)}, ${"%.1f".format(st.panY)}", color = Green, fontSize = 11.sp)
            }
            Text(
                "Touch controls only. Hand tracking is not built yet.",
                color = Dim, fontSize = 10.sp, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            )
            if (showHelp) {
                HudCard(Modifier.align(Alignment.BottomCenter).padding(8.dp)) {
                    Column {
                        Text("DRAG: rotate", fontSize = 12.sp)
                        Text("PINCH: zoom", fontSize = 12.sp)
                        Text("TWO FINGERS: move", fontSize = 12.sp)
                        Text("DOUBLE-TAP: reset", fontSize = 12.sp)
                        Text("CORE: fly inside the sphere", fontSize = 12.sp)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoloBtn("GESTURES", showHelp, Modifier.weight(1f)) { showHelp = !showHelp }
            HoloBtn(if (st.autoSpin) "ROTATE: ON" else "ROTATE: OFF", st.autoSpin, Modifier.weight(1f)) { st.autoSpin = !st.autoSpin }
            HoloBtn("INSPECT", st.scale > 1.8f, Modifier.weight(1f)) { st.scale = if (st.scale > 1.8f) 1f else 2.2f }
            HoloBtn(if (st.inside) "EXIT CORE" else "CORE", st.inside, Modifier.weight(1f)) { st.inside = !st.inside }
            HoloBtn("RESET", false, Modifier.weight(1f)) { st.reset() }
        }
    }
}
