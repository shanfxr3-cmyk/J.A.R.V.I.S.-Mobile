// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Lets Jarvis be chosen as the phone's default digital assistant (Settings > Apps > Default apps). */
class JarvisInteractionService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

/** Power/home long-press: open Jarvis in voice mode right away. No screen content is read. */
class JarvisSession(private val c: Context) : VoiceInteractionSession(c) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            startAssistantActivity(Intent(c, MainActivity::class.java).putExtra("voice", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } catch (_: Throwable) {}
        hide()
    }
}

/**
 * Android may point the phone's speech recognition at the assistant's recognizer, so this one forwards
 * everything to Google's real recognizer. It records and keeps nothing.
 */
class JarvisRecognitionService : RecognitionService() {
    private var inner: SpeechRecognizer? = null

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        val cb = listener ?: return
        inner?.destroy()
        val google = ComponentName("com.google.android.googlequicksearchbox", "com.google.android.voicesearch.serviceapi.GoogleRecognitionService")
        val r = try { SpeechRecognizer.createSpeechRecognizer(this, google) } catch (_: Exception) { null }
        if (r == null) { cb.error(SpeechRecognizer.ERROR_CLIENT); return }
        inner = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { cb.readyForSpeech(p ?: Bundle()) }
            override fun onBeginningOfSpeech() { cb.beginningOfSpeech() }
            override fun onRmsChanged(v: Float) { cb.rmsChanged(v) }
            override fun onBufferReceived(b: ByteArray?) { if (b != null) cb.bufferReceived(b) }
            override fun onEndOfSpeech() { cb.endOfSpeech() }
            override fun onError(e: Int) { cb.error(e) }
            override fun onResults(b: Bundle?) { cb.results(b ?: Bundle()) }
            override fun onPartialResults(b: Bundle?) { cb.partialResults(b ?: Bundle()) }
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(recognizerIntent ?: Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH))
    }

    override fun onStopListening(listener: Callback?) { inner?.stopListening() }
    override fun onCancel(listener: Callback?) { inner?.cancel() }
    override fun onDestroy() { inner?.destroy(); inner = null; super.onDestroy() }
}
