package com.jarvis.aiassistant.holo

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

const val HIST = 96
const val BLIPS = 14

/**
 * All high-frequency data lives here in primitive arrays, mutated in place.
 * [t] and [tick] are read only inside the draw phase, so they invalidate drawing, never composition.
 */
@Stable
class HoloTelemetry {
    var t by mutableFloatStateOf(0f)
    var tick by mutableIntStateOf(0)

    internal var cpu = 0; internal var net = 0; internal var lat = 0
    internal var hdg = 0; internal var alt = 0; internal var pwr = 0
    internal val hist = FloatArray(HIST)
    internal var head = 0

    internal val bAng = FloatArray(BLIPS) { it * 0.449f }
    internal val bRad = FloatArray(BLIPS) { 0.25f + (it * 37 % 11) / 15f }
    internal val bSpd = FloatArray(BLIPS) { 0.02f + (it % 5) * 0.012f }

    private var acc = 0f
    private var phase = 0f

    /** Overwrites the simulated RAM / NET / BAT labels with measured values. No allocation. */
    internal fun applyReal(ramPct: Int, netKb: Int, battPct: Int) {
        cpu = ramPct.coerceIn(0, 99); net = netKb.coerceIn(0, 999); pwr = if (battPct < 0) 0 else battPct.coerceIn(0, 99)
    }

    /** Advance by dt seconds. No allocation; data refreshes at ~10 Hz, blips every frame. */
    internal fun step(dt: Float, speed: Float) {
        t += dt * speed
        phase += dt
        for (i in 0 until BLIPS) {
            bAng[i] += bSpd[i] * dt * speed
            if (bAng[i] > TAU) bAng[i] -= TAU
        }
        acc += dt
        if (acc < 0.1f) return
        acc = 0f
        val p = phase
        cpu = (38f + 22f * Lut.sin(p * 0.7f) + 9f * Lut.sin(p * 2.3f)).toInt().coerceIn(0, 99)
        net = (480f + 300f * Lut.sin(p * 0.9f + 1f) + 80f * Lut.sin(p * 3.1f)).toInt().coerceIn(0, 999)
        lat = (24f + 10f * Lut.sin(p * 1.7f) + 4f * Lut.sin(p * 5f)).toInt().coerceIn(0, 999)
        hdg = ((p * 9f).toInt() % 360 + 360) % 360
        alt = (120f + 12f * Lut.sin(p * 0.3f)).toInt()
        pwr = (87f + 5f * Lut.sin(p * 0.11f)).toInt().coerceIn(0, 99)
        hist[head] = 0.5f + 0.32f * Lut.sin(p * 4.1f) + 0.18f * Lut.sin(p * 11f + cpu)
        head = (head + 1) % HIST
        tick++
    }
}
