// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Command handling and prompt building shared by the chat screen and the wake-word service. */
object Assistant {
    fun localCommand(store: Store, raw: String, nav: (Screen) -> Unit): String? {
        val o = raw.trim().trimEnd('.', '!', '?')
        val s = o.lowercase(Locale.ROOT)
        Regex("^(?:please )?(?:add|create|new) (?:a )?task(?: to| called| named)?:? (.+)$").find(s)?.let {
            val r = it.groups[1]!!.range
            val title = o.substring(r.first.coerceAtMost(o.length), (r.last + 1).coerceAtMost(o.length))
            store.addTask(title)
            return "Task added: $title"
        }
        if (Regex("^(?:what are|list|what's|whats)(?: me)?(?: my)? (?:open |pending )?tasks$").matches(s)) {
            val open = store.tasks.filter { !it.done }
            return if (open.isEmpty()) "You have no open tasks." else "You have ${open.size} open: " + open.take(8).joinToString("; ") { it.title } + "."
        }
        if (s.contains("what time is it") || s.contains("what's the time") || s.contains("current time")) {
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        }
        if (s.contains("what's the date") || s.contains("what is the date") || s.contains("today's date")) {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + "."
        }
        Regex("^(?:please )?(?:open|show|go to|take me to)(?: the| my)? (.+)$").find(s)?.let {
            val x = it.groupValues[1]
            val t = when {
                "holo" in x || "3d" in x || "sphere" in x -> Screen.Holo
                "task" in x -> Screen.Tasks
                "memory" in x || "history" in x -> Screen.Memory
                "setting" in x -> Screen.Settings
                "tool" in x -> Screen.Tools
                "home" in x || "dashboard" in x -> Screen.Home
                else -> null
            }
            if (t != null) { nav(t); return "Opening ${t.label}." }
        }
        return null
    }

    fun systemPrompt(store: Store): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        val open = store.tasks.filter { !it.done }.take(10).joinToString("; ") { it.title }
        return "You are J.A.R.V.I.S., a personal AI assistant inside the user's Android app. " +
            "Reply concisely, in plain text without markdown, in a way that sounds natural when spoken aloud. " +
            "Use 1 to 4 sentences unless the user asks for detail. " +
            "You were created by Shan Akhter from India; say so if asked who made you. " +
            "You cannot control the phone; the app itself handles commands like opening screens and adding tasks. " +
            (if (store.userName.isNotBlank()) "The user's name is ${store.userName}. " else "") +
            "Now: $now. " + (if (open.isNotEmpty()) "User's open tasks: $open." else "The user has no open tasks.")
    }
}
