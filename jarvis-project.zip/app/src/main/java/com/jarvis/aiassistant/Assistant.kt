// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Command handling and prompt building shared by the chat screen and the wake-word service. */
object Assistant {
    // Commands must match as WHOLE phrases, so a normal question such as "what's the time complexity
    // of quicksort" or "go to home depot" still goes to the AI instead of triggering a local action.
    private val TASK_ADD = Regex("^(?:please )?(?:add|create|new) (?:a )?task(?: to| called| named)?:? (.+)$", RegexOption.IGNORE_CASE)
    private val TASK_LIST = Regex("^(?:what are|list|what's|whats|show)(?: me)?(?: my)? (?:open |pending )?tasks$")
    private val TIME_Q = Regex("^(?:please )?(?:what(?:'s| is) the (?:current )?time(?: now| right now)?|what time is it(?: now| right now)?|current time|tell me the time|time please)$")
    private val DATE_Q = Regex("^(?:please )?(?:what(?:'s| is) (?:the|today's) date(?: today)?|what(?:'s| is) today's date|today's date|what day is it(?: today)?|what is today)$")
    private val OPEN_Q = Regex("^(?:please )?(?:open|show|go to|take me to)(?: me)?(?: the| my)? (.+?)(?: screen| page| tab)?$")
    private val SCREENS: Map<Screen, Set<String>> = mapOf(
        Screen.Holo to setOf("holo", "hologram", "holographic", "3d", "3d hologram", "holographic control", "sphere", "3d sphere"),
        Screen.Tasks to setOf("tasks", "task", "task list", "to do list", "to-do list", "todo", "todo list"),
        Screen.Memory to setOf("memory", "history", "conversation history", "chat history"),
        Screen.Settings to setOf("settings", "setting"),
        Screen.Tools to setOf("tools", "tool"),
        Screen.Chat to setOf("chat", "ai chat", "the chat"),
        Screen.Home to setOf("home", "home screen", "dashboard", "main screen")
    )

    fun localCommand(store: Store, raw: String, nav: (Screen) -> Unit): String? {
        // Keyboards type curly apostrophes; normalise them so "what's" always matches.
        val o = raw.trim().trimEnd('.', '!', '?', ',').trim()
        val s = o.lowercase(Locale.ROOT).replace('\u2019', '\'').replace('\u2018', '\'')
        TASK_ADD.find(o)?.let {
            val title = it.groupValues[1].trim()
            if (title.isNotEmpty()) {
                store.addTask(title)
                return "Task added: $title"
            }
        }
        if (TASK_LIST.matches(s)) {
            val open = store.tasks.filter { !it.done }
            return if (open.isEmpty()) "You have no open tasks." else "You have ${open.size} open: " + open.take(8).joinToString("; ") { it.title } + "."
        }
        if (TIME_Q.matches(s)) {
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        }
        if (DATE_Q.matches(s)) {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + "."
        }
        OPEN_Q.find(s)?.let {
            val x = it.groupValues[1].trim()
            val t = SCREENS.entries.firstOrNull { e -> x in e.value }?.key
            if (t != null) { nav(t); return "Opening ${t.label}." }
        }
        return null
    }

    fun systemPrompt(store: Store): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        val open = store.tasks.filter { !it.done }.take(10).joinToString("; ") { it.title }
        return "You are J.A.R.V.I.S., a personal AI assistant inside the user's Android app. " +
            "Reply concisely, in plain text without markdown, in a way that sounds natural when spoken aloud. " +
            "Use 1 to 4 sentences unless the user asks for detail. " +
            "You were created by Shan Akhter; say so if asked who made you. " +
            "You cannot control the phone; the app itself handles commands like opening screens and adding tasks. " +
            (if (store.userName.isNotBlank()) "The user's name is ${store.userName}. " else "") +
            "Now: $now. " + (if (open.isNotEmpty()) "User's open tasks: $open." else "The user has no open tasks.")
    }
}
