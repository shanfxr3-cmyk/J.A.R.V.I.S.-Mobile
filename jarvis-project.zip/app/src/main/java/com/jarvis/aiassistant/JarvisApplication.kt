// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Application
import android.app.NotificationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

/** Loads saved data and opens the Keystore off the main thread, so the first screen does not wait for it. */
class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { Store.get(applicationContext) }
            removeLegacyData()
        }
    }

    /** Deletes files, settings and notification channels that older versions left on the phone after an update. */
    private fun removeLegacyData() {
        runCatching {
            File(filesDir, "gev").deleteRecursively()
            File(filesDir, "node-home").deleteRecursively()
            File(cacheDir, "node-tmp").deleteRecursively()
        }
        listOf("gev_ui", "jarvis_watch", "trk").forEach { runCatching { deleteSharedPreferences(it) } }
        val notifications = getSystemService(NotificationManager::class.java) ?: return
        listOf("jarvis_gev", "jarvis_world_watch").forEach { runCatching { notifications.deleteNotificationChannel(it) } }
    }
}
