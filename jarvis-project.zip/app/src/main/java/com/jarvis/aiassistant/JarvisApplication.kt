// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Application
import android.app.NotificationManager
import java.io.File

/** Loads saved data and opens the Keystore on a background thread, so the first screen does not wait for it. */
class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching { Shell.init(this) }
        Thread {
            runCatching { Store.get(applicationContext) }
            removeOldData()
        }.also { it.name = "warmup"; it.start() }
    }

    /** Deletes files, settings and the notification channel that an older version left on the phone after an update. */
    private fun removeOldData() {
        runCatching { File(filesDir, "gev").deleteRecursively() }
        runCatching { File(filesDir, "node-home").deleteRecursively() }
        runCatching { File(cacheDir, "node-tmp").deleteRecursively() }
        runCatching { deleteSharedPreferences("gev_ui") }
        runCatching { getSystemService(NotificationManager::class.java)?.deleteNotificationChannel("jarvis_gev") }
        // World Watch was removed: drop its saved settings, cached results and alert channel (its alarm is cleared by Android on update).
        runCatching { deleteSharedPreferences("jarvis_watch") }
        runCatching { getSystemService(NotificationManager::class.java)?.deleteNotificationChannel("jarvis_world_watch") }
    }
}
