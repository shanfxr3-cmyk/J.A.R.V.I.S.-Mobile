// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.io.InputStream
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

data class ShellOut(val code: Int, val out: String, val err: String) {
    val ok get() = code == 0
    fun text() = (out + "\n" + err).trim()
}

data class AccessSnap(
    val installed: Boolean, val running: Boolean, val granted: Boolean, val uid: Int,
    val a11yListed: Boolean, val a11yBound: Boolean, val secure: Boolean
)

/** Runs commands with shell (or root) rights through Shizuku, and uses that power to give Jarvis every permission Android lets a shell grant. */
object Shell {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4207
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var started = false

    // Shizuku 13 keeps newProcess private; reflection is the documented workaround for plain shell commands.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            .apply { isAccessible = true }
    }

    fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
    val PKG_RE = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    fun init(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        runCatching {
            Shizuku.addBinderReceivedListenerSticky { Control.onShizukuChange(app) }
            Shizuku.addRequestPermissionResultListener { _, r -> if (r == PackageManager.PERMISSION_GRANTED) Control.onShizukuChange(app) }
        }
    }

    fun installed(ctx: Context): Boolean = try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (_: Throwable) { false }
    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    fun granted(): Boolean = try { running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    fun uid(): Int = try { Shizuku.getUid() } catch (_: Throwable) { -1 }

    fun snapshot(ctx: Context): AccessSnap {
        val me = ComponentName(ctx, ScreenService::class.java).flattenToString()
        val listed = Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services").orEmpty().split(':').contains(me)
        val secure = ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        return AccessSnap(installed(ctx), running(), granted(), uid(), listed, ScreenService.running, secure)
    }

    fun summary(ctx: Context): String {
        val s = snapshot(ctx)
        val sh = when { !s.installed -> "Shizuku not installed"; !s.running -> "Shizuku stopped"; !s.granted -> "Shizuku needs allow"; s.uid == 0 -> "Shizuku root"; else -> "Shizuku ready" }
        return sh + " - Accessibility " + if (s.a11yBound) "on" else "off"
    }

    fun openApp(ctx: Context) {
        val i = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (i != null) runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        else runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://shizuku.rikka.app/download/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun request(ctx: Context): String {
        if (!installed(ctx)) return "Shizuku is not installed."
        if (!running()) return "Shizuku is not running. Open it and start it."
        if (granted()) return "Already allowed."
        return try {
            if (Shizuku.shouldShowRequestPermissionRationale()) { openApp(ctx); "Allow Jarvis inside Shizuku (authorized apps)." }
            else { Shizuku.requestPermission(REQ); "Tap Allow in the dialog." }
        } catch (e: Throwable) { "Could not ask: ${e.message}" }
    }

    private fun drain(s: InputStream, sb: StringBuilder) {
        runCatching {
            s.bufferedReader().use { r ->
                val buf = CharArray(4096)
                while (true) {
                    val n = r.read(buf)
                    if (n < 0) break
                    synchronized(sb) { if (sb.length < 200_000) sb.append(buf, 0, n) }
                }
            }
        }
    }

    /** Runs [cmd] with `sh -c` as the Shizuku user (shell, or root if Shizuku runs as root). Blocking. */
    fun exec(cmd: String, timeoutMs: Long = 20_000): ShellOut {
        if (!granted()) return ShellOut(-1, "", "Shizuku is not ready")
        return try {
            val p = newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val o = StringBuilder(); val e = StringBuilder()
            val t1 = pool.submit(Runnable { drain(p.inputStream, o) })
            val t2 = pool.submit(Runnable { drain(p.errorStream, e) })
            val code = try { pool.submit(Callable { p.waitFor() }).get(timeoutMs, TimeUnit.MILLISECONDS) }
            catch (_: TimeoutException) { runCatching { p.destroy() }; -2 }
            runCatching { t1.get(1500, TimeUnit.MILLISECONDS); t2.get(1500, TimeUnit.MILLISECONDS) }
            ShellOut(code, synchronized(o) { o.toString() }, synchronized(e) { e.toString() })
        } catch (ex: Throwable) { ShellOut(-1, "", (ex.cause ?: ex).message ?: ex.javaClass.simpleName) }
    }

    private val APPOPS = listOf(
        "ACCESS_RESTRICTED_SETTINGS", "SYSTEM_ALERT_WINDOW", "WRITE_SETTINGS", "MANAGE_EXTERNAL_STORAGE", "REQUEST_INSTALL_PACKAGES",
        "GET_USAGE_STATS", "SCHEDULE_EXACT_ALARM", "USE_FULL_SCREEN_INTENT", "MANAGE_MEDIA", "READ_CLIPBOARD", "WRITE_CLIPBOARD",
        "RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND", "START_FOREGROUND", "WAKE_LOCK", "TURN_SCREEN_ON", "POST_NOTIFICATION",
        "PICTURE_IN_PICTURE", "MONITOR_LOCATION", "MONITOR_HIGH_POWER_LOCATION", "ACCESS_NOTIFICATIONS", "NO_ISOLATED_STORAGE"
    )

    /** Gives Jarvis everything a shell can: every permission in the manifest, every special access, background freedom, listener and assistant roles, accessibility. */
    fun grantAll(ctx: Context): String {
        if (!granted()) return "Shizuku is not ready. Start it and allow Jarvis first."
        val pkg = ctx.packageName
        val declared = runCatching { ctx.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions?.toList() }
            .getOrNull().orEmpty().filter { it.contains('.') }
        val sb = StringBuilder()
        fun step(tag: String, cmd: String) {
            sb.append("if ").append(cmd).append(" >/dev/null 2>&1; then echo ").append(q("+$tag")).append("; else echo ").append(q("-$tag")).append("; fi\n")
        }
        step("op:ACCESS_RESTRICTED_SETTINGS", "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow")
        declared.forEach { step("perm:$it", "cmd package grant $pkg $it") }
        APPOPS.filter { it != "ACCESS_RESTRICTED_SETTINGS" }.forEach { step("op:$it", "cmd appops set $pkg $it allow") }
        step("battery:whitelist", "cmd deviceidle whitelist +$pkg")
        step("battery:bucket", "am set-standby-bucket $pkg active")
        step("listener", "cmd notification allow_listener ${ComponentName(ctx, JarvisNotifListener::class.java).flattenToString()}")
        val assistant = ComponentName(ctx, JarvisInteractionService::class.java).flattenToString()
        step("assistant", "settings put secure assistant ${q(assistant)} && settings put secure voice_interaction_service ${q(assistant)}")
        val r = exec(sb.toString(), 150_000)
        val lines = r.out.lines().filter { it.length > 1 && (it[0] == '+' || it[0] == '-') }
        if (lines.isEmpty()) return "Failed: " + r.text().take(160).ifBlank { "no output" }
        // Judge by what Android says Jarvis really holds, not by whether the grant command accepted the permission.
        // Normal permissions (INTERNET, WAKE_LOCK...) are granted at install and the command rejects them, which is fine.
        val held = declared.count { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val allPerm = declared.size
        val missing = declared.filter { ctx.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.map { it.substringAfterLast('.') }
        val okOps = lines.count { it.startsWith("+op:") }
        val allOps = lines.count { it.substring(1).startsWith("op:") }
        val extras = listOf("battery:whitelist" to "battery", "listener" to "notification listener", "assistant" to "assistant role")
            .joinToString(", ") { (t, n) -> n + if (lines.any { it == "+$t" }) " yes" else " no" }
        val acc = enableAccessibility(ctx)
        return "Permissions $held/$allPerm held, special access $okOps/$allOps, $extras. $acc" +
            if (missing.isNotEmpty()) " Not grantable without system privileges (${missing.size}): " + missing.take(12).joinToString(", ") + (if (missing.size > 12) ", and more." else ".") else ""
    }

    /** Turns the accessibility service on without the Settings maze (also clears Android's restricted-settings block). */
    fun enableAccessibility(ctx: Context): String {
        if (ScreenService.running) return "Accessibility already on."
        if (!granted()) return "Shizuku is needed to switch accessibility on."
        val me = ComponentName(ctx, ScreenService::class.java).flattenToString()
        val cur = Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services").orEmpty()
        val others = cur.split(':').filter { it.isNotBlank() && it != "null" && it != me }
        val without = others.joinToString(":")
        val next = (others + me).joinToString(":")
        val r = exec(
            "cmd appops set ${ctx.packageName} ACCESS_RESTRICTED_SETTINGS allow; " +
                (if (without.isEmpty()) "settings delete secure enabled_accessibility_services; " else "settings put secure enabled_accessibility_services ${q(without)}; ") + "sleep 0.4; " +
                "settings put secure enabled_accessibility_services ${q(next)}; settings put secure accessibility_enabled 1"
        )
        return if (r.ok) "Accessibility switched on." else "Accessibility failed: " + r.text().take(120)
    }
}
