// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Quake(val id: String, val mag: Double, val place: String, val time: Long, val lat: Double, val lon: Double, val url: String)
data class Hazard(val id: String, val kind: String, val title: String, val level: String, val where_: String)
data class Article(val url: String, val title: String, val domain: String)
data class Plane(val hex: String, val call: String, val type: String, val lat: Double, val lon: Double, val alt: String, val squawk: String, val mil: Boolean, val distNm: Double)
data class IssPos(val lat: Double, val lon: Double, val altKm: Double, val kmh: Double, val visibility: String)
data class Ship(val mmsi: String, val name: String, val lat: Double, val lon: Double)

/**
 * World Watch: free public data feeds only (USGS, GDACS, NOAA/NWS, GDELT, wheretheiss.at, adsb.lol, AISStream).
 * Nothing here needs an account except ships, which use the person's own free AISStream key.
 * Each fetch function blocks, so call it from a background thread.
 */
object WorldWatch {
    private const val UA = "JarvisMobile/0.13 (personal Android assistant)"
    const val CHANNEL = "jarvis_world_watch"
    const val ACTION_POLL = "com.jarvis.aiassistant.WATCH_POLL"
    private const val EMERGENCY_NM = 300.0

    fun sp(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("jarvis_watch", Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("on", false)

    fun clearAll(ctx: Context) {
        cancel(ctx)
        try { sp(ctx).edit().clear().apply() } catch (_: Throwable) {}
    }

    // ---------- HTTP ----------

    private fun http(url: String, accept: String = "application/json", timeout: Int = 9000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", accept)
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val sb = StringBuilder()
            c.inputStream.bufferedReader().use { r ->
                val buf = CharArray(8192)
                while (true) {
                    val n = r.read(buf)
                    if (n < 0) break
                    sb.append(buf, 0, n)
                    if (sb.length > 3_000_000) break   // never hold a runaway response in memory
                }
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- Earthquakes (USGS) ----------

    fun quakes(minMag: Double): List<Quake> {
        val feed = when {
            minMag >= 4.5 -> "4.5_day"
            minMag >= 2.5 -> "2.5_day"
            else -> "1.0_day"
        }
        val f = JSONObject(http("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/$feed.geojson"))
            .optJSONArray("features") ?: return emptyList()
        val out = ArrayList<Quake>()
        for (i in 0 until f.length()) {
            try {
                val o = f.getJSONObject(i)
                val p = o.getJSONObject("properties")
                val mag = p.optDouble("mag", Double.NaN)
                if (mag.isNaN() || mag < minMag) continue
                val c = o.optJSONObject("geometry")?.optJSONArray("coordinates")
                out.add(
                    Quake(
                        o.optString("id"), mag, p.optString("place", "Unknown place"), p.optLong("time", 0L),
                        c?.optDouble(1, 0.0) ?: 0.0, c?.optDouble(0, 0.0) ?: 0.0, p.optString("url", "")
                    )
                )
            } catch (_: Throwable) {}
        }
        return out.sortedByDescending { it.time }.take(25)
    }

    // ---------- Disasters (GDACS, worldwide) and US weather alerts (NOAA / NWS) ----------

    private fun kindName(code: String) = when (code.uppercase(Locale.ROOT)) {
        "EQ" -> "Earthquake"; "TC" -> "Cyclone"; "FL" -> "Flood"; "VO" -> "Volcano"
        "DR" -> "Drought"; "WF" -> "Wildfire"; "TS" -> "Tsunami"; else -> code.ifBlank { "Event" }
    }

    /** Orange and Red alerts only, so the list stays meaningful. */
    fun disasters(): List<Hazard> {
        val f = JSONObject(http("https://www.gdacs.org/gdacsapi/api/events/geteventlist/EVENTS4APP"))
            .optJSONArray("features") ?: return emptyList()
        val out = ArrayList<Hazard>()
        for (i in 0 until f.length()) {
            try {
                val p = f.getJSONObject(i).optJSONObject("properties") ?: continue
                val level = p.optString("alertlevel")
                if (!level.equals("Orange", true) && !level.equals("Red", true)) continue
                val id = p.optString("eventtype") + p.optString("eventid") + "-" + p.optString("episodeid")
                val title = p.optString("name").ifBlank { p.optString("description") }.ifBlank { kindName(p.optString("eventtype")) }
                out.add(Hazard(id, kindName(p.optString("eventtype")), title.take(140), level, p.optString("country")))
            } catch (_: Throwable) {}
        }
        return out.take(20)
    }

    /** NOAA / National Weather Service: severe and extreme alerts. United States only. */
    fun usAlerts(): List<Hazard> {
        val f = JSONObject(
            http("https://api.weather.gov/alerts/active?status=actual&message_type=alert&severity=Extreme,Severe", "application/geo+json")
        ).optJSONArray("features") ?: return emptyList()
        val out = ArrayList<Hazard>()
        for (i in 0 until f.length()) {
            try {
                val p = f.getJSONObject(i).getJSONObject("properties")
                out.add(
                    Hazard(
                        p.optString("id"), p.optString("event", "Weather alert"),
                        p.optString("headline").ifBlank { p.optString("event") }.take(160),
                        p.optString("severity"), p.optString("areaDesc").take(80)
                    )
                )
            } catch (_: Throwable) {}
        }
        return out.take(15)
    }

    // ---------- News keyword watch (GDELT) ----------

    fun news(keywords: String): List<Article> {
        val terms = keywords.split(',').map { it.trim() }.filter { it.length >= 3 }.take(6)
        if (terms.isEmpty()) return emptyList()
        val q = if (terms.size == 1) terms[0] else "(" + terms.joinToString(" OR ") { if (it.contains(' ')) "\"$it\"" else it } + ")"
        val body = http(
            "https://api.gdeltproject.org/api/v2/doc/doc?query=${enc(q)}&mode=artlist&maxrecords=15&format=json&sort=datedesc&timespan=60min"
        ).trim()
        // GDELT answers plain text (not JSON) when it is rate limited or the query is rejected.
        if (!body.startsWith("{")) return emptyList()
        val a = JSONObject(body).optJSONArray("articles") ?: return emptyList()
        val out = ArrayList<Article>()
        for (i in 0 until a.length()) {
            try {
                val o = a.getJSONObject(i)
                out.add(Article(o.optString("url"), o.optString("title").take(160), o.optString("domain")))
            } catch (_: Throwable) {}
        }
        return out
    }

    // ---------- International Space Station ----------

    fun iss(): IssPos {
        val o = JSONObject(http("https://api.wheretheiss.at/v1/satellites/25544"))
        return IssPos(o.getDouble("latitude"), o.getDouble("longitude"), o.optDouble("altitude", 0.0), o.optDouble("velocity", 0.0), o.optString("visibility"))
    }

    // ---------- Aircraft (adsb.lol, free, community ADS-B) ----------

    fun distNm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 3440.065
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }

    private fun parsePlanes(body: String, lat: Double?, lon: Double?): List<Plane> {
        val o = JSONObject(body)
        val a = o.optJSONArray("ac") ?: o.optJSONArray("aircraft") ?: return emptyList()
        val out = ArrayList<Plane>()
        for (i in 0 until a.length()) {
            try {
                val x = a.getJSONObject(i)
                val la = x.optDouble("lat", Double.NaN)
                val lo = x.optDouble("lon", Double.NaN)
                if (la.isNaN() || lo.isNaN()) continue
                out.add(
                    Plane(
                        x.optString("hex"), x.optString("flight").trim(), x.optString("t"), la, lo,
                        x.opt("alt_baro")?.toString() ?: "?", x.optString("squawk"),
                        (x.optInt("dbFlags", 0) and 1) != 0,
                        if (lat != null && lon != null) distNm(lat, lon, la, lo) else -1.0
                    )
                )
            } catch (_: Throwable) {}
        }
        return out
    }

    /** Aircraft squawking 7700 (emergency), 7600 (radio failure) or 7500 (hijack code), worldwide. */
    fun emergencies(lat: Double?, lon: Double?): List<Plane> {
        val out = ArrayList<Plane>()
        var failures = 0
        for (sq in listOf("7700", "7600", "7500")) {
            try { out.addAll(parsePlanes(http("https://api.adsb.lol/v2/sqk/$sq"), lat, lon)) } catch (_: Throwable) { failures++ }
        }
        if (failures == 3) throw IOException("Aircraft feed unreachable")
        return out.sortedBy { if (it.distNm < 0) 1e9 else it.distNm }
    }

    /** Military aircraft within [nm] nautical miles of the point. */
    fun military(lat: Double, lon: Double, nm: Int): List<Plane> =
        parsePlanes(http("https://api.adsb.lol/v2/mil", timeout = 12000), lat, lon)
            .filter { it.distNm in 0.0..nm.toDouble() }.sortedBy { it.distNm }

    // ---------- Ships (AISStream, free personal key) ----------

    /** Listens to the AISStream live feed for a few seconds and returns the ships seen inside the area. */
    fun ships(key: String, lat: Double, lon: Double, nm: Int, seconds: Long = 8): List<Ship> {
        val dLat = nm / 60.0
        val dLon = nm / (60.0 * cos(Math.toRadians(lat)).coerceAtLeast(0.2))
        val box = JSONArray()
            .put(JSONArray().put(lat - dLat).put(lon - dLon))
            .put(JSONArray().put(lat + dLat).put(lon + dLon))
        val sub = JSONObject()
            .put("APIKey", key)
            .put("BoundingBoxes", JSONArray().put(box))
            .put("FilterMessageTypes", JSONArray().put("PositionReport"))
            .toString()
        val found = ConcurrentHashMap<String, Ship>()
        val problem = arrayOfNulls<String>(1)
        val done = CountDownLatch(1)
        val client = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).build()
        val ws = client.newWebSocket(
            Request.Builder().url("wss://stream.aisstream.io/v0/stream").build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send(sub)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val o = JSONObject(text)
                        if (o.has("error")) { problem[0] = o.optString("error"); done.countDown(); return }
                        val m = o.optJSONObject("MetaData") ?: return
                        val id = m.opt("MMSI")?.toString() ?: return
                        found[id] = Ship(id, m.optString("ShipName").trim().ifBlank { "Unnamed" }, m.optDouble("latitude", 0.0), m.optDouble("longitude", 0.0))
                    } catch (_: Throwable) {}
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    problem[0] = t.message ?: "Connection failed"
                    done.countDown()
                }
            }
        )
        try { done.await(seconds, TimeUnit.SECONDS) } catch (_: InterruptedException) {}
        try { ws.close(1000, null) } catch (_: Throwable) {}
        try { client.dispatcher.executorService.shutdown() } catch (_: Throwable) {}
        if (found.isEmpty() && problem[0] != null) throw IOException(problem[0])
        return found.values.sortedBy { distNm(lat, lon, it.lat, it.lon) }
    }

    // ---------- Windy embed ----------

    fun windyUrl(lat: Double, lon: Double, zoom: Int): String =
        "https://embed.windy.com/embed2.html?lat=${"%.3f".format(Locale.US, lat)}&lon=${"%.3f".format(Locale.US, lon)}" +
            "&zoom=$zoom&level=surface&overlay=wind&product=ecmwf&menu=&message=true&type=map&location=coordinates" +
            "&metricWind=default&metricTemp=default"

    // ---------- Area the person cares about ----------

    class Area(val lat: Double, val lon: Double, val nm: Int)

    fun area(ctx: Context): Area? {
        val s = sp(ctx)
        val la = s.getString("lat", "")?.trim()?.toDoubleOrNull()?.takeIf { it in -90.0..90.0 } ?: return null
        val lo = s.getString("lon", "")?.trim()?.toDoubleOrNull()?.takeIf { it in -180.0..180.0 } ?: return null
        return Area(la, lo, s.getInt("nm", 100).coerceIn(10, 250))
    }

    // ---------- Cache of the latest result, so voice commands can answer without the network ----------

    fun cachePut(ctx: Context, key: String, text: String) {
        try { sp(ctx).edit().putString("c_$key", text).putLong("t_$key", System.currentTimeMillis()).apply() } catch (_: Throwable) {}
    }

    fun cacheGet(ctx: Context, key: String): String? {
        val s = sp(ctx)
        val t = s.getString("c_$key", null) ?: return null
        val age = (System.currentTimeMillis() - s.getLong("t_$key", 0L)) / 60000
        return if (age < 2) t else "$t (checked ${ago(age)} ago)"
    }

    fun ago(minutes: Long): String = when {
        minutes < 60 -> "$minutes min"
        minutes < 60 * 48 -> "${minutes / 60} h"
        else -> "${minutes / 1440} d"
    }

    fun quakeLine(q: Quake) = "Magnitude ${"%.1f".format(Locale.US, q.mag)} earthquake, ${q.place}, ${ago((System.currentTimeMillis() - q.time) / 60000)} ago."

    // ---------- Background alerts ----------

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 31, Intent(ctx, WatchReceiver::class.java).setAction(ACTION_POLL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun schedule(ctx: Context, delayMs: Long = sp(ctx).getInt("every", 30) * 60_000L) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delayMs, pending(ctx))
        } catch (_: Throwable) {}
    }

    fun cancel(ctx: Context) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx)) } catch (_: Throwable) {}
    }

    /** After a restart or app update. */
    fun reschedule(ctx: Context) {
        if (enabled(ctx)) schedule(ctx)
    }

    /** One background check of every feed the person switched on. Sends notifications for anything new. */
    fun pollOnce(ctx: Context) {
        val s = sp(ctx)
        if (!s.getBoolean("on", false)) return
        if (!Legal.isAccepted(Store.get(ctx))) return
        val first = !s.contains("seen")
        val seen = LinkedHashSet<String>()
        (s.getString("seen", "") ?: "").split("\n").filter { it.isNotBlank() }.forEach { seen.add(it) }
        val fresh = ArrayList<Pair<String, String>>()
        val lock = Any()
        fun note(id: String, text: String) {
            synchronized(lock) {
                if (seen.add(id) && !first) fresh.add(id to text)
            }
        }

        val home = area(ctx)
        val workers = ArrayList<Thread>()
        fun job(block: () -> Unit) {
            val t = Thread { try { block() } catch (_: Throwable) {} }
            t.start()
            workers.add(t)
        }

        if (s.getBoolean("q", true)) job {
            val min = s.getFloat("qmag", 5.5f).toDouble()
            val list = quakes(min)
            list.firstOrNull()?.let { cachePut(ctx, "quake", quakeLine(it)) }
            list.filter { System.currentTimeMillis() - it.time < 6 * 3600_000L }.forEach { note("q" + it.id, quakeLine(it)) }
        }
        if (s.getBoolean("dis", true)) job {
            val list = disasters()
            list.firstOrNull()?.let { cachePut(ctx, "disaster", "${it.level} ${it.kind}: ${it.title}") }
            list.forEach { note("d" + it.id, "${it.level} alert, ${it.kind}: ${it.title}") }
        }
        if (s.getBoolean("nws", false)) job {
            usAlerts().forEach { note("w" + it.id.hashCode(), "${it.kind}: ${it.title}") }
        }
        if (s.getBoolean("news", false)) job {
            val list = news(s.getString("kw", "") ?: "")
            list.firstOrNull()?.let { cachePut(ctx, "news", it.title) }
            list.take(3).forEach { note("n" + it.url.hashCode(), "News: ${it.title}") }
        }
        if (s.getBoolean("air", false)) job {
            emergencies(home?.lat, home?.lon)
                .filter { it.squawk == "7700" || it.squawk == "7500" }
                .filter { home == null || it.distNm in 0.0..EMERGENCY_NM }
                .forEach {
                    val what = if (it.squawk == "7500") "hijack code 7500" else "emergency code 7700"
                    val where_ = if (it.distNm >= 0) ", ${it.distNm.toInt()} nautical miles away" else ""
                    note("a" + it.hex + it.squawk, "Aircraft ${it.call.ifBlank { it.hex }} is squawking $what$where_.")
                }
        }
        if (s.getBoolean("air", false) && home != null) job {
            military(home.lat, home.lon, home.nm).forEach {
                note("m" + it.hex, "Military aircraft ${it.call.ifBlank { it.hex }} ${if (it.type.isNotBlank()) "(${it.type}) " else ""}is ${it.distNm.toInt()} nautical miles away.")
            }
        }
        workers.forEach { try { it.join(30_000) } catch (_: InterruptedException) {} }

        synchronized(lock) {
            s.edit().putString("seen", seen.toList().takeLast(400).joinToString("\n")).putLong("lastPoll", System.currentTimeMillis()).apply()
            if (fresh.isEmpty()) return
            notifyAll(ctx, fresh.toList())
            if (s.getBoolean("spk", true)) WakeService.speakAlert("World Watch. " + fresh[0].second)
        }
    }

    private fun notifyAll(ctx: Context, items: List<Pair<String, String>>) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "World Watch alerts", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(
                ctx, 32, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            fun build(title: String, text: String) = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_jarvis)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            items.take(4).forEach { (id, text) -> nm.notify(9000 + (id.hashCode() and 0xfff), build("World Watch", text)) }
            if (items.size > 4) nm.notify(9999, build("World Watch", "${items.size - 4} more new alerts. Open World Watch to see them."))
            Store.get(ctx).log("World Watch: ${items.size} new alert" + if (items.size == 1) "" else "s")
        } catch (_: Throwable) {}
    }
}

/** Alarm target for the background World Watch check (not exported). */
class WatchReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != WorldWatch.ACTION_POLL) return
        val app = context.applicationContext
        val pr = goAsync()
        Thread {
            try {
                WorldWatch.pollOnce(app)
            } catch (_: Throwable) {
            } finally {
                try { WorldWatch.reschedule(app) } catch (_: Throwable) {}
                pr.finish()
            }
        }.start()
    }
}
