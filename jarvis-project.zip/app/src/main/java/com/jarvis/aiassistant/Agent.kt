// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Asks the PERSON (never the AI) whether a risky action may run. Blocking; called on a background thread. */
fun interface Confirmer { fun confirm(title: String, detail: String): Boolean }

/** Which tools a run may use. */
enum class ToolMode(val allows: (ToolDef) -> Boolean) {
    /** Chat screen: everything, risky tools after a confirmation dialog. */
    FULL({ true }),
    /** Voice with no screen to confirm on: only tools that need no confirmation. */
    VOICE({ !it.confirm }),
    /** Briefings and watch tasks: look, never act. */
    READ_ONLY({ it.readOnly })
}

object Agent {
    private const val MAX_ROUNDS = 8
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()

    /** Short live-status text for the overlay and "On it, sir". */
    fun statusFor(tool: String) = when (tool) {
        "search_web" -> "Searching the web"; "read_page" -> "Reading a page"; "get_weather" -> "Checking the weather"
        "set_timer" -> "Setting a timer"; "set_alarm" -> "Setting an alarm"; "background_task" -> "Starting a background job"
        "remember" -> "Saving that"; "open_app" -> "Opening the app"; "read_calendar" -> "Checking your calendar"
        "read_notifications" -> "Reading notifications"; "get_location" -> "Finding where you are"
        else -> tool.replace('_', ' ').replaceFirstChar { it.uppercase() }
    }

    /** Runs the model, executes the tools it asks for, and returns the final spoken text. Blocking. */
    fun run(
        ctx: Context, store: Store, system: String, history: List<Pair<String, String>>,
        mode: ToolMode, confirmer: Confirmer?, call: AiCall?,
        onStatus: (String) -> Unit = {}, onDelta: (String) -> Unit
    ): String {
        Web.clearSources()
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        var round = 0
        while (true) {
            val tools = if (round >= MAX_ROUNDS) null else Tools.specs(mode.allows)
            val r = Ai.chat(store.apiKey, store.model, system, msgs, tools, call, onDelta)
            if (r.toolCalls.isEmpty()) {
                if (r.text.isNotBlank() || round == 0) return r.text
                onDelta("Done."); return "Done."
            }
            if (r.text.isNotBlank()) onDelta(" ")
            val tc = JSONArray()
            r.toolCalls.forEach { t ->
                tc.put(JSONObject().put("id", t.id).put("type", "function")
                    .put("function", JSONObject().put("name", t.name).put("arguments", t.args.ifBlank { "{}" })))
            }
            msgs.put(JSONObject().put("role", "assistant").put("content", r.text.ifBlank { JSONObject.NULL }).put("tool_calls", tc))
            if (call?.cancelled == true) throw java.io.IOException("Cancelled.")
            onStatus(r.toolCalls.joinToString(", ") { statusFor(it.name) } + "...")
            // Independent tools run at the same time; ones that need the person's tap run afterwards, one by one.
            val outs = arrayOfNulls<String>(r.toolCalls.size)
            val par = r.toolCalls.indices.filter { Tools.find(r.toolCalls[it].name)?.confirm != true }
            pool.invokeAll(par.map { i -> java.util.concurrent.Callable { outs[i] = execute(ctx, store, r.toolCalls[i], mode, confirmer) } })
            r.toolCalls.indices.filter { it !in par }.forEach { i ->
                if (call?.cancelled == true) throw java.io.IOException("Cancelled.")
                outs[i] = execute(ctx, store, r.toolCalls[i], mode, confirmer)
            }
            r.toolCalls.forEachIndexed { i, t ->
                msgs.put(JSONObject().put("role", "tool").put("tool_call_id", t.id).put("content", (outs[i] ?: "No result.").take(4000)))
            }
            round++
        }
    }

    internal fun execute(ctx: Context, store: Store, t: ToolCall, mode: ToolMode, confirmer: Confirmer?): String {
        val tool = Tools.find(t.name)
        if (tool == null || !mode.allows(tool)) return "That tool is not available here."
        val args = try { JSONObject(t.args.ifBlank { "{}" }) } catch (_: Exception) { return "The arguments were not valid JSON." }
        if (tool.confirm) {
            val ok = confirmer?.confirm("Jarvis wants to act", tool.ask(args)) ?: false
            if (!ok) return "The person declined, or could not be asked. Do not retry; tell them it was not done."
        }
        return try { tool.run(ctx, store, args) } catch (e: Throwable) { "Failed: ${e.message ?: e.javaClass.simpleName}" }
    }
}
