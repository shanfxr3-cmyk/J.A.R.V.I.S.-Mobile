// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun batteryPercent(ctx: Context): Int {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}

/** Returns (available bytes, total bytes) of device RAM. */
fun ramInfo(ctx: Context): Pair<Long, Long> {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return Pair(mi.availMem, mi.totalMem)
}

fun gb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytes / 1073741824.0)

fun timeStr(t: Long): String = SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(t))
