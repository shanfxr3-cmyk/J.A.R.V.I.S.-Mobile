// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun batteryPercent(ctx: Context): Int {
    val manager = ctx.getSystemService(BatteryManager::class.java)
    val percent = runCatching { manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }.getOrDefault(-1)
    return if (percent in 0..100) percent else -1   // some phones return Int.MIN_VALUE
}

fun batteryText(percent: Int): String = if (percent < 0) "--" else "$percent%"

/** Returns (available bytes, total bytes) of device RAM. */
fun ramInfo(ctx: Context): Pair<Long, Long> {
    val info = ActivityManager.MemoryInfo()
    ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
    return info.availMem to info.totalMem
}

fun gb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytes / 1073741824.0)

fun timeStr(millis: Long): String = SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(millis))

/** Live battery and RAM readings, refreshed by [rememberDeviceStats]. */
@Stable
class DeviceStats(private val ctx: Context) {
    var battery by mutableIntStateOf(batteryPercent(ctx))
        private set
    var ram by mutableStateOf(ramInfo(ctx))
        private set

    fun refresh() {
        battery = batteryPercent(ctx)
        ram = ramInfo(ctx)
    }
}

/** Polls battery and RAM only while the app is visible (see [LaunchWhileStarted]). */
@Composable
fun rememberDeviceStats(intervalMs: Long): DeviceStats {
    val appContext = LocalContext.current.applicationContext
    val stats = remember { DeviceStats(appContext) }
    LaunchWhileStarted {
        while (true) {
            stats.refresh()
            delay(intervalMs)
        }
    }
    return stats
}
