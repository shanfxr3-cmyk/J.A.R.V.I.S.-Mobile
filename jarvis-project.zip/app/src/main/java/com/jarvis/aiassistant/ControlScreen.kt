// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun StatusLine(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, pulse = false, size = 7.dp)
        Spacer(Modifier.width(8.dp))
        MonoText(Mono.label(label, 7), color = Dim, size = 10.sp)
        Text(value, color = color, fontFamily = MonoFont, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 11.sp, maxLines = 2)
    }
}

/** Settings > Phone control. Emits its cards into the Settings column. */
@Composable
internal fun ControlPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var snap by remember { mutableStateOf(Shell.snapshot(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchWhileStarted {
        while (true) {
            snap = withContext(Dispatchers.IO) { Shell.snapshot(ctx) }
            delay(1500)
        }
    }
    fun work(block: () -> String) {
        if (busy) return
        busy = true; msg = "Working..."
        scope.launch { msg = withContext(Dispatchers.IO) { runCatching(block).getOrElse { "Failed: ${it.message}" } }; busy = false }
    }

    SubHeader("PHONE CONTROL", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val shizuku = when {
                !snap.installed -> "NOT INSTALLED"
                !snap.running -> "INSTALLED / NOT RUNNING"
                !snap.granted -> "RUNNING / NOT ALLOWED"
                snap.uid == 0 -> "READY / ROOT"
                else -> "READY / SHELL"
            }
            StatusLine("SHIZUKU", shizuku, if (snap.granted) Green else if (snap.running) Amber else Dim)
            StatusLine(
                "ACCESS", if (snap.a11yBound) "ON / CAN SEE AND TOUCH THE SCREEN" else if (snap.a11yListed) "LISTED / NOT CONNECTED" else "OFF",
                if (snap.a11yBound) Green else if (snap.a11yListed) Amber else Dim
            )
            StatusLine("SECURE", if (snap.secure) "YES" else "NO (GRANT ALL FIXES IT)", if (snap.secure) Green else Amber)
        }
    }

    SectionTitle("SHIZUKU")
    HudBtn("Open Shizuku", Modifier.fillMaxWidth(), BtnKind.Outline) { Shell.openApp(ctx) }
    HudBtn("Allow Jarvis in Shizuku", Modifier.fillMaxWidth(), enabled = !busy && !snap.granted) { work { Shell.request(ctx) } }
    HudBtn("Grant ALL permissions now", Modifier.fillMaxWidth(), enabled = !busy && snap.granted) {
        work { val r = Shell.grantAll(ctx); store.markControlGranted(BuildConfig.VERSION_CODE); r }
    }

    SectionTitle("ACCESSIBILITY")
    HudBtn("Turn on accessibility", Modifier.fillMaxWidth(), enabled = !busy && !snap.a11yBound) {
        if (snap.granted) work { Shell.enableAccessibility(ctx) }
        else {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            msg = "Find Jarvis control, turn it on. If it is greyed out: App info, three dots, Allow restricted settings."
        }
    }
    HudBtn("Open accessibility settings", Modifier.fillMaxWidth(), BtnKind.Outline) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    HudBtn("Open app info (restricted settings)", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }

    SectionTitle("BEHAVIOUR")
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Act without asking", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Note("Taps, typing, keys, toggles and settings run at once, also by voice. Uninstall, clear data, reboot, shell, calls and texts still ask in chat and never run by voice.")
                }
                HudSwitch(store.controlFree) { store.updateControlFree(it) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Repair at Shizuku start", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Note("When Shizuku comes up, re-grant permissions and switch accessibility back on.")
                }
                HudSwitch(store.controlAuto) { store.updateControlAuto(it) }
            }
        }
    }

    SectionTitle("TEST")
    HudBtn("Test: read the screen", Modifier.fillMaxWidth(), BtnKind.Outline, enabled = !busy) {
        work { Tools.find("screen_read")?.run?.invoke(ctx, store, org.json.JSONObject()) ?: "Missing." }
    }
    HudBtn("Test: press Home", Modifier.fillMaxWidth(), BtnKind.Outline, enabled = !busy) {
        work { Tools.find("press_key")?.run?.invoke(ctx, store, org.json.JSONObject().put("key", "home")) ?: "Missing." }
    }
    msg?.let { Text(it, color = Amber, fontSize = 12.sp) }
    Note("Shizuku has to be started again after every reboot (Wireless debugging, or USB). Accessibility stays on by itself.")
}
