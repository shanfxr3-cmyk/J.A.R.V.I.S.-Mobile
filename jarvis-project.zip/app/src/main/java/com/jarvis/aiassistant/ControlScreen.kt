// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Settings > Phone control. Emits its cards into the Settings column. */
@Composable
internal fun ControlPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var snap by remember { mutableStateOf(Shell.snapshot(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchWhileStarted {
        while (true) {
            snap = withContext(Dispatchers.IO) { Shell.snapshot(ctx) }
            delay(1500)
        }
    }
    fun work(block: () -> String) {
        if (busy) return
        busy = true; msg = "Working..."
        scope.launch { msg = withContext(Dispatchers.IO) { runCatching(block).getOrElse { "Failed: ${it.message}" } }; busy = false }
    }

    SubHeader("PHONE CONTROL", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("SHIZUKU", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
            Text(
                when {
                    !snap.installed -> "Not installed"
                    !snap.running -> "Installed, not running"
                    !snap.granted -> "Running, Jarvis not allowed yet"
                    snap.uid == 0 -> "Ready, root"
                    else -> "Ready, shell"
                }
            )
            Text("ACCESSIBILITY", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
            Text(if (snap.a11yBound) "On, Jarvis can see and touch the screen" else if (snap.a11yListed) "Listed but not connected, tap Turn on again" else "Off")
            Text("Secure settings access: " + if (snap.secure) "yes" else "no (Grant all fixes it)", color = Dim, fontSize = 12.sp)
        }
    }

    SectionTitle("SHIZUKU")
    HudBtn("Open Shizuku", Modifier.fillMaxWidth(), BtnKind.Outline) { Shell.openApp(ctx) }
    HudBtn("Allow Jarvis in Shizuku", Modifier.fillMaxWidth(), enabled = !busy && !snap.granted) { work { Shell.request(ctx) } }
    HudBtn("Grant ALL permissions now", Modifier.fillMaxWidth(), enabled = !busy && snap.granted) {
        work { val r = Shell.grantAll(ctx); store.markControlGranted(BuildConfig.VERSION_CODE); r }
    }

    SectionTitle("ACCESSIBILITY")
    HudBtn("Turn on accessibility", Modifier.fillMaxWidth(), enabled = !busy && !snap.a11yBound) {
        if (snap.granted) work { Shell.enableAccessibility(ctx) }
        else {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            msg = "Find Jarvis control, turn it on. If it is greyed out: App info, three dots, Allow restricted settings."
        }
    }
    HudBtn("Open accessibility settings", Modifier.fillMaxWidth(), BtnKind.Outline) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    HudBtn("Open app info (restricted settings)", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }

    SectionTitle("BEHAVIOUR")
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Act without asking", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Note("Taps, typing, keys, toggles and settings run at once, also by voice. Uninstall, clear data, reboot, shell, calls and texts still ask in chat and never run by voice.")
                }
                HudSwitch(store.controlFree) { store.setControlFree(it) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Repair at Shizuku start", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Note("When Shizuku comes up, re-grant permissions and switch accessibility back on.")
                }
                HudSwitch(store.controlAuto) { store.setControlAuto(it) }
            }
        }
    }

    SectionTitle("TEST")
    HudBtn("Test: read the screen", Modifier.fillMaxWidth(), BtnKind.Outline, enabled = !busy) {
        work { Tools.find("screen_read")?.run?.invoke(ctx, store, org.json.JSONObject()) ?: "Missing." }
    }
    HudBtn("Test: press Home", Modifier.fillMaxWidth(), BtnKind.Outline, enabled = !busy) {
        work { Tools.find("press_key")?.run?.invoke(ctx, store, org.json.JSONObject().put("key", "home")) ?: "Missing." }
    }
    msg?.let { Text(it, color = Amber, fontSize = 12.sp) }
    Note("Shizuku has to be started again after every reboot (Wireless debugging, or USB). Accessibility stays on by itself.")
}
