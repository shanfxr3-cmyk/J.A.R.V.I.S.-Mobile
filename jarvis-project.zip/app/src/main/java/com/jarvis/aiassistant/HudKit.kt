// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.net.TrafficStats
import android.os.SystemClock
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================================================
// Readout layer. Live numbers use Inter with tabular figures and a minimum width, so a value that
// changes never shifts or resizes anything around it.
// =====================================================================================================

private val TNUM = androidx.compose.ui.text.TextStyle(fontFeatureSettings = "tnum")

/** Single-line text. When [chars] > 0 the box is at least that many characters wide (live values never shrink the row). */
@Composable
fun MonoText(
    text: String, modifier: Modifier = Modifier, color: Color = Ink, size: TextUnit = 14.sp, bold: Boolean = false,
    align: TextAlign = TextAlign.Start, chars: Int = 0, overflow: TextOverflow = TextOverflow.Clip
) {
    val m = if (chars > 0) {
        val w = with(LocalDensity.current) { (size.toPx() * MONO_ADVANCE * chars).toDp() }
        modifier.widthIn(min = w)
    } else modifier
    Text(
        text, m, color = color, fontSize = size, fontFamily = BodyFont, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        style = TNUM, textAlign = align, maxLines = 1, softWrap = false, overflow = overflow
    )
}

/** Fast-changing readout. [value] is read here, inside this tiny composable, so a change recomposes only this text. */
@Composable
fun LiveMono(value: () -> String, chars: Int, modifier: Modifier = Modifier, color: Color = Ink, size: TextUnit = 14.sp, bold: Boolean = false, align: TextAlign = TextAlign.End) {
    MonoText(value(), modifier, color, size, bold, align, chars)
}

/** "Label ........ value" line with a live value. */
@Composable
fun DataRow(label: String, valueChars: Int, modifier: Modifier = Modifier, color: Color = Ink, value: () -> String) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        MonoText(label, color = Dim, size = 13.sp)
        Spacer(Modifier.weight(1f))
        LiveMono(value, valueChars, color = color, bold = true)
    }
}

@Composable
fun PanelTitle(text: String, color: Color = Cyan, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Led(color, size = 7.dp, pulse = false)
        Spacer(Modifier.width(8.dp))
        Text(text.soft(), color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
    }
}

/** Rounded status pill, e.g. "API key set". */
@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.background(color.copy(alpha = 0.14f), PillShape).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Led(color, size = 7.dp, pulse = false)
        Spacer(Modifier.width(6.dp))
        Text(text.soft(), color = color, fontSize = 12.sp, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** "412 KB/s" below 1 MB/s, "1.2 MB/s" above. */
fun friendlyRate(kbps: Int): String {
    val k = kbps.coerceAtLeast(0)
    return if (k < 1000) "$k KB/s" else "${k / 1024}.${(k % 1024) * 10 / 1024} MB/s"
}

private val TIME_FMT = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())

/** Short readable timestamp. Main thread only. */
fun monoTime(t: Long): String = TIME_FMT.format(Date(t))

// =====================================================================================================
// GPU / draw-phase widgets. Paths, brushes and strokes are built in drawWithCache; draw blocks only mutate and draw.
// =====================================================================================================

/** Smooth rounded progress bar. [fraction] is read in the draw phase, so level changes never recompose anything. */
@Composable
fun SegBar(fraction: () -> Float, modifier: Modifier = Modifier, color: Color = Cyan, segments: Int = 20, warnAt: Float = 2f) {
    val frac by rememberUpdatedState(fraction)
    Spacer(
        modifier.height(8.dp).drawWithCache {
            val h = size.height
            val rr = androidx.compose.ui.geometry.CornerRadius(h / 2f)
            val track = color.copy(alpha = 0.14f)
            onDrawBehind {
                val f = frac().coerceIn(0f, 1f)
                val on = if (f >= warnAt) Amber else color
                drawRoundRect(track, cornerRadius = rr)
                if (f > 0f) drawRoundRect(on, size = Size(maxOf(size.width * f, h), h), cornerRadius = rr)
            }
        }
    )
}

// =====================================================================================================
// Live device telemetry: RAM allocation, exact network deltas, battery. Sampled once a second while the app is visible.
// =====================================================================================================

const val SPARK_N = 60

@Stable
class SysTelemetry {
    var ramUsedPct by mutableIntStateOf(0)
    var ramFreeMb by mutableIntStateOf(0)
    var ramTotalMb by mutableIntStateOf(0)
    var rxKbps by mutableIntStateOf(0)
    var txKbps by mutableIntStateOf(0)
    var battery by mutableIntStateOf(-1)
    /** Bumped after every sample. Read only in draw blocks and derivedStateOf nodes. */
    var tick by mutableIntStateOf(0)
    @JvmField val rx = FloatArray(SPARK_N)
    @JvmField val tx = FloatArray(SPARK_N)
    @JvmField var head = 0

    private var lastRx = -1L
    private var lastTx = -1L
    private var lastT = 0L

    fun sample(ctx: Context) {
        val (free, total) = ramInfo(ctx)
        val mb = 1048576L
        ramFreeMb = (free / mb).toInt()
        ramTotalMb = (total / mb).toInt()
        ramUsedPct = if (total > 0) (100L - free * 100L / total).toInt().coerceIn(0, 100) else 0
        battery = batteryPercent(ctx)

        val now = SystemClock.elapsedRealtime()
        val r = TrafficStats.getTotalRxBytes()
        val t = TrafficStats.getTotalTxBytes()
        var dr = 0; var dt = 0
        if (lastT != 0L && r >= 0 && t >= 0 && lastRx >= 0 && lastTx >= 0) {
            val ms = (now - lastT).coerceAtLeast(1L)
            dr = ((r - lastRx) * 1000L / ms / 1024L).toInt().coerceAtLeast(0)
            dt = ((t - lastTx) * 1000L / ms / 1024L).toInt().coerceAtLeast(0)
        }
        lastRx = r; lastTx = t; lastT = now
        rxKbps = dr; txKbps = dt
        rx[head] = dr.toFloat(); tx[head] = dt.toFloat()
        head = (head + 1) % SPARK_N
        tick++
    }
}

@Composable
fun rememberSysTelemetry(periodMs: Long = 1000L): SysTelemetry {
    val app = LocalContext.current.applicationContext
    val tel = remember { SysTelemetry() }
    LaunchWhileStarted {
        while (true) { tel.sample(app); delay(periodMs) }
    }
    return tel
}

/** Download (blue, filled) and upload (amber) history, one sample per second, drawn as smooth curves. */
@Composable
fun NetSpark(tel: SysTelemetry, modifier: Modifier = Modifier) {
    Spacer(
        modifier.drawWithCache {
            val w = size.width; val h = size.height
            val dx = w / (SPARK_N - 1)
            val lineRx = Path(); val fillRx = Path(); val lineTx = Path()
            val fillBrush = Brush.verticalGradient(listOf(Cyan.copy(alpha = 0.30f), Color.Transparent), 0f, h)
            val stroke = Stroke(2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round, join = StrokeJoin.Round)
            fun smooth(p: Path, xs: FloatArray, first: Boolean) {
                var px = xs[0]; var py = xs[1]
                if (first) p.moveTo(px, py) else p.lineTo(px, py)
                var i = 2
                while (i < xs.size) {
                    val x = xs[i]; val y = xs[i + 1]
                    p.quadraticTo(px, py, (px + x) * 0.5f, (py + y) * 0.5f)
                    px = x; py = y; i += 2
                }
                p.lineTo(px, py)
            }
            val ptsR = FloatArray(SPARK_N * 2); val ptsT = FloatArray(SPARK_N * 2)
            onDrawBehind {
                if (tel.tick < 0) return@onDrawBehind
                var mx = 64f
                for (i in 0 until SPARK_N) { if (tel.rx[i] > mx) mx = tel.rx[i]; if (tel.tx[i] > mx) mx = tel.tx[i] }
                val k = (h - 6f) / mx
                for (j in 0 until SPARK_N) {
                    val i = (tel.head + j) % SPARK_N
                    ptsR[j * 2] = j * dx; ptsR[j * 2 + 1] = h - 3f - tel.rx[i] * k
                    ptsT[j * 2] = j * dx; ptsT[j * 2 + 1] = h - 3f - tel.tx[i] * k
                }
                lineRx.rewind(); fillRx.rewind(); lineTx.rewind()
                smooth(lineRx, ptsR, true); smooth(lineTx, ptsT, true)
                fillRx.moveTo(0f, h); smooth(fillRx, ptsR, false); fillRx.lineTo(w, h); fillRx.close()
                drawPath(fillRx, fillBrush)
                drawPath(lineRx, Cyan, style = stroke)
                drawPath(lineTx, Amber, style = stroke)
            }
        }
    )
}

// =====================================================================================================
// Status cards: memory and battery, AI model order, network.
// =====================================================================================================

@Composable
fun SysPanel(tel: SysTelemetry, modifier: Modifier = Modifier) {
    val bat = tel.battery
    val bc = if (bat in 0..15) Danger else if (bat in 0..30) Amber else Green
    HudCard(modifier, pad = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PanelTitle("Memory")
            DataRow("In use", 4) { "${tel.ramUsedPct}%" }
            SegBar({ tel.ramUsedPct / 100f }, Modifier.fillMaxWidth(), warnAt = 0.9f)
            DataRow("Free", 7) { "${tel.ramFreeMb} MB" }
            DataRow("Total", 7) { "${tel.ramTotalMb} MB" }
            Spacer(Modifier.height(4.dp))
            DataRow("Battery", 4, color = bc) { if (tel.battery < 0) "--" else "${tel.battery}%" }
            SegBar({ tel.battery.coerceAtLeast(0) / 100f }, Modifier.fillMaxWidth(), color = bc)
        }
    }
}

@Composable
private fun LadderRow(id: String, preferred: String, tel: SysTelemetry) {
    val tag by remember(id, preferred) {
        derivedStateOf {
            if (tel.tick < 0) "" else when {
                ModelLadder.isResting(id) -> "Resting"
                ModelLadder.best(preferred) == id -> "Active"
                else -> "Standby"
            }
        }
    }
    val c = when (tag) { "Resting" -> Amber; "Active" -> Green; else -> Dim }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        MonoText(id.substringAfterLast('/'), Modifier.weight(1f), color = Ink, size = 13.sp, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.width(8.dp))
        MonoText(tag, Modifier.background(c.copy(alpha = 0.14f), PillShape).padding(horizontal = 9.dp, vertical = 3.dp), color = c, size = 11.sp, bold = true)
    }
}

@Composable
fun ModelPanel(store: Store, tel: SysTelemetry, modifier: Modifier = Modifier) {
    val preferred = store.model
    val ids = remember(preferred, store.ladder) { ModelLadder.order(preferred) }
    HudCard(modifier, pad = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PanelTitle("AI models", Amber)
            ids.forEach { id -> LadderRow(id, preferred, tel) }
            Spacer(Modifier.height(4.dp))
            val g = store.groqKey.isNotBlank(); val m = store.geminiKey.isNotBlank()
            DataRow("Groq key", 6, color = if (g) Green else Dim) { if (g) "Set" else "None" }
            DataRow("Gemini key", 6, color = if (m) Green else Dim) { if (m) "Set" else "None" }
        }
    }
}

@Composable
fun NetPanel(tel: SysTelemetry, modifier: Modifier = Modifier) {
    HudCard(modifier, pad = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PanelTitle("Network")
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    MonoText("Download", color = Dim, size = 12.sp)
                    LiveMono({ friendlyRate(tel.rxKbps) }, 8, color = Cyan, size = 17.sp, bold = true, align = TextAlign.Start)
                }
                Column {
                    MonoText("Upload", color = Dim, size = 12.sp)
                    LiveMono({ friendlyRate(tel.txKbps) }, 8, color = Amber, size = 17.sp, bold = true, align = TextAlign.Start)
                }
            }
            NetSpark(tel, Modifier.fillMaxWidth().height(48.dp))
        }
    }
}

/** Memory and battery beside the model list, network below. */
@Composable
fun SystemConsole(store: Store, tel: SysTelemetry, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SysPanel(tel, Modifier.weight(1f).fillMaxHeight())
            ModelPanel(store, tel, Modifier.weight(1f).fillMaxHeight())
        }
        NetPanel(tel, Modifier.fillMaxWidth())
    }
}

/** Kept for compatibility. The numbered index column is gone from the new design, so this draws nothing. */
@Composable
fun IndexTag(n: Int, color: Color = Dim, digits: Int = 3) { }

/** Summary tile: small caption over a large number (memory screen header). */
@Composable
fun CounterCell(caption: String, value: Int, digits: Int, color: Color, modifier: Modifier = Modifier) {
    HudCard(modifier, pad = 14.dp) {
        Column {
            Text(caption.soft(), color = Dim, fontFamily = BodyFont, fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text("$value", color = color, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 28.sp, maxLines = 1)
        }
    }
}
