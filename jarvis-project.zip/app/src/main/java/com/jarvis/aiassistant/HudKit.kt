// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.net.TrafficStats
import android.os.SystemClock
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================================================
// Monospace data compaction layer: every number is a fixed number of characters in a fixed-advance font,
// and its box has a fixed width, so a value that changes never moves or resizes anything around it.
// =====================================================================================================

/** Text in a box exactly [chars] characters wide (when chars > 0). One line, never wraps, never grows. */
@Composable
fun MonoText(
    text: String, modifier: Modifier = Modifier, color: Color = Ink, size: TextUnit = 12.sp, bold: Boolean = false,
    align: TextAlign = TextAlign.Start, chars: Int = 0, overflow: TextOverflow = TextOverflow.Clip
) {
    val m = if (chars > 0) {
        val w = with(LocalDensity.current) { (size.toPx() * MONO_ADVANCE * chars).toDp() + 1.dp }
        modifier.width(w)
    } else modifier
    Text(
        text, m, color = color, fontSize = size, fontFamily = MonoFont, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = align, maxLines = 1, softWrap = false, overflow = overflow
    )
}

/**
 * Fast-changing readout. [value] is read here, inside this tiny composable, so a change recomposes only this text
 * and never its parent. Pair with derivedStateOf at the call site when the source updates more often than the text.
 */
@Composable
fun LiveMono(value: () -> String, chars: Int, modifier: Modifier = Modifier, color: Color = Ink, size: TextUnit = 11.sp, bold: Boolean = false, align: TextAlign = TextAlign.End) {
    MonoText(value(), modifier, color, size, bold, align, chars)
}

/** "LABEL ........ VALUE" line with a fixed-width live value. */
@Composable
fun DataRow(label: String, valueChars: Int, modifier: Modifier = Modifier, color: Color = Cyan, value: () -> String) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        MonoText(Mono.label(label, 4), color = Dim, size = 10.sp)
        Spacer(Modifier.weight(1f))
        LiveMono(value, valueChars, color = color, bold = true)
    }
}

@Composable
fun PanelTitle(text: String, color: Color = Cyan, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Led(color, size = 5.dp)
        Spacer(Modifier.width(6.dp))
        Text(text, color = color, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.sp, maxLines = 1)
    }
}

/** Fixed width status tag, e.g. "KEY SET". */
@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.border(0.5.dp, color.copy(alpha = 0.7f), CutCornerShape(topStart = 5.dp, bottomEnd = 5.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Led(color, size = 5.dp)
        Spacer(Modifier.width(5.dp))
        Text(text, color = color, fontSize = 9.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1, letterSpacing = 0.5.sp)
    }
}

private val TIME_FMT = SimpleDateFormat("dd/MM HH:mm", Locale.US)

/** Constant-width timestamp (11 characters). Main thread only. */
fun monoTime(t: Long): String = TIME_FMT.format(Date(t))

// =====================================================================================================
// GPU / draw-phase widgets. Paths, brushes and strokes are built in drawWithCache; draw blocks only mutate and draw.
// =====================================================================================================

/** Segmented level bar. [fraction] is read in the draw phase, so level changes never recompose anything. */
@Composable
fun SegBar(fraction: () -> Float, modifier: Modifier = Modifier, color: Color = Cyan, segments: Int = 20, warnAt: Float = 2f) {
    val frac by rememberUpdatedState(fraction)
    Spacer(
        modifier.height(7.dp).drawWithCache {
            val gap = 1.5.dp.toPx()
            val sw = (size.width - gap * (segments - 1)) / segments
            val h = size.height
            val dimC = color.copy(alpha = 0.14f)
            onDrawBehind {
                val f = frac().coerceIn(0f, 1f)
                val lit = (f * segments + 0.5f).toInt()
                val on = if (f >= warnAt) Amber else color
                for (i in 0 until segments) drawRect(if (i < lit) on else dimC, Offset(i * (sw + gap), 0f), Size(sw, h))
            }
        }
    )
}

// =====================================================================================================
// Live device telemetry: RAM allocation, exact network deltas, battery. Sampled once a second while the app is visible.
// =====================================================================================================

const val SPARK_N = 60

@Stable
class SysTelemetry {
    var ramUsedPct by mutableIntStateOf(0)
    var ramFreeMb by mutableIntStateOf(0)
    var ramTotalMb by mutableIntStateOf(0)
    var rxKbps by mutableIntStateOf(0)
    var txKbps by mutableIntStateOf(0)
    var battery by mutableIntStateOf(-1)
    /** Bumped after every sample. Read only in draw blocks and derivedStateOf nodes. */
    var tick by mutableIntStateOf(0)
    @JvmField val rx = FloatArray(SPARK_N)
    @JvmField val tx = FloatArray(SPARK_N)
    @JvmField var head = 0
    val cores: Int = Runtime.getRuntime().availableProcessors()

    private var lastRx = -1L
    private var lastTx = -1L
    private var lastT = 0L

    fun sample(ctx: Context) {
        val (free, total) = ramInfo(ctx)
        val mb = 1048576L
        ramFreeMb = (free / mb).toInt()
        ramTotalMb = (total / mb).toInt()
        ramUsedPct = if (total > 0) (100L - free * 100L / total).toInt().coerceIn(0, 100) else 0
        battery = batteryPercent(ctx)

        val now = SystemClock.elapsedRealtime()
        val r = TrafficStats.getTotalRxBytes()
        val t = TrafficStats.getTotalTxBytes()
        var dr = 0; var dt = 0
        if (lastT != 0L && r >= 0 && t >= 0 && lastRx >= 0 && lastTx >= 0) {
            val ms = (now - lastT).coerceAtLeast(1L)
            dr = ((r - lastRx) * 1000L / ms / 1024L).toInt().coerceAtLeast(0)
            dt = ((t - lastTx) * 1000L / ms / 1024L).toInt().coerceAtLeast(0)
        }
        lastRx = r; lastTx = t; lastT = now
        rxKbps = dr; txKbps = dt
        rx[head] = dr.toFloat(); tx[head] = dt.toFloat()
        head = (head + 1) % SPARK_N
        tick++
    }
}

@Composable
fun rememberSysTelemetry(periodMs: Long = 1000L): SysTelemetry {
    val app = LocalContext.current.applicationContext
    val tel = remember { SysTelemetry() }
    LaunchWhileStarted {
        while (true) { tel.sample(app); delay(periodMs) }
    }
    return tel
}

/** Download (cyan, filled) and upload (amber) history, one sample per second. */
@Composable
fun NetSpark(tel: SysTelemetry, modifier: Modifier = Modifier) {
    Spacer(
        modifier.drawWithCache {
            val w = size.width; val h = size.height
            val dx = w / (SPARK_N - 1)
            val lineRx = Path(); val fillRx = Path(); val lineTx = Path()
            val base = Path().apply { moveTo(0f, h - 0.5f); lineTo(w, h - 0.5f) }
            val fillBrush = Brush.verticalGradient(listOf(Cyan.copy(alpha = 0.28f), Color.Transparent), 0f, h)
            val stroke = Stroke(1.2.dp.toPx(), join = StrokeJoin.Round)
            val baseStroke = Stroke(0.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
            val baseC = Cyan.copy(alpha = 0.3f)
            onDrawBehind {
                if (tel.tick < 0) return@onDrawBehind
                var mx = 64f
                for (i in 0 until SPARK_N) { if (tel.rx[i] > mx) mx = tel.rx[i]; if (tel.tx[i] > mx) mx = tel.tx[i] }
                val k = (h - 3f) / mx
                lineRx.rewind(); fillRx.rewind(); lineTx.rewind()
                for (j in 0 until SPARK_N) {
                    val i = (tel.head + j) % SPARK_N
                    val x = j * dx
                    val yr = h - 1.5f - tel.rx[i] * k
                    val yt = h - 1.5f - tel.tx[i] * k
                    if (j == 0) { lineRx.moveTo(x, yr); lineTx.moveTo(x, yt); fillRx.moveTo(x, h); fillRx.lineTo(x, yr) }
                    else { lineRx.lineTo(x, yr); lineTx.lineTo(x, yt); fillRx.lineTo(x, yr) }
                }
                fillRx.lineTo(w, h); fillRx.close()
                drawPath(base, baseC, style = baseStroke)
                drawPath(fillRx, fillBrush)
                drawPath(lineRx, Cyan, style = stroke)
                drawPath(lineTx, Amber, style = stroke)
            }
        }
    )
}

// =====================================================================================================
// Tactical status console: memory / battery, model path ladder, network telemetry.
// =====================================================================================================

@Composable
fun SysPanel(tel: SysTelemetry, modifier: Modifier = Modifier) {
    val bat = tel.battery
    val bc = if (bat in 0..15) Danger else if (bat in 0..30) Amber else Green
    HudCard(modifier, pad = 10.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            PanelTitle("SYS.MEM")
            DataRow("RAM", 4) { Mono.pct(tel.ramUsedPct) + "%" }
            SegBar({ tel.ramUsedPct / 100f }, Modifier.fillMaxWidth(), warnAt = 0.9f)
            DataRow("FREE", 7) { Mono.pad(tel.ramFreeMb, 4) + " MB" }
            DataRow("TOTL", 7) { Mono.pad(tel.ramTotalMb, 4) + " MB" }
            Spacer(Modifier.height(2.dp))
            DataRow("BATT", 4, color = bc) { if (tel.battery < 0) "---%" else Mono.pct(tel.battery) + "%" }
            SegBar({ tel.battery.coerceAtLeast(0) / 100f }, Modifier.fillMaxWidth(), color = bc)
            DataRow("CORE", 2) { Mono.pad(tel.cores, 2) }
        }
    }
}

@Composable
private fun LadderRow(n: Int, id: String, preferred: String, tel: SysTelemetry) {
    val tag by remember(id, preferred) {
        derivedStateOf {
            if (tel.tick < 0) "" else when {
                ModelLadder.isResting(id) -> "REST"
                ModelLadder.best(preferred) == id -> "LIVE"
                else -> "STBY"
            }
        }
    }
    val c = when (tag) { "REST" -> Amber; "LIVE" -> Cyan; else -> Dim }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        MonoText(Mono.pad(n, 2), color = Dim, size = 10.sp)
        Spacer(Modifier.width(6.dp))
        MonoText(id.substringAfterLast('/'), Modifier.weight(1f), color = c, size = 10.sp, overflow = TextOverflow.Ellipsis)
        MonoText(tag, color = c, size = 10.sp, bold = true, chars = 4, align = TextAlign.End)
    }
}

@Composable
fun ModelPanel(store: Store, tel: SysTelemetry, modifier: Modifier = Modifier) {
    val preferred = store.model
    val ids = remember(preferred) { listOf(preferred, DEFAULT_MODEL, FAST_MODEL).distinct() }
    HudCard(modifier, pad = 10.dp, accent = Amber) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            PanelTitle("MODEL.PATH", Amber)
            ids.forEachIndexed { i, id -> LadderRow(i + 1, id, preferred, tel) }
            Spacer(Modifier.height(2.dp))
            val hasKey = store.apiKey.isNotBlank()
            DataRow("KEY", 6, color = if (hasKey) Green else Amber) { if (hasKey) "SET" else "NONE" }
            val backup = store.backupKey.isNotBlank()
            DataRow("BKUP", 6, color = if (backup) Green else Dim) { if (backup) "SET" else "NONE" }
        }
    }
}

@Composable
fun NetPanel(tel: SysTelemetry, modifier: Modifier = Modifier) {
    HudCard(modifier, pad = 10.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PanelTitle("NET.TELEMETRY", modifier = Modifier.weight(1f))
                MonoText("1HZ / KB/S", color = Dim, size = 9.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MonoText("RX", color = Cyan, size = 10.sp, bold = true); Spacer(Modifier.width(5.dp))
                    LiveMono({ Mono.rate(tel.rxKbps) }, 5, color = Cyan, size = 12.sp, bold = true)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MonoText("TX", color = Amber, size = 10.sp, bold = true); Spacer(Modifier.width(5.dp))
                    LiveMono({ Mono.rate(tel.txKbps) }, 5, color = Amber, size = 12.sp, bold = true)
                }
            }
            NetSpark(tel, Modifier.fillMaxWidth().height(36.dp))
        }
    }
}

/** Two-column console: memory and battery beside the model ladder, network below. */
@Composable
fun SystemConsole(store: Store, tel: SysTelemetry, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SysPanel(tel, Modifier.weight(1f).fillMaxHeight())
            ModelPanel(store, tel, Modifier.weight(1f).fillMaxHeight())
        }
        NetPanel(tel, Modifier.fillMaxWidth())
    }
}

/** Index column used by task and memory logs: a fixed 3-digit counter. */
@Composable
fun IndexTag(n: Int, color: Color = Dim, digits: Int = 3) {
    MonoText(Mono.pad(n, digits), color = color, size = 10.sp, chars = digits)
}

/** Big fixed-width counter cell with a caption (memory screen header). */
@Composable
fun CounterCell(caption: String, value: Int, digits: Int, color: Color, modifier: Modifier = Modifier) {
    HudCard(modifier, pad = 10.dp, accent = color) {
        Column {
            Text(caption, color = Dim, fontFamily = HudFont, fontSize = 9.sp, letterSpacing = 1.sp, maxLines = 1)
            MonoText(Mono.pad(value, digits), color = color, size = 22.sp, bold = true, chars = digits)
        }
    }
}
