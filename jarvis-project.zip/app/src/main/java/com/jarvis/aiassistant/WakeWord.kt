// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer

/**
 * On-device "Hey Jarvis" detector using openWakeWord (open source, no account or key).
 * Pipeline: 16 kHz audio -> melspectrogram.onnx -> embedding_model.onnx -> hey_jarvis_v0.1.onnx.
 * The three ONNX models are downloaded once on first use and cached in app storage.
 */
class WakeWord(private val ctx: Context) {
    companion object {
        private const val BASE = "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/"
        private val MODELS = listOf("melspectrogram.onnx", "embedding_model.onnx", "hey_jarvis_v0.1.onnx")
        private const val RATE = 16000
        private const val CHUNK = 1280          // 80 ms
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76       // mel frames per embedding
        private const val EMB_DIM = 96
        private const val EMB_FRAMES = 16       // embeddings per wake-word inference

        fun modelsReady(ctx: Context): Boolean =
            MODELS.all { File(ctx.filesDir, "oww/$it").let { f -> f.exists() && f.length() > 1000 } }

        /** Blocking. Call off the main thread. */
        fun downloadModels(ctx: Context) {
            val dir = File(ctx.filesDir, "oww").apply { mkdirs() }
            for (name in MODELS) {
                val out = File(dir, name)
                if (out.exists() && out.length() > 1000) continue
                val tmp = File(dir, "$name.part")
                val c = URL(BASE + name).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                try {
                    if (c.responseCode != 200) throw RuntimeException("Download of $name failed (HTTP ${c.responseCode}).")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                } finally { c.disconnect() }
                if (!tmp.renameTo(out)) throw RuntimeException("Could not save $name.")
            }
        }
    }

    private val env = OrtEnvironment.getEnvironment()
    private var mel: OrtSession? = null
    private var emb: OrtSession? = null
    private var ww: OrtSession? = null
    private var rec: AudioRecord? = null
    @Volatile private var running = false
    private var thread: Thread? = null

    private val melBuf = ArrayList<FloatArray>()   // each 32 floats
    private val embBuf = ArrayList<FloatArray>()   // each 96 floats
    private val raw = ShortArray(CHUNK + 480)      // 1280 new + 3*160 context samples
    private var warm = 0

    /** Threshold on the 0..1 model score. */
    @Volatile var threshold = 0.5f

    private fun load() {
        if (mel != null) return
        val d = File(ctx.filesDir, "oww")
        val o = OrtSession.SessionOptions().apply { setIntraOpNumThreads(1) }
        mel = env.createSession(File(d, MODELS[0]).absolutePath, o)
        emb = env.createSession(File(d, MODELS[1]).absolutePath, o)
        ww = env.createSession(File(d, MODELS[2]).absolutePath, o)
    }

    private fun reset() {
        melBuf.clear(); embBuf.clear()
        repeat(MEL_WINDOW) { melBuf.add(FloatArray(MEL_BINS) { 1f }) }
        repeat(EMB_FRAMES) { embBuf.add(FloatArray(EMB_DIM)) }
        raw.fill(0)
        warm = 0
    }

    /** Starts listening on a background thread. onHeard is called on that thread. Throws if mic/model setup fails. */
    @SuppressLint("MissingPermission")
    fun start(onHeard: () -> Unit) {
        if (running) return
        load()
        reset()
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK * 4)
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); throw RuntimeException("Microphone is busy or unavailable.") }
        rec = r
        r.startRecording()
        running = true
        thread = Thread {
            val chunk = ShortArray(CHUNK)
            while (running) {
                var n = 0
                while (running && n < CHUNK) {
                    val k = r.read(chunk, n, CHUNK - n)
                    if (k <= 0) { running = false; break }
                    n += k
                }
                if (!running) break
                val score = try { process(chunk) } catch (_: Throwable) { 0f }
                if (warm >= 12 && score >= threshold) {
                    running = false
                    onHeard()
                    break
                }
            }
        }.also { it.name = "wakeword"; it.start() }
    }

    /** Stops and releases the microphone so SpeechRecognizer can use it. */
    fun stop() {
        running = false
        try { thread?.join(500) } catch (_: Throwable) {}
        thread = null
        try { rec?.stop() } catch (_: Throwable) {}
        try { rec?.release() } catch (_: Throwable) {}
        rec = null
    }

    fun close() {
        stop()
        try { mel?.close() } catch (_: Throwable) {}
        try { emb?.close() } catch (_: Throwable) {}
        try { ww?.close() } catch (_: Throwable) {}
        mel = null; emb = null; ww = null
    }

    private fun process(chunk: ShortArray): Float {
        // Slide the raw window: keep the last 480 samples, append 1280 new ones.
        System.arraycopy(raw, CHUNK, raw, 0, 480)
        System.arraycopy(chunk, 0, raw, 480, CHUNK)
        val f = FloatArray(raw.size) { raw[it].toFloat() }

        // 1) mel spectrogram -> ~8 new frames of 32 bins, scaled x/10 + 2
        val melOut = env.createTensor(f, longArrayOf(1, f.size.toLong())).use { t ->
            mel!!.run(mapOf(mel!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer)
            }
        }
        var i = 0
        while (i + MEL_BINS <= melOut.size) {
            melBuf.add(FloatArray(MEL_BINS) { melOut[i + it] / 10f + 2f })
            i += MEL_BINS
        }
        while (melBuf.size > MEL_WINDOW) melBuf.removeAt(0)
        if (melBuf.size < MEL_WINDOW) return 0f

        // 2) embedding of the last 76 mel frames -> 96 floats
        val flat = FloatArray(MEL_WINDOW * MEL_BINS)
        for (r in 0 until MEL_WINDOW) System.arraycopy(melBuf[r], 0, flat, r * MEL_BINS, MEL_BINS)
        val e = env.createTensor(flat, longArrayOf(1, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1)).use { t ->
            emb!!.run(mapOf(emb!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer)
            }
        }
        embBuf.add(e.copyOf(EMB_DIM))
        while (embBuf.size > EMB_FRAMES) embBuf.removeAt(0)
        warm++

        // 3) wake-word model over the last 16 embeddings
        val feat = FloatArray(EMB_FRAMES * EMB_DIM)
        for (r in 0 until EMB_FRAMES) System.arraycopy(embBuf[r], 0, feat, r * EMB_DIM, EMB_DIM)
        return env.createTensor(feat, longArrayOf(1, EMB_FRAMES.toLong(), EMB_DIM.toLong())).use { t ->
            ww!!.run(mapOf(ww!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer).firstOrNull() ?: 0f
            }
        }
    }

    private fun OrtEnvironment.createTensor(data: FloatArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(this, FloatBuffer.wrap(data), shape)

    private fun flatten(b: FloatBuffer): FloatArray {
        val d = b.duplicate(); d.rewind()
        return FloatArray(d.remaining()).also { d.get(it) }
    }
}
