// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer

/**
 * On-device "Hey Jarvis" detector using openWakeWord (open source, no account or key).
 * Pipeline: 16 kHz audio -> melspectrogram.onnx -> embedding_model.onnx -> hey_jarvis_v0.1.onnx.
 * The three ONNX models are downloaded once on first use and cached in app storage.
 */
/** A model file exists but ONNX cannot load it (damaged download). */
class ModelLoadException(msg: String, cause: Throwable?) : RuntimeException(msg, cause)

class WakeWord(private val ctx: Context) {
    companion object {
        private const val BASE = "https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/"
        private val MODELS = listOf("melspectrogram.onnx", "embedding_model.onnx", "hey_jarvis_v0.1.onnx")
        private const val RATE = 16000
        private const val CHUNK = 1280          // 80 ms
        private const val MEL_BINS = 32
        private const val MEL_WINDOW = 76       // mel frames per embedding
        private const val EMB_DIM = 96
        private const val EMB_FRAMES = 16       // embeddings per wake-word inference

        fun modelsReady(ctx: Context): Boolean =
            MODELS.all { File(ctx.filesDir, "oww/$it").let { f -> f.exists() && f.length() > MIN_BYTES } }

        private const val MIN_BYTES = 50_000L

        /** Removes the downloaded models so the next start fetches fresh copies. */
        fun deleteModels(ctx: Context) {
            try { File(ctx.filesDir, "oww").deleteRecursively() } catch (_: Throwable) {}
        }

        /** Blocking. Call off the main thread. */
        fun downloadModels(ctx: Context) {
            val dir = File(ctx.filesDir, "oww").apply { mkdirs() }
            for (name in MODELS) {
                val out = File(dir, name)
                if (out.exists() && out.length() > MIN_BYTES) continue
                val tmp = File(dir, "$name.part")
                val c = URL(BASE + name).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                try {
                    if (c.responseCode != 200) throw RuntimeException("Download of $name failed (HTTP ${c.responseCode}).")
                    val expected = c.contentLengthLong
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    // A cut-off download must never be kept as if it were a model.
                    if ((expected > 0 && tmp.length() != expected) || tmp.length() <= MIN_BYTES) {
                        tmp.delete()
                        throw RuntimeException("Download of $name was incomplete. Try again.")
                    }
                } finally { c.disconnect() }
                out.delete()
                if (!tmp.renameTo(out)) throw RuntimeException("Could not save $name.")
            }
        }
    }

    private val env = OrtEnvironment.getEnvironment()
    private var mel: OrtSession? = null
    private var emb: OrtSession? = null
    private var ww: OrtSession? = null
    private var rec: AudioRecord? = null
    @Volatile private var running = false
    private var thread: Thread? = null

    private val melBuf = ArrayList<FloatArray>()   // each 32 floats
    private val embBuf = ArrayList<FloatArray>()   // each 96 floats
    private val raw = ShortArray(CHUNK + 480)      // 1280 new + 3*160 context samples
    private var warm = 0
    // Re-used work buffers: no per-chunk allocation of the big arrays (less garbage collection, less CPU).
    private val fBuf = FloatArray(CHUNK + 480)
    private val flatBuf = FloatArray(MEL_WINDOW * MEL_BINS)
    private val featBuf = FloatArray(EMB_FRAMES * EMB_DIM)
    @Volatile private var errors = 0
    /** Last inference error, for diagnostics. */
    @Volatile var lastError: String? = null

    /** Threshold on the 0..1 model score. */
    @Volatile var threshold = 0.75f

    /** Loudness floor (RMS, 16-bit units): a detection only counts if real sound was heard in the last second. */
    @Volatile var minLevel = 330f

    // A single noisy frame must never wake the app: 3 of the last 5 frames have to score above the threshold.
    private val hitHist = BooleanArray(5)
    private var hitIdx = 0
    private val levelHist = FloatArray(12)
    private var levelIdx = 0

    /** Loads the three ONNX models. Call from a background thread (it takes a moment); start() will then skip it. */
    fun prepare() = load()

    private fun load() {
        if (mel != null) return
        val d = File(ctx.filesDir, "oww")
        val o = OrtSession.SessionOptions().apply { setIntraOpNumThreads(1) }
        try {
            mel = env.createSession(File(d, MODELS[0]).absolutePath, o)
            emb = env.createSession(File(d, MODELS[1]).absolutePath, o)
            ww = env.createSession(File(d, MODELS[2]).absolutePath, o)
        } catch (t: Throwable) {
            try { mel?.close() } catch (_: Throwable) {}
            try { emb?.close() } catch (_: Throwable) {}
            try { ww?.close() } catch (_: Throwable) {}
            mel = null; emb = null; ww = null
            throw ModelLoadException("Wake word model could not be loaded (${t.message}).", t)
        }
    }

    private fun reset() {
        melBuf.clear(); embBuf.clear()
        repeat(MEL_WINDOW) { melBuf.add(FloatArray(MEL_BINS) { 1f }) }
        repeat(EMB_FRAMES) { embBuf.add(FloatArray(EMB_DIM)) }
        raw.fill(0)
        warm = 0
        hitHist.fill(false); hitIdx = 0
        levelHist.fill(0f); levelIdx = 0
    }

    /** Starts listening on a background thread. onHeard is called on that thread. Throws if mic/model setup fails. */
    @SuppressLint("MissingPermission")
    fun start(onDead: (String) -> Unit = {}, onHeard: () -> Unit) {
        if (running) return
        load()
        reset()
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK * 2 * 8)   // bytes: ~640 ms, survives short CPU stalls
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); throw RuntimeException("Microphone is busy or unavailable.") }
        rec = r
        r.startRecording()
        running = true
        errors = 0
        lastError = null
        thread = Thread {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Throwable) {}
            val chunk = ShortArray(CHUNK)
            var died: String? = null
            while (running) {
                var n = 0
                while (running && n < CHUNK) {
                    val k = r.read(chunk, n, CHUNK - n)
                    if (k <= 0) {
                        // A read error while we were not asked to stop = the microphone was taken away.
                        if (running) died = "Microphone stopped delivering audio (error $k). Another app or a call may be using it."
                        running = false; break
                    }
                    n += k
                }
                if (!running) break
                val score = try { process(chunk).also { errors = 0 } } catch (t: Throwable) {
                    lastError = t.message ?: t.javaClass.simpleName
                    errors++
                    if (errors >= 25) { died = "Wake word model keeps failing: $lastError"; running = false }
                    0f
                }
                var sq = 0.0
                for (x in chunk) sq += x.toDouble() * x
                levelHist[levelIdx] = Math.sqrt(sq / CHUNK).toFloat(); levelIdx = (levelIdx + 1) % levelHist.size
                hitHist[hitIdx] = score >= threshold; hitIdx = (hitIdx + 1) % hitHist.size
                val hits = hitHist.count { it }
                val loud = (levelHist.maxOrNull() ?: 0f) >= minLevel
                // warm >= 20: ~1.6 s after (re)starting, so the beep and the end of my own speech are never mistaken for the wake word.
                if (running && warm >= 20 && hits >= 3 && loud) {
                    running = false
                    onHeard()
                    break
                }
            }
            died?.let { onDead(it) }
        }.also { it.name = "wakeword"; it.start() }
    }

    /** Stops and releases the microphone so SpeechRecognizer can use it. */
    fun stop() {
        running = false
        try { thread?.join(500) } catch (_: Throwable) {}
        thread = null
        try { rec?.stop() } catch (_: Throwable) {}
        try { rec?.release() } catch (_: Throwable) {}
        rec = null
    }

    fun close() {
        stop()
        try { mel?.close() } catch (_: Throwable) {}
        try { emb?.close() } catch (_: Throwable) {}
        try { ww?.close() } catch (_: Throwable) {}
        mel = null; emb = null; ww = null
    }

    private fun process(chunk: ShortArray): Float {
        // Slide the raw window: keep the last 480 samples, append 1280 new ones.
        System.arraycopy(raw, CHUNK, raw, 0, 480)
        System.arraycopy(chunk, 0, raw, 480, CHUNK)
        val f = fBuf
        for (n in raw.indices) f[n] = raw[n].toFloat()

        // 1) mel spectrogram -> ~8 new frames of 32 bins, scaled x/10 + 2
        val melOut = env.createTensor(f, longArrayOf(1, f.size.toLong())).use { t ->
            mel!!.run(mapOf(mel!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer)
            }
        }
        var i = 0
        while (i + MEL_BINS <= melOut.size) {
            melBuf.add(FloatArray(MEL_BINS) { melOut[i + it] / 10f + 2f })
            i += MEL_BINS
        }
        while (melBuf.size > MEL_WINDOW) melBuf.removeAt(0)
        if (melBuf.size < MEL_WINDOW) return 0f

        // 2) embedding of the last 76 mel frames -> 96 floats
        val flat = flatBuf
        for (r in 0 until MEL_WINDOW) System.arraycopy(melBuf[r], 0, flat, r * MEL_BINS, MEL_BINS)
        val e = env.createTensor(flat, longArrayOf(1, MEL_WINDOW.toLong(), MEL_BINS.toLong(), 1)).use { t ->
            emb!!.run(mapOf(emb!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer)
            }
        }
        embBuf.add(e.copyOf(EMB_DIM))
        while (embBuf.size > EMB_FRAMES) embBuf.removeAt(0)
        warm++

        // 3) wake-word model over the last 16 embeddings
        val feat = featBuf
        for (r in 0 until EMB_FRAMES) System.arraycopy(embBuf[r], 0, feat, r * EMB_DIM, EMB_DIM)
        return env.createTensor(feat, longArrayOf(1, EMB_FRAMES.toLong(), EMB_DIM.toLong())).use { t ->
            ww!!.run(mapOf(ww!!.inputNames.first() to t)).use { res ->
                flatten((res[0] as OnnxTensor).floatBuffer).firstOrNull() ?: 0f
            }
        }
    }

    private fun OrtEnvironment.createTensor(data: FloatArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(this, FloatBuffer.wrap(data), shape)

    private fun flatten(b: FloatBuffer): FloatArray {
        val d = b.duplicate(); d.rewind()
        return FloatArray(d.remaining()).also { d.get(it) }
    }
}
