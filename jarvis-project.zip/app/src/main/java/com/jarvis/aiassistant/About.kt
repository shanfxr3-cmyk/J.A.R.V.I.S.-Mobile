// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment

/** Version and updates. Private build: no consent gate, no legal screens, no official/unofficial label. */
@Composable
fun AboutScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val up = Updater.available

    LaunchedEffect(Unit) { Updater.sync(ctx); if (Updater.info == null) Updater.check(ctx.applicationContext) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenHeader("ABOUT", "Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("J.A.R.V.I.S", color = Cyan, fontFamily = TitleFont, fontSize = 16.sp)
                Text("Based on J.A.R.V.I.S. Mobile by Shan Akhter. Apache License 2.0.", color = Dim, fontSize = 14.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("UPDATES".soft(), color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("New versions install over this one. Your chats, tasks and settings stay.", color = Dim, fontSize = 14.sp)
                if (Updater.status.isNotEmpty()) Text(Updater.status, color = if (up != null || Updater.isError) Amber else Green, fontSize = 14.sp)
                if (up != null && up.notes.isNotBlank()) Text(up.notes, color = Dim, fontSize = 13.sp)
                if (Updater.progress >= 0) Text("Downloading ${Updater.progress}%", color = Cyan, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Updater.check(ctx.applicationContext) }, enabled = !Updater.busy) { Text("Check") }
                    if (Updater.downloaded != null && up != null) {
                        Button(onClick = { Updater.install(ctx) }) { Text("Install") }
                    } else if (up != null) {
                        Button(onClick = { Updater.download(ctx) }, enabled = !Updater.busy) { Text("Download and install") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Check when the app opens", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.updateCheck, { store.markUpdateCheck(it) })
                }
            }
        }
    }
}
