// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** [intent] receives this app's package name. */
private class ToolAction(val label: String, val intent: (packageName: String) -> Intent)

private val TOOL_ACTIONS = listOf(
    ToolAction("Open Wi-Fi settings") { Intent(Settings.ACTION_WIFI_SETTINGS) },
    ToolAction("Open Bluetooth settings") { Intent(Settings.ACTION_BLUETOOTH_SETTINGS) },
    ToolAction("Open this app's settings") { Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it")) },
    ToolAction("Open this app's notification settings") {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, it)
    },
    ToolAction("Open battery saver settings") { Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
)

@Composable
fun ToolsScreen(store: Store) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<ToolAction?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val stats = rememberDeviceStats(intervalMs = 3000)
    val (freeRam, totalRam) = stats.ram

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ScreenHeader("TOOLS", "Only actions Android allows. Each one asks first.")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DEVICE STATUS", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Battery: ${batteryText(stats.battery)}")
                Text("RAM free: ${gb(freeRam)} of ${gb(totalRam)}")
            }
        }
        TOOL_ACTIONS.forEach { action ->
            HudCard(Modifier.fillMaxWidth(), onClick = { pending = action }) { Text(action.label) }
        }
        error?.let { Text(it, color = Amber, fontSize = 12.sp) }
    }

    pending?.let { action ->
        ConfirmDialog("Confirm action", "${action.label}?", "Open", {
            try {
                ctx.startActivity(action.intent(ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                store.log("Tool used: ${action.label}")
                error = null
            } catch (e: Exception) {
                error = "Could not open: ${e.message}"
            }
            pending = null
        }, { pending = null })
    }
}
