// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Alignment
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ToolAction(val label: String, val intent: (String) -> Intent)

@Composable
fun ToolsScreen(store: Store, onOpen: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<ToolAction?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val tel = rememberSysTelemetry()

    val actions = listOf(
        ToolAction("Open Wi-Fi settings") { Intent(Settings.ACTION_WIFI_SETTINGS) },
        ToolAction("Open Bluetooth settings") { Intent(Settings.ACTION_BLUETOOTH_SETTINGS) },
        ToolAction("Open this app's settings") {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it"))
        },
        ToolAction("Open this app's notification settings") {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, it)
        },
        ToolAction("Open battery saver settings") { Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ScreenHeader("TOOLS", "ONLY ACTIONS ANDROID ALLOWS / EACH ONE ASKS FIRST")
        SectionTitle("DEVICE STATUS")
        SystemConsole(store, tel)
        SectionTitle("ACTIONS")
        actions.forEachIndexed { i, a ->
            HudCard(Modifier.fillMaxWidth(), onClick = { pending = a }, pad = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IndexTag(i + 1, digits = 2)
                    Spacer(Modifier.width(10.dp))
                    Text(a.label, Modifier.weight(1f), fontSize = 12.sp, fontFamily = MonoFont, maxLines = 2)
                    HudIcon(Ic.Chevron, tint = Dim, size = 14.dp)
                }
            }
        }
        error?.let { Text(it, color = Amber, fontSize = 11.sp, fontFamily = MonoFont) }
    }

    pending?.let { a ->
        HudDialog("CONFIRM ACTION", "${a.label}?", "OPEN", {
            try {
                ctx.startActivity(a.intent(ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                error = null
            } catch (e: Exception) {
                error = "Could not open: ${e.message}"
            }
            pending = null
        }, { pending = null })
    }
}
