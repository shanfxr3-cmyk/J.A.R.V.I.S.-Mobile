// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ToolAction(val label: String, val intent: (String) -> Intent)

@Composable
fun ToolsScreen(store: Store) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<ToolAction?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var battery by remember { mutableIntStateOf(batteryPercent(ctx)) }
    var ram by remember { mutableStateOf(ramInfo(ctx)) }
    // Refresh while the screen is visible instead of showing one frozen snapshot.
    LaunchWhileStarted {
        while (true) {
            battery = batteryPercent(ctx)
            ram = ramInfo(ctx)
            kotlinx.coroutines.delay(3000)
        }
    }

    val actions = listOf(
        ToolAction("Open Wi-Fi settings") { Intent(Settings.ACTION_WIFI_SETTINGS) },
        ToolAction("Open Bluetooth settings") { Intent(Settings.ACTION_BLUETOOTH_SETTINGS) },
        ToolAction("Open this app's settings") {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it"))
        },
        ToolAction("Open this app's notification settings") {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, it)
        },
        ToolAction("Open battery saver settings") { Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
    )

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ScreenHeader("TOOLS", "Only actions Android allows. Each one asks first.")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DEVICE STATUS", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Battery: ${batteryText(battery)}")
                Text("RAM free: ${gb(ram.first)} of ${gb(ram.second)}")
            }
        }
        actions.forEach { a ->
            HudCard(Modifier.fillMaxWidth(), onClick = { pending = a }) { Text(a.label) }
        }
        error?.let { Text(it, color = Amber, fontSize = 12.sp) }
    }

    pending?.let { a ->
        ConfirmDialog("Confirm action", "${a.label}?", "Open", {
            try {
                ctx.startActivity(a.intent(ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                store.log("Tool used: ${a.label}")
                error = null
            } catch (e: Exception) {
                error = "Could not open: ${e.message}"
            }
            pending = null
        }, { pending = null })
    }
}
