// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.content.IntentFilter
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * One thing the AI may do on the phone. [confirm] tools open a dialog the person must answer before they run;
 * the AI never sees or controls that dialog. [readOnly] tools only look at things and are the only kind allowed
 * in unattended runs (morning briefing, watch tasks).
 */
class ToolDef(
    val name: String,
    val description: String,
    val params: List<Param> = emptyList(),
    val confirm: Boolean = false,
    val readOnly: Boolean = false,
    /** Short plain sentence shown in the confirmation dialog. */
    val ask: (JSONObject) -> String = { name },
    val run: (Context, Store, JSONObject) -> String
) {
    class Param(val name: String, val type: String, val desc: String, val required: Boolean = true, val values: List<String>? = null)

    fun spec(): JSONObject {
        val props = JSONObject()
        params.forEach { p ->
            val o = JSONObject().put("type", p.type).put("description", p.desc)
            p.values?.let { o.put("enum", JSONArray(it)) }
            props.put(p.name, o)
        }
        return JSONObject().put("type", "function").put("function", JSONObject()
            .put("name", name).put("description", description)
            .put("parameters", JSONObject().put("type", "object").put("properties", props)
                .put("required", JSONArray(params.filter { it.required }.map { it.name }))))
    }
}

object Tools {
    private fun s(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "string", d, req)
    private fun i(n: String, d: String, req: Boolean = true) = ToolDef.Param(n, "integer", d, req)
    private fun b(n: String, d: String) = ToolDef.Param(n, "boolean", d)

    private fun launch(ctx: Context, intent: Intent): String =
        try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok" }
        catch (e: Throwable) { "Could not do that: ${e.message ?: "no app can handle it"}" }

    val core: List<ToolDef> = listOf(
        ToolDef("get_battery", "Battery level and whether the phone is charging.", readOnly = true) { c, _, _ ->
            val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (level < 0) "Battery level unavailable." else "Battery ${level * 100 / scale} percent, " + if (charging) "charging." else "not charging."
        },
        ToolDef("set_timer", "Start a countdown timer in the clock app.", listOf(i("seconds", "Length in seconds (1 to 86400)"), s("label", "Short label", false))) { c, _, a ->
            val sec = a.optInt("seconds", 0)
            if (sec !in 1..86400) "Timer length must be between 1 second and 24 hours."
            else {
                val r = launch(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                if (r == "ok") "Timer set for ${spoken(sec)}." else r
            }
        },
        ToolDef("set_alarm", "Set an alarm in the clock app for a time of day (24-hour clock). Rings at the next occurrence.",
            listOf(i("hour", "Hour 0 to 23"), i("minute", "Minute 0 to 59"), s("label", "Short label", false))) { c, _, a ->
            val h = a.optInt("hour", -1); val m = a.optInt("minute", -1)
            if (h !in 0..23 || m !in 0..59) "That is not a valid time."
            else {
                val r = launch(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                if (r == "ok") "Alarm set for %d:%02d.".format(h, m) else r
            }
        },
        ToolDef("torch", "Turn the flashlight on or off.", listOf(b("on", "true for on, false for off"))) { c, _, a ->
            try {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                if (id == null) "This phone has no flashlight."
                else { val on = a.optBoolean("on", true); cm.setTorchMode(id, on); if (on) "Flashlight on." else "Flashlight off." }
            } catch (e: Throwable) { "Could not use the flashlight: ${e.message}" }
        },
        ToolDef("set_volume", "Set the media volume as a percentage.", listOf(i("percent", "0 to 100"))) { c, _, a ->
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val p = a.optInt("percent", -1)
            if (p !in 0..100) "Volume must be between 0 and 100 percent."
            else {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (p / 100f * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).roundToInt(), AudioManager.FLAG_SHOW_UI)
                "Volume set to $p percent."
            }
        },
        ToolDef("media_control", "Control whatever media is playing.",
            listOf(ToolDef.Param("action", "string", "What to do", true, listOf("play_pause", "next", "previous", "stop")))) { c, _, a ->
            val code = when (a.optString("action")) {
                "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; else -> -1
            }
            if (code < 0) "Unknown media action."
            else {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val t = SystemClock.uptimeMillis()
                am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
                am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
                "Done."
            }
        },
        // ---- Risky tools: each one needs the person to tap Allow. They only open the phone's own app; nothing is sent. ----
        ToolDef("dial_number", "Open the phone dialer with a number filled in. The person still has to press call.",
            listOf(s("number", "Phone number")), confirm = true, ask = { "Open the dialer for ${it.optString("number")}?" }) { c, _, a ->
            val n = a.optString("number").trim()
            if (!PHONE.matches(n)) "That does not look like a phone number."
            else { val r = launch(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))); if (r == "ok") "Dialer opened." else r }
        },
        ToolDef("compose_sms", "Open the messaging app with a text ready to send. The person still has to press send.",
            listOf(s("number", "Phone number"), s("message", "Text of the message")), confirm = true,
            ask = { "Open a text to ${it.optString("number")} saying: \"${it.optString("message").take(120)}\"?" }) { c, _, a ->
            val n = a.optString("number").trim()
            if (!PHONE.matches(n)) "That does not look like a phone number."
            else { val r = launch(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", a.optString("message").take(1000))); if (r == "ok") "Message ready to send." else r }
        },
        ToolDef("open_settings", "Open one of the phone's settings pages. It only opens the page; the person changes things themselves.",
            listOf(ToolDef.Param("page", "string", "Which page", true, listOf("wifi", "bluetooth", "display", "sound", "battery", "location", "apps"))),
            confirm = true, ask = { "Open the ${it.optString("page")} settings?" }) { c, _, a ->
            val act = when (a.optString("page")) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS; "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY; "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS; else -> null
            }
            if (act == null) "Unknown settings page." else { val r = launch(c, Intent(act)); if (r == "ok") "Opened." else r }
        }
    )

    private val PHONE = Regex("^[+0-9 ()\\-]{3,20}$")

    fun spoken(sec: Int): String = when {
        sec % 3600 == 0 -> "${sec / 3600} hour" + if (sec / 3600 == 1) "" else "s"
        sec % 60 == 0 && sec >= 60 -> "${sec / 60} minute" + if (sec / 60 == 1) "" else "s"
        else -> "$sec seconds"
    }

    fun all(): List<ToolDef> = core + Mind.tools + Web.tools

    /** Tools offered to the model. [filter] narrows them (voice-only and unattended runs cannot ask for confirmation). */
    fun specs(filter: (ToolDef) -> Boolean): JSONArray = JSONArray().also { a -> all().filter(filter).forEach { a.put(it.spec()) } }

    fun find(name: String): ToolDef? = all().firstOrNull { it.name == name }
}
