// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Self-updater. Looks at this project's latest GitHub Release, downloads the APK, checks that it is
 * signed with the same key as the installed app, then hands it to Android's installer. Because the
 * key and the application id stay the same, the update installs over the old app and keeps all data.
 */
object Updater {
    data class Info(val code: Int, val name: String, val notes: String, val url: String, val size: Long)

    private val ui = Handler(Looper.getMainLooper())
    var info by mutableStateOf<Info?>(null)
        private set
    var status by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    var progress by mutableIntStateOf(-1)
        private set
    var downloaded by mutableStateOf<File?>(null)
        private set

    val available: Info? get() = info?.takeIf { it.code > BuildConfig.VERSION_CODE }

    private fun ua() = "JarvisVoiceOnly/" + BuildConfig.VERSION_NAME

    fun check(ctx: Context) {
        if (busy) return
        busy = true
        status = "Checking for updates..."
        Thread {
            var msg = ""
            var found: Info? = null
            try {
                val u = URL("https://api.github.com/repos/${BuildConfig.REPO_OWNER}/${BuildConfig.REPO_NAME}/releases/latest")
                val c = u.openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", ua())
                c.connectTimeout = 10000
                c.readTimeout = 15000
                if (c.responseCode == 404) {
                    msg = "No update published yet."
                } else if (c.responseCode != 200) {
                    msg = "Update check failed (HTTP ${c.responseCode})."
                } else {
                    val j = JSONObject(c.inputStream.bufferedReader().readText())
                    val code = j.optString("tag_name").removePrefix("build-").toIntOrNull()
                    val assets = j.optJSONArray("assets")
                    var url = ""
                    var size = 0L
                    if (assets != null) {
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name").endsWith(".apk")) {
                                url = a.optString("browser_download_url")
                                size = a.optLong("size")
                                break
                            }
                        }
                    }
                    if (code == null || url.isEmpty()) {
                        msg = "Latest release has no installable APK."
                    } else {
                        val inf = Info(code, j.optString("name", "build $code"), j.optString("body").take(600), url, size)
                        found = inf
                        msg = if (code > BuildConfig.VERSION_CODE) "Update available: ${inf.name}" else "You're on the latest version."
                    }
                }
            } catch (e: Throwable) {
                msg = "Couldn't check for updates: ${e.message ?: "no connection"}"
            }
            ui.post {
                info = found ?: info
                status = msg
                busy = false
            }
        }.start()
    }

    fun download(ctx: Context) {
        val i = available ?: return
        if (busy) return
        busy = true
        progress = 0
        status = "Downloading update..."
        val app = ctx.applicationContext
        Thread {
            var msg = ""
            var file: File? = null
            try {
                val dir = File(app.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val out = File(dir, "jarvis-update.apk")
                val c = URL(i.url).openConnection() as HttpURLConnection
                c.setRequestProperty("User-Agent", ua())
                c.instanceFollowRedirects = true
                c.connectTimeout = 15000
                c.readTimeout = 30000
                val total = if (c.contentLengthLong > 0) c.contentLengthLong else i.size
                var done = 0L
                c.inputStream.use { inp ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(64 * 1024)
                        var last = -1
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                            done += n
                            val p = if (total > 0) (done * 100 / total).toInt() else 0
                            if (p != last) {
                                last = p
                                ui.post { progress = p }
                            }
                        }
                    }
                }
                if (!Integrity.sameSigner(app, out)) {
                    out.delete()
                    msg = "Blocked: that APK is not signed with the same key as this app."
                } else {
                    file = out
                    msg = "Downloaded. Tap Install."
                }
            } catch (e: Throwable) {
                msg = "Download failed: ${e.message ?: "no connection"}"
            }
            ui.post {
                downloaded = file
                status = msg
                busy = false
                progress = -1
                if (file != null) install(app)
            }
        }.start()
    }

    fun install(ctx: Context) {
        val f = downloaded ?: return
        try {
            if (!ctx.packageManager.canRequestPackageInstalls()) {
                status = "Allow \"Install unknown apps\" for Jarvis, come back, then tap Install."
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Throwable) {
            status = "Couldn't open the installer: ${e.message}"
        }
    }
}

/** Small banner on Home when a newer version exists. */
@Composable
fun UpdateBanner(nav: (Screen) -> Unit) {
    val u = Updater.available ?: return
    HudCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = { nav(Screen.About) }) {
        Column {
            Text("UPDATE AVAILABLE", color = Amber, fontFamily = HudFont, fontSize = 13.sp)
            Text(u.name + ". Tap to update. Your data stays.", color = Dim, fontSize = 12.sp)
        }
    }
}
