// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Self-updater. Looks at this project's latest GitHub Release, downloads the APK, checks that it is
 * signed with the same key as the installed app, then hands it to Android's installer. Because the
 * key and the application id stay the same, the update installs over the old app and keeps all data.
 */
object Updater {
    data class Info(val code: Int, val name: String, val notes: String, val url: String, val size: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    var info by mutableStateOf<Info?>(null)
        private set
    var status by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    var progress by mutableIntStateOf(-1)
        private set
    var downloaded by mutableStateOf<File?>(null)
        private set

    /** Version code of what is really installed right now (re-read from Android, so it is never stale). */
    private var current by mutableIntStateOf(BuildConfig.VERSION_CODE)

    val available: Info? get() = info?.takeIf { it.code > current }

    /**
     * Re-checks the downloaded APK against the installed app. If the update has since been installed
     * (or the file is gone or no longer newer), the "downloaded, tap Install" state is cleared.
     * Call when the app comes back to the foreground and when the About screen opens.
     */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        runCatching {
            current = PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0)).toInt()
        }
        val f = downloaded ?: return
        val pi = f.takeIf { it.exists() }?.let { runCatching { app.packageManager.getPackageArchiveInfo(it.absolutePath, 0) }.getOrNull() }
        val apkCode = pi?.let { PackageInfoCompat.getLongVersionCode(it) } ?: -1L
        if (apkCode <= current) {
            runCatching { f.delete() }
            downloaded = null
            progress = -1
            status = if (apkCode >= 0) "You're on the latest version." else ""
        }
    }

    /** True when [status] describes a failure (used to colour it). */
    val isError: Boolean get() = status.startsWith("Couldn't") || status.startsWith("Download failed") ||
        status.startsWith("Update check failed") || status.startsWith("Blocked") || status.startsWith("GitHub")

    /** Release tags look like "build-N". N is turned into a version code with BuildConfig.TAG_OFFSET (see app/build.gradle.kts). */
    private fun tagToCode(tag: String): Int? = tag.removePrefix("build-").toIntOrNull()?.plus(BuildConfig.TAG_OFFSET)

    private fun updateFile(ctx: Context) = File(File(ctx.cacheDir, "updates"), "jarvis-update.apk")

    private fun ua() = "Jarvis/" + BuildConfig.VERSION_NAME

    /** Only https links on GitHub's own hosts are accepted as an update download, whatever the release data says. */
    private fun trustedDownload(url: String): Boolean = try {
        val u = URL(url)
        val h = u.host.lowercase()
        u.protocol == "https" && (h == "github.com" || h.endsWith(".github.com") || h.endsWith(".githubusercontent.com"))
    } catch (_: Throwable) {
        false
    }

    fun check(ctx: Context) {
        if (busy) return
        busy = true
        status = "Checking for updates..."
        scope.launch {
            var msg = ""
            var found: Info? = null
            var conn: HttpURLConnection? = null
            try {
                val u = URL("https://api.github.com/repos/${BuildConfig.REPO_OWNER}/${BuildConfig.REPO_NAME}/releases/latest")
                val c = u.openConnection() as HttpURLConnection
                conn = c
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", ua())
                c.connectTimeout = 10000
                c.readTimeout = 15000
                if (c.responseCode == 404) {
                    msg = "No update published yet."
                } else if (c.responseCode == 403 || c.responseCode == 429) {
                    msg = "GitHub is limiting update checks from this network. Try again in a while."
                } else if (c.responseCode != 200) {
                    msg = "Update check failed (HTTP ${c.responseCode})."
                } else {
                    val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    val code = tagToCode(j.optString("tag_name"))
                    val assets = j.optJSONArray("assets")
                    var url = ""
                    var size = 0L
                    if (assets != null) {
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name").endsWith(".apk")) {
                                url = a.optString("browser_download_url")
                                size = a.optLong("size")
                                break
                            }
                        }
                    }
                    if (code == null || url.isEmpty()) {
                        msg = "Latest release has no installable APK."
                    } else if (!trustedDownload(url)) {
                        msg = "Blocked: the update link does not point to GitHub."
                    } else {
                        val inf = Info(code, j.optString("name", "build $code"), j.optString("body").take(600), url, size)
                        found = inf
                        msg = if (code > current) "Update available: ${inf.name}" else "You're on the latest version."
                    }
                }
            } catch (e: Exception) {
                msg = "Couldn't check for updates: ${e.message ?: "no connection"}"
            } finally {
                runCatching { conn?.disconnect() }
            }
            // An update downloaded earlier (the app may have been restarted since) is picked up again.
            var again: File? = null
            val f = found
            if (f != null && f.code > current) {
                val old = updateFile(ctx)
                if (old.exists() && f.size > 0 && old.length() == f.size && Integrity.sameSigner(ctx.applicationContext, old)) again = old
            }
            withContext(Dispatchers.Main) {
                info = found ?: info
                if (again != null && downloaded == null) { downloaded = again; msg = "Update already downloaded. Tap Install." }
                status = msg
                busy = false
            }
        }
    }

    fun download(ctx: Context) {
        val i = available ?: return
        if (busy) return
        busy = true
        progress = 0
        status = "Downloading update..."
        val app = ctx.applicationContext
        scope.launch {
            var msg = ""
            var file: File? = null
            var conn: HttpURLConnection? = null
            try {
                if (!trustedDownload(i.url)) throw IOException("the update link does not point to GitHub.")
                val out = updateFile(app)
                val dir = out.parentFile!!
                dir.mkdirs()
                // Already downloaded and complete? Reuse it instead of fetching the whole APK again.
                if (out.exists() && i.size > 0 && out.length() == i.size && Integrity.sameSigner(app, out)) {
                    file = out
                    msg = "Downloaded. Tap Install."
                } else {
                    dir.listFiles()?.forEach { it.delete() }
                    val c = URL(i.url).openConnection() as HttpURLConnection
                    conn = c
                    c.setRequestProperty("User-Agent", ua())
                    c.instanceFollowRedirects = true
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    if (c.responseCode != 200) throw IOException("GitHub answered HTTP ${c.responseCode}.")
                    val total = if (c.contentLengthLong > 0) c.contentLengthLong else i.size
                    var done = 0L
                    c.inputStream.use { inp ->
                        out.outputStream().use { os ->
                            val buf = ByteArray(64 * 1024)
                            var last = -1
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                os.write(buf, 0, n)
                                done += n
                                val p = if (total > 0) (done * 100 / total).toInt() else 0
                                if (p != last) {
                                    last = p
                                    progress = p
                                }
                            }
                        }
                    }
                    if (total > 0 && done != total) {
                        out.delete()
                        msg = "Download failed: the file was cut off. Try again."
                    } else if (!Integrity.sameSigner(app, out)) {
                        out.delete()
                        msg = "Blocked: that APK is not signed with the same key as this app."
                    } else {
                        // Package name and version must also match what we expect (Android enforces it too; this explains it).
                        val pi = try { app.packageManager.getPackageArchiveInfo(out.absolutePath, 0) } catch (_: Throwable) { null }
                        if (pi != null && pi.packageName != app.packageName) {
                            out.delete()
                            msg = "Blocked: that APK is a different app."
                        } else if (pi != null && PackageInfoCompat.getLongVersionCode(pi) <= current) {
                            out.delete()
                            msg = "Download failed: that APK is not newer than the installed version."
                        } else {
                            file = out
                            msg = "Downloaded. Tap Install."
                        }
                    }
                }
            } catch (e: Exception) {
                msg = "Download failed: ${e.message ?: "no connection"}"
                // A half-written file must never be kept.
                runCatching { updateFile(app).delete() }
            } finally {
                runCatching { conn?.disconnect() }
            }
            withContext(Dispatchers.Main) {
                downloaded = file
                status = msg
                busy = false
                progress = -1
                if (file != null) install(app)
            }
        }
    }

    fun install(ctx: Context) {
        val f = downloaded ?: return
        try {
            if (!ctx.packageManager.canRequestPackageInstalls()) {
                status = "Allow \"Install unknown apps\" for Jarvis, come back, then tap Install."
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Throwable) {
            status = "Couldn't open the installer: ${e.message}"
        }
    }
}

/** Small banner on Home when a newer version exists. */
@Composable
fun UpdateBanner(nav: (Screen) -> Unit) {
    val u = Updater.available ?: return
    HudCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = { nav(Screen.About) }) {
        Column {
            Text("UPDATE AVAILABLE", color = Amber, fontFamily = HudFont, fontSize = 13.sp)
            Text(u.name + ". Tap to update. Your data stays.", color = Dim, fontSize = 12.sp)
        }
    }
}
