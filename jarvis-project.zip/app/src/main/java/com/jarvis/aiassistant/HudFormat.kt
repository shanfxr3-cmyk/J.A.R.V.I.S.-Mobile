// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Fixed-width number formatting. Pure Kotlin (no Android, no Compose) so it is unit-tested on the JVM.
 * Every function returns a string whose length depends only on its width argument, so a readout never changes size.
 */
object Mono {
    /** Zero padded and clamped to what fits: pad(7,3) = "007", pad(12345,3) = "999", pad(-4,3) = "000". */
    fun pad(v: Int, width: Int): String {
        var max = 1
        repeat(width.coerceIn(1, 9)) { max *= 10 }
        val s = v.coerceIn(0, max - 1).toString()
        return if (s.length >= width) s else "0".repeat(width - s.length) + s
    }

    /** Left-aligned text cut or space padded to exactly [width] characters. */
    fun label(s: String, width: Int): String = if (s.length >= width) s.substring(0, width) else s.padEnd(width)

    /** Data rate in exactly 5 characters: "0412K" (KB/s) below 10 MB/s, "11.7M" above, capped at "99.9M". */
    fun rate(kbps: Int): String {
        val k = kbps.coerceAtLeast(0)
        if (k < 10_000) return pad(k, 4) + "K"
        val t = (k * 10L / 1024L).toInt().coerceAtMost(999)
        return pad(t / 10, 2) + "." + (t % 10) + "M"
    }

    /** Percent as exactly 3 digits. */
    fun pct(v: Int): String = pad(v, 3)

    /** Rough token estimate (4 characters per token) as exactly 5 digits. */
    fun tokens(chars: Int): String = pad((chars + 3) / 4, 5)

    /** Percent 0..100 from a fraction. */
    fun pctOf(f: Float): Int = (f * 100f + 0.5f).toInt().coerceIn(0, 100)
}

/**
 * Speech amplitude maths for the visualizer. Pure Kotlin, allocation-free after construction.
 * Audio threads write bands, the frame loop reads them, so no object is created per frame or per capture.
 */
object SpeechDsp {
    const val BANDS = 32

    /** Speech recognizer loudness (about -2 to 10 dB) to 0..1. */
    fun rmsDbToLevel(db: Float): Float = ((db + 2f) / 12f).coerceIn(0f, 1f)

    private val NOISE = FloatArray(64).also { n ->
        var s = 12345
        for (i in n.indices) { s = s * 1103515245 + 12345; n[i] = ((s ushr 16) and 0x7fff) / 32767f }
    }

    /** Centre-weighted band shape with a little per-capture jitter, so a single loudness value still looks like a spectrum. */
    fun shape(band: Int, jitter: Int): Float {
        val bell = 0.45f + 0.55f * sin(Math.PI.toFloat() * (band + 0.5f) / BANDS)
        return bell * (0.6f + 0.4f * NOISE[(band * 7 + jitter * 13) and 63])
    }

    /** Stand-in speech envelope for voices that expose no audio (the phone's own TTS): word-like bursts across the bands. */
    fun synth(t: Float, band: Int): Float {
        val word = 0.30f + 0.70f * Math.abs(sin(t * 3.3f)) * Math.abs(sin(t * 1.3f + 0.7f))
        val tone = 0.55f + 0.45f * sin(t * 7f + band * 0.62f)
        return (word * tone * shape(band, 0)).coerceIn(0f, 1f)
    }

    /** Quiet ripple while listening for the person to start speaking. */
    fun breath(t: Float, band: Int): Float = 0.08f + 0.05f * sin(t * 2.2f + band * 0.5f)

    /** A scanning bump that travels across the bands while thinking. */
    fun scan(t: Float, band: Int): Float {
        val d = band - ((t * 14f) % (BANDS + 8f) - 4f)
        return 0.05f + 0.55f * kotlin.math.exp(-d * d / 6f)
    }

    /**
     * Turns an Android Visualizer FFT capture into [BANDS] log-spaced band levels (0..1) with automatic gain.
     * Not thread safe on purpose: one instance is owned by the capture thread.
     */
    class FftBands {
        private val edges = IntArray(BANDS + 1)
        private var edgesFor = -1
        private var peak = 8f

        private fun build(bins: Int) {
            edgesFor = bins
            val usable = (bins * 0.36f).toInt().coerceIn(BANDS + 1, bins - 1)
            edges[0] = 1
            for (i in 1..BANDS) {
                val g = usable.toFloat().pow(i.toFloat() / BANDS).toInt()
                edges[i] = maxOf(g, edges[i - 1] + 1)
            }
            if (edges[BANDS] > bins) edges[BANDS] = bins
        }

        /** [fft] is Visualizer layout: bin k is (re, im) at 2k and 2k+1; index 0 holds DC and Nyquist. Returns false when too short. */
        fun process(fft: ByteArray, out: FloatArray): Boolean {
            val bins = fft.size / 2
            if (bins < BANDS + 2 || out.size < BANDS) return false
            if (edgesFor != bins) build(bins)
            var frameMax = 0f
            for (b in 0 until BANDS) {
                val lo = edges[b]
                val hi = maxOf(edges[b + 1], lo + 1).coerceAtMost(bins)
                var sum = 0f
                for (k in lo until hi) {
                    val re = fft[2 * k].toFloat(); val im = fft[2 * k + 1].toFloat()
                    sum += sqrt(re * re + im * im)
                }
                val m = sum / (hi - lo).coerceAtLeast(1)
                out[b] = m
                if (m > frameMax) frameMax = m
            }
            peak = maxOf(peak * 0.985f, frameMax, 6f)
            val inv = 1f / peak
            val gate = (frameMax / 6f).coerceAtMost(1f)   // silence stays flat instead of being boosted to full scale
            for (b in 0 until BANDS) out[b] = (sqrt(out[b] * inv) * gate).coerceIn(0f, 1f)
            return true
        }
    }
}
