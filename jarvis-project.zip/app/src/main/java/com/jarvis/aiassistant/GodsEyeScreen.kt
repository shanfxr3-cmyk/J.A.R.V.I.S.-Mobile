// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

/**
 * Keeps the God's Eye View server alive while Jarvis is in the background.
 * The server is a child process of the app, so Android only keeps it while the app process lives;
 * a foreground service (with a visible notification) is what keeps the app process alive.
 */
class GodsEyeService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.aiassistant.GEV_STOP"
        private const val CHANNEL = "jarvis_gev"
        private const val NOTIF_ID = 9
        @Volatile var running = false

        /** Starts the service, which starts the server. Call it while the app is visible. */
        fun start(ctx: Context) {
            if (GodsEye.status != "RUNNING" && GodsEye.status != "STARTING") { GodsEye.status = "STARTING"; GodsEye.statusMsg = "Starting..." }
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, GodsEyeService::class.java))
            } catch (e: Throwable) {
                GodsEye.status = "ERROR"; GodsEye.statusMsg = "Could not start the background service: ${e.message}"
            }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, GodsEyeService::class.java)) } catch (_: Throwable) {}
        }
    }

    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            GodsEye.stop()
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        goForeground()
        if (worker?.isAlive != true) {
            val app = applicationContext
            worker = Thread {
                GodsEye.start(app)
                // If it could not start, there is nothing to keep alive.
                if (!GodsEye.isRunning()) stopSelf()
            }.also { it.name = "gev-start"; it.start() }
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "God's Eye View server", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
        val open = PendingIntent.getActivity(
            this, 30, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 31, Intent(this, GodsEyeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("God's Eye View is running")
            .setContentText("The globe server is on this phone. Tap Stop to turn it off.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        // "specialUse": the server is a local web server run for the user. dataSync would be cut off after 6 hours on Android 15.
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    override fun onDestroy() {
        running = false
        // The service ending (Stop button, stopService, Android) means the server is not needed any more.
        // A failed start keeps its error message for the screen, so only stop a server that is really up.
        if (GodsEye.isRunning()) Thread { GodsEye.stop() }.also { it.name = "gev-stop"; it.start() }
        super.onDestroy()
    }
}

/** Looks inside the page after it has had time to draw: canvas size, the centre pixel, loader text and which hosts it fetched from. */
private const val PROBE_JS = "(function(){try{var o=[];var c=document.querySelector('#cesiumContainer canvas');" +
    "o.push('canvas='+(c?(c.width+'x'+c.height+' css '+c.clientWidth+'x'+c.clientHeight):'none'));" +
    "if(c){try{var t=document.createElement('canvas');t.width=9;t.height=9;var x=t.getContext('2d');x.drawImage(c,0,0,9,9);var d=x.getImageData(4,4,1,1).data;o.push('centrePixel='+d[0]+','+d[1]+','+d[2]+','+d[3]);}catch(e){o.push('pixel read failed '+e)}}" +
    "var l=document.querySelector('#loading-screen');if(l){var cs=getComputedStyle(l);o.push('loading-screen display='+cs.display+' opacity='+cs.opacity+' text='+(l.textContent||'').trim().replace(/\\s+/g,' ').slice(0,160));}else o.push('loading-screen gone');" +
    "var h={};performance.getEntriesByType('resource').forEach(function(e){try{var k=new URL(e.name).host;h[k]=(h[k]||0)+1}catch(_){}});o.push('fetched='+JSON.stringify(h));" +
    "o.push('body='+document.body.className.slice(0,120));return o.join(' | ')}catch(x){return 'probe failed '+x}})()"

private fun probeLater(v: WebView, delayMs: Long, tag: String) {
    v.postDelayed({
        try {
            v.evaluateJavascript(PROBE_JS) { r -> GodsEye.addLog("[web probe $tag] " + (r ?: "").trim('"')) }
        } catch (_: Throwable) {}
    }, delayMs)
}

private fun isLocal(uri: Uri?): Boolean = uri?.host.let { it == "127.0.0.1" || it == "localhost" }

/** The God's Eye View globe: starts the local server, then shows it in a WebView. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GodsEyeScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val hasBundle = remember { GodsEye.hasBundle(app) }
    val status = GodsEye.status

    // False until the first start request is made, so the first frame shows "starting" and not "off".
    var requested by remember { mutableStateOf(false) }
    // Start the server (through the foreground service) when this screen opens.
    LaunchedEffect(Unit) {
        if (hasBundle && !GodsEye.isRunning()) GodsEyeService.start(app)
        else if (GodsEye.isRunning()) { GodsEye.status = "RUNNING"; GodsEye.statusMsg = "" }
        requested = true
    }
    // If the app was resumed and the server died while it was away, start it again.
    LaunchWhileStarted(status) {
        if (hasBundle && status == "RUNNING" && !GodsEye.isRunning()) GodsEyeService.start(app)
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        var web by remember { mutableStateOf<WebView?>(null) }
        var canBack by remember { mutableStateOf(false) }
        var showLog by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().height(36.dp).background(Panel).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.clickable { onClose() }.padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                HudIcon(Ic.Back, size = 16.dp)
                Spacer(Modifier.width(4.dp))
                Text("JARVIS", color = Cyan, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            Text("GOD'S EYE VIEW", color = Dim, fontSize = 11.sp, fontFamily = HudFont, letterSpacing = 1.sp)
            Spacer(Modifier.weight(1f))
            if (status == "RUNNING") {
                Text("LOG", color = Dim, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { showLog = !showLog }.padding(horizontal = 8.dp, vertical = 6.dp))
                Text("RELOAD", color = Cyan, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { web?.reload() }.padding(horizontal = 8.dp, vertical = 6.dp))
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                !hasBundle -> Message(
                    "NOT IN THIS BUILD",
                    "This APK has no God's Eye View bundle. Run the \"Get God's Eye View\" workflow once, then run \"Android build\" again.",
                    Amber, onClose = onClose
                )
                status == "RUNNING" -> GodsEyeWeb(
                    onWeb = { web = it },
                    onCanBack = { canBack = it },
                    onCrash = { GodsEye.status = "ERROR"; GodsEye.statusMsg = "The globe's web view crashed (usually low memory). Tap Try again." }
                )
                status == "ERROR" -> ErrorView(
                    onRetry = { GodsEye.status = "STARTING"; GodsEye.statusMsg = "Starting..."; GodsEyeService.start(app) },
                    onClose = onClose
                )
                status == "OFF" && requested -> Message(
                    "SERVER IS OFF",
                    "The God's Eye View server was stopped (for example with the Stop button in the notification).",
                    Dim, onClose = onClose, actionLabel = "Start", onAction = { GodsEyeService.start(app) }
                )
                else -> Starting()
            }
            if (showLog) WebLogView()
        }
        // Back moves through the page's own history first, then leaves the screen.
        BackHandler(enabled = status == "RUNNING" && canBack) { web?.goBack() }
    }
}

/** Shows what the page printed to its console (errors, WebGL result), to find out why the globe is black. */
@Composable
private fun WebLogView() {
    var text by remember { mutableStateOf("") }
    LaunchWhileStarted {
        while (true) { text = GodsEye.log().lines().filter { it.startsWith("[web") }.takeLast(60).joinToString("\n"); delay(800) }
    }
    Column(Modifier.fillMaxSize().background(Bg.copy(alpha = 0.94f)).verticalScroll(rememberScrollState()).padding(10.dp)) {
        Text("PAGE LOG (send a screenshot)", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(text.ifBlank { "(nothing yet)" }, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
    }
}

@Composable
private fun Starting() {
    var tail by remember { mutableStateOf("") }
    LaunchWhileStarted {
        while (true) { tail = GodsEye.log().lines().takeLast(6).joinToString("\n"); delay(700) }
    }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("STARTING GOD'S EYE VIEW", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Text(GodsEye.statusMsg.ifBlank { "Starting..." }, color = Dim, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text("The first start unpacks the app and can take a minute.", color = Dim, fontSize = 11.sp)
        if (tail.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text(tail, color = Dim, fontSize = 10.sp, fontFamily = FontFamily.Monospace, maxLines = 6)
        }
    }
}

@Composable
private fun ErrorView(onRetry: () -> Unit, onClose: () -> Unit) {
    val log = remember { GodsEye.log().lines().takeLast(25).joinToString("\n") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("COULD NOT START", color = Danger, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(GodsEye.statusMsg.ifBlank { "The server did not start." }, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onRetry) { Text("Try again") }
            Button(onClick = onClose) { Text("Back") }
        }
        if (log.isNotBlank()) {
            Text("LOG (send a screenshot of this if it keeps failing)", color = Dim, fontSize = 11.sp)
            Text(log, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
    }
}

@Composable
private fun Message(
    title: String, text: String, color: androidx.compose.ui.graphics.Color, onClose: () -> Unit,
    actionLabel: String? = null, onAction: () -> Unit = {}
) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = color, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        Text(text, color = Dim, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (actionLabel != null) Button(onClick = onAction) { Text(actionLabel) }
            Button(onClick = onClose) { Text("Back") }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun GodsEyeWeb(onWeb: (WebView?) -> Unit, onCanBack: (Boolean) -> Unit, onCrash: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var pending by remember { mutableStateOf<PermissionRequest?>(null) }
    var micHeld by remember { mutableStateOf(false) }

    // The globe's voice agent uses the microphone. Ask Android once, then let the page use it.
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val r = pending; pending = null
        if (r != null) {
            if (ok) {
                if (!micHeld) { micHeld = true; WakeService.hold(true) } // the wake-word detector must not fight over the microphone
                r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else r.deny()
        }
    }
    DisposableEffect(Unit) { onDispose { if (micHeld) WakeService.hold(false) } }

    val holder = remember { arrayOfNulls<WebView>(1) }
    DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            when (e) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> holder[0]?.onPause()
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> holder[0]?.onResume()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            holder[0]?.let { w -> onWeb(null); try { w.stopLoading(); w.destroy() } catch (_: Throwable) {} }
            holder[0] = null
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).also { w ->
                holder[0] = w
                onWeb(w)
                w.setBackgroundColor(0xFF050B14.toInt())
                w.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    allowFileAccess = false
                    allowContentAccess = false
                    setSupportZoom(false)
                    builtInZoomControls = false
                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                }
                w.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        // Pages of the globe stay inside; any other site opens in the phone's browser.
                        if (isLocal(r.url)) return false
                        if (r.isForMainFrame) {
                            try { v.context.startActivity(Intent(Intent.ACTION_VIEW, r.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
                        }
                        return true
                    }
                    override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) { onCanBack(v.canGoBack()) }
                    override fun onReceivedError(v: WebView, r: WebResourceRequest, e: android.webkit.WebResourceError) {
                        GodsEye.addLog("[web load error] ${r.url.path} ${e.description}")
                    }
                    override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, e: android.webkit.WebResourceResponse) {
                        if (e.statusCode >= 400) GodsEye.addLog("[web http ${e.statusCode}] ${r.url.host}${r.url.path}".take(200))
                    }
                    override fun onPageFinished(v: WebView, url: String?) {
                        v.evaluateJavascript(
                            "(function(){try{var c=document.createElement('canvas');var g2=!!c.getContext('webgl2');var g1=!!document.createElement('canvas').getContext('webgl');" +
                            "var d=(c.getContext('webgl2')||c.getContext('webgl'));var e=d&&d.getExtension('WEBGL_debug_renderer_info');" +
                            "return 'webgl2='+g2+' webgl='+g1+' gpu='+(e?d.getParameter(e.UNMASKED_RENDERER_WEBGL):'?')+' view='+innerWidth+'x'+innerHeight+' dpr='+devicePixelRatio}catch(x){return 'probe failed '+x}})()"
                        ) { r -> GodsEye.addLog("[web info] " + (r ?: "").trim('"')) }
                        probeLater(v, 6_000, "6s")
                        probeLater(v, 20_000, "20s")
                    }
                    override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) { onCanBack(v.canGoBack()) }
                    override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                        holder[0] = null; onWeb(null)
                        try { v.destroy() } catch (_: Throwable) {}
                        onCrash()
                        return true
                    }
                }
                w.webChromeClient = object : WebChromeClient() {
                    override fun onPermissionRequest(request: PermissionRequest) {
                        // Only the globe itself (this phone's own server) may ask, and only for the microphone.
                        val local = isLocal(request.origin)
                        val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                        if (!local || !wantsMic) { request.deny(); return }
                        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            if (!micHeld) { micHeld = true; WakeService.hold(true) }
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            pending?.deny()
                            pending = request
                            askMic.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                    override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                        val lvl = m.messageLevel()
                        if (lvl == ConsoleMessage.MessageLevel.ERROR || lvl == ConsoleMessage.MessageLevel.WARNING) {
                            GodsEye.addLog("[web ${lvl.name.lowercase()}] ${m.message().take(300)} (${m.sourceId().substringAfterLast('/')}:${m.lineNumber()})")
                        }
                        return true
                    }
                    override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                        callback?.invoke(origin, false, false) // no location permission in this app
                    }
                }
                w.loadUrl(GodsEye.URL_BASE + "/")
            }
        }
    )
}
