// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Small floating bar shown over other apps while Jarvis listens, thinks and speaks after the wake word,
 * so it does not take over the screen. Needs the "display over other apps" permission, which the person
 * grants in Android settings. The bar cannot be touched (nothing can be tapped through it) and shows only
 * what is being said. Main thread only.
 */
object Overlay {
    private val h = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var title: TextView? = null
    private var body: TextView? = null
    private var wm: WindowManager? = null
    private val hideRun = Runnable { remove() }

    fun allowed(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun onState(ctx: Context, state: String, enabled: Boolean) {
        if (!enabled || !allowed(ctx)) { remove(); return }
        when (state) {
            "LISTENING", "THINKING", "SPEAKING" -> {
                h.removeCallbacks(hideRun)
                show(ctx.applicationContext)
                title?.text = when (state) { "LISTENING" -> "LISTENING..."; "THINKING" -> "THINKING..."; else -> "J.A.R.V.I.S." }
                if (state == "LISTENING") body?.text = ""
            }
            else -> if (root != null) { h.removeCallbacks(hideRun); h.postDelayed(hideRun, if (state == "WAITING") 2500L else 0L) }
        }
    }

    fun note(text: String) { body?.text = text.takeLast(180) }

    private fun show(ctx: Context) {
        if (root != null) return
        try {
            val d = ctx.resources.displayMetrics.density
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
                background = GradientDrawable().apply { setColor(0xF0131A22.toInt()); cornerRadius = 24 * d; setStroke((1 * d).toInt(), 0x24FFFFFF) }
            }
            val t = TextView(ctx).apply { setTextColor(0xFFEAF0F6.toInt()); textSize = 13f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
            val b = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 15f; maxLines = 4 }
            box.addView(t); box.addView(b)
            val lp = WindowManager.LayoutParams(
                (ctx.resources.displayMetrics.widthPixels * 0.92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (40 * d).toInt() }
            val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            w.addView(box, lp)
            wm = w; root = box; title = t; body = b
        } catch (_: Throwable) { root = null }
    }

    fun remove() {
        h.removeCallbacks(hideRun)
        try { root?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        root = null; title = null; body = null
    }
}
