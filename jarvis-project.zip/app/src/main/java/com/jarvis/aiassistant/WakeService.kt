// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Hands-free "Hey Jarvis" wake word (openWakeWord, open source, runs on-device, no account or key).
 * Flow: wait for the keyword -> beep -> listen to one request -> answer (spoken) -> wait again.
 * The detector is stopped while the speech recogniser and the speaker use the microphone/audio.
 */
class WakeService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.aiassistant.WAKE_STOP"
        const val ACTION_REFRESH = "com.jarvis.aiassistant.WAKE_REFRESH"
        const val ACTION_REVIVE = "com.jarvis.aiassistant.WAKE_REVIVE"
        private const val CHANNEL = "jarvis_wake"
        private const val NOTIF_ID = 7

        /** OFF, STARTING, WAITING, LISTENING, THINKING, SPEAKING, ERROR */
        var state by mutableStateOf("OFF")
        var error by mutableStateOf<String?>(null)

        /** Set by the visible app so spoken "open ..." commands can switch screens. */
        @Volatile var navHook: ((Screen) -> Unit)? = null

        /** True while the service object exists (used by the 24/7 watchdog). */
        @Volatile var running = false

        // Hooks the live service installs so Settings and Chat can talk to it without restarting it.
        @Volatile private var holdHook: ((Boolean) -> Unit)? = null
        @Volatile private var sensHook: ((Float) -> Unit)? = null
        @Volatile private var keepHook: (() -> Unit)? = null

        /** Chat pauses the detector while it uses the microphone or speaker (on = true), and releases it again (false). */
        fun hold(on: Boolean) { holdHook?.invoke(on) }
        /** Apply a new sensitivity right away. */
        fun applySensitivity(sens: Float) { sensHook?.invoke(sens) }
        /** Re-read the always-on setting (takes or drops the wake lock). */
        fun applyKeepAlive() { keepHook?.invoke() }

        /** Slider 0.3-0.9 -> model threshold (50% = 0.75). Never below 0.5, which false-triggers constantly. */
        fun thresholdFor(sens: Float): Float = (0.85f - (sens - 0.3f) * 0.5f).coerceIn(0.5f, 0.95f)

        /** Slider -> loudness floor: quiet background noise can never trigger the wake word. */
        fun levelFor(sens: Float): Float = (600f * (1.05f - sens)).coerceIn(200f, 450f)

        /** [user] = true when the person asked for it, so it should come back after being killed. */
        fun start(ctx: Context, user: Boolean = true) {
            error = null
            state = "STARTING"
            if (user) {
                val st = Store.get(ctx)
                st.resetInitFails()
                st.markWakeWanted(true)
                if (st.keepAlive) KeepAlive.schedule(ctx)
            }
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
            } catch (e: Throwable) {
                error = "Could not start the listener: ${e.message}"
                state = "ERROR"
            }
        }

        fun stop(ctx: Context) {
            Store.get(ctx).markWakeWanted(false)
            KeepAlive.cancel(ctx)
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pm: WakeWord? = null
    private var voice: Voice? = null
    private var tone: ToneGenerator? = null
    private lateinit var store: Store
    private var busy = false
    private var alive = false
    private var initializing = false
    private var lock: PowerManager.WakeLock? = null
    private var chatHolding = false
    private var aiCall: AiCall? = null
    private var modelRetry = false
    private var shuttingDown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(applicationContext)
        alive = true
        running = true
        holdHook = { on -> main.post { holdForChat(on) } }
        sensHook = { s -> main.post { pm?.threshold = thresholdFor(s); pm?.minLevel = levelFor(s) } }
        keepHook = { main.post { applyKeepAliveNow() } }
    }

    private fun holdForChat(on: Boolean) {
        if (!alive || shuttingDown) return
        if (on) {
            if (busy || chatHolding || pm == null) return
            chatHolding = true
            busy = true
            runCatching { pm?.stop() }
            state = "PAUSED"
        } else {
            if (!chatHolding) return
            chatHolding = false
            resume()
        }
    }

    private fun applyKeepAliveNow() {
        if (store.keepAlive) { acquireLock(); KeepAlive.schedule(this) } else releaseLock()
    }

    // The wake lock has a timeout and is renewed, so it can never be held forever by a stuck service.
    private val renewLock = object : Runnable {
        override fun run() {
            if (!alive) return
            if (store.keepAlive) { releaseLock(); acquireLock() }
            main.postDelayed(this, 6 * 60 * 60 * 1000L)
        }
    }

    private fun acquireLock() {
        if (lock?.isHeld == true) return
        runCatching {
            lock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake")
                .apply { setReferenceCounted(false); acquire(8 * 60 * 60 * 1000L) }
            main.removeCallbacks(renewLock)
            main.postDelayed(renewLock, 6 * 60 * 60 * 1000L)
        }
    }

    private fun releaseLock() {
        runCatching { if (lock?.isHeld == true) lock?.release() }
        lock = null
        main.removeCallbacks(renewLock)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App swiped from Recents: make sure the watchdog is armed so the listener comes back.
        if (store.wakeWanted && store.keepAlive) KeepAlive.schedule(this, 5000)
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            store.markWakeWanted(false)
            KeepAlive.cancel(this)
            stopSelf()
            return START_NOT_STICKY
        }
        val revive = intent == null || intent.action == ACTION_REVIVE
        if (intent == null && !store.wakeWanted) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            goForeground()
        } catch (e: Throwable) {
            if (revive) {
                // Android doesn't let the microphone be started from the background here.
                // Ask the person to tap once instead.
                KeepAlive.postResume(this)
                state = "OFF"
                stopSelf()
            } else {
                fail("Could not start the background listener: ${e.message}")
            }
            return START_NOT_STICKY
        }
        KeepAlive.clearResume(this)
        if (intent?.action == ACTION_REFRESH) return if (store.keepAlive) START_STICKY else START_NOT_STICKY
        if (pm == null) initWake()
        if (store.keepAlive) {
            acquireLock()
            KeepAlive.schedule(this)
            return START_STICKY
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Wake word", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // If the notification is swiped away (Android 14+ allows it), put it straight back.
        val refresh = PendingIntent.getService(
            this, 2, Intent(this, WakeService::class.java).setAction(ACTION_REFRESH), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("J.A.R.V.I.S. is listening")
            .setContentText(if (store.keepAlive) "Listening 24/7. Say \"Hey Jarvis\"" else "Say \"Hey Jarvis\" to wake me")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setDeleteIntent(refresh)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun initWake() {
        if (initializing) return
        initializing = true
        state = "STARTING"
        Thread {
            try {
                if (!WakeWord.modelsReady(applicationContext)) {
                    main.post { state = "DOWNLOADING" }
                    WakeWord.downloadModels(applicationContext)
                }
                // Loading three ONNX models takes a moment: do it here, not on the main thread.
                val w = WakeWord(applicationContext)
                try { w.prepare() } catch (e: Throwable) {
                    runCatching { w.close() }
                    main.post { onInitError(e) }
                    return@Thread
                }
                main.post {
                    if (!alive) { try { w.close() } catch (_: Throwable) {}; return@post }
                    try {
                        voice = Voice(applicationContext)
                        tone = try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) } catch (_: Throwable) { null }
                        w.threshold = thresholdFor(store.wakeSens)
                        w.minLevel = levelFor(store.wakeSens)
                        pm = w
                        w.start(onDead = { why -> main.post { detectorDied(why) } }) { main.post { onWake() } }
                        state = "WAITING"
                        store.resetInitFails()
                    } catch (e: Throwable) {
                        onInitError(e)
                    }
                }
            } catch (e: Throwable) {
                main.post { fail("Could not download the wake word model (needs internet once): ${e.message}") }
            }
        }.start()
    }

    private fun onInitError(e: Throwable) {
        if (e is ModelLoadException && !modelRetry) {
            // A damaged model file: delete it and download a fresh copy once.
            modelRetry = true
            runCatching { pm?.close() }
            pm = null
            WakeWord.deleteModels(applicationContext)
            initializing = false
            initWake()
        } else {
            fail(e.message ?: "Wake word engine failed to start.")
        }
    }

    private fun fail(msg: String) {
        initializing = false
        store.noteInitFail()
        error = msg
        state = "ERROR"
        stopSelf()
    }

    private fun resume() {
        busy = false
        if (!alive || shuttingDown) return
        try { pm?.start(onDead = { why -> main.post { detectorDied(why) } }) { main.post { onWake() } } } catch (e: Throwable) { fail(e.message ?: "Could not resume listening."); return }
        state = "WAITING"
    }

    private var deadTries = 0

    /** The detector thread ended on its own (mic lost or model failing). Retry with a growing delay, then show an error. */
    private fun detectorDied(why: String) {
        if (!alive || busy) return
        runCatching { pm?.stop() }
        deadTries++
        if (deadTries > 5) { fail("Listening stopped: $why"); return }
        error = why
        state = "STARTING"
        val delayMs = 2000L * (1 shl (deadTries - 1))
        main.postDelayed({
            if (!alive || busy) return@postDelayed
            try {
                pm?.start(onDead = { w -> main.post { detectorDied(w) } }) { main.post { onWake() } }
                state = "WAITING"
                error = null
            } catch (e: Throwable) { detectorDied(e.message ?: "Could not restart the microphone.") }
        }, delayMs)
    }

    private fun onWake() {
        if (busy || !alive) return
        busy = true
        deadTries = 0
        runCatching { pm?.stop() }
        runCatching { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 160) }
        state = "LISTENING"
        // Short pause so the beep is not picked up as speech and the microphone is released.
        main.postDelayed({
            val v = voice
            if (!alive || v == null) return@postDelayed
            v.listen(
                onPartial = {},
                onResult = { t -> if (t.trim().length < 3) resume() else handle(t) },
                onFail = { msg, _ ->
                    if (msg.startsWith("Didn't catch")) resume()
                    else { error = msg; resume() }
                }
            )
        }, 350)
    }

    /** "Hey Jarvis, turn off wake word": say so, then switch the listener off until it is turned on again by hand. */
    private fun turnOffByVoice(text: String) {
        shuttingDown = true
        store.addMessage(true, text)
        store.markWakeWanted(false)          // the watchdog and app start-up must not bring it back
        KeepAlive.cancel(this)
        KeepAlive.clearResume(this)
        store.addMessage(false, Assistant.WAKE_OFF_REPLY)
        error = null
        state = "SPEAKING"
        val v = voice
        if (v == null) { stopSelf(); return }
        v.speak(Assistant.WAKE_OFF_REPLY) { stopSelf() }
    }

    private fun handle(text: String) {
        if (Assistant.isWakeOff(text)) { turnOffByVoice(text); return }
        state = "THINKING"
        store.addMessage(true, text)
        var navMissed = false
        val local = Assistant.localCommand(store, text) { s ->
            val h = navHook
            if (h != null) { h(s) } else { navMissed = true }
        }
        if (local != null) {
            val out = if (navMissed) "Open the app and I can show you that." else local
            store.addMessage(false, out)
            say(out)
            return
        }
        val key = store.apiKey
        if (key.isBlank()) { say("Add an A I key in settings first."); return }
        val sys = Assistant.systemPrompt(store) + " The user spoke this by voice: answer in one to three short sentences."
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        val call = AiCall()
        aiCall = call
        scope.launch {
            try {
                val full = withContext(Dispatchers.IO) { Ai.stream(key, store.model, sys, hist, call) {} }
                if (!alive) return@launch
                store.addMessage(false, full)
                say(full)
            } catch (e: CancellationException) {
                throw e   // the service is stopping: do not report an error or start speaking
            } catch (e: Exception) {
                if (!alive || call.cancelled) return@launch
                error = e.message ?: "AI request failed."
                say("Sorry, I could not reach the A I.")
            } finally {
                if (aiCall === call) aiCall = null
            }
        }
    }

    private fun say(text: String) {
        if (!alive) return
        state = "SPEAKING"
        val v = voice
        if (v == null) { resume(); return }
        if (v.ttsMissing) error = "No text-to-speech engine installed. Install Google Speech Services to hear replies."
        v.speak(text) { resume() }
    }

    override fun onDestroy() {
        alive = false
        running = false
        holdHook = null; sensHook = null; keepHook = null
        runCatching { aiCall?.cancel() }
        releaseLock()
        main.removeCallbacksAndMessages(null)
        scope.cancel()
        runCatching { pm?.stop() }
        runCatching { pm?.close() }
        pm = null
        voice?.destroy()
        voice = null
        runCatching { tone?.release() }
        tone = null
        if (state != "ERROR") state = "OFF"
        super.onDestroy()
    }
}
