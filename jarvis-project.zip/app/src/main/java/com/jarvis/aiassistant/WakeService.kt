// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class WakeState { OFF, STARTING, DOWNLOADING, WAITING, PAUSED, LISTENING, THINKING, SPEAKING, ERROR }

/**
 * Hands-free "Hey Jarvis" wake word (openWakeWord, open source, runs on-device, no account or key).
 * Flow: wait for the keyword -> beep -> listen to one request -> answer (spoken) -> wait again.
 * The detector is stopped while the speech recogniser and the speaker use the microphone/audio.
 */
class WakeService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.aiassistant.WAKE_STOP"
        const val ACTION_REFRESH = "com.jarvis.aiassistant.WAKE_REFRESH"
        const val ACTION_REVIVE = "com.jarvis.aiassistant.WAKE_REVIVE"
        private const val CHANNEL = "jarvis_wake"
        private const val NOTIF_ID = 7
        private const val WAKE_LOCK_MS = 8 * 60 * 60 * 1000L
        private const val LOCK_RENEW_MS = 6 * 60 * 60 * 1000L

        var state by mutableStateOf(WakeState.OFF)
        var error by mutableStateOf<String?>(null)

        /** Set by the visible app so spoken "open ..." commands can switch screens. */
        @Volatile var navHook: ((Screen) -> Unit)? = null

        @Volatile private var current: WakeService? = null

        /** True while the service object exists (used by the 24/7 watchdog). */
        val running: Boolean get() = current != null

        // Hooks the live service installs so Settings and Chat can talk to it without restarting it.
        @Volatile private var holdHook: ((Boolean) -> Unit)? = null
        @Volatile private var sensHook: ((Float) -> Unit)? = null
        @Volatile private var keepHook: (() -> Unit)? = null

        /** Chat pauses the detector while it uses the microphone or speaker (on = true), and releases it again (false). */
        fun hold(on: Boolean) { holdHook?.invoke(on) }
        /** Apply a new sensitivity right away. */
        fun applySensitivity(sens: Float) { sensHook?.invoke(sens) }
        /** Re-read the always-on setting (takes or drops the wake lock). */
        fun applyKeepAlive() { keepHook?.invoke() }

        /** Slider 0.3-0.9 -> model threshold (50% = 0.75). Never below 0.5, which false-triggers constantly. */
        fun thresholdFor(sens: Float): Float = (0.85f - (sens - 0.3f) * 0.5f).coerceIn(0.5f, 0.95f)

        /** Slider -> loudness floor: quiet background noise can never trigger the wake word. */
        fun levelFor(sens: Float): Float = (600f * (1.05f - sens)).coerceIn(200f, 450f)

        /** [user] = true when the person asked for it, so it should come back after being killed. */
        fun start(ctx: Context, user: Boolean = true) {
            error = null
            state = WakeState.STARTING
            if (user) {
                val st = Store.get(ctx)
                st.resetInitFails()
                st.markWakeWanted(true)
                if (st.keepAlive) KeepAlive.schedule(ctx)
            }
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
            } catch (e: Throwable) {
                error = "Could not start the listener: ${e.message}"
                state = WakeState.ERROR
            }
        }

        fun stop(ctx: Context) {
            Store.get(ctx).markWakeWanted(false)
            KeepAlive.cancel(ctx)
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pm: WakeWord? = null
    private var voice: Voice? = null
    private var tone: ToneGenerator? = null
    private lateinit var store: Store
    private var busy = false
    private var alive = false
    private var initializing = false
    private var lock: PowerManager.WakeLock? = null
    private var chatHolding = false
    private var aiCall: AiCall? = null
    private var modelRetry = false
    private var shuttingDown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(applicationContext)
        alive = true
        current = this
        holdHook = holdForChatHook
        sensHook = sensitivityHook
        keepHook = keepAliveHook
    }

    private val holdForChatHook: (Boolean) -> Unit = { on -> main.post { holdForChat(on) } }
    private val sensitivityHook: (Float) -> Unit = { sens ->
        main.post { pm?.let { it.threshold = thresholdFor(sens); it.minLevel = levelFor(sens) } }
    }
    private val keepAliveHook: () -> Unit = { main.post { applyKeepAliveNow() } }

    private fun holdForChat(on: Boolean) {
        if (!alive || shuttingDown) return
        if (on) {
            if (busy || chatHolding || pm == null) return
            chatHolding = true
            busy = true
            runCatching { pm?.stop() }
            state = WakeState.PAUSED
        } else {
            if (!chatHolding) return
            chatHolding = false
            resume()
        }
    }

    private fun applyKeepAliveNow() {
        if (store.keepAlive) { acquireLock(); KeepAlive.schedule(this) } else releaseLock()
    }

    // The wake lock has a timeout and is renewed, so it can never be held forever by a stuck service.
    private val renewLock = object : Runnable {
        override fun run() {
            if (!alive) return
            if (store.keepAlive) { releaseLock(); acquireLock() }
            main.postDelayed(this, LOCK_RENEW_MS)
        }
    }

    private fun acquireLock() {
        if (lock?.isHeld == true) return
        runCatching {
            lock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake")
                .apply { setReferenceCounted(false); acquire(WAKE_LOCK_MS) }
            main.removeCallbacks(renewLock)
            main.postDelayed(renewLock, LOCK_RENEW_MS)
        }
    }

    private fun releaseLock() {
        runCatching { if (lock?.isHeld == true) lock?.release() }
        lock = null
        main.removeCallbacks(renewLock)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App swiped from Recents: make sure the watchdog is armed so the listener comes back.
        if (store.wakeWanted && store.keepAlive) KeepAlive.schedule(this, 5000)
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            store.markWakeWanted(false)
            KeepAlive.cancel(this)
            stopSelf()
            return START_NOT_STICKY
        }
        val revive = intent == null || intent.action == ACTION_REVIVE
        if (intent == null && !store.wakeWanted) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            goForeground()
        } catch (e: Throwable) {
            if (revive) {
                // Android doesn't let the microphone be started from the background here.
                // Ask the person to tap once instead.
                KeepAlive.postResume(this)
                state = WakeState.OFF
                stopSelf()
            } else {
                fail("Could not start the background listener: ${e.message}")
            }
            return START_NOT_STICKY
        }
        KeepAlive.clearResume(this)
        if (intent?.action == ACTION_REFRESH) return if (store.keepAlive) START_STICKY else START_NOT_STICKY
        if (pm == null) initWake()
        if (store.keepAlive) {
            acquireLock()
            KeepAlive.schedule(this)
            return START_STICKY
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Wake word", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // If the notification is swiped away (Android 14+ allows it), put it straight back.
        val refresh = PendingIntent.getService(
            this, 2, Intent(this, WakeService::class.java).setAction(ACTION_REFRESH), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("J.A.R.V.I.S. is listening")
            .setContentText(if (store.keepAlive) "Listening 24/7. Say \"Hey Jarvis\"" else "Say \"Hey Jarvis\" to wake me")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setDeleteIntent(refresh)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun initWake() {
        if (initializing) return
        initializing = true
        state = WakeState.STARTING
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    if (!WakeWord.modelsReady(applicationContext)) {
                        withContext(Dispatchers.Main) { state = WakeState.DOWNLOADING }
                        WakeWord.downloadModels(applicationContext)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail("Could not download the wake word model (needs internet once): ${e.message}")
                return@launch
            }
            // Loading three ONNX models takes a moment: keep it off the main thread.
            val detector = WakeWord(applicationContext)
            try {
                withContext(Dispatchers.IO) { detector.prepare() }
            } catch (e: Throwable) {
                detector.close()
                if (e is CancellationException) throw e
                onInitError(e)
                return@launch
            }
            startDetector(detector)
        }
    }

    private fun startDetector(detector: WakeWord) {
        if (!alive) { detector.close(); return }
        try {
            voice = Voice(applicationContext)
            tone = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) }.getOrNull()
            detector.threshold = thresholdFor(store.wakeSens)
            detector.minLevel = levelFor(store.wakeSens)
            pm = detector
            startListening()
            store.resetInitFails()
            store.log("Wake word started")
        } catch (e: Throwable) {
            onInitError(e)
        }
    }

    /** (Re)starts the detector. [onDead] and [onWake] are invoked on the main thread. */
    private fun startListening() {
        pm?.start(onDead = { why -> main.post { detectorDied(why) } }) { main.post { onWake() } }
        state = WakeState.WAITING
    }

    private fun onInitError(e: Throwable) {
        if (e is ModelLoadException && !modelRetry) {
            // A damaged model file: delete it and download a fresh copy once.
            modelRetry = true
            pm?.close()
            pm = null
            WakeWord.deleteModels(applicationContext)
            initializing = false
            initWake()
        } else {
            fail(e.message ?: "Wake word engine failed to start.")
        }
    }

    private fun fail(msg: String) {
        initializing = false
        store.noteInitFail()
        error = msg
        state = WakeState.ERROR
        stopSelf()
    }

    private fun resume() {
        busy = false
        if (!alive || shuttingDown) return
        try { startListening() } catch (e: Throwable) { fail(e.message ?: "Could not resume listening.") }
    }

    private var deadTries = 0

    /** The detector thread ended on its own (mic lost or model failing). Retry with a growing delay, then show an error. */
    private fun detectorDied(why: String) {
        if (!alive || busy) return
        runCatching { pm?.stop() }
        deadTries++
        if (deadTries > 5) { fail("Listening stopped: $why"); return }
        error = why
        state = WakeState.STARTING
        val delayMs = 2000L * (1 shl (deadTries - 1))
        main.postDelayed({
            if (!alive || busy) return@postDelayed
            try {
                startListening()
                error = null
            } catch (e: Throwable) { detectorDied(e.message ?: "Could not restart the microphone.") }
        }, delayMs)
    }

    private fun onWake() {
        if (busy || !alive) return
        busy = true
        deadTries = 0
        runCatching { pm?.stop() }
        runCatching { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 160) }
        state = WakeState.LISTENING
        store.log("Wake word heard")
        // Short pause so the beep is not picked up as speech and the microphone is released.
        main.postDelayed({
            val v = voice
            if (!alive || v == null) return@postDelayed
            v.listen(
                onPartial = {},
                onResult = { t -> if (t.trim().length < 3) resume() else handle(t) },
                onFail = { msg, _ ->
                    if (msg.startsWith("Didn't catch")) resume()
                    else { error = msg; resume() }
                }
            )
        }, 350)
    }

    /** "Hey Jarvis, turn off wake word": say so, then switch the listener off until it is turned on again by hand. */
    private fun turnOffByVoice(text: String) {
        shuttingDown = true
        store.addMessage(true, text)
        store.markWakeWanted(false)          // the watchdog and app start-up must not bring it back
        KeepAlive.cancel(this)
        KeepAlive.clearResume(this)
        store.log("Wake word turned off by voice")
        store.addMessage(false, Assistant.WAKE_OFF_REPLY)
        error = null
        state = WakeState.SPEAKING
        val v = voice
        if (v == null) { stopSelf(); return }
        v.speak(Assistant.WAKE_OFF_REPLY) { stopSelf() }
    }

    private fun handle(text: String) {
        if (Assistant.isWakeOff(text)) { turnOffByVoice(text); return }
        state = WakeState.THINKING
        store.addMessage(true, text)
        var navMissed = false
        val local = Assistant.localCommand(store, text) { screen ->
            if (navHook?.invoke(screen) == null) navMissed = true
        }
        if (local != null) {
            val out = if (navMissed) "Open the app and I can show you that." else local
            store.addMessage(false, out)
            say(out)
            return
        }
        val key = store.apiKey
        if (key.isBlank()) { say("Add an A I key in settings first."); return }
        val sys = Assistant.systemPrompt(store) + " The user spoke this by voice: answer in one to three short sentences."
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        val call = AiCall()
        aiCall = call
        scope.launch {
            try {
                val full = withContext(Dispatchers.IO) { Ai.stream(key, store.model, sys, hist, call) {} }
                if (!alive) return@launch
                store.addMessage(false, full)
                store.log("AI replied (voice)")
                say(full)
            } catch (e: CancellationException) {
                throw e   // the service is stopping: do not report an error or start speaking
            } catch (e: Exception) {
                if (!alive || call.cancelled) return@launch
                error = e.message ?: "AI request failed."
                say("Sorry, I could not reach the A I.")
            } finally {
                if (aiCall === call) aiCall = null
            }
        }
    }

    private fun say(text: String) {
        if (!alive) return
        state = WakeState.SPEAKING
        val v = voice
        if (v == null) { resume(); return }
        if (v.ttsMissing) error = "No text-to-speech engine installed. Install Google Speech Services to hear replies."
        v.speak(text) { resume() }
    }

    override fun onDestroy() {
        alive = false
        // A newer instance may already have installed its own hooks: only remove ours.
        if (current === this) current = null
        if (holdHook === holdForChatHook) holdHook = null
        if (sensHook === sensitivityHook) sensHook = null
        if (keepHook === keepAliveHook) keepHook = null
        aiCall?.cancel()
        releaseLock()
        main.removeCallbacksAndMessages(null)
        scope.cancel()
        pm?.close()
        pm = null
        voice?.destroy()
        voice = null
        runCatching { tone?.release() }
        tone = null
        if (state != WakeState.ERROR) state = WakeState.OFF
        super.onDestroy()
    }
}
