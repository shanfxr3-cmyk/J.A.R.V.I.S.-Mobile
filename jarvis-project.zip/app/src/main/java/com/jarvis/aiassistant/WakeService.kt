// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Hands-free "Hey Jarvis" wake word (openWakeWord, open source, runs on-device, no account or key).
 * Flow: wait for the keyword -> beep -> listen to one request -> answer (spoken) -> wait again.
 * The detector is stopped while the speech recogniser and the speaker use the microphone/audio.
 */
class WakeService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.aiassistant.WAKE_STOP"
        const val ACTION_REFRESH = "com.jarvis.aiassistant.WAKE_REFRESH"
        const val ACTION_REVIVE = "com.jarvis.aiassistant.WAKE_REVIVE"
        private const val CHANNEL = "jarvis_wake"
        private const val NOTIF_ID = 7

        /** OFF, STARTING, WAITING, LISTENING, THINKING, SPEAKING, ERROR */
        var state by mutableStateOf("OFF")
        var error by mutableStateOf<String?>(null)

        /** Set by the visible app so spoken "open ..." commands can switch screens. */
        @Volatile var navHook: ((Screen) -> Unit)? = null

        /** True while the service object exists (used by the 24/7 watchdog). */
        @Volatile var running = false

        /** [user] = true when the person asked for it, so it should come back after being killed. */
        fun start(ctx: Context, user: Boolean = true) {
            error = null
            state = "STARTING"
            if (user) {
                val st = Store.get(ctx)
                st.setWakeWanted(true)
                if (st.keepAlive) KeepAlive.schedule(ctx)
            }
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
            } catch (e: Throwable) {
                error = "Could not start the listener: ${e.message}"
                state = "ERROR"
            }
        }

        fun stop(ctx: Context) {
            Store.get(ctx).setWakeWanted(false)
            KeepAlive.cancel(ctx)
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pm: WakeWord? = null
    private var voice: Voice? = null
    private var tone: ToneGenerator? = null
    private lateinit var store: Store
    private var busy = false
    private var alive = false
    private var initializing = false
    private var lock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(applicationContext)
        alive = true
        running = true
    }

    private fun acquireLock() {
        try {
            if (lock?.isHeld == true) return
            lock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake")
                .apply { setReferenceCounted(false); acquire() }
        } catch (_: Throwable) {
        }
    }

    private fun releaseLock() {
        try { if (lock?.isHeld == true) lock?.release() } catch (_: Throwable) {}
        lock = null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App swiped from Recents: make sure the watchdog is armed so the listener comes back.
        if (store.wakeWanted && store.keepAlive) KeepAlive.schedule(this, 5000)
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            store.setWakeWanted(false)
            KeepAlive.cancel(this)
            stopSelf()
            return START_NOT_STICKY
        }
        val revive = intent == null || intent.action == ACTION_REVIVE
        if (intent == null && !store.wakeWanted) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            goForeground()
        } catch (e: Throwable) {
            if (revive) {
                // Android doesn't let the microphone be started from the background here.
                // Ask the person to tap once instead.
                KeepAlive.postResume(this)
                state = "OFF"
                stopSelf()
            } else {
                fail("Could not start the background listener: ${e.message}")
            }
            return START_NOT_STICKY
        }
        KeepAlive.clearResume(this)
        if (intent?.action == ACTION_REFRESH) return if (store.keepAlive) START_STICKY else START_NOT_STICKY
        if (pm == null) initWake()
        if (store.keepAlive) {
            acquireLock()
            KeepAlive.schedule(this)
            return START_STICKY
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Wake word", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // If the notification is swiped away (Android 14+ allows it), put it straight back.
        val refresh = PendingIntent.getService(
            this, 2, Intent(this, WakeService::class.java).setAction(ACTION_REFRESH), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("J.A.R.V.I.S. is listening")
            .setContentText(if (store.keepAlive) "Listening 24/7. Say \"Hey Jarvis\"" else "Say \"Hey Jarvis\" to wake me")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setDeleteIntent(refresh)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun initWake() {
        if (initializing) return
        initializing = true
        state = "STARTING"
        Thread {
            try {
                if (!WakeWord.modelsReady(applicationContext)) {
                    main.post { state = "DOWNLOADING" }
                    WakeWord.downloadModels(applicationContext)
                }
                main.post {
                    if (!alive) return@post
                    try {
                        voice = Voice(applicationContext)
                        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Throwable) { null }
                        val w = WakeWord(applicationContext)
                        w.threshold = (1.2f - store.wakeSens).coerceIn(0.2f, 0.95f)
                        pm = w
                        w.start { main.post { onWake() } }
                        state = "WAITING"
                        store.log("Wake word started")
                    } catch (e: Throwable) {
                        fail(e.message ?: "Wake word engine failed to start.")
                    }
                }
            } catch (e: Throwable) {
                main.post { fail("Could not download the wake word model (needs internet once): ${e.message}") }
            }
        }.start()
    }

    private fun fail(msg: String) {
        initializing = false
        error = msg
        state = "ERROR"
        stopSelf()
    }

    private fun resume() {
        busy = false
        if (!alive) return
        try { pm?.start { main.post { onWake() } } } catch (e: Throwable) { fail(e.message ?: "Could not resume listening."); return }
        state = "WAITING"
    }

    private fun onWake() {
        if (busy || !alive) return
        busy = true
        try { pm?.stop() } catch (_: Throwable) {}
        try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 160) } catch (_: Throwable) {}
        state = "LISTENING"
        store.log("Wake word heard")
        // Short pause so the beep is not picked up as speech and the microphone is released.
        main.postDelayed({
            val v = voice
            if (!alive || v == null) return@postDelayed
            v.listen(
                onPartial = {},
                onResult = { t -> handle(t) },
                onFail = { msg, _ ->
                    if (msg.startsWith("Didn't catch")) resume()
                    else { error = msg; resume() }
                }
            )
        }, 350)
    }

    private fun handle(text: String) {
        state = "THINKING"
        store.addMessage(true, text)
        var navMissed = false
        val local = Assistant.localCommand(store, text) { s ->
            val h = navHook
            if (h != null) { h(s) } else { navMissed = true }
        }
        if (local != null) {
            val out = if (navMissed) "Open the app and I can show you that." else local
            store.addMessage(false, out)
            say(out)
            return
        }
        val key = store.apiKey
        if (key.isBlank()) { say("Add an A I key in settings first."); return }
        val sys = Assistant.systemPrompt(store) + " The user spoke this by voice: answer in one to three short sentences."
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        scope.launch {
            try {
                val full = withContext(Dispatchers.IO) { Ai.stream(key, store.model, sys, hist) {} }
                store.addMessage(false, full)
                store.log("AI replied (voice)")
                say(full)
            } catch (e: Exception) {
                error = e.message ?: "AI request failed."
                say("Sorry, I could not reach the A I.")
            }
        }
    }

    private fun say(text: String) {
        state = "SPEAKING"
        val v = voice
        if (v == null) { resume(); return }
        v.speak(text) { resume() }
    }

    override fun onDestroy() {
        alive = false
        running = false
        releaseLock()
        main.removeCallbacksAndMessages(null)
        scope.cancel()
        try { pm?.stop() } catch (_: Throwable) {}
        try { pm?.close() } catch (_: Throwable) {}
        pm = null
        voice?.destroy()
        voice = null
        try { tone?.release() } catch (_: Throwable) {}
        tone = null
        if (state != "ERROR") state = "OFF"
        super.onDestroy()
    }
}
