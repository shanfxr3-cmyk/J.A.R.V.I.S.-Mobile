// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Facts that appear in the legal screens. The long documents live in the assets/legal folder. */
object Legal {
    /**
     * Bump this number ONLY when the legal documents change in a way that needs fresh consent.
     * Normal app updates keep the saved acceptance, so the listener is not switched off by an update.
     */
    const val CONSENT_VERSION = 2   // 2: World Watch disclosures added, camera text removed (0.13.1)

    fun isAccepted(store: Store): Boolean = store.consentVersion == CONSENT_VERSION

    const val APP = "J.A.R.V.I.S"
    const val AUTHOR = "Shan Akhter"
    const val EMAIL = "shanakhter777@gmail.com"
    const val RELEASED = "24 October 2026"
    const val YEAR = "2026"
    const val REPO = "https://github.com/shanfxr3-cmyk/J.A.R.V.I.S.-Mobile"

    /** Which document the Legal screen shows: privacy, terms, usage, thirdparty, license, branding. */
    var doc by mutableStateOf("privacy")

    fun title(key: String) = when (key) {
        "privacy" -> "PRIVACY POLICY"
        "terms" -> "TERMS & CONDITIONS"
        "usage" -> "USAGE POLICY"
        "thirdparty" -> "OPEN-SOURCE LICENCES"
        "license" -> "APACHE LICENSE 2.0"
        "branding" -> "FORK & BRANDING RULES"
        else -> "LEGAL"
    }

    fun read(ctx: Context, key: String): String = try {
        val name = if (key == "license") "license.txt" else "$key.md"
        ctx.assets.open("legal/$name").bufferedReader().use { it.readText() }
    } catch (e: Throwable) {
        "Couldn't load this document: ${e.message}\nIt is also in the project repository: $REPO"
    }
}

/** Tiny renderer for the bundled documents: "# ", "## ", "- " and plain lines. */
@Composable
fun DocView(text: String) {
    // Plain consecutive lines are merged into one Text each, so a 200-line licence is a few dozen items, not 200.
    val lines = remember(text) {
        val out = ArrayList<String>()
        val para = StringBuilder()
        fun flush() { if (para.isNotEmpty()) { out.add(para.toString()); para.clear() } }
        for (raw in text.split("\n")) {
            val l = raw.trimEnd().replace("**", "").replace("`", "")
            val special = l.startsWith("# ") || l.startsWith("## ") || l.startsWith("- ") || l.isBlank()
            if (special) { flush(); out.add(l) }
            else { if (para.isNotEmpty()) para.append('\n'); para.append(l) }
        }
        flush()
        out
    }
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (l in lines) {
            when {
                l.startsWith("# ") -> Text(l.drop(2), color = Cyan, fontFamily = TitleFont, fontSize = 15.sp)
                l.startsWith("## ") -> Text(
                    l.drop(3), color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
                l.startsWith("- ") -> Row {
                    Text("-", color = Cyan, fontSize = 13.sp, fontFamily = UiFont)
                    Spacer(Modifier.width(8.dp))
                    Text(l.drop(2), Modifier.weight(1f), fontSize = 13.sp, fontFamily = UiFont, color = Color(0xFFD5E2EC))
                }
                l.isBlank() -> Spacer(Modifier.height(2.dp))
                else -> Text(l, fontSize = 13.sp, fontFamily = UiFont, color = Color(0xFFD5E2EC))
            }
        }
    }
}

@Composable
fun LegalScreen() {
    val ctx = LocalContext.current
    val key = Legal.doc
    val text = remember(key) { Legal.read(ctx, key) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        ScreenHeader(Legal.title(key), Legal.APP)
        HudCard(Modifier.fillMaxWidth()) { DocView(text) }
    }
}

private fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
}

private fun mail(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Legal.EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, Legal.APP + " " + BuildConfig.VERSION_NAME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Throwable) {}
}

@Composable
fun AboutScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val official = remember { Integrity.isOfficial(ctx) }
    val up = Updater.available
    fun doc(k: String) { Legal.doc = k; nav(Screen.Legal) }

    LaunchedEffect(Unit) { Updater.sync(ctx); if (Updater.info == null) Updater.check(ctx.applicationContext) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenHeader("ABOUT", "Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(Legal.APP, color = Cyan, fontFamily = TitleFont, fontSize = 16.sp)
                Text("Designed and built by ${Legal.AUTHOR}.", fontSize = 14.sp)
                Text("First released ${Legal.RELEASED}.", color = Dim, fontSize = 12.sp)
                Text("Copyright ${Legal.YEAR} ${Legal.AUTHOR}. Open source under the Apache License 2.0.", color = Dim, fontSize = 12.sp)
                Text("Forks and remakes must keep this credit.", color = Dim, fontSize = 12.sp)
                if (official) {
                    Text("OFFICIAL BUILD", color = Green, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Signed with the developer's key.", color = Dim, fontSize = 11.sp)
                } else {
                    Text("UNOFFICIAL BUILD", color = Amber, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("This copy is not signed with the original developer's key. It may be a fork, a modified copy, or a test build.", color = Dim, fontSize = 11.sp)
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("UPDATES", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("New versions install over this one. Your chats, tasks and settings stay.", color = Dim, fontSize = 12.sp)
                if (Updater.status.isNotEmpty()) Text(Updater.status, color = if (up != null || Updater.isError) Amber else Green, fontSize = 12.sp)
                if (up != null && up.notes.isNotBlank()) Text(up.notes, color = Dim, fontSize = 11.sp)
                if (Updater.progress >= 0) Text("Downloading ${Updater.progress}%", color = Cyan, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { Updater.check(ctx.applicationContext) }, enabled = !Updater.busy) { Text("Check") }
                    if (Updater.downloaded != null && up != null) {
                        Button(onClick = { Updater.install(ctx) }) { Text("Install") }
                    } else if (up != null) {
                        Button(onClick = { Updater.download(ctx) }, enabled = !Updater.busy) { Text("Download and install") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Check when the app opens", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.updateCheck, { store.markUpdateCheck(it) })
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("LEGAL", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                TextButton(onClick = { doc("privacy") }) { Text("Privacy Policy") }
                TextButton(onClick = { doc("terms") }) { Text("Terms and Conditions") }
                TextButton(onClick = { doc("usage") }) { Text("Usage Policy") }
                TextButton(onClick = { doc("branding") }) { Text("Fork and Branding Rules") }
                TextButton(onClick = { doc("thirdparty") }) { Text("Open-source Licences and Credits") }
                TextButton(onClick = { doc("license") }) { Text("Apache License 2.0 (this app)") }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("CONTACT AND SOURCE", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                TextButton(onClick = { mail(ctx) }) { Text(Legal.EMAIL) }
                TextButton(onClick = { openUrl(ctx, Legal.REPO) }) { Text("Source code on GitHub") }
            }
        }
    }
}

/** First-launch gate. The app doesn't open until the terms and privacy policy are accepted. */
@Composable
fun ConsentScreen(store: Store, onDecline: () -> Unit) {
    var viewing by remember { mutableStateOf<String?>(null) }
    var checked by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val v = viewing
    if (v != null) {
        val text = remember(v) { Legal.read(ctx, v) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
            TextButton(onClick = { viewing = null }) { Text("< Back") }
            HudCard(Modifier.fillMaxWidth()) { DocView(text) }
        }
        return
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("AUTHORISATION REQUIRED", color = Cyan, fontFamily = TitleFont, fontSize = 22.sp)
        Text(Legal.APP, color = Dim, fontFamily = HudFont, fontSize = 14.sp)
        Text("Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})", color = Dim, fontFamily = HudFont, fontSize = 12.sp)
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("KEY PROVISIONS AT A GLANCE", color = Cyan, fontFamily = HudFont, fontSize = 14.sp)
                Text("- This Application is an independent, non-commercial project, provided without warranty.", fontSize = 13.sp)
                Text("- Your conversations, tasks and keys are stored on your device. The Developer operates no servers and collects no data. When you use the AI, your message goes straight from your phone to Groq (and spoken replies to Fish Audio if you add a key); speech recognition may be processed by Google.", fontSize = 13.sp)
                Text("- AI output may be inaccurate. Do not rely on it for medical, legal, financial or safety-critical decisions.", fontSize = 13.sp)
                Text("- The microphone and the wake word must be used lawfully and with the consent of any person affected.", fontSize = 13.sp)
                Text("- The source code is licensed under Apache 2.0. Attribution must be preserved.", fontSize = 13.sp)
                Text("- You are asked to accept again only when these documents change.", fontSize = 13.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("FULL DOCUMENTS", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                TextButton(onClick = { viewing = "terms" }) { Text("Terms and Conditions") }
                TextButton(onClick = { viewing = "privacy" }) { Text("Privacy Policy") }
                TextButton(onClick = { viewing = "usage" }) { Text("Usage Policy") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked, { checked = it })
            Text(
                "I confirm that I am at least 18 years of age (or have the consent of a parent or legal guardian), and that I have read and accept the Terms and Conditions, the Privacy Policy and the Usage Policy applicable to this version of the Application.",
                Modifier.weight(1f), fontSize = 13.sp
            )
        }
        Button(onClick = {
            store.acceptConsent(Legal.CONSENT_VERSION)
            // Bring the listener straight back if it was on before (the app is visible, so Android allows it).
            if (store.wakeWanted && KeepAlive.micGranted(ctx) && !WakeService.running) WakeService.start(ctx.applicationContext, user = false)
        }, enabled = checked, modifier = Modifier.fillMaxWidth()) {
            Text("ACCEPT AND CONTINUE")
        }
        TextButton(onClick = onDecline, modifier = Modifier.fillMaxWidth()) { Text("Decline and close the application") }
        Text("Developed by ${Legal.AUTHOR}.", color = Dim, fontSize = 11.sp)
    }
}
