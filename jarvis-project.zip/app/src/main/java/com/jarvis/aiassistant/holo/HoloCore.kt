package com.jarvis.aiassistant.holo

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Build
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.res.ResourcesCompat
import com.jarvis.aiassistant.LaunchWhileStarted
import com.jarvis.aiassistant.R
import com.jarvis.aiassistant.WakeService
import kotlin.math.sqrt

private val HoloCyan = Color(0xFF00F0FF)
private const val DOTS = 220
private const val NTICK = 120
private val LBL_CPU = "RAM 000 %".toCharArray()
private val LBL_NET = "NET 000 KB".toCharArray()
private val LBL_LAT = "LAT 000 MS".toCharArray()
private val LBL_HDG = "HDG 000 DEG".toCharArray()
private val LBL_ALT = "ALT 000 M".toCharArray()
private val LBL_PWR = "BAT 000 %".toCharArray()
private val LBL_SYS = "SYS NOMINAL".toCharArray()
private val LBL_TL = "TELEMETRY".toCharArray()
private val LBL_TR = "TACTICAL".toCharArray()

private fun strokeP(w: Float, c: Color = HoloCyan, cap: StrokeCap = StrokeCap.Butt, fx: PathEffect? = null) =
    Paint().apply { isAntiAlias = true; style = PaintingStyle.Stroke; strokeWidth = w; color = c; strokeCap = cap; pathEffect = fx }

private fun fillP(c: Color = HoloCyan) =
    Paint().apply { isAntiAlias = true; style = PaintingStyle.Fill; color = c }

private fun textP(tf: Typeface?, size: Float, align: android.graphics.Paint.Align, c: Color = HoloCyan) =
    android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        typeface = tf ?: Typeface.MONOSPACE; textSize = size; textAlign = align; color = c.toArgb()
    }

/** Everything the draw loop touches is built here, once per size/density. The draw method allocates nothing. */
private class HoloScene(val w: Float, val h: Float, val d: Float, orb: Typeface?, grot: Typeface?, mono: Typeface?) {
    private val cx = w * 0.5f
    private val cy = h * 0.5f
    private val m = minOf(w, h)
    private val r = m * 0.25f
    private val radarR = r * 1.12f

    // --- static geometry (explicit sin/cos loops) ---
    private val grid: FloatArray
    private val gridN: Int
    private val ticksMinor = FloatArray(NTICK * 4)
    private val ticksMajor = FloatArray(NTICK / 10 * 4)
    private val dx = FloatArray(DOTS); private val dy = FloatArray(DOTS); private val dz = FloatArray(DOTS)
    private val bk = Array(3) { FloatArray(DOTS * 2) }
    private val bkN = IntArray(3)
    private val cross = FloatArray(16)
    private val dia = FloatArray(16)
    private val wave = FloatArray((HIST - 1) * 4)
    private val brackets = Path()
    private var ticksMinorN = 0
    private var ticksMajorN = 0

    // --- paints ---
    private val gridP = strokeP(d * 0.6f)
    private val gridF = gridP.asFrameworkPaint()
    private val ringR = floatArrayOf(r * 1.15f, r * 1.30f, r * 1.45f, r * 1.60f)
    private val ringDeg = floatArrayOf(22f, -34f, 15f, -9f)
    private val ringP = Array(4) { i ->
        val c = TAU * ringR[i]
        when (i) {
            0 -> strokeP(d * 1.0f, fx = PathEffect.dashPathEffect(floatArrayOf(c / 48f * 0.6f, c / 48f * 0.4f), 0f))
            1 -> strokeP(d * 2.2f, cap = StrokeCap.Round)
            2 -> strokeP(d * 1.2f, fx = PathEffect.dashPathEffect(floatArrayOf(c / 90f * 0.25f, c / 90f * 0.75f), 0f))
            else -> strokeP(d * 2.6f, cap = StrokeCap.Round)
        }
    }
    private val satP = fillP(Color.White)
    private val tickMinP = strokeP(d * 0.8f); private val tickMinF = tickMinP.asFrameworkPaint()
    private val tickMajP = strokeP(d * 1.6f); private val tickMajF = tickMajP.asFrameworkPaint()
    private val dotP = Array(3) { i ->
        strokeP(d * (1.1f + i * 0.9f), cap = StrokeCap.Round).also { it.alpha = 0.22f + 0.36f * i }
    }
    private val dotF = Array(3) { dotP[it].asFrameworkPaint() }
    private val bodyP = fillP().also {
        it.shader = RadialGradient(cx - r * 0.28f, cy - r * 0.30f, r * 1.15f,
            intArrayOf(0x3800F0FF, 0x0F00F0FF, 0x0000F0FF), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }
    private val coreP = fillP().also {
        it.shader = RadialGradient(cx, cy, r * 0.62f,
            intArrayOf(0xFFE6FEFF.toInt(), 0x6600F0FF, 0x0000F0FF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
    }
    private val haloP = fillP().also {
        it.shader = RadialGradient(cx, cy, r * 2.0f,
            intArrayOf(0x3300F0FF, 0x0000F0FF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
    }
    private val backP = fillP().also {
        it.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(0xFF0B1116.toInt(), 0xFF05080B.toInt()), null, Shader.TileMode.CLAMP)
    }
    private val sweepP = fillP().also {
        it.shader = SweepGradient(0f, 0f, intArrayOf(0x0000F0FF, 0x0000F0FF, 0x7000F0FF),
            floatArrayOf(0f, 0.72f, 1f))
    }
    private val rimP = strokeP(d * 1.0f).also { it.alpha = 0.45f }
    private val sweepLineP = strokeP(d * 1.4f)
    private val blipP = fillP(Color.White)
    private val reticleP = strokeP(d * 1.1f).also { it.alpha = 0.9f }
    private val reticleF = reticleP.asFrameworkPaint()
    private val bracketP = strokeP(d * 1.5f).also { it.alpha = 0.85f }
    private val waveP = strokeP(d * 1.1f, cap = StrokeCap.Round); private val waveF = waveP.asFrameworkPaint()
    private val headP = textP(orb, d * 9.5f, android.graphics.Paint.Align.LEFT)
    private val headRP = textP(orb, d * 9.5f, android.graphics.Paint.Align.RIGHT)
    private val lblP = textP(mono ?: grot, d * 8.5f, android.graphics.Paint.Align.LEFT)
    private val lblRP = textP(mono ?: grot, d * 8.5f, android.graphics.Paint.Align.RIGHT)

    // --- text buffers, rewritten at ~10 Hz ---
    private val bCpu = LBL_CPU.copyOf(); private val bNet = LBL_NET.copyOf(); private val bLat = LBL_LAT.copyOf()
    private val bHdg = LBL_HDG.copyOf(); private val bAlt = LBL_ALT.copyOf(); private val bPwr = LBL_PWR.copyOf()
    private var lastTick = -1

    init {
        val sp = m / 10f
        val nv = (w / sp).toInt() + 2
        val nh = (h / sp).toInt() + 2
        grid = FloatArray((nv + nh) * 4)
        var o = 0
        for (i in -nv / 2..nv / 2) {
            val x = cx + i * sp
            if (x < 0f || x > w) continue
            grid[o++] = x; grid[o++] = 0f; grid[o++] = x; grid[o++] = h
        }
        for (j in -nh / 2..nh / 2) {
            val y = cy + j * sp
            if (y < 0f || y > h) continue
            grid[o++] = 0f; grid[o++] = y; grid[o++] = w; grid[o++] = y
        }
        gridN = o

        // tick ring: r*1.68 .. r*1.74 minor, r*1.68 .. r*1.82 every 10th
        var mi = 0; var ma = 0
        for (i in 0 until NTICK) {
            val a = i * TAU / NTICK
            val c = Lut.cos(a); val s = Lut.sin(a)
            if (i % 10 == 0) {
                ticksMajor[ma++] = c * r * 1.68f; ticksMajor[ma++] = s * r * 1.68f
                ticksMajor[ma++] = c * r * 1.82f; ticksMajor[ma++] = s * r * 1.82f
            } else {
                ticksMinor[mi++] = c * r * 1.68f; ticksMinor[mi++] = s * r * 1.68f
                ticksMinor[mi++] = c * r * 1.74f; ticksMinor[mi++] = s * r * 1.74f
            }
        }
        ticksMinorN = mi; ticksMajorN = ma

        // Fibonacci sphere
        val golden = 2.3999631f
        for (i in 0 until DOTS) {
            val yy = 1f - 2f * (i + 0.5f) / DOTS
            val rad = sqrt(1f - yy * yy)
            val phi = i * golden
            dx[i] = Lut.cos(phi) * rad; dy[i] = yy; dz[i] = Lut.sin(phi) * rad
        }

        // static crosshair: four gapped arms
        for (k in 0 until 4) {
            val a = k * TAU / 4f
            val c = Lut.cos(a); val s = Lut.sin(a)
            cross[k * 4] = cx + c * r * 0.16f; cross[k * 4 + 1] = cy + s * r * 0.16f
            cross[k * 4 + 2] = cx + c * r * 0.30f; cross[k * 4 + 3] = cy + s * r * 0.30f
        }

        // corner brackets
        val e = d * 8f; val L = d * 18f
        brackets.moveTo(e, e + L); brackets.lineTo(e, e); brackets.lineTo(e + L, e)
        brackets.moveTo(w - e - L, e); brackets.lineTo(w - e, e); brackets.lineTo(w - e, e + L)
        brackets.moveTo(e, h - e - L); brackets.lineTo(e, h - e); brackets.lineTo(e + L, h - e)
        brackets.moveTo(w - e - L, h - e); brackets.lineTo(w - e, h - e); brackets.lineTo(w - e, h - e - L)
    }
    private fun refreshText(t: HoloTelemetry) {
        putInt(bCpu, 4, t.cpu, 3); putInt(bNet, 4, t.net, 3); putInt(bLat, 4, t.lat, 3)
        putInt(bHdg, 4, t.hdg, 3); putInt(bAlt, 4, t.alt, 3); putInt(bPwr, 4, t.pwr, 3)
    }

    fun draw(c: Canvas, t: HoloTelemetry, intensity: Float) {
        val time = t.t
        val nc = c.nativeCanvas
        if (t.tick != lastTick) { lastTick = t.tick; refreshText(t) }
        val breathe = 0.5f + 0.5f * Lut.sin(time * 1.6f)

        // backdrop + grid
        c.drawRect(0f, 0f, w, h, backP)
        gridP.alpha = 0.05f + 0.035f * breathe
        nc.drawLines(grid, 0, gridN, gridF)
        haloP.alpha = 0.55f + 0.30f * breathe + 0.15f * intensity
        c.drawCircle(Offset(cx, cy), r * 2.0f, haloP)

        // radar disc: sweep wedge, rim, blips
        val sw = time * 1.9f
        c.save(); c.translate(cx, cy); c.rotate(sw * 57.29578f)
        c.drawCircle(Offset.Zero, radarR, sweepP)
        c.drawLine(Offset.Zero, Offset(radarR, 0f), sweepLineP)
        c.restore()
        c.drawCircle(Offset(cx, cy), radarR, rimP)
        for (i in 0 until BLIPS) {
            var dl = (sw - t.bAng[i]) % TAU
            if (dl < 0f) dl += TAU
            val b = 1f - dl / (TAU * 0.8f)
            if (b <= 0.02f) continue
            val rr = t.bRad[i] * radarR
            blipP.alpha = b
            c.drawCircle(Offset(cx + Lut.cos(t.bAng[i]) * rr, cy + Lut.sin(t.bAng[i]) * rr), d * (1.6f + 1.4f * b), blipP)
        }

        // sphere body + dots (3 depth buckets)
        c.drawCircle(Offset(cx, cy), r, bodyP)
        val yaw = time * 0.42f
        val cyw = Lut.cos(yaw); val syw = Lut.sin(yaw)
        val ct = 0.9487f; val st = -0.3162f   // fixed tilt
        bkN[0] = 0; bkN[1] = 0; bkN[2] = 0
        for (i in 0 until DOTS) {
            val x1 = dx[i] * cyw + dz[i] * syw
            val z1 = -dx[i] * syw + dz[i] * cyw
            val yy = dy[i] * ct - z1 * st
            val zz = dy[i] * st + z1 * ct
            val k = if (zz < -0.25f) 0 else if (zz < 0.45f) 1 else 2
            val a = bk[k]; val n = bkN[k]
            a[n] = cx + x1 * r; a[n + 1] = cy + yy * r
            bkN[k] = n + 2
        }
        for (k in 0 until 3) nc.drawPoints(bk[k], 0, bkN[k], dotF[k])
        coreP.alpha = 0.30f + 0.25f * breathe + 0.30f * intensity
        c.drawCircle(Offset(cx, cy), r * 0.62f, coreP)

        // counter-rotating rings + satellites
        for (k in 0 until 4) {
            val rr = ringR[k]
            ringP[k].alpha = 0.45f + 0.15f * breathe
            c.save(); c.translate(cx, cy); c.rotate(time * ringDeg[k] * (1f + 0.6f * intensity))
            if (k == 1) {
                for (j in 0 until 3) c.drawArc(-rr, -rr, rr, rr, j * 120f, 70f, false, ringP[k])
            } else if (k == 3) {
                c.drawArc(-rr, -rr, rr, rr, 0f, 40f, false, ringP[k])
                c.drawArc(-rr, -rr, rr, rr, 180f, 40f, false, ringP[k])
            } else c.drawArc(-rr, -rr, rr, rr, 0f, 360f, false, ringP[k])
            val sa = time * (1.35f - 0.4f * k)
            satP.alpha = 0.9f
            c.drawCircle(Offset(Lut.cos(sa) * rr, Lut.sin(sa) * rr), d * 2.2f, satP)
            c.restore()
        }

        // tick ring (counter to ring 0)
        c.save(); c.translate(cx, cy); c.rotate(-time * 6f)
        tickMinP.alpha = 0.40f; tickMajP.alpha = 0.90f
        nc.drawLines(ticksMinor, 0, ticksMinorN, tickMinF)
        nc.drawLines(ticksMajor, 0, ticksMajorN, tickMajF)
        c.restore()

        // reticle: static gapped crosshair + rotating diamond
        nc.drawLines(cross, 0, 16, reticleF)
        val ra = time * 0.5f; val rd = r * 0.12f
        for (k in 0 until 4) {
            val a0 = ra + k * TAU / 4f; val a1 = a0 + TAU / 4f
            dia[k * 4] = cx + Lut.cos(a0) * rd; dia[k * 4 + 1] = cy + Lut.sin(a0) * rd
            dia[k * 4 + 2] = cx + Lut.cos(a1) * rd; dia[k * 4 + 3] = cy + Lut.sin(a1) * rd
        }
        nc.drawLines(dia, 0, 16, reticleF)
        c.drawPath(brackets, bracketP)

        // telemetry text
        val blink = if (((time * 2f).toInt() and 1) == 0) 255 else 110
        val x0 = d * 12f; val x1 = w - d * 12f; val ls = d * 13f; val y0 = d * 22f
        nc.drawText(LBL_TL, 0, LBL_TL.size, x0, y0, headP)
        nc.drawText(LBL_TR, 0, LBL_TR.size, x1, y0, headRP)
        nc.drawText(bCpu, 0, bCpu.size, x0, y0 + ls, lblP)
        nc.drawText(bNet, 0, bNet.size, x0, y0 + 2 * ls, lblP)
        nc.drawText(bLat, 0, bLat.size, x0, y0 + 3 * ls, lblP)
        nc.drawText(bHdg, 0, bHdg.size, x1, y0 + ls, lblRP)
        nc.drawText(bAlt, 0, bAlt.size, x1, y0 + 2 * ls, lblRP)
        nc.drawText(bPwr, 0, bPwr.size, x1, y0 + 3 * ls, lblRP)
        lblRP.alpha = blink
        nc.drawText(LBL_SYS, 0, LBL_SYS.size, x1, y0 + 4 * ls, lblRP)
        lblRP.alpha = 255

        // waveform from ring buffer
        val wx = x0; val ww = d * 62f; val wy = y0 + 3 * ls + d * 26f; val wh = d * 18f
        val step = ww / (HIST - 1)
        var o = 0
        for (i in 0 until HIST - 1) {
            val a = t.hist[(t.head + i) % HIST]; val b = t.hist[(t.head + i + 1) % HIST]
            wave[o++] = wx + i * step; wave[o++] = wy - a * wh
            wave[o++] = wx + (i + 1) * step; wave[o++] = wy - b * wh
        }
        waveP.alpha = 0.85f
        nc.drawLines(wave, 0, o, waveF)
    }
}

/**
 * Holographic telemetry core. Composition runs once: time, data and the "busy" speed live in
 * [HoloTelemetry] / derivedStateOf and are read only in the draw phase or the frame loop.
 */
@SuppressLint("NewApi")
@Composable
fun HoloCore(modifier: Modifier = Modifier, sys: com.jarvis.aiassistant.SysTelemetry? = null) {
    val ctx = LocalContext.current
    val tel = remember { HoloTelemetry() }
    val fx = remember { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) HoloFx() else null }
    val faces = remember(ctx) { Faces(ctx) }
    val target by remember {
        derivedStateOf {
            when (WakeService.state) { "LISTENING" -> 2.2f; "THINKING" -> 3.0f; "SPEAKING" -> 1.8f; else -> 1f }
        }
    }
    val targetNow by rememberUpdatedState(target)
    val intensity = remember { floatArrayOf(0f) }

    LaunchWhileStarted {
        var last = 0L
        var sp = 1f
        val frame: (Long) -> Unit = { now ->
            if (last != 0L) {
                val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                sp += (targetNow - sp) * (dt * 4f).coerceAtMost(1f)
                intensity[0] = ((sp - 1f) / 2f).coerceIn(0f, 1f)
                tel.step(dt, sp)
                if (sys != null) tel.applyReal(sys.ramUsedPct, sys.rxKbps + sys.txKbps, sys.battery)   // real RAM, network and battery on the ring labels
            }
            last = now
        }
        while (true) androidx.compose.runtime.withFrameNanos(frame)
    }

    Box(modifier) {
        Spacer(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    if (fx != null) renderEffect = fx.effect(size.width, size.height, density)
                }
                .drawWithCache {
                    val scene = HoloScene(size.width, size.height, density, faces.orbitron, faces.grotesk, faces.mono)
                    onDrawBehind { drawIntoCanvas { scene.draw(it, tel, intensity[0]) } }
                }
        )
        if (fx != null) {
            Spacer(
                Modifier.fillMaxSize().drawBehind {
                    fx.overlayUniforms(size.width, size.height, tel.t, 0.6f + 0.4f * intensity[0])
                    drawRect(fx.overlayBrush, blendMode = BlendMode.Plus)
                }
            )
        }
    }
}

private class Faces(ctx: Context) {
    val orbitron: Typeface? = ResourcesCompat.getFont(ctx, R.font.orbitron_bold)
    val grotesk: Typeface? = ResourcesCompat.getFont(ctx, R.font.spacegrotesk_medium)
    val mono: Typeface? = ResourcesCompat.getFont(ctx, R.font.spacemono_regular)
}
