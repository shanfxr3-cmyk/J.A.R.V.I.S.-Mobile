// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Sends the phone's precise position to the user's own jarvis-hub (POST /v1/location) while the always-on alert service runs.
 * The hub only sends rain alerts when it holds a recent, accurate fix from here. Nothing goes anywhere except the hub address in Settings.
 */
object Locator {
    private const val EVERY_MS = 5 * 60_000L
    private var app: Context? = null
    private var started = false
    @Volatile private var lastSentAt = 0L
    @Volatile private var lastAcc = 99999.0

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) { push(location) }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Needed for older Android versions")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    fun fineGranted(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun backgroundGranted(c: Context) = Build.VERSION.SDK_INT < 29 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun shareOn(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("locShare", true)

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(ctx: Context) {
        val c = ctx.applicationContext
        app = c
        if (started || !fineGranted(c) || !shareOn(c)) return
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            var any = false
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.allProviders.contains(p) && lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, EVERY_MS, 0f, listener, Looper.getMainLooper())
                    any = true
                }
            }
            started = any
            val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last != null && System.currentTimeMillis() - last.time < 10 * 60_000L) push(last)
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun stop(ctx: Context) {
        try { (ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(listener) } catch (_: Throwable) {}
        started = false
    }

    private fun push(l: Location) {
        val c = app ?: return
        if (l.hasAccuracy() && l.accuracy > 500f) return          // useless for an exact-area alert
        val acc = if (l.hasAccuracy()) l.accuracy.toDouble() else 9999.0
        val now = System.currentTimeMillis()
        if (now - lastSentAt < 90_000L && acc >= lastAcc * 0.7) return   // at most one per 90 s, unless clearly more precise
        val st = Store.get(c)
        if (!Hub.configured(st)) return
        lastSentAt = now; lastAcc = acc
        Thread { if (!Hub.sendLocation(st, l.latitude, l.longitude, acc)) { lastSentAt = 0L; lastAcc = 99999.0 } }.also { it.isDaemon = true }.start()
    }

    private fun activityOf(c: Context): Activity? {
        var x: Context? = c
        while (x != null) {
            if (x is Activity) return x
            x = (x as? ContextWrapper)?.baseContext
        }
        return null
    }

    /** Foreground location prompt (precise + approximate are requested together, as Android 12+ requires). */
    fun request(a: Activity) {
        a.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 78)
    }

    /** Called after any permission dialog: restart the service so it picks up location, then ask once for "Allow all the time". */
    fun afterResult(a: Activity) {
        AlertService.sync(a)
        val sp = a.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        if (fineGranted(a) && !backgroundGranted(a) && !sp.getBoolean("permAskedBg1", false)) {
            sp.edit().putBoolean("permAskedBg1", true).apply()
            if (Build.VERSION.SDK_INT >= 29) a.requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 79)
        }
    }

    fun summary(c: Context): String = when {
        !fineGranted(c) -> "Off - tap to allow precise location"
        !backgroundGranted(c) -> "Only while the app is open - tap to allow all the time"
        shareOn(c) -> "Sharing with your hub for local rain alerts - tap to pause"
        else -> "Paused - tap to resume"
    }

    fun onTap(c: Context) {
        val a = activityOf(c)
        when {
            !fineGranted(c) -> a?.let { request(it) }
            !backgroundGranted(c) && a != null && Build.VERSION.SDK_INT >= 29 -> a.requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 79)
            else -> {
                val on = !shareOn(c)
                c.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("locShare", on).apply()
                if (on) start(c) else stop(c)
            }
        }
    }
}
