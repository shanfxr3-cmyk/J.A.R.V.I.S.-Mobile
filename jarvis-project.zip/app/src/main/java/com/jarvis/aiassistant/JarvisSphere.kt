// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AColor
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.io.ByteArrayInputStream

/** Pose written by the hand-gesture controller and read by the sphere (rotation in degrees, scale, pan in controller units). */
class HoloState {
    @Volatile var rotX = 20f
    @Volatile var rotY = -30f
    @Volatile var velX = 0f
    @Volatile var velY = 0f
    @Volatile var scale = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f
    @Volatile var inside = false
    @Volatile var handActive = false
    @Volatile var gestureEnabled = true
    @Volatile var panScale = 2.4f
    @Volatile var panLimX = 0.7f
    @Volatile var panLimY = 1.2f

    fun reset() {
        rotX = 20f; rotY = -30f; scale = 1f; panX = 0f; panY = 0f; inside = false; velX = 0f; velY = 0f
    }
}

private const val BASE_HOST = "jarvis.local"
private val CDN_HOSTS = setOf(BASE_HOST, "cdnjs.cloudflare.com")

private class SphereBridge(private val onReady: () -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    @JavascriptInterface fun ready() { main.post(onReady) }
}

/** Owns the WebView that draws the Three.js core (assets/sphere/jarvis_sphere.html). */
class SphereHost(ctx: Context) {
    var ready by mutableStateOf(false)
    var failed by mutableStateOf(false)

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility")
    val view: WebView = WebView(ctx).apply {
        setBackgroundColor(AColor.TRANSPARENT)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        with(settings) {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        addJavascriptInterface(SphereBridge { ready = true }, "Android")
        webViewClient = object : WebViewClient() {
            // The page may only talk to its own origin and the Three.js CDN.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.scheme == "data" || request.url.scheme == "about" || (request.url.host ?: "") in CDN_HOSTS) null
                else WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                ready = false; failed = true
                return true
            }
        }
        // Dragging on the sphere must rotate it, not scroll the Home screen.
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        try {
            val html = ctx.assets.open("sphere/jarvis_sphere.html").bufferedReader().use { it.readText() }
            loadDataWithBaseURL("https://$BASE_HOST/", html, "text/html", "utf-8", null)
        } catch (_: Throwable) { failed = true }
    }

    fun js(code: String) { if (ready) view.evaluateJavascript(code, null) }

    /** Current pose of the sphere as rotX, rotY (degrees) and scale, so hand tracking continues from where it is. */
    fun pose(cb: (Float, Float, Float) -> Unit) {
        if (!ready) return
        view.evaluateJavascript("jarvisGetPose()") { r ->
            val p = r?.trim('"')?.split(',')?.mapNotNull { it.toFloatOrNull() }
            if (p != null && p.size == 3) cb(p[0], p[1], p[2])
        }
    }
}

@Composable
fun rememberSphereHost(): SphereHost {
    val ctx = LocalContext.current
    val host = remember { SphereHost(ctx) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, host) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) host.view.onPause()
            else if (e == Lifecycle.Event.ON_RESUME) host.view.onResume()
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            host.view.stopLoading()
            host.view.removeJavascriptInterface("Android")
            host.view.destroy()
        }
    }
    return host
}

@Composable
fun JarvisSphere(host: SphereHost, modifier: Modifier = Modifier) {
    AndroidView(factory = { host.view }, modifier = modifier)
}
