// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

/** Memory and watch-list tools. They only change data stored on this phone. */
object Mind {
    val tools: List<ToolDef> = listOf(
        ToolDef("remember", "Save a short fact or preference about the person so you remember it in future chats.",
            listOf(ToolDef.Param("fact", "string", "One short sentence"))) { _, st, a ->
            if (st.addMemory(a.optString("fact"))) "Remembered." else "That was empty or already saved."
        },
        ToolDef("forget", "Delete saved memories that contain the given words.",
            listOf(ToolDef.Param("match", "string", "Words that appear in the memory"))) { _, st, a ->
            val n = st.forgetMemory(a.optString("match")); if (n == 0) "Nothing saved matched that." else "Forgot $n item" + if (n == 1) "." else "s."
        },
        ToolDef("watch_topic", "Start watching a topic: Jarvis checks the news a few times a day and sends a notification only when something new happens.",
            listOf(ToolDef.Param("topic", "string", "Short topic"))) { c, st, a ->
            if (st.addWatch(a.optString("topic"))) { Briefing.reschedule(c, st); "Watching it." } else "Could not add that (empty, duplicate, or you already watch 5 topics)."
        },
        ToolDef("unwatch_topic", "Stop watching a topic.", listOf(ToolDef.Param("topic", "string", "Topic words"))) { c, st, a ->
            val n = st.removeWatch(a.optString("topic")); Briefing.reschedule(c, st); if (n == 0) "You were not watching that." else "Stopped watching it."
        }
    )
}
