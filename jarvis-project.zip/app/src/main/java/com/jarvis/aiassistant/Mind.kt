// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

/** Long-term memory: facts about the person, saved on this phone and given to the AI in every chat. */
object Mind {
    val tools: List<ToolDef> = listOf(
        ToolDef("remember", "Save a lasting fact about the person (preferences, people, routines, plans) so you know it in future chats.",
            listOf(ToolDef.Param("fact", "string", "One short fact"))) { _, st, a ->
            if (st.addMemory(a.optString("fact"))) "Remembered." else "Already known or too short."
        },
        ToolDef("forget", "Delete saved facts that contain this text.", listOf(ToolDef.Param("match", "string", "Text to match"))) { _, st, a ->
            val n = st.forgetMemory(a.optString("match")); if (n == 0) "Nothing matched." else "Forgot $n."
        },
        ToolDef("list_memories", "List everything saved about the person.", readOnly = true) { _, st, _ ->
            if (st.memories.isEmpty()) "Nothing saved yet." else st.memories.joinToString("; ")
        }
    )
}
