// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Set by the tile, widget and assistant button; the chat screen reads it and starts voice mode, then clears it. */
object Launch {
    var voice by mutableStateOf(false)
}

private fun launchIntent(ctx: Context, voice: Boolean): Intent =
    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("voice", voice)

/** Quick Settings tile: pull down the shade, tap Jarvis, and voice mode opens. */
class JarvisTile : TileService() {
    override fun onStartListening() {
        qsTile?.let { it.state = Tile.STATE_INACTIVE; it.label = "Jarvis"; it.updateTile() }
    }

    override fun onClick() {
        val i = launchIntent(this, true)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 21, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}

/** Home-screen widget with two one-tap buttons. */
class JarvisWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.widget_jarvis)
            v.setOnClickPendingIntent(R.id.w_talk, pi(context, 31, true))
            v.setOnClickPendingIntent(R.id.w_chat, pi(context, 32, false))
            manager.updateAppWidget(id, v)
        }
    }

    private fun pi(ctx: Context, code: Int, voice: Boolean): PendingIntent =
        PendingIntent.getActivity(ctx, code, launchIntent(ctx, voice), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}
