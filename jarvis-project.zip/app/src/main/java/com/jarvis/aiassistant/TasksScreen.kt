// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Small tonal pill used in task and memory rows. */
@Composable
internal fun MiniBtn(label: String, color: Color = Cyan, onClick: () -> Unit) {
    Box(
        Modifier.clip(PillShape).background(color.copy(alpha = 0.14f), PillShape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    ) { Text(label.soft(), color = color, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1) }
}

@Composable
fun TasksScreen(store: Store) {
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var editText by remember { mutableStateOf("") }
    val sorted by remember { derivedStateOf { store.tasks.sortedBy { it.done } } }
    val active by remember { derivedStateOf { store.tasks.count { !it.done } } }
    val completed by remember { derivedStateOf { store.tasks.count { it.done } } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        ScreenHeader("Tasks", "Saved on this device", trailing = {
            Row(
                Modifier.background(PanelHi, PillShape).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                LiveMono({ "$active" }, 1, color = Cyan, size = 13.sp, bold = true)
                MonoText("open", color = Dim, size = 13.sp)
                MonoText("/", color = Dim, size = 13.sp)
                LiveMono({ "$completed" }, 1, color = Green, size = 13.sp, bold = true)
                MonoText("done", color = Dim, size = 13.sp)
            }
        })
        Row(verticalAlignment = Alignment.Bottom) {
            HudInput(input, { input = it }, "Add a task", Modifier.weight(1f), singleLine = true)
            Spacer(Modifier.width(8.dp))
            HudBtn("Add", Modifier.height(56.dp)) { store.addTask(input); input = "" }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (sorted.isEmpty()) item { Text("No tasks yet. Add one above.", color = Dim, fontFamily = BodyFont, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp)) }
            itemsIndexed(sorted, key = { _, t -> t.id }) { _, t ->
                HudCard(Modifier.fillMaxWidth(), pad = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HudCheck(t.done) { store.toggleTask(t.id) }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            t.title, Modifier.weight(1f), fontSize = 15.sp, fontFamily = BodyFont, maxLines = 3,
                            color = if (t.done) Dim else Ink,
                            textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                        )
                        Spacer(Modifier.width(8.dp))
                        MiniBtn("Edit") { editing = t; editText = t.title }
                        Spacer(Modifier.width(6.dp))
                        MiniBtn("Delete", Danger) { store.deleteTask(t.id) }
                    }
                }
            }
        }
        if (completed > 0) {
            Spacer(Modifier.height(8.dp))
            HudBtn("Clear completed", Modifier.fillMaxWidth(), BtnKind.Outline) { store.clearCompleted() }
        }
    }

    editing?.let { t ->
        AlertDialog(
            onDismissRequest = { editing = null },
            containerColor = PanelHi,
            shape = RoundedCornerShape(28.dp),
            tonalElevation = 0.dp,
            title = { Text("Edit task", color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
            text = { HudInput(editText, { editText = it }, "Task", singleLine = true) },
            confirmButton = { TextButton(onClick = { store.updateTask(t.id, editText); editing = null }) { Text("Save", color = Cyan, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel", color = Dim, fontFamily = TitleFont, fontSize = 14.sp) } }
        )
    }
}
