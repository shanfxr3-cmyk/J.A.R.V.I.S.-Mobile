// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Small bordered action tag used in task and memory rows. */
@Composable
internal fun MiniBtn(label: String, color: Color = Cyan, onClick: () -> Unit) {
    Box(
        Modifier.border(0.5.dp, color.copy(alpha = 0.7f), CutCornerShape(topStart = 4.dp, bottomEnd = 4.dp))
            .clickable(onClick = onClick).padding(horizontal = 7.dp, vertical = 5.dp)
    ) { Text(label, color = color, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 9.sp, maxLines = 1) }
}

@Composable
fun TasksScreen(store: Store) {
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var editText by remember { mutableStateOf("") }
    val sorted by remember { derivedStateOf { store.tasks.sortedBy { it.done } } }
    val active by remember { derivedStateOf { store.tasks.count { !it.done } } }
    val completed by remember { derivedStateOf { store.tasks.count { it.done } } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ScreenHeader("TASKS", "LOCAL TASK LOG", trailing = {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MonoText("ACT", color = Dim, size = 9.sp); Spacer(Modifier.width(4.dp))
                    LiveMono({ Mono.pad(active, 3) }, 3, color = Cyan, size = 12.sp, bold = true)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MonoText("DON", color = Dim, size = 9.sp); Spacer(Modifier.width(4.dp))
                    LiveMono({ Mono.pad(completed, 3) }, 3, color = Green, size = 12.sp, bold = true)
                }
            }
        })
        Row(verticalAlignment = Alignment.Bottom) {
            HudInput(input, { input = it }, "New task", Modifier.weight(1f), singleLine = true)
            Spacer(Modifier.width(8.dp))
            HudBtn("ADD", Modifier.height(56.dp)) { store.addTask(input); input = "" }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (sorted.isEmpty()) item { Text("No tasks yet.", color = Dim, fontFamily = MonoFont, fontSize = 12.sp) }
            itemsIndexed(sorted, key = { _, t -> t.id }) { i, t ->
                HudCard(Modifier.fillMaxWidth(), pad = 8.dp, accent = if (t.done) Dim else Cyan) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IndexTag(i + 1)
                        Spacer(Modifier.width(8.dp))
                        HudCheck(t.done) { store.toggleTask(t.id) }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            t.title, Modifier.weight(1f), fontSize = 12.sp, fontFamily = MonoFont, maxLines = 3,
                            color = if (t.done) Dim else Ink,
                            textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                        )
                        Spacer(Modifier.width(8.dp))
                        MiniBtn("EDIT") { editing = t; editText = t.title }
                        Spacer(Modifier.width(4.dp))
                        MiniBtn("DEL", Danger) { store.deleteTask(t.id) }
                    }
                }
            }
        }
        if (completed > 0) {
            Spacer(Modifier.height(6.dp))
            HudBtn("CLEAR COMPLETED", Modifier.fillMaxWidth(), BtnKind.Outline) { store.clearCompleted() }
        }
    }

    editing?.let { t ->
        AlertDialog(
            onDismissRequest = { editing = null },
            containerColor = Panel,
            shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp),
            tonalElevation = 0.dp,
            title = { Text("EDIT TASK", color = Cyan, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
            text = { HudInput(editText, { editText = it }, "Task", singleLine = true) },
            confirmButton = { TextButton(onClick = { store.updateTask(t.id, editText); editing = null }) { Text("SAVE", color = Cyan, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 12.sp) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("CANCEL", color = Dim, fontFamily = TitleFont, fontSize = 12.sp) } }
        )
    }
}
