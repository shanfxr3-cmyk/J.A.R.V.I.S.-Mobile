// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

@Composable
fun TasksScreen(store: Store) {
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var editText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ScreenHeader("TASKS", "${store.tasks.count { !it.done }} active, ${store.tasks.count { it.done }} completed")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("New task") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { store.addTask(input); input = "" }) { Text("Add") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (store.tasks.isEmpty()) {
                item { Text("No tasks yet.", color = Dim) }
            }
            items(store.tasks.sortedBy { it.done }, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = t.done, onCheckedChange = { store.toggleTask(t.id) })
                    Text(
                        t.title, Modifier.weight(1f),
                        color = if (t.done) Dim else androidx.compose.ui.graphics.Color.White,
                        textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                    )
                    TextButton(onClick = { editing = t; editText = t.title }) { Text("Edit") }
                    TextButton(onClick = { store.deleteTask(t.id) }) { Text("Del") }
                }
            }
        }
        if (store.tasks.any { it.done }) {
            TextButton(onClick = { store.clearCompleted() }) { Text("Clear completed") }
        }
    }

    editing?.let { t ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit task") },
            text = { OutlinedTextField(value = editText, onValueChange = { editText = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { store.updateTask(t.id, editText); editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}
