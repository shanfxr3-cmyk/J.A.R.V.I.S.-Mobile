package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

const val DEFAULT_MODEL = "llama-3.3-70b-versatile"

data class TaskItem(val id: Long, val title: String, val done: Boolean, val created: Long)
data class Msg(val fromUser: Boolean, val text: String, val time: Long)
data class ActivityItem(val text: String, val time: Long)

/** Local persistence (SharedPreferences + JSON). Everything shown in the UI comes from here. */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    val tasks = mutableStateListOf<TaskItem>()
    val messages = mutableStateListOf<Msg>()
    val activity = mutableStateListOf<ActivityItem>()
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
        private set
    var apiKey by mutableStateOf(sp.getString("apiKey", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL)
        private set
    var speakReplies by mutableStateOf(sp.getBoolean("speak", true))
        private set
    var picoKey by mutableStateOf(sp.getString("picoKey", "") ?: "")
        private set
    var wakeSens by mutableStateOf(sp.getFloat("wakeSens", 0.7f))
        private set

    companion object {
        @Volatile private var inst: Store? = null
        /** One shared instance per process, so the app and the wake-word service see the same data. */
        fun get(context: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(context.applicationContext).also { inst = it } }
    }

    private fun arr(key: String): JSONArray =
        try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    init {
        val t = arr("tasks")
        for (i in 0 until t.length()) {
            val o = t.getJSONObject(i)
            tasks.add(TaskItem(o.getLong("id"), o.getString("title"), o.getBoolean("done"), o.getLong("created")))
        }
        val m = arr("messages")
        for (i in 0 until m.length()) {
            val o = m.getJSONObject(i)
            messages.add(Msg(o.getBoolean("user"), o.getString("text"), o.getLong("time")))
        }
        val a = arr("activity")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            activity.add(ActivityItem(o.getString("text"), o.getLong("time")))
        }
    }

    private fun saveTasks() {
        val a = JSONArray()
        tasks.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("created", it.created))
        }
        sp.edit().putString("tasks", a.toString()).apply()
    }

    private fun saveMessages() {
        val a = JSONArray()
        messages.forEach {
            a.put(JSONObject().put("user", it.fromUser).put("text", it.text).put("time", it.time))
        }
        sp.edit().putString("messages", a.toString()).apply()
    }

    private fun saveActivity() {
        val a = JSONArray()
        activity.forEach { a.put(JSONObject().put("text", it.text).put("time", it.time)) }
        sp.edit().putString("activity", a.toString()).apply()
    }

    fun log(text: String) {
        activity.add(0, ActivityItem(text, System.currentTimeMillis()))
        while (activity.size > 50) activity.removeAt(activity.lastIndex)
        saveActivity()
    }

    fun addTask(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        tasks.add(TaskItem(now, t, false, now))
        saveTasks()
        log("Task added: $t")
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        tasks[i] = tasks[i].copy(done = !tasks[i].done)
        saveTasks()
        log(if (tasks[i].done) "Task completed: ${tasks[i].title}" else "Task reopened: ${tasks[i].title}")
    }

    fun updateTask(id: Long, title: String) {
        val t = title.trim()
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0 || t.isEmpty()) return
        tasks[i] = tasks[i].copy(title = t)
        saveTasks()
        log("Task edited: $t")
    }

    fun deleteTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val title = tasks[i].title
        tasks.removeAt(i)
        saveTasks()
        log("Task deleted: $title")
    }

    fun clearCompleted() {
        tasks.removeAll { it.done }
        saveTasks()
        log("Completed tasks cleared")
    }

    fun addMessage(fromUser: Boolean, text: String) {
        messages.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (messages.size > 500) messages.removeAt(0)
        saveMessages()
    }

    fun clearMessages() {
        messages.clear()
        saveMessages()
        log("Conversation history cleared")
    }

    fun setUser(name: String) {
        userName = name.trim()
        sp.edit().putString("userName", userName).apply()
        log("Name saved")
    }

    fun setAi(key: String, m: String) {
        apiKey = key.trim()
        model = m.trim().ifEmpty { DEFAULT_MODEL }
        sp.edit().putString("apiKey", apiKey).putString("model", model).apply()
        log("AI settings saved")
    }

    fun setWake(key: String, sens: Float) {
        picoKey = key.trim()
        wakeSens = sens.coerceIn(0.2f, 0.95f)
        sp.edit().putString("picoKey", picoKey).putFloat("wakeSens", wakeSens).apply()
        log("Wake word settings saved")
    }

    fun setSpeak(on: Boolean) {
        speakReplies = on
        sp.edit().putBoolean("speak", on).apply()
    }

    fun clearAll() {
        tasks.clear(); messages.clear(); activity.clear()
        userName = ""; apiKey = ""; picoKey = ""; wakeSens = 0.7f; model = DEFAULT_MODEL; speakReplies = true
        sp.edit().clear().apply()
    }
}
