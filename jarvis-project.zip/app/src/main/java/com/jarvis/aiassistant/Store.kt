// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

const val DEFAULT_MODEL = "openai/gpt-oss-120b"
const val FAST_MODEL = "openai/gpt-oss-20b"
/** Models Groq has shut down. A saved id from this list is moved to DEFAULT_MODEL at start. */
val DEAD_MODELS = setOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "llama3-70b-8192", "llama3-8b-8192", "mixtral-8x7b-32768", "gemma2-9b-it")
fun migrateModel(m: String?): String = if (m.isNullOrBlank() || m in DEAD_MODELS) DEFAULT_MODEL else m

data class TaskItem(val id: Long, val title: String, val done: Boolean, val created: Long)
data class Msg(val fromUser: Boolean, val text: String, val time: Long)

/** Local persistence (SharedPreferences + JSON). Everything shown in the UI comes from here. */
class Store(context: Context) {
    private val appCtx: Context = context.applicationContext
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    /** Voice/chat command "start world view": asks Termux to run the God's Eye View server. */
    fun startWorldServer(): String {
        return TermuxRunner.start(appCtx)
    }
    val tasks = mutableStateListOf<TaskItem>()
    val messages = mutableStateListOf<Msg>()
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
        private set
    var apiKey by mutableStateOf(Secrets.decrypt(sp.getString("apiKey", "")))
        private set
    var model by mutableStateOf(migrateModel(sp.getString("model", DEFAULT_MODEL)))
        private set
    var speakReplies by mutableStateOf(sp.getBoolean("speak", true))
        private set
    var fishKey by mutableStateOf(Secrets.decrypt(sp.getString("fishKey", "")))
        private set
    var fishVoice by mutableStateOf(sp.getString("fishVoice", "") ?: "")
        private set
    var fishModel by mutableStateOf(FishTts.migrate(sp.getString("fishModel", FishTts.DEFAULT_MODEL)))
        private set
    /** Shown in Settings when an API key could not be stored or read back from the Android Keystore. */
    var keyWarning by mutableStateOf<String?>(null)
        private set
    /** How many wake-word start-ups failed in a row (the watchdog stops retrying after 3). */
    var initFails by mutableStateOf(sp.getInt("initFails", 0))
        private set
    var wakeSens by mutableStateOf(sp.getFloat("wakeSens", 0.5f))
        private set
    /** The user wants the wake word on. Used to bring it back after Android kills it. */
    var wakeWanted by mutableStateOf(sp.getBoolean("wakeWanted", false))
        private set
    /** 24/7 mode: sticky service, wake lock, watchdog alarm. */
    var keepAlive by mutableStateOf(sp.getBoolean("keepAlive", true))
        private set
    var consentVersion by mutableStateOf(sp.getInt("consentVersion", 0))
        private set
    var updateCheck by mutableStateOf(sp.getBoolean("updateCheck", true))
        private set

    // ---- Memory, personality, briefing (all stored on this phone only) ----
    val memories = mutableStateListOf<String>().also { l ->
        try { val a = JSONArray(sp.getString("memories", "[]")); for (i in 0 until a.length()) l.add(a.getString(i)) } catch (_: Exception) {}
    }
    var instructions by mutableStateOf(sp.getString("instructions", "") ?: "")
    var personality by mutableStateOf(sp.getString("personality", "classic") ?: "classic")
    var city by mutableStateOf(sp.getString("city", "") ?: "")
    var briefOn by mutableStateOf(sp.getBoolean("briefOn", false))
    var briefHour by mutableStateOf(sp.getInt("briefHour", 7))
    var briefMin by mutableStateOf(sp.getInt("briefMin", 30))
    val watches = mutableStateListOf<String>().also { l ->
        try { val a = JSONArray(sp.getString("watches", "[]")); for (i in 0 until a.length()) l.add(a.getString(i)) } catch (_: Exception) {}
    }

    var overlayOn by mutableStateOf(sp.getBoolean("overlayOn", false))
    var appLock by mutableStateOf(sp.getBoolean("appLock", false))

    fun setOverlay(on: Boolean) { overlayOn = on; sp.edit().putBoolean("overlayOn", on).apply() }
    fun setAppLock(on: Boolean) { appLock = on; sp.edit().putBoolean("appLock", on).apply() }

    private fun saveList(key: String, l: List<String>) { sp.edit().putString(key, JSONArray(l).toString()).apply() }

    fun addMemory(fact: String): Boolean {
        val f = fact.trim().trimEnd('.').take(200)
        if (f.length < 3 || memories.any { it.equals(f, ignoreCase = true) }) return false
        memories.add(f)
        while (memories.size > 60) memories.removeAt(0)
        saveList("memories", memories)
        return true
    }

    fun forgetMemory(match: String): Int {
        val m = match.trim().lowercase()
        if (m.length < 2) return 0
        val gone = memories.filter { it.lowercase().contains(m) }
        memories.removeAll(gone.toSet())
        if (gone.isNotEmpty()) saveList("memories", memories)
        return gone.size
    }

    fun clearMemories() { memories.clear(); saveList("memories", memories) }

    fun setMind(instr: String, pers: String, cityName: String) {
        instructions = instr.trim().take(600)
        personality = pers
        city = cityName.trim().take(80)
        sp.edit().putString("instructions", instructions).putString("personality", personality).putString("city", city).apply()
    }

    fun setBrief(on: Boolean, hour: Int, min: Int) {
        briefOn = on; briefHour = hour.coerceIn(0, 23); briefMin = min.coerceIn(0, 59)
        sp.edit().putBoolean("briefOn", on).putInt("briefHour", briefHour).putInt("briefMin", briefMin).apply()
    }

    fun addWatch(topic: String): Boolean {
        val t = topic.trim().take(80)
        if (t.length < 2 || watches.size >= 5 || watches.any { it.equals(t, ignoreCase = true) }) return false
        watches.add(t); saveList("watches", watches); return true
    }

    fun removeWatch(match: String): Int {
        val m = match.trim().lowercase()
        if (m.isEmpty()) return 0
        val gone = watches.filter { it.lowercase().contains(m) }
        watches.removeAll(gone.toSet())
        if (gone.isNotEmpty()) saveList("watches", watches)
        return gone.size
    }

    companion object {
        @Volatile private var inst: Store? = null
        /** One shared instance per process, so the app and the wake-word service see the same data. */
        fun get(context: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(context.applicationContext).also { inst = it } }
    }

    private fun arr(key: String): JSONArray =
        try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    // Saving happens on a background thread: the lists are copied on the main thread (cheap),
    // then turned into JSON and written there, so a long history never stutters the UI.
    private val saveThread = HandlerThread("store-save").apply { start() }
    private val saver = Handler(saveThread.looper)
    @Volatile private var epoch = 0

    private fun scheduleSave(token: String, build: () -> String) {
        val ep = epoch
        saver.removeCallbacksAndMessages(token)
        saver.postAtTime({
            if (ep != epoch) return@postAtTime
            runCatching { sp.edit().putString(token, build()).apply() }
        }, token, SystemClock.uptimeMillis() + 150)
    }

    init {
        // Keys saved by older versions are plain text: encrypt them in place once.
        for (name in listOf("apiKey", "fishKey")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.isNotBlank() && !raw.startsWith(Secrets.PREFIX)) {
                Secrets.encrypt(raw)?.let { sp.edit().putString(name, it).apply() }
            }
        }
        // Each saved item is read on its own: one damaged record is skipped instead of crashing the app.
        val seen = HashSet<Long>()
        val t = arr("tasks")
        for (i in 0 until t.length()) {
            try {
                val o = t.getJSONObject(i)
                var id = o.optLong("id", System.currentTimeMillis() + i)
                while (!seen.add(id)) id++
                tasks.add(TaskItem(id, o.optString("title", ""), o.optBoolean("done", false), o.optLong("created", id)))
            } catch (_: Throwable) {}
        }
        val m = arr("messages")
        for (i in 0 until m.length()) {
            try {
                val o = m.getJSONObject(i)
                messages.add(Msg(o.optBoolean("user", false), o.optString("text", ""), o.optLong("time", 0L)))
            } catch (_: Throwable) {}
        }
        // The old "recent activity" log was removed: delete what earlier versions saved.
        if (sp.contains("activity")) sp.edit().remove("activity").apply()
        // A key that was stored but can no longer be decrypted (keystore reset, restored phone, ...).
        for (name in listOf("apiKey", "fishKey")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.startsWith(Secrets.PREFIX) && Secrets.decrypt(raw).isBlank()) {
                keyWarning = "A saved API key could not be read from this phone's secure storage. Paste it again in Settings."
            }
        }
    }

    private fun saveTasks() {
        val snap = tasks.toList()
        scheduleSave("tasks") {
            val a = JSONArray()
            snap.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("created", it.created)) }
            a.toString()
        }
    }

    private fun saveMessages() {
        val snap = messages.toList()
        scheduleSave("messages") {
            val a = JSONArray()
            snap.forEach { a.put(JSONObject().put("user", it.fromUser).put("text", it.text).put("time", it.time)) }
            a.toString()
        }
    }

    fun addTask(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        // Ids must be unique: two tasks added in the same millisecond would crash the list.
        val id = maxOf(now, (tasks.maxOfOrNull { it.id } ?: 0L) + 1)
        tasks.add(TaskItem(id, t, false, now))
        saveTasks()
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        tasks[i] = tasks[i].copy(done = !tasks[i].done)
        saveTasks()
    }

    fun updateTask(id: Long, title: String) {
        val t = title.trim()
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0 || t.isEmpty()) return
        tasks[i] = tasks[i].copy(title = t)
        saveTasks()
    }

    fun deleteTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val title = tasks[i].title
        tasks.removeAt(i)
        saveTasks()
    }

    fun clearCompleted() {
        tasks.removeAll { it.done }
        saveTasks()
    }

    fun addMessage(fromUser: Boolean, text: String) {
        messages.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (messages.size > 500) messages.removeAt(0)
        saveMessages()
    }

    fun clearMessages() {
        messages.clear()
        saveMessages()
    }

    fun setUser(name: String) {
        userName = name.trim()
        sp.edit().putString("userName", userName).apply()
    }

    fun setAi(key: String, m: String) {
        apiKey = key.trim()
        model = migrateModel(m.trim())
        val enc = Secrets.encrypt(apiKey)
        keyWarning = if (enc == null && apiKey.isNotBlank()) "Could not store the Groq key securely on this phone. It works now but will be forgotten when the app restarts." else null
        sp.edit().putString("apiKey", enc ?: "").putString("model", model).apply()
    }

    fun setFish(key: String, voice: String, m: String) {
        fishKey = key.trim()
        fishVoice = voice.trim()
        fishModel = FishTts.migrate(m.trim())
        val enc = Secrets.encrypt(fishKey)
        if (enc == null && fishKey.isNotBlank()) keyWarning = "Could not store the Fish Audio key securely on this phone. It works now but will be forgotten when the app restarts."
        sp.edit().putString("fishKey", enc ?: "").putString("fishVoice", fishVoice).putString("fishModel", fishModel).apply()
    }

    fun setWake(sens: Float) {
        wakeSens = sens.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("wakeSens", wakeSens).apply()
    }

    fun setSpeak(on: Boolean) {
        speakReplies = on
        sp.edit().putBoolean("speak", on).apply()
    }

    fun markWakeWanted(on: Boolean) {
        wakeWanted = on
        sp.edit().putBoolean("wakeWanted", on).apply()
    }

    fun markKeepAlive(on: Boolean) {
        keepAlive = on
        sp.edit().putBoolean("keepAlive", on).apply()
    }

    fun markUpdateCheck(on: Boolean) {
        updateCheck = on
        sp.edit().putBoolean("updateCheck", on).apply()
    }

    fun acceptConsent(version: Int) {
        consentVersion = version
        sp.edit().putInt("consentVersion", version).putLong("consentAt", System.currentTimeMillis()).apply()
    }

    fun noteInitFail() {
        initFails++
        sp.edit().putInt("initFails", initFails).apply()
    }

    fun resetInitFails() {
        if (initFails == 0) return
        initFails = 0
        sp.edit().putInt("initFails", 0).apply()
    }

    fun clearAll() {
        // Drop any save still waiting in the queue so it cannot write old data back after the wipe.
        epoch++
        saver.removeCallbacksAndMessages(null)
        keyWarning = null; initFails = 0
        tasks.clear(); messages.clear()
        userName = ""; apiKey = ""; fishKey = ""; fishVoice = ""; fishModel = FishTts.DEFAULT_MODEL; wakeSens = 0.5f; model = DEFAULT_MODEL; speakReplies = true
        wakeWanted = false; keepAlive = true; updateCheck = true; consentVersion = 0
        memories.clear(); watches.clear(); instructions = ""; personality = "classic"; city = ""; briefOn = false; briefHour = 7; briefMin = 30; overlayOn = false; appLock = false
        sp.edit().clear().apply()
    }
}
