// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

const val DEFAULT_MODEL = "openai/gpt-oss-120b"
const val FAST_MODEL = "openai/gpt-oss-20b"
/** Models Groq has shut down. A saved id from this list is moved to DEFAULT_MODEL at start. */
val DEAD_MODELS = setOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "llama3-70b-8192", "llama3-8b-8192", "mixtral-8x7b-32768", "gemma2-9b-it")
fun migrateModel(m: String?): String = if (m.isNullOrBlank() || m in DEAD_MODELS) DEFAULT_MODEL else m

data class TaskItem(val id: Long, val title: String, val done: Boolean, val created: Long)
data class Msg(val fromUser: Boolean, val text: String, val time: Long)
data class ActivityItem(val text: String, val time: Long)

/** Local persistence (SharedPreferences + JSON). Everything shown in the UI comes from here. */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    val tasks = mutableStateListOf<TaskItem>()
    val messages = mutableStateListOf<Msg>()
    val activity = mutableStateListOf<ActivityItem>()
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
        private set
    var apiKey by mutableStateOf(Secrets.decrypt(sp.getString("apiKey", "")))
        private set
    var model by mutableStateOf(migrateModel(sp.getString("model", DEFAULT_MODEL)))
        private set
    var speakReplies by mutableStateOf(sp.getBoolean("speak", true))
        private set
    var fishKey by mutableStateOf(Secrets.decrypt(sp.getString("fishKey", "")))
        private set
    var fishVoice by mutableStateOf(sp.getString("fishVoice", "") ?: "")
        private set
    var fishModel by mutableStateOf(FishTts.migrate(sp.getString("fishModel", FishTts.DEFAULT_MODEL)))
        private set
    /** Shown in Settings when an API key could not be stored or read back from the Android Keystore. */
    var keyWarning by mutableStateOf<String?>(null)
        private set
    /** How many wake-word start-ups failed in a row (the watchdog stops retrying after 3). */
    var initFails by mutableStateOf(sp.getInt("initFails", 0))
        private set
    var wakeSens by mutableStateOf(sp.getFloat("wakeSens", 0.5f))
        private set
    /** The user wants the wake word on. Used to bring it back after Android kills it. */
    var wakeWanted by mutableStateOf(sp.getBoolean("wakeWanted", false))
        private set
    /** 24/7 mode: sticky service, wake lock, watchdog alarm. */
    var keepAlive by mutableStateOf(sp.getBoolean("keepAlive", true))
        private set
    var consentVersion by mutableStateOf(sp.getInt("consentVersion", 0))
        private set
    var updateCheck by mutableStateOf(sp.getBoolean("updateCheck", true))
        private set

    companion object {
        private const val SAVE_DEBOUNCE_MS = 150L
        @Volatile private var inst: Store? = null
        /** One shared instance per process, so the app and the wake-word service see the same data. */
        fun get(context: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(context.applicationContext).also { inst = it } }
    }

    private fun readArray(key: String): JSONArray =
        runCatching { JSONArray(sp.getString(key, "[]")) }.getOrDefault(JSONArray())

    // Saving is debounced and runs off the main thread: the lists are copied on the caller's thread (cheap),
    // then turned into JSON and written in the background, so a long history never stutters the UI.
    private val saveScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val pendingSaves = ConcurrentHashMap<String, Job>()
    @Volatile private var epoch = 0

    private fun scheduleSave(key: String, build: () -> String) {
        val savedEpoch = epoch
        pendingSaves.put(key, saveScope.launch {
            delay(SAVE_DEBOUNCE_MS)
            if (savedEpoch == epoch) runCatching { sp.edit().putString(key, build()).apply() }
        })?.cancel()
    }

    init {
        // Keys saved by older versions are plain text: encrypt them in place once.
        for (name in listOf("apiKey", "fishKey")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.isNotBlank() && !raw.startsWith(Secrets.PREFIX)) {
                Secrets.encrypt(raw)?.let { sp.edit().putString(name, it).apply() }
            }
        }
        // Each saved item is read on its own: one damaged record is skipped instead of crashing the app.
        val seen = HashSet<Long>()
        readArray("tasks").forEachObject { index, o ->
            var id = o.optLong("id", System.currentTimeMillis() + index)
            while (!seen.add(id)) id++
            tasks.add(TaskItem(id, o.optString("title", ""), o.optBoolean("done", false), o.optLong("created", id)))
        }
        readArray("messages").forEachObject { _, o ->
            messages.add(Msg(o.optBoolean("user", false), o.optString("text", ""), o.optLong("time", 0L)))
        }
        readArray("activity").forEachObject { _, o ->
            activity.add(ActivityItem(o.optString("text", ""), o.optLong("time", 0L)))
        }
        // A key that was stored but can no longer be decrypted (keystore reset, restored phone, ...).
        for (name in listOf("apiKey", "fishKey")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.startsWith(Secrets.PREFIX) && Secrets.decrypt(raw).isBlank()) {
                keyWarning = "A saved API key could not be read from this phone's secure storage. Paste it again in Settings."
            }
        }
    }

    /** Reads each record on its own: one damaged entry is skipped instead of crashing the app. */
    private inline fun JSONArray.forEachObject(action: (index: Int, JSONObject) -> Unit) {
        for (i in 0 until length()) runCatching { action(i, getJSONObject(i)) }
    }

    private fun <T> saveList(key: String, items: List<T>, toJson: (T) -> JSONObject) {
        val snapshot = items.toList()
        scheduleSave(key) { JSONArray().apply { snapshot.forEach { put(toJson(it)) } }.toString() }
    }

    private fun saveTasks() = saveList("tasks", tasks) {
        JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("created", it.created)
    }

    private fun saveMessages() = saveList("messages", messages) {
        JSONObject().put("user", it.fromUser).put("text", it.text).put("time", it.time)
    }

    private fun saveActivity() = saveList("activity", activity) {
        JSONObject().put("text", it.text).put("time", it.time)
    }

    fun log(text: String) {
        activity.add(0, ActivityItem(text, System.currentTimeMillis()))
        while (activity.size > 50) activity.removeAt(activity.lastIndex)
        saveActivity()
    }

    fun addTask(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        // Ids must be unique: two tasks added in the same millisecond would crash the list.
        val id = maxOf(now, (tasks.maxOfOrNull { it.id } ?: 0L) + 1)
        tasks.add(TaskItem(id, t, false, now))
        saveTasks()
        log("Task added: $t")
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        tasks[i] = tasks[i].copy(done = !tasks[i].done)
        saveTasks()
        log(if (tasks[i].done) "Task completed: ${tasks[i].title}" else "Task reopened: ${tasks[i].title}")
    }

    fun updateTask(id: Long, title: String) {
        val t = title.trim()
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0 || t.isEmpty()) return
        tasks[i] = tasks[i].copy(title = t)
        saveTasks()
        log("Task edited: $t")
    }

    fun deleteTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val title = tasks[i].title
        tasks.removeAt(i)
        saveTasks()
        log("Task deleted: $title")
    }

    fun clearCompleted() {
        tasks.removeAll { it.done }
        saveTasks()
        log("Completed tasks cleared")
    }

    fun addMessage(fromUser: Boolean, text: String) {
        messages.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (messages.size > 500) messages.removeAt(0)
        saveMessages()
    }

    fun clearMessages() {
        messages.clear()
        saveMessages()
        log("Conversation history cleared")
    }

    fun setUser(name: String) {
        userName = name.trim()
        sp.edit().putString("userName", userName).apply()
        log("Name saved")
    }

    fun setAi(key: String, m: String) {
        apiKey = key.trim()
        model = migrateModel(m.trim())
        val enc = Secrets.encrypt(apiKey)
        keyWarning = if (enc == null && apiKey.isNotBlank()) "Could not store the Groq key securely on this phone. It works now but will be forgotten when the app restarts." else null
        sp.edit().putString("apiKey", enc ?: "").putString("model", model).apply()
        log("AI settings saved")
    }

    fun setFish(key: String, voice: String, m: String) {
        fishKey = key.trim()
        fishVoice = voice.trim()
        fishModel = FishTts.migrate(m.trim())
        val enc = Secrets.encrypt(fishKey)
        if (enc == null && fishKey.isNotBlank()) keyWarning = "Could not store the Fish Audio key securely on this phone. It works now but will be forgotten when the app restarts."
        sp.edit().putString("fishKey", enc ?: "").putString("fishVoice", fishVoice).putString("fishModel", fishModel).apply()
        log("Fish Audio voice settings saved")
    }

    fun setWake(sens: Float) {
        wakeSens = sens.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("wakeSens", wakeSens).apply()
        log("Wake word settings saved")
    }

    fun setSpeak(on: Boolean) {
        speakReplies = on
        sp.edit().putBoolean("speak", on).apply()
    }

    fun markWakeWanted(on: Boolean) {
        wakeWanted = on
        sp.edit().putBoolean("wakeWanted", on).apply()
    }

    fun markKeepAlive(on: Boolean) {
        keepAlive = on
        sp.edit().putBoolean("keepAlive", on).apply()
    }

    fun markUpdateCheck(on: Boolean) {
        updateCheck = on
        sp.edit().putBoolean("updateCheck", on).apply()
    }

    fun acceptConsent(version: Int) {
        consentVersion = version
        sp.edit().putInt("consentVersion", version).putLong("consentAt", System.currentTimeMillis()).apply()
        log("Terms and privacy policy accepted (v$version)")
    }

    fun noteInitFail() {
        initFails++
        sp.edit().putInt("initFails", initFails).apply()
    }

    fun resetInitFails() {
        if (initFails == 0) return
        initFails = 0
        sp.edit().putInt("initFails", 0).apply()
    }

    fun clearAll() {
        // Drop any save still waiting in the queue so it cannot write old data back after the wipe.
        epoch++
        saveScope.coroutineContext[Job]?.cancelChildren()
        pendingSaves.clear()
        keyWarning = null; initFails = 0
        tasks.clear(); messages.clear(); activity.clear()
        userName = ""; apiKey = ""; fishKey = ""; fishVoice = ""; fishModel = FishTts.DEFAULT_MODEL; wakeSens = 0.5f; model = DEFAULT_MODEL; speakReplies = true
        wakeWanted = false; keepAlive = true; updateCheck = true; consentVersion = 0
        sp.edit().clear().apply()
    }
}
