// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

/** Six rungs, tried top to bottom. Gemini and Gemma ids use the Gemini key, the rest use the Groq key. */
val DEFAULT_LADDER = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "openai/gpt-oss-20b", "openai/gpt-oss-120b")
val DEFAULT_MODEL = DEFAULT_LADDER[0]
const val FAST_MODEL = "openai/gpt-oss-20b"
/** Models Groq has shut down. A saved id from this list is moved to DEFAULT_MODEL at start. */
val DEAD_MODELS = setOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "llama3-70b-8192", "llama3-8b-8192", "mixtral-8x7b-32768", "gemma2-9b-it")
fun migrateModel(m: String?): String = if (m.isNullOrBlank() || m in DEAD_MODELS) DEFAULT_MODEL else m

data class TaskItem(val id: Long, val title: String, val done: Boolean, val created: Long)
data class Msg(val fromUser: Boolean, val text: String, val time: Long)

/** Local persistence (SharedPreferences + JSON). Everything shown in the UI comes from here. */
class Store(context: Context) {
    private val appCtx: Context = context.applicationContext
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    val tasks = mutableStateListOf<TaskItem>()
    val messages = mutableStateListOf<Msg>()
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
        private set
    /** Keys and model saved by older versions (one key that was either a Groq key or the hub token). */
    private val legacyKey = Secrets.decrypt(sp.getString("apiKey", ""))
    var groqKey by mutableStateOf(Secrets.decrypt(sp.getString("groqKey", "")).ifBlank {
        if (legacyKey.startsWith("gsk_")) legacyKey else Secrets.decrypt(sp.getString("backupKey", ""))
    })
        private set
    var geminiKey by mutableStateOf(Secrets.decrypt(sp.getString("geminiKey", "")))
        private set
    var ladder by mutableStateOf(
        sp.getString("ladder", null)?.split("\n")?.map { it.trim() }?.filter { it.isNotEmpty() }?.takeIf { it.isNotEmpty() }
            ?: sp.getString("model", null)?.let(::migrateModel)?.takeIf { it !in DEFAULT_LADDER }?.let { listOf(it) + DEFAULT_LADDER }
            ?: DEFAULT_LADDER
    )
        private set
    /** The model asked for first (top rung). The ladder takes over when it fails. */
    val model: String get() = ladder.firstOrNull() ?: DEFAULT_MODEL
    /** What the AI calls pass as the key: the hub token. Direct keys (Groq, Gemini) are held by Ai. */
    val apiKey: String get() = hubBearer
    /** True when Jarvis can answer: through the hub, or directly with a Groq or Gemini key. */
    val aiReady: Boolean get() = hubBearer.isNotBlank() || groqKey.isNotBlank() || geminiKey.isNotBlank()
    var speakReplies by mutableStateOf(sp.getBoolean("speak", true))
        private set
    var fishKey by mutableStateOf(Secrets.decrypt(sp.getString("fishKey", "")))
        private set
    var fishVoice by mutableStateOf(sp.getString("fishVoice", "") ?: "")
        private set
    var fishModel by mutableStateOf(FishTts.migrate(sp.getString("fishModel", FishTts.DEFAULT_MODEL)))
        private set
    var elevenKey by mutableStateOf(Secrets.decrypt(sp.getString("elevenKey", "")))
        private set
    var elevenVoice by mutableStateOf(sp.getString("elevenVoice", "") ?: "")
        private set
    var elevenModel by mutableStateOf(ElevenTts.migrate(sp.getString("elevenModel", ElevenTts.DEFAULT_MODEL)))
        private set
    /** Shown in Settings when an API key could not be stored or read back from the Android Keystore. */
    var keyWarning by mutableStateOf<String?>(null)
        private set
    /** How many wake-word start-ups failed in a row (the watchdog stops retrying after 3). */
    var initFails by mutableStateOf(sp.getInt("initFails", 0))
        private set
    var wakeSens by mutableStateOf(sp.getFloat("wakeSens", 0.5f))
        private set
    /** The user wants the wake word on. Used to bring it back after Android kills it. */
    var wakeWanted by mutableStateOf(sp.getBoolean("wakeWanted", false))
        private set
    /** 24/7 mode: sticky service, wake lock, watchdog alarm. */
    var keepAlive by mutableStateOf(sp.getBoolean("keepAlive", true))
        private set
    /** Phone control tools run without a tap on Allow (chat and voice). Risky ones (uninstall, wipe data, reboot, shell) still ask in chat. */
    var controlFree by mutableStateOf(sp.getBoolean("controlFree", false).also { Control.free = it })
        private set
    /** Lite visuals: no depth shadows, tilt parallax or press animation (saves battery). */
    var liteVisuals by mutableStateOf(sp.getBoolean("liteVisuals", false).also { Fx.lite = it })
        private set
    /** When Shizuku starts, quietly re-grant permissions and switch accessibility back on. Off by default: the person opts in. */
    var controlAuto by mutableStateOf(sp.getBoolean("controlAuto", false))
        private set
    /** App version for which "grant everything" last ran automatically. */
    var controlGrantedVer by mutableStateOf(sp.getInt("controlGrantedVer", 0))
        private set
    var consentVersion by mutableStateOf(sp.getInt("consentVersion", 0))
        private set
    var updateCheck by mutableStateOf(sp.getBoolean("updateCheck", true))
        private set

    // ---- Memory, personality, briefing (all stored on this phone only) ----
    val memories = mutableStateListOf<String>().also { l ->
        try { val a = JSONArray(sp.getString("memories", "[]")); for (i in 0 until a.length()) l.add(a.getString(i)) } catch (_: Exception) {}
    }
    var instructions by mutableStateOf(sp.getString("instructions", "") ?: "")
    var personality by mutableStateOf(sp.getString("personality", "classic") ?: "classic")
    var city by mutableStateOf(sp.getString("city", "") ?: "")
    var hubUrl by mutableStateOf(
        sp.getString("hubUrl", BuildConfig.DEFAULT_HUB_URL) ?: ""
    )
    var hubToken by mutableStateOf(Secrets.decrypt(sp.getString("hubToken", "")).ifBlank { if (legacyKey.isNotBlank() && !legacyKey.startsWith("gsk_")) legacyKey else "" })
    var alertsOn by mutableStateOf(sp.getBoolean("alertsOn", true))
    var battWarn by mutableStateOf(sp.getBoolean("battWarn", true))
    /** The token the hub expects. */
    val hubBearer: String get() = hubToken
    init {
        Hub.chatUrl = hubUrl.trim().trimEnd('/') + "/v1/chat/completions"
        Ai.groqKey = groqKey; Ai.geminiKey = geminiKey; ModelLadder.ladder = ladder
        // Move keys from the old single-key layout into their own fields, once.
        if (!sp.contains("groqKey") && groqKey.isNotBlank()) sp.edit().putString("groqKey", Secrets.encrypt(groqKey) ?: "").apply()
        if (legacyKey.isNotBlank() && !legacyKey.startsWith("gsk_") && Secrets.decrypt(sp.getString("hubToken", "")).isBlank()) sp.edit().putString("hubToken", Secrets.encrypt(hubToken) ?: "").apply()
    }
    var briefOn by mutableStateOf(sp.getBoolean("briefOn", false))
    var briefHour by mutableStateOf(sp.getInt("briefHour", 7))
    var briefMin by mutableStateOf(sp.getInt("briefMin", 30))
    val watches = mutableStateListOf<String>().also { l ->
        try { val a = JSONArray(sp.getString("watches", "[]")); for (i in 0 until a.length()) l.add(a.getString(i)) } catch (_: Exception) {}
    }

    var overlayOn by mutableStateOf(sp.getBoolean("overlayOn", false))
    private var appLockState by mutableStateOf(sp.getBoolean("appLock", false))
    val appLock: Boolean get() = appLockState

    fun setOverlay(on: Boolean) { overlayOn = on; sp.edit().putBoolean("overlayOn", on).apply() }
    fun setAppLock(on: Boolean) { appLockState = on; sp.edit().putBoolean("appLock", on).apply() }

    private fun saveList(key: String, l: List<String>) { sp.edit().putString(key, JSONArray(l).toString()).apply() }

    fun addMemory(fact: String): Boolean {
        val f = fact.trim().trimEnd('.').take(200)
        if (f.length < 3 || memories.any { it.equals(f, ignoreCase = true) }) return false
        memories.add(f)
        while (memories.size > 60) memories.removeAt(0)
        saveList("memories", memories)
        return true
    }

    fun forgetMemory(match: String): Int {
        val m = match.trim().lowercase()
        if (m.length < 2) return 0
        val gone = memories.filter { it.lowercase().contains(m) }
        memories.removeAll(gone.toSet())
        if (gone.isNotEmpty()) saveList("memories", memories)
        return gone.size
    }

    fun clearMemories() { memories.clear(); saveList("memories", memories) }

    fun setMind(instr: String, pers: String, cityName: String) {
        instructions = instr.trim().take(600)
        personality = pers
        city = cityName.trim().take(80)
        sp.edit().putString("instructions", instructions).putString("personality", personality).putString("city", city).apply()
    }

    fun setHub(url: String, token: String, alerts: Boolean, batt: Boolean) {
        hubUrl = url.trim(); hubToken = token.trim(); alertsOn = alerts; battWarn = batt
        Hub.chatUrl = hubUrl.trimEnd('/') + "/v1/chat/completions"
        sp.edit().putString("hubUrl", hubUrl).putString("hubToken", Secrets.encrypt(hubToken) ?: "")
            .putBoolean("alertsOn", alerts).putBoolean("battWarn", batt).apply()
    }

    fun setBrief(on: Boolean, hour: Int, min: Int) {
        briefOn = on; briefHour = hour.coerceIn(0, 23); briefMin = min.coerceIn(0, 59)
        sp.edit().putBoolean("briefOn", on).putInt("briefHour", briefHour).putInt("briefMin", briefMin).apply()
    }

    fun addWatch(topic: String): Boolean {
        val t = topic.trim().take(80)
        if (t.length < 2 || watches.size >= 5 || watches.any { it.equals(t, ignoreCase = true) }) return false
        watches.add(t); saveList("watches", watches); return true
    }

    fun removeWatch(match: String): Int {
        val m = match.trim().lowercase()
        if (m.isEmpty()) return 0
        val gone = watches.filter { it.lowercase().contains(m) }
        watches.removeAll(gone.toSet())
        if (gone.isNotEmpty()) saveList("watches", watches)
        return gone.size
    }

    companion object {
        @Volatile private var inst: Store? = null
        /** One shared instance per process, so the app and the wake-word service see the same data. */
        fun get(context: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(context.applicationContext).also { inst = it } }
    }

    private fun arr(key: String): JSONArray =
        try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    // Saving happens on a background thread: the lists are copied on the main thread (cheap),
    // then turned into JSON and written there, so a long history never stutters the UI.
    private val saveThread = HandlerThread("store-save").apply { start() }
    private val saver = Handler(saveThread.looper)
    @Volatile private var epoch = 0

    private fun scheduleSave(token: String, build: () -> String) {
        val ep = epoch
        saver.removeCallbacksAndMessages(token)
        saver.postAtTime({
            if (ep != epoch) return@postAtTime
            runCatching { sp.edit().putString(token, build()).apply() }
        }, token, SystemClock.uptimeMillis() + 150)
    }

    init {
        // Keys saved by older versions are plain text: encrypt them in place once.
        for (name in listOf("apiKey", "groqKey", "geminiKey", "fishKey", "elevenKey", "backupKey", "hubToken")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.isNotBlank() && !raw.startsWith(Secrets.PREFIX)) {
                Secrets.encrypt(raw)?.let { sp.edit().putString(name, it).apply() }
            }
        }
        // Each saved item is read on its own: one damaged record is skipped instead of crashing the app.
        val seen = HashSet<Long>()
        val t = arr("tasks")
        for (i in 0 until t.length()) {
            try {
                val o = t.getJSONObject(i)
                var id = o.optLong("id", System.currentTimeMillis() + i)
                while (!seen.add(id)) id++
                tasks.add(TaskItem(id, o.optString("title", ""), o.optBoolean("done", false), o.optLong("created", id)))
            } catch (_: Throwable) {}
        }
        val m = arr("messages")
        for (i in 0 until m.length()) {
            try {
                val o = m.getJSONObject(i)
                messages.add(Msg(o.optBoolean("user", false), o.optString("text", ""), o.optLong("time", 0L)))
            } catch (_: Throwable) {}
        }
        // The old "recent activity" log was removed: delete what earlier versions saved.
        if (sp.contains("activity")) sp.edit().remove("activity").apply()
        // A key that was stored but can no longer be decrypted (keystore reset, restored phone, ...).
        for (name in listOf("apiKey", "groqKey", "geminiKey", "fishKey", "elevenKey", "backupKey", "hubToken")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.startsWith(Secrets.PREFIX) && Secrets.decrypt(raw).isBlank()) {
                keyWarning = "A saved API key could not be read from this phone's secure storage. Paste it again in Settings."
            }
        }
    }

    private fun saveTasks() {
        val snap = tasks.toList()
        scheduleSave("tasks") {
            val a = JSONArray()
            snap.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("created", it.created)) }
            a.toString()
        }
    }

    private fun saveMessages() {
        val snap = messages.toList()
        scheduleSave("messages") {
            val a = JSONArray()
            snap.forEach { a.put(JSONObject().put("user", it.fromUser).put("text", it.text).put("time", it.time)) }
            a.toString()
        }
    }

    fun addTask(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        // Ids must be unique: two tasks added in the same millisecond would crash the list.
        val id = maxOf(now, (tasks.maxOfOrNull { it.id } ?: 0L) + 1)
        tasks.add(TaskItem(id, t, false, now))
        saveTasks()
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        tasks[i] = tasks[i].copy(done = !tasks[i].done)
        saveTasks()
    }

    fun updateTask(id: Long, title: String) {
        val t = title.trim()
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0 || t.isEmpty()) return
        tasks[i] = tasks[i].copy(title = t)
        saveTasks()
    }

    fun deleteTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val title = tasks[i].title
        tasks.removeAt(i)
        saveTasks()
    }

    fun clearCompleted() {
        tasks.removeAll { it.done }
        saveTasks()
    }

    fun addMessage(fromUser: Boolean, text: String) {
        messages.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (messages.size > 500) messages.removeAt(0)
        saveMessages()
    }

    fun clearMessages() {
        messages.clear()
        saveMessages()
    }

    fun setUser(name: String) {
        userName = name.trim()
        sp.edit().putString("userName", userName).apply()
    }

    /** Saves both provider keys and the ladder. Blank rungs are dropped; an empty list restores the default six. */
    fun setAi(groq: String, gemini: String, rungs: List<String>) {
        groqKey = groq.trim(); geminiKey = gemini.trim()
        ladder = rungs.map { it.trim() }.filter { it.isNotEmpty() }.distinct().ifEmpty { DEFAULT_LADDER }
        Ai.groqKey = groqKey; Ai.geminiKey = geminiKey; ModelLadder.ladder = ladder
        val g = Secrets.encrypt(groqKey); val m = Secrets.encrypt(geminiKey)
        keyWarning = if ((g == null && groqKey.isNotBlank()) || (m == null && geminiKey.isNotBlank())) "Could not store a key securely on this phone. It works now but will be forgotten when the app restarts." else null
        sp.edit().putString("groqKey", g ?: "").putString("geminiKey", m ?: "").putString("ladder", ladder.joinToString("
")).remove("model").apply()
    }

    fun setFish(key: String, voice: String, m: String) {
        fishKey = key.trim()
        fishVoice = voice.trim()
        fishModel = FishTts.migrate(m.trim())
        val enc = Secrets.encrypt(fishKey)
        if (enc == null && fishKey.isNotBlank()) keyWarning = "Could not store the Fish Audio key securely on this phone. It works now but will be forgotten when the app restarts."
        sp.edit().putString("fishKey", enc ?: "").putString("fishVoice", fishVoice).putString("fishModel", fishModel).apply()
    }

    fun setEleven(key: String, voice: String, m: String) {
        elevenKey = key.trim()
        elevenVoice = voice.trim()
        elevenModel = ElevenTts.migrate(m.trim())
        val enc = Secrets.encrypt(elevenKey)
        if (enc == null && elevenKey.isNotBlank()) keyWarning = "Could not store the ElevenLabs key securely on this phone. It works now but will be forgotten when the app restarts."
        sp.edit().putString("elevenKey", enc ?: "").putString("elevenVoice", elevenVoice).putString("elevenModel", elevenModel).apply()
    }

    fun setWake(sens: Float) {
        wakeSens = sens.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("wakeSens", wakeSens).apply()
    }

    fun setSpeak(on: Boolean) {
        speakReplies = on
        sp.edit().putBoolean("speak", on).apply()
    }

    fun markWakeWanted(on: Boolean) {
        wakeWanted = on
        sp.edit().putBoolean("wakeWanted", on).apply()
    }

    fun updateControlFree(on: Boolean) {
        controlFree = on; Control.free = on
        sp.edit().putBoolean("controlFree", on).apply()
    }

    fun updateControlAuto(on: Boolean) {
        controlAuto = on
        sp.edit().putBoolean("controlAuto", on).apply()
    }

    fun markControlGranted(ver: Int) {
        controlGrantedVer = ver
        sp.edit().putInt("controlGrantedVer", ver).apply()
    }

    fun markLite(on: Boolean) {
        liteVisuals = on; Fx.lite = on
        sp.edit().putBoolean("liteVisuals", on).apply()
    }

    fun markKeepAlive(on: Boolean) {
        keepAlive = on
        sp.edit().putBoolean("keepAlive", on).apply()
    }

    fun markUpdateCheck(on: Boolean) {
        updateCheck = on
        sp.edit().putBoolean("updateCheck", on).apply()
    }

    fun acceptConsent(version: Int) {
        consentVersion = version
        sp.edit().putInt("consentVersion", version).putLong("consentAt", System.currentTimeMillis()).apply()
    }

    fun noteInitFail() {
        initFails++
        sp.edit().putInt("initFails", initFails).apply()
    }

    fun resetInitFails() {
        if (initFails == 0) return
        initFails = 0
        sp.edit().putInt("initFails", 0).apply()
    }

    fun clearAll() {
        // Drop any save still waiting in the queue so it cannot write old data back after the wipe.
        epoch++
        saver.removeCallbacksAndMessages(null)
        keyWarning = null; initFails = 0
        tasks.clear(); messages.clear()
        userName = ""; groqKey = ""; geminiKey = ""; ladder = DEFAULT_LADDER; Ai.groqKey = ""; Ai.geminiKey = ""; ModelLadder.ladder = DEFAULT_LADDER; hubToken = ""; fishKey = ""; fishVoice = ""; fishModel = FishTts.DEFAULT_MODEL; elevenKey = ""; elevenVoice = ""; elevenModel = ElevenTts.DEFAULT_MODEL; wakeSens = 0.5f; speakReplies = true
        wakeWanted = false; keepAlive = true; updateCheck = true; consentVersion = 0; controlFree = false; Control.free = false; controlAuto = false; controlGrantedVer = 0
        memories.clear(); watches.clear(); instructions = ""; personality = "classic"; city = ""; briefOn = false; briefHour = 7; briefMin = 30; overlayOn = false; appLockState = false
        sp.edit().clear().apply()
    }
}
