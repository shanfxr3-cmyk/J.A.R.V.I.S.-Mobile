// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

const val DEFAULT_MODEL = "llama-3.3-70b-versatile"

data class TaskItem(val id: Long, val title: String, val done: Boolean, val created: Long)
data class Msg(val fromUser: Boolean, val text: String, val time: Long)
data class ActivityItem(val text: String, val time: Long)

/** Local persistence (SharedPreferences + JSON). Everything shown in the UI comes from here. */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    val tasks = mutableStateListOf<TaskItem>()
    val messages = mutableStateListOf<Msg>()
    val activity = mutableStateListOf<ActivityItem>()
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
        private set
    var apiKey by mutableStateOf(Secrets.decrypt(sp.getString("apiKey", "")))
        private set
    var model by mutableStateOf(sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL)
        private set
    var speakReplies by mutableStateOf(sp.getBoolean("speak", true))
        private set
    var fishKey by mutableStateOf(Secrets.decrypt(sp.getString("fishKey", "")))
        private set
    var fishVoice by mutableStateOf(sp.getString("fishVoice", "") ?: "")
        private set
    var fishModel by mutableStateOf(sp.getString("fishModel", FishTts.DEFAULT_MODEL) ?: FishTts.DEFAULT_MODEL)
        private set
    var wakeSens by mutableStateOf(sp.getFloat("wakeSens", 0.7f))
        private set
    /** The user wants the wake word on. Used to bring it back after Android kills it. */
    var wakeWanted by mutableStateOf(sp.getBoolean("wakeWanted", false))
        private set
    /** 24/7 mode: sticky service, wake lock, watchdog alarm. */
    var keepAlive by mutableStateOf(sp.getBoolean("keepAlive", true))
        private set
    var consentVersion by mutableStateOf(sp.getInt("consentVersion", 0))
        private set
    var updateCheck by mutableStateOf(sp.getBoolean("updateCheck", true))
        private set

    companion object {
        @Volatile private var inst: Store? = null
        /** One shared instance per process, so the app and the wake-word service see the same data. */
        fun get(context: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(context.applicationContext).also { inst = it } }
    }

    private fun arr(key: String): JSONArray =
        try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    init {
        // Keys saved by older versions are plain text: encrypt them in place once.
        for (name in listOf("apiKey", "fishKey")) {
            val raw = sp.getString(name, "") ?: ""
            if (raw.isNotBlank() && !raw.startsWith(Secrets.PREFIX)) {
                Secrets.encrypt(raw)?.let { sp.edit().putString(name, it).apply() }
            }
        }
        val t = arr("tasks")
        for (i in 0 until t.length()) {
            val o = t.getJSONObject(i)
            tasks.add(TaskItem(o.getLong("id"), o.getString("title"), o.getBoolean("done"), o.getLong("created")))
        }
        val m = arr("messages")
        for (i in 0 until m.length()) {
            val o = m.getJSONObject(i)
            messages.add(Msg(o.getBoolean("user"), o.getString("text"), o.getLong("time")))
        }
        val a = arr("activity")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            activity.add(ActivityItem(o.getString("text"), o.getLong("time")))
        }
    }

    private fun saveTasks() {
        val a = JSONArray()
        tasks.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("created", it.created))
        }
        sp.edit().putString("tasks", a.toString()).apply()
    }

    private fun saveMessages() {
        val a = JSONArray()
        messages.forEach {
            a.put(JSONObject().put("user", it.fromUser).put("text", it.text).put("time", it.time))
        }
        sp.edit().putString("messages", a.toString()).apply()
    }

    private fun saveActivity() {
        val a = JSONArray()
        activity.forEach { a.put(JSONObject().put("text", it.text).put("time", it.time)) }
        sp.edit().putString("activity", a.toString()).apply()
    }

    fun log(text: String) {
        activity.add(0, ActivityItem(text, System.currentTimeMillis()))
        while (activity.size > 50) activity.removeAt(activity.lastIndex)
        saveActivity()
    }

    fun addTask(title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        tasks.add(TaskItem(now, t, false, now))
        saveTasks()
        log("Task added: $t")
    }

    fun toggleTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        tasks[i] = tasks[i].copy(done = !tasks[i].done)
        saveTasks()
        log(if (tasks[i].done) "Task completed: ${tasks[i].title}" else "Task reopened: ${tasks[i].title}")
    }

    fun updateTask(id: Long, title: String) {
        val t = title.trim()
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0 || t.isEmpty()) return
        tasks[i] = tasks[i].copy(title = t)
        saveTasks()
        log("Task edited: $t")
    }

    fun deleteTask(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val title = tasks[i].title
        tasks.removeAt(i)
        saveTasks()
        log("Task deleted: $title")
    }

    fun clearCompleted() {
        tasks.removeAll { it.done }
        saveTasks()
        log("Completed tasks cleared")
    }

    fun addMessage(fromUser: Boolean, text: String) {
        messages.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (messages.size > 500) messages.removeAt(0)
        saveMessages()
    }

    fun clearMessages() {
        messages.clear()
        saveMessages()
        log("Conversation history cleared")
    }

    fun setUser(name: String) {
        userName = name.trim()
        sp.edit().putString("userName", userName).apply()
        log("Name saved")
    }

    fun setAi(key: String, m: String) {
        apiKey = key.trim()
        model = m.trim().ifEmpty { DEFAULT_MODEL }
        sp.edit().putString("apiKey", Secrets.encrypt(apiKey) ?: "").putString("model", model).apply()
        log("AI settings saved")
    }

    fun setFish(key: String, voice: String, m: String) {
        fishKey = key.trim()
        fishVoice = voice.trim()
        fishModel = m.trim().ifEmpty { FishTts.DEFAULT_MODEL }
        sp.edit().putString("fishKey", Secrets.encrypt(fishKey) ?: "").putString("fishVoice", fishVoice).putString("fishModel", fishModel).apply()
        log("Fish Audio voice settings saved")
    }

    fun setWake(sens: Float) {
        wakeSens = sens.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("wakeSens", wakeSens).apply()
        log("Wake word settings saved")
    }

    fun setSpeak(on: Boolean) {
        speakReplies = on
        sp.edit().putBoolean("speak", on).apply()
    }

    fun markWakeWanted(on: Boolean) {
        wakeWanted = on
        sp.edit().putBoolean("wakeWanted", on).apply()
    }

    fun markKeepAlive(on: Boolean) {
        keepAlive = on
        sp.edit().putBoolean("keepAlive", on).apply()
    }

    fun markUpdateCheck(on: Boolean) {
        updateCheck = on
        sp.edit().putBoolean("updateCheck", on).apply()
    }

    fun acceptConsent(version: Int) {
        consentVersion = version
        sp.edit().putInt("consentVersion", version).putLong("consentAt", System.currentTimeMillis()).apply()
        log("Terms and privacy policy accepted (v$version)")
    }

    fun clearAll() {
        tasks.clear(); messages.clear(); activity.clear()
        userName = ""; apiKey = ""; fishKey = ""; fishVoice = ""; fishModel = FishTts.DEFAULT_MODEL; wakeSens = 0.7f; model = DEFAULT_MODEL; speakReplies = true
        wakeWanted = false; keepAlive = true; updateCheck = true; consentVersion = 0
        sp.edit().clear().apply()
    }
}
