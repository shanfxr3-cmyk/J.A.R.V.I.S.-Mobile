// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun greeting(): String {
    val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return if (hr < 5) "Still up" else if (hr < 12) "Good morning" else if (hr < 18) "Good afternoon" else "Good evening"
}

@Composable
private fun BrandBar(store: Store) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(46.dp).background(Brush.linearGradient(listOf(Cyan.copy(alpha = 0.35f), Cyan.copy(alpha = 0.10f))), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("J", color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Jarvis", color = Ink, fontSize = 22.sp, fontFamily = TitleFont, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            Text(
                greeting().let { g -> if (store.userName.isBlank()) g else "$g, ${store.userName}" },
                color = Dim, fontSize = 13.sp, fontFamily = BodyFont, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        val hasKey = store.apiKey.isNotBlank()
        StatusChip(if (hasKey) "API key set" else "No API key", if (hasKey) Green else Amber)
    }
}

/** Orb in a rounded card. The waveform stays composed because its frame loop is what feeds the orb's speech level. */
@Composable
private fun CoreCard(nav: (Screen) -> Unit) {
    val mode by remember { derivedStateOf { orbMode() } }
    HudCard(Modifier.fillMaxWidth(), pad = 0.dp) {
        Box(Modifier.fillMaxWidth().height(290.dp).clip(CardShape)) {
            SoftOrb(Modifier.fillMaxSize()) { nav(Screen.Chat) }
            Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(orbLabel(mode), color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                VoiceWave(Modifier.width(180.dp).height(24.dp))
            }
        }
    }
}

@Composable
private fun ListenCard() {
    val ws = WakeService.state
    val sc = if (ws == "OFF") Dim else if (ws == "ERROR" || ws == "STARTING" || ws == "DOWNLOADING") Amber else Green
    HudCard(Modifier.fillMaxWidth(), pad = 16.dp, accent = sc) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Led(sc, pulse = ws != "OFF", size = 10.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when (ws) {
                        "WAITING" -> "Listening for \"Jarvis\""
                        "LISTENING" -> "Listening"
                        "THINKING" -> "Thinking"
                        "SPEAKING" -> "Speaking"
                        "STARTING" -> "Wake word is starting"
                        "DOWNLOADING" -> "Wake word is downloading"
                        "PAUSED" -> "Paused while chat uses the mic"
                        "ERROR" -> "Wake word error"
                        else -> "Wake word is off"
                    },
                    color = Ink, fontSize = 15.sp, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (ws == "OFF") "Turn it on in Settings" else WakeService.error ?: "Say \"Hey Jarvis\", then your request",
                    color = Dim, fontSize = 13.sp, fontFamily = BodyFont, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ConversationCard(store: Store, nav: (Screen) -> Unit) {
    HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Chat) }) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudIcon(Ic.Chat, size = 20.dp)
                Spacer(Modifier.width(10.dp))
                Text("Conversation", color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1)
                Text("${store.messages.size}", color = Dim, fontSize = 13.sp, fontFamily = BodyFont)
                Spacer(Modifier.width(8.dp))
                HudIcon(Ic.Chevron, tint = Dim, size = 16.dp)
            }
            Spacer(Modifier.height(10.dp))
            val last = store.messages.takeLast(2)
            if (last.isEmpty()) {
                Text("No conversation yet. Tap to open chat.", color = Dim, fontSize = 14.sp, fontFamily = BodyFont)
            } else {
                last.forEach {
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(if (it.fromUser) "You" else "Jarvis", Modifier.width(48.dp), color = if (it.fromUser) Dim else Cyan, fontSize = 13.sp, fontFamily = BodyFont, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(it.text, Modifier.weight(1f), fontSize = 14.sp, fontFamily = BodyFont, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun Shortcut(ic: Ic, label: String, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier.heightIn(min = 84.dp), onClick, pad = 8.dp) {
        Column(Modifier.fillMaxWidth().align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(40.dp).background(Cyan.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                HudIcon(ic, size = 22.dp)
            }
            Text(label, fontFamily = BodyFont, fontWeight = FontWeight.Medium, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1, color = Ink)
        }
    }
}

/** HomeScreen reads no fast-changing state: telemetry, speech level and wake state are each read inside their own leaf. */
@Composable
fun HomeScreen(store: Store, nav: (Screen) -> Unit) {
    val tel = rememberSysTelemetry()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp)) {
        UpdateBanner(nav)
        BrandBar(store)
        Spacer(Modifier.height(16.dp))
        CoreCard(nav)
        Spacer(Modifier.height(12.dp))
        ListenCard()
        Spacer(Modifier.height(20.dp))

        Text("Quick actions", color = Dim, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Ic.Tasks, "Tasks", Modifier.weight(1f)) { nav(Screen.Tasks) }
            Shortcut(Ic.Chat, "Chat", Modifier.weight(1f)) { nav(Screen.Chat) }
            Shortcut(Ic.Memory, "Memory", Modifier.weight(1f)) { nav(Screen.Memory) }
            Shortcut(Ic.Tools, "Tools", Modifier.weight(1f)) { nav(Screen.Tools) }
        }
        Spacer(Modifier.height(20.dp))

        ConversationCard(store, nav)
        Spacer(Modifier.height(20.dp))

        Text("Device status", color = Dim, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
        Spacer(Modifier.height(10.dp))
        SystemConsole(store, tel)
        Spacer(Modifier.height(12.dp))
    }
}
