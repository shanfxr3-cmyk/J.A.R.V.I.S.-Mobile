// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.aiassistant.holo.HoloCore

private fun voiceTag(): String {
    val ws = WakeService.state
    return when {
        SpeechLevel.speaking || ws == "SPEAKING" -> "SPK"
        SpeechLevel.listening || ws == "LISTENING" -> "LSN"
        ws == "THINKING" -> "THK"
        else -> "IDL"
    }
}

@Composable
private fun BrandBar(store: Store) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        val chrome = androidx.compose.runtime.remember { Modifier.hudPanel(Cyan, cut = 5.dp, bracket = 6.dp) }
        Box(Modifier.size(44.dp).then(chrome), contentAlignment = Alignment.Center) {
            Text("AI", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 17.sp, fontFamily = TitleFont, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1, softWrap = false)
            Text(
                if (store.userName.isBlank()) "PERSONAL AI" else "PERSONAL AI / ${store.userName.uppercase()}",
                color = Dim, fontSize = 10.sp, fontFamily = MonoFont, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        val hasKey = store.apiKey.isNotBlank()
        StatusChip(if (hasKey) "KEY SET" else "NO KEY", if (hasKey) Green else Amber)
    }
}

@Composable
private fun CoreCard(tel: SysTelemetry) {
    HudCard(Modifier.fillMaxWidth(), pad = 8.dp) {
        Box(Modifier.fillMaxWidth().height(230.dp)) {
            HoloCore(Modifier.fillMaxSize(), tel)
            Row(Modifier.align(Alignment.TopStart).padding(start = 4.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                MonoText("AMP", color = Dim, size = 9.sp); Spacer(Modifier.width(4.dp))
                LiveMono({ Mono.pct(SpeechLevel.pct) }, 3, color = Cyan, size = 10.sp, bold = true)
            }
            Row(Modifier.align(Alignment.TopEnd).padding(end = 4.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                MonoText("VOX", color = Dim, size = 9.sp); Spacer(Modifier.width(4.dp))
                LiveMono({ voiceTag() }, 3, color = Amber, size = 10.sp, bold = true)
            }
            VoiceWave(Modifier.align(Alignment.BottomCenter).fillMaxWidth(0.8f).height(30.dp))
        }
    }
}

@Composable
private fun ListenCard() {
    val ws = WakeService.state
    val sc = if (ws == "OFF") Dim else if (ws == "ERROR" || ws == "STARTING" || ws == "DOWNLOADING") Amber else Green
    HudCard(Modifier.fillMaxWidth(), pad = 10.dp, accent = sc) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Led(sc, pulse = ws != "OFF", size = 9.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when (ws) {
                        "WAITING" -> "LISTENING FOR \"JARVIS\""
                        "LISTENING" -> "LISTENING"
                        "THINKING" -> "THINKING"
                        "SPEAKING" -> "SPEAKING"
                        "STARTING" -> "WAKE WORD: STARTING"
                        "DOWNLOADING" -> "WAKE WORD: DOWNLOADING"
                        "PAUSED" -> "PAUSED: CHAT HAS THE MIC"
                        "ERROR" -> "WAKE WORD: ERROR"
                        else -> "WAKE WORD: OFF"
                    },
                    color = sc, fontSize = 11.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (ws == "OFF") "Turn it on in Settings" else WakeService.error ?: "Say \"Hey Jarvis\", then your request",
                    color = Dim, fontSize = 10.sp, fontFamily = MonoFont, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ConversationCard(store: Store, nav: (Screen) -> Unit) {
    HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Chat) }) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudIcon(Ic.Chat, size = 16.dp)
                Spacer(Modifier.width(8.dp))
                Text("CONVERSATION", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f), maxLines = 1)
                MonoText(Mono.pad(store.messages.size, 4), color = Dim, size = 10.sp, chars = 4)
                Spacer(Modifier.width(8.dp))
                HudIcon(Ic.Chevron, tint = Dim, size = 14.dp)
            }
            Spacer(Modifier.height(6.dp))
            val last = store.messages.takeLast(2)
            if (last.isEmpty()) {
                Text("No conversation yet. Tap to open chat.", color = Dim, fontSize = 11.sp, fontFamily = MonoFont)
            } else {
                last.forEach {
                    Row(Modifier.padding(vertical = 2.dp)) {
                        MonoText(if (it.fromUser) "USR" else "JRV", color = if (it.fromUser) Dim else Cyan, size = 10.sp, bold = true, chars = 3)
                        Spacer(Modifier.width(8.dp))
                        Text(it.text, Modifier.weight(1f), fontSize = 11.sp, fontFamily = MonoFont, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun Shortcut(ic: Ic, label: String, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier.heightIn(min = 72.dp), onClick, pad = 10.dp) {
        Column(Modifier.fillMaxWidth().align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HudIcon(ic, size = 24.dp)
            Text(label, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.5.sp, textAlign = TextAlign.Center, maxLines = 1, color = Color.White)
        }
    }
}

/**
 * Multi-column tactical console. HomeScreen itself reads no fast-changing state: telemetry, speech amplitude and the wake
 * state are each read inside their own leaf composable, so a change recomposes only that readout.
 */
@Composable
fun HomeScreen(store: Store, nav: (Screen) -> Unit) {
    val tel = rememberSysTelemetry()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        UpdateBanner(nav)
        BrandBar(store)
        Spacer(Modifier.height(10.dp))
        CoreCard(tel)
        Spacer(Modifier.height(8.dp))
        ListenCard()
        Spacer(Modifier.height(12.dp))

        SectionTitle("SYSTEM CONSOLE")
        Spacer(Modifier.height(8.dp))
        SystemConsole(store, tel)
        Spacer(Modifier.height(12.dp))

        ConversationCard(store, nav)
        Spacer(Modifier.height(12.dp))

        SectionTitle("SHORTCUTS")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Shortcut(Ic.Tasks, "TASKS", Modifier.weight(1f)) { nav(Screen.Tasks) }
            Shortcut(Ic.Chat, "CHAT", Modifier.weight(1f)) { nav(Screen.Chat) }
            Shortcut(Ic.Memory, "MEMORY", Modifier.weight(1f)) { nav(Screen.Memory) }
            Shortcut(Ic.Tools, "TOOLS", Modifier.weight(1f)) { nav(Screen.Tools) }
        }
        Spacer(Modifier.height(8.dp))
    }
}
