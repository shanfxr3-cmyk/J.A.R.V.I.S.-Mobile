package com.jarvis.aiassistant

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun AiSphere(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "sphere")
    val angle by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2.7f
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.25f), Color.Transparent), c, r * 1.4f),
            r * 1.4f, c
        )
        drawCircle(Cyan.copy(alpha = 0.85f), r, c, style = Stroke(2f))
        for (k in 0 until 8) {
            val a = Math.toRadians((angle + k * 22.5).toDouble())
            val w = abs((r * cos(a)).toFloat())
            drawOval(Cyan.copy(alpha = 0.45f), Offset(c.x - w, c.y - r), Size(2 * w, 2 * r), style = Stroke(1.2f))
        }
        for (lat in -2..2) {
            val dy = lat * r / 3f
            val half = sqrt(r * r - dy * dy)
            drawOval(
                Cyan.copy(alpha = 0.35f),
                Offset(c.x - half, c.y + dy - half * 0.18f),
                Size(2 * half, half * 0.36f),
                style = Stroke(1.2f)
            )
        }
        rotate(-20f, c) {
            drawOval(
                Cyan.copy(alpha = 0.6f),
                Offset(c.x - r * 1.5f, c.y - r * 0.45f),
                Size(r * 3f, r * 0.9f),
                style = Stroke(1.5f)
            )
            val oa = Math.toRadians(angle * 2.0)
            drawCircle(
                Color.White, 5f,
                Offset(c.x + (r * 1.5f * cos(oa)).toFloat(), c.y + (r * 0.45f * sin(oa)).toFloat())
            )
        }
    }
}

@Composable
private fun SysCard(label: String, value: String, modifier: Modifier) {
    HudCard(modifier) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Dim, fontSize = 11.sp, fontFamily = Stark)
            Text(value, color = Green, fontSize = 18.sp, fontFamily = Stark, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun Shortcut(label: String, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier.heightIn(min = 64.dp), onClick) {
        Text(label, Modifier.align(Alignment.Center).fillMaxWidth(), fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun HomeScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var battery by remember { mutableIntStateOf(batteryPercent(ctx)) }
    var ram by remember { mutableStateOf(ramInfo(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            battery = batteryPercent(ctx)
            ram = ramInfo(ctx)
            delay(5000)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        // Header
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).border(2.dp, Cyan, CircleShape).background(Panel, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("AI", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 26.sp, fontFamily = IronFont, letterSpacing = 1.sp, maxLines = 1, softWrap = false)
                Text(
                    if (store.userName.isBlank()) "PERSONAL AI" else "PERSONAL AI - ${store.userName.uppercase()}",
                    color = Dim, fontSize = 11.sp
                )
            }
            Text("AI: NOT CONNECTED", color = Amber, fontSize = 11.sp, fontFamily = Stark, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(40.dp).border(1.dp, Cyan, CircleShape).background(Panel, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("MIC", color = Cyan, fontFamily = Stark, fontSize = 10.sp) }
        }
        Spacer(Modifier.height(8.dp))

        // Sphere
        HudCard(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                AiSphere(Modifier.fillMaxSize())
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("JARVIS", color = Cyan, fontSize = 48.sp, fontFamily = IronFont, letterSpacing = 8.sp)
                    Text("AI CORE", color = Cyan, fontSize = 20.sp, fontFamily = StarkHollow, letterSpacing = 6.sp)
                    Text("v0.7.0", color = Dim, fontSize = 12.sp, fontFamily = Stark)
                    Text("LOCAL MODE", color = Amber, fontSize = 13.sp, fontFamily = Stark, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        // Listening status (real: reflects the wake-word service)
        val ws = WakeService.state
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).height(1.dp).background(Dim.copy(alpha = 0.5f)))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    when (ws) {
                        "WAITING" -> "LISTENING FOR \"JARVIS\""
                        "LISTENING" -> "LISTENING..."
                        "THINKING" -> "THINKING..."
                        "SPEAKING" -> "SPEAKING..."
                        "STARTING" -> "WAKE WORD: STARTING"
                        "ERROR" -> "WAKE WORD: ERROR"
                        else -> "WAKE WORD: OFF"
                    },
                    color = if (ws == "OFF") Dim else if (ws == "ERROR") Amber else Green, fontSize = 14.sp, fontFamily = Stark, fontWeight = FontWeight.Bold
                )
                Text(
                    if (ws == "OFF") "Turn it on in Settings" else WakeService.error ?: "Say \"Hey Jarvis\", then your request",
                    color = Dim, fontSize = 11.sp
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        // Conversation preview
        HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Chat) }) {
            Column {
                Text("CONVERSATIONAL AI PANEL", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                val last = store.messages.takeLast(2)
                if (last.isEmpty()) {
                    Text("No conversation yet. Tap to open chat.", color = Dim, fontSize = 13.sp)
                } else {
                    last.forEach {
                        Row {
                            Text(if (it.fromUser) "YOU: " else "JARVIS: ", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(it.text, Modifier.weight(1f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        // System info (real values)
        Text("SYSTEM INFORMATION", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SysCard("CPU CORES", Runtime.getRuntime().availableProcessors().toString(), Modifier.weight(1f))
            SysCard("RAM FREE", "${gb(ram.first)}", Modifier.weight(1f))
            SysCard("BATTERY", "$battery%", Modifier.weight(1f))
        }
        Text("CPU load is not readable by apps on modern Android, so cores are shown instead.", color = Dim, fontSize = 10.sp)
        Spacer(Modifier.height(10.dp))

        // Shortcuts + recent activity
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SHORTCUTS", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Shortcut("TASKS", Modifier.weight(1f)) { nav(Screen.Tasks) }
                    Shortcut("CHAT", Modifier.weight(1f)) { nav(Screen.Chat) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Shortcut("MEMORY", Modifier.weight(1f)) { nav(Screen.Memory) }
                    Shortcut("TOOLS", Modifier.weight(1f)) { nav(Screen.Tools) }
                }
                Shortcut("OPEN 3D HOLOGRAM", Modifier.fillMaxWidth()) { nav(Screen.Holo) }
            }
            Column(Modifier.weight(1f)) {
                Text("RECENT ACTIVITY", color = Cyan, fontFamily = Stark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (store.activity.isEmpty()) {
                            Text("Nothing yet.", color = Dim, fontSize = 12.sp)
                        } else {
                            store.activity.take(5).forEach {
                                Column {
                                    Text(it.text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(timeStr(it.time), color = Dim, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
