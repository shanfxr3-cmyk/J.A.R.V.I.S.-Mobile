// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun AiSphere(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "sphere")
    val angle by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    val glow by t.animateFloat(
        0.16f, 0.34f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2.7f
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = glow), Color.Transparent), c, r * 1.4f),
            r * 1.4f, c
        )
        drawCircle(Cyan.copy(alpha = 0.85f), r, c, style = Stroke(2f))
        for (k in 0 until 8) {
            val a = Math.toRadians((angle + k * 22.5).toDouble())
            val w = abs((r * cos(a)).toFloat())
            drawOval(Cyan.copy(alpha = 0.45f), Offset(c.x - w, c.y - r), Size(2 * w, 2 * r), style = Stroke(1.2f))
        }
        for (lat in -2..2) {
            val dy = lat * r / 3f
            val half = sqrt(r * r - dy * dy)
            drawOval(
                Cyan.copy(alpha = 0.35f),
                Offset(c.x - half, c.y + dy - half * 0.18f),
                Size(2 * half, half * 0.36f),
                style = Stroke(1.2f)
            )
        }
        rotate(-20f, c) {
            drawOval(
                Cyan.copy(alpha = 0.6f),
                Offset(c.x - r * 1.5f, c.y - r * 0.45f),
                Size(r * 3f, r * 0.9f),
                style = Stroke(1.5f)
            )
            val oa = Math.toRadians(angle * 2.0)
            drawCircle(
                Color.White, 5f,
                Offset(c.x + (r * 1.5f * cos(oa)).toFloat(), c.y + (r * 0.45f * sin(oa)).toFloat())
            )
        }
    }
}

@Composable
private fun Gauge(fraction: Float, color: Color, value: String, label: String, modifier: Modifier) {
    HudCard(modifier, pad = 10.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 5.dp.toPx()
                    val tl = Offset(sw / 2, sw / 2)
                    val sz = Size(size.width - sw, size.height - sw)
                    drawArc(color.copy(alpha = 0.15f), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    val f = fraction.coerceIn(0f, 1f)
                    if (f > 0f) drawArc(color, 135f, 270f * f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(value, color = color, fontFamily = MonoFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            }
            Spacer(Modifier.height(4.dp))
            Text(label, color = Dim, fontSize = 10.sp, fontFamily = HudFont, letterSpacing = 1.sp, maxLines = 1)
        }
    }
}

@Composable
private fun Shortcut(ic: Ic, label: String, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier.heightIn(min = 72.dp), onClick, pad = 10.dp) {
        Column(Modifier.fillMaxWidth().align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HudIcon(ic, size = 24.dp)
            Text(label, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

@Composable
fun HomeScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var battery by remember { mutableIntStateOf(batteryPercent(ctx)) }
    var ram by remember { mutableStateOf(ramInfo(ctx)) }
    LaunchWhileStarted {
        while (true) {
            battery = batteryPercent(ctx)
            ram = ramInfo(ctx)
            delay(5000)
        }
    }
    val pulseT = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseT.animateFloat(
        0.35f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dot"
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        UpdateBanner(nav)
        // Header
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).border(2.dp, Brush.sweepGradient(listOf(Cyan, Cyan.copy(alpha = 0.15f), Cyan)), CircleShape).background(Panel, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("AI", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 18.sp, fontFamily = TitleFont, letterSpacing = 0.sp, maxLines = 1, softWrap = false)
                Text(
                    if (store.userName.isBlank()) "PERSONAL AI" else "PERSONAL AI - ${store.userName.uppercase()}",
                    color = Dim, fontSize = 11.sp, maxLines = 1
                )
            }
            val hasKey = store.apiKey.isNotBlank()
            val kc = if (hasKey) Green else Amber
            Row(
                Modifier.background(kc.copy(alpha = 0.10f), RoundedCornerShape(50)).border(1.dp, kc.copy(alpha = 0.5f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(6.dp).background(kc, CircleShape))
                Spacer(Modifier.width(5.dp))
                Text(if (hasKey) "KEY SET" else "NO KEY", color = kc, fontSize = 10.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(38.dp).border(1.dp, Cyan.copy(alpha = 0.6f), CircleShape).background(Panel, CircleShape),
                contentAlignment = Alignment.Center
            ) { HudIcon(Ic.Mic, size = 18.dp) }
        }
        Spacer(Modifier.height(10.dp))

        // Sphere
        HudCard(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
                AiSphere(Modifier.fillMaxSize())
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("JARVIS", color = Cyan, fontSize = 30.sp, fontFamily = TitleFont, letterSpacing = 4.sp)
                    Text("AI CORE", color = Cyan, fontSize = 15.sp, fontFamily = AccentFont, letterSpacing = 6.sp)
                    Text("v${BuildConfig.VERSION_NAME}", color = Dim, fontSize = 11.sp, fontFamily = HudFont)
                    Text(if (store.apiKey.isNotBlank()) "AI READY" else "LOCAL MODE", color = if (store.apiKey.isNotBlank()) Green else Amber, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        // Listening status (real: reflects the wake-word service)
        val ws = WakeService.state
        val sc = if (ws == "OFF") Dim else if (ws == "ERROR" || ws == "STARTING" || ws == "DOWNLOADING") Amber else Green
        HudCard(Modifier.fillMaxWidth(), pad = 10.dp, accent = sc) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(sc.copy(alpha = if (ws == "OFF") 0.5f else pulse), CircleShape))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when (ws) {
                            "WAITING" -> "LISTENING FOR \"JARVIS\""
                            "LISTENING" -> "LISTENING..."
                            "THINKING" -> "THINKING..."
                            "SPEAKING" -> "SPEAKING..."
                            "STARTING" -> "WAKE WORD: STARTING"
                            "DOWNLOADING" -> "WAKE WORD: DOWNLOADING MODEL"
                            "PAUSED" -> "PAUSED WHILE CHAT USES THE MIC"
                            "ERROR" -> "WAKE WORD: ERROR"
                            else -> "WAKE WORD: OFF"
                        },
                        color = sc, fontSize = 13.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (ws == "OFF") "Turn it on in Settings" else WakeService.error ?: "Say \"Hey Jarvis\", then your request",
                        color = Dim, fontSize = 11.sp
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        // Conversation preview
        HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Chat) }) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HudIcon(Ic.Chat, size = 16.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("CONVERSATION", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                    HudIcon(Ic.Chevron, tint = Dim, size = 14.dp)
                }
                Spacer(Modifier.height(6.dp))
                val last = store.messages.takeLast(2)
                if (last.isEmpty()) {
                    Text("No conversation yet. Tap to open chat.", color = Dim, fontSize = 13.sp)
                } else {
                    last.forEach {
                        Row(Modifier.padding(vertical = 2.dp)) {
                            Text(if (it.fromUser) "YOU: " else "JARVIS: ", color = if (it.fromUser) Dim else Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(it.text, Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // System info (real values)
        SectionTitle("SYSTEM")
        Spacer(Modifier.height(6.dp))
        val cores = Runtime.getRuntime().availableProcessors()
        val usedFrac = if (ram.second > 0) 1f - ram.first.toFloat() / ram.second.toFloat() else 0f
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Gauge(cores / 8f, Cyan, cores.toString(), "CPU CORES", Modifier.weight(1f))
            Gauge(usedFrac, if (usedFrac > 0.9f) Amber else Cyan, gb(ram.first).replace(" GB", "GB"), "RAM FREE", Modifier.weight(1f))
            Gauge(
                if (battery < 0) 0f else battery / 100f,
                if (battery in 0..15) Danger else if (battery in 0..30) Amber else Green,
                batteryText(battery), "BATTERY", Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text("CPU load is not readable by apps on modern Android, so cores are shown instead.", color = Dim, fontSize = 10.sp)
        Spacer(Modifier.height(12.dp))

        // Shortcuts
        SectionTitle("SHORTCUTS")
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Shortcut(Ic.Tasks, "TASKS", Modifier.weight(1f)) { nav(Screen.Tasks) }
            Shortcut(Ic.Chat, "CHAT", Modifier.weight(1f)) { nav(Screen.Chat) }
            Shortcut(Ic.Memory, "MEMORY", Modifier.weight(1f)) { nav(Screen.Memory) }
            Shortcut(Ic.Tools, "TOOLS", Modifier.weight(1f)) { nav(Screen.Tools) }
        }
        Spacer(Modifier.height(8.dp))
        HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Holo) }, pad = 12.dp, accent = Green) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                HudIcon(Ic.Holo, tint = Green, size = 22.dp)
                Spacer(Modifier.width(10.dp))
                Text("OPEN 3D HOLOGRAM", Modifier.weight(1f), color = Green, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp)
                HudIcon(Ic.Chevron, tint = Green, size = 14.dp)
            }
        }
        Spacer(Modifier.height(12.dp))

        // Recent activity
        SectionTitle("RECENT ACTIVITY")
        Spacer(Modifier.height(6.dp))
        HudCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (store.activity.isEmpty()) {
                    Text("Nothing yet.", color = Dim, fontSize = 12.sp)
                } else {
                    store.activity.take(5).forEach {
                        Row(verticalAlignment = Alignment.Top) {
                            Box(Modifier.padding(top = 5.dp).size(6.dp).background(Cyan, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(it.text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(timeStr(it.time), color = Dim, fontSize = 10.sp, fontFamily = MonoFont)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
