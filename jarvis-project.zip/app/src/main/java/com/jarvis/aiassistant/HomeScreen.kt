// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun Gauge(fraction: Float, color: Color, value: String, label: String, modifier: Modifier) {
    HudCard(modifier, pad = 10.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val strokeWidth = 5.dp.toPx()
                    val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                    val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                    val stroke = Stroke(strokeWidth, cap = StrokeCap.Round)
                    drawArc(color.copy(alpha = 0.15f), 135f, 270f, false, topLeft, arcSize, style = stroke)
                    val filled = fraction.coerceIn(0f, 1f)
                    if (filled > 0f) drawArc(color, 135f, 270f * filled, false, topLeft, arcSize, style = stroke)
                }
                Text(value, color = color, fontFamily = MonoFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            }
            Spacer(Modifier.height(4.dp))
            Text(label, color = Dim, fontSize = 10.sp, fontFamily = HudFont, letterSpacing = 1.sp, maxLines = 1)
        }
    }
}

@Composable
private fun Shortcut(icon: Ic, label: String, modifier: Modifier, onClick: () -> Unit) {
    HudCard(modifier.heightIn(min = 72.dp), onClick, pad = 10.dp) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HudIcon(icon, size = 24.dp)
            Text(label, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

private fun WakeState.headline(): String = when (this) {
    WakeState.WAITING -> "LISTENING FOR \"JARVIS\""
    WakeState.LISTENING -> "LISTENING..."
    WakeState.THINKING -> "THINKING..."
    WakeState.SPEAKING -> "SPEAKING..."
    WakeState.STARTING -> "WAKE WORD: STARTING"
    WakeState.DOWNLOADING -> "WAKE WORD: DOWNLOADING MODEL"
    WakeState.PAUSED -> "PAUSED WHILE CHAT USES THE MIC"
    WakeState.ERROR -> "WAKE WORD: ERROR"
    WakeState.OFF -> "WAKE WORD: OFF"
}

private fun WakeState.tint(): Color = when (this) {
    WakeState.OFF -> Dim
    WakeState.ERROR, WakeState.STARTING, WakeState.DOWNLOADING -> Amber
    else -> Green
}

@Composable
private fun HomeHeader(store: Store) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp)
                .border(2.dp, Brush.sweepGradient(listOf(Cyan, Cyan.copy(alpha = 0.15f), Cyan)), CircleShape)
                .background(Panel, CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("AI", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 18.sp, fontFamily = TitleFont, letterSpacing = 0.sp, maxLines = 1, softWrap = false)
            Text(
                if (store.userName.isBlank()) "PERSONAL AI" else "PERSONAL AI - ${store.userName.uppercase()}",
                color = Dim, fontSize = 11.sp, maxLines = 1
            )
        }
        val hasKey = store.apiKey.isNotBlank()
        val keyColor = if (hasKey) Green else Amber
        Row(
            Modifier
                .background(keyColor.copy(alpha = 0.10f), RoundedCornerShape(50))
                .border(1.dp, keyColor.copy(alpha = 0.5f), RoundedCornerShape(50))
                .padding(horizontal = 9.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(6.dp).background(keyColor, CircleShape))
            Spacer(Modifier.width(5.dp))
            Text(if (hasKey) "KEY SET" else "NO KEY", color = keyColor, fontSize = 10.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(38.dp).border(1.dp, Cyan.copy(alpha = 0.6f), CircleShape).background(Panel, CircleShape),
            contentAlignment = Alignment.Center
        ) { HudIcon(Ic.Mic, size = 18.dp) }
    }
}

/** Reflects the real state of the wake-word service. */
@Composable
private fun WakeStatusCard() {
    val state = WakeService.state
    val tint = state.tint()
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.35f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dot"
    )
    HudCard(Modifier.fillMaxWidth(), pad = 10.dp, accent = tint) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(tint.copy(alpha = if (state == WakeState.OFF) 0.5f else pulse), CircleShape))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(state.headline(), color = tint, fontSize = 13.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold)
                Text(
                    if (state == WakeState.OFF) "Turn it on in Settings" else WakeService.error ?: "Say \"Hey Jarvis\", then your request",
                    color = Dim, fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun ConversationCard(store: Store, nav: (Screen) -> Unit) {
    HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Chat) }) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudIcon(Ic.Chat, size = 16.dp)
                Spacer(Modifier.width(8.dp))
                Text("CONVERSATION", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                HudIcon(Ic.Chevron, tint = Dim, size = 14.dp)
            }
            Spacer(Modifier.height(6.dp))
            val lastTwo = store.messages.takeLast(2)
            if (lastTwo.isEmpty()) {
                Text("No conversation yet. Tap to open chat.", color = Dim, fontSize = 13.sp)
            }
            lastTwo.forEach { message ->
                Row(Modifier.padding(vertical = 2.dp)) {
                    Text(
                        if (message.fromUser) "YOU: " else "JARVIS: ",
                        color = if (message.fromUser) Dim else Cyan,
                        fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp
                    )
                    Text(message.text, Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun SystemGauges(stats: DeviceStats) {
    val cores = Runtime.getRuntime().availableProcessors()
    val (freeRam, totalRam) = stats.ram
    val usedFraction = if (totalRam > 0) 1f - freeRam.toFloat() / totalRam.toFloat() else 0f
    val battery = stats.battery
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Gauge(cores / 8f, Cyan, cores.toString(), "CPU CORES", Modifier.weight(1f))
        Gauge(usedFraction, if (usedFraction > 0.9f) Amber else Cyan, gb(freeRam).replace(" GB", "GB"), "RAM FREE", Modifier.weight(1f))
        Gauge(
            if (battery < 0) 0f else battery / 100f,
            when {
                battery in 0..15 -> Danger
                battery in 0..30 -> Amber
                else -> Green
            },
            batteryText(battery), "BATTERY", Modifier.weight(1f)
        )
    }
    Spacer(Modifier.height(4.dp))
    Text("CPU load is not readable by apps on modern Android, so cores are shown instead.", color = Dim, fontSize = 10.sp)
}

@Composable
private fun RecentActivityCard(store: Store) {
    HudCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (store.activity.isEmpty()) {
                Text("Nothing yet.", color = Dim, fontSize = 12.sp)
            }
            store.activity.take(5).forEach { item ->
                Row(verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 5.dp).size(6.dp).background(Cyan, CircleShape))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(timeStr(item.time), color = Dim, fontSize = 10.sp, fontFamily = MonoFont)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(store: Store, nav: (Screen) -> Unit) {
    val stats = rememberDeviceStats(intervalMs = 5000)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        UpdateBanner(nav)
        HomeHeader(store)
        Spacer(Modifier.height(10.dp))

        HudCard(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
                AiSphere(Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(10.dp))

        WakeStatusCard()
        Spacer(Modifier.height(10.dp))

        ConversationCard(store, nav)
        Spacer(Modifier.height(12.dp))

        SectionTitle("SYSTEM")
        Spacer(Modifier.height(6.dp))
        SystemGauges(stats)
        Spacer(Modifier.height(12.dp))

        SectionTitle("SHORTCUTS")
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Shortcut(Ic.Tasks, "TASKS", Modifier.weight(1f)) { nav(Screen.Tasks) }
            Shortcut(Ic.Chat, "CHAT", Modifier.weight(1f)) { nav(Screen.Chat) }
            Shortcut(Ic.Memory, "MEMORY", Modifier.weight(1f)) { nav(Screen.Memory) }
            Shortcut(Ic.Tools, "TOOLS", Modifier.weight(1f)) { nav(Screen.Tools) }
        }
        Spacer(Modifier.height(12.dp))

        SectionTitle("RECENT ACTIVITY")
        Spacer(Modifier.height(6.dp))
        RecentActivityCard(store)
        Spacer(Modifier.height(8.dp))
    }
}
