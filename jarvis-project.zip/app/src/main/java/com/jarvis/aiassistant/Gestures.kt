package com.jarvis.aiassistant

import android.os.SystemClock
import kotlin.math.hypot

/**
 * Turns real hand landmarks into changes of the sphere state.
 *  - PINCH (thumb + index) and move  -> move the sphere
 *  - FIST and move                   -> rotate the sphere
 *  - TWO hands pinching, spread/close -> scale (and move by their midpoint)
 *  - scale above ~3.2x               -> enter the core; below ~2.4x -> leave it
 *  - TWO fists held 1.5 s            -> reset
 */
class GestureController(private val st: HoloState, private val ts: TrackState) {
    private enum class G { NONE, PINCH, FIST }

    private val pinchState = BooleanArray(2)
    private var cur = G.NONE
    private var stable = 0
    private var engaged = false
    private var ax = 0f
    private var ay = 0f
    private var twoDist = -1f
    private var tmx = 0f
    private var tmy = 0f
    private var fistsSince = 0L

    private fun dist(a: LmPt, b: LmPt, w: Int, hh: Int) = hypot((a.x - b.x) * w, (a.y - b.y) * hh)

    private fun curled(h: List<LmPt>, tip: Int, pip: Int, w: Int, hh: Int) =
        dist(h[tip], h[0], w, hh) < dist(h[pip], h[0], w, hh)

    private fun isFist(h: List<LmPt>, w: Int, hh: Int): Boolean {
        var c = 0
        if (curled(h, 8, 6, w, hh)) c++
        if (curled(h, 12, 10, w, hh)) c++
        if (curled(h, 16, 14, w, hh)) c++
        if (curled(h, 20, 18, w, hh)) c++
        return c >= 3
    }

    private fun classify(i: Int, h: List<LmPt>, w: Int, hh: Int): G {
        if (h.size < 21) return G.NONE
        val r = pinchRatio(h, w, hh)
        pinchState[i] = if (pinchState[i]) r < 0.45f else r < 0.30f
        return if (pinchState[i]) G.PINCH else if (isFist(h, w, hh)) G.FIST else G.NONE
    }

    fun release() {
        cur = G.NONE; stable = 0; engaged = false; twoDist = -1f; fistsSince = 0L
        pinchState[0] = false; pinchState[1] = false
        st.handActive = false
        ts.gesture = "NONE"
    }

    fun update(hands: List<List<LmPt>>, w: Int, hh: Int) {
        if (!st.gestureEnabled || hands.isEmpty() || w <= 0 || hh <= 0) { release(); return }
        val two = hands.take(2)
        val g = two.mapIndexed { i, h -> classify(i, h, w, hh) }
        val now = SystemClock.uptimeMillis()

        if (g.size == 2) {
            if (g[0] == G.PINCH && g[1] == G.PINCH) { engaged = false; cur = G.NONE; twoHandScale(two, w, hh); return }
            if (g[0] == G.FIST && g[1] == G.FIST) {
                engaged = false; cur = G.NONE; twoDist = -1f
                st.handActive = true
                if (fistsSince == 0L) fistsSince = now
                ts.gesture = "TWO FISTS - HOLD TO RESET"
                if (now - fistsSince > 1500) { st.reset(); fistsSince = now + 3000 }
                return
            }
        }
        fistsSince = 0L
        twoDist = -1f
        oneHand(two[0], g[0], w, hh)
    }

    private fun twoHandScale(hs: List<List<LmPt>>, w: Int, hh: Int) {
        st.handActive = true
        ts.gesture = "TWO-HAND SCALE"
        val a = hs[0][9]; val b = hs[1][9]
        val d = dist(a, b, w, hh)
        val mx = (a.x + b.x) / 2f * w
        val my = (a.y + b.y) / 2f * hh
        if (twoDist <= 0f) { twoDist = d; tmx = mx; tmy = my; return }
        val sd = twoDist + (d - twoDist) * 0.5f
        val ratio = sd / twoDist
        if (kotlin.math.abs(ratio - 1f) > 0.005f) st.scale = (st.scale * ratio).coerceIn(0.3f, 4f)
        st.panX = (st.panX + (mx - tmx) / w * st.panScale * 1.6f).coerceIn(-3f, 3f)
        st.panY = (st.panY - (my - tmy) / w * st.panScale * 1.6f).coerceIn(-3f, 3f)
        twoDist = sd; tmx = mx; tmy = my
        if (st.scale > 3.2f) st.inside = true else if (st.inside && st.scale < 2.4f) st.inside = false
    }

    private fun oneHand(h: List<LmPt>, g: G, w: Int, hh: Int) {
        if (g == cur) stable++ else { cur = g; stable = 0; engaged = false }
        if (g == G.NONE) { ts.gesture = "OPEN HAND"; st.handActive = false; return }
        st.handActive = true
        ts.gesture = if (g == G.PINCH) "PINCH - GRAB" else "FIST - ROTATE"
        if (stable < 3) return
        val px = h[9].x * w
        val py = h[9].y * hh
        if (!engaged) { ax = px; ay = py; engaged = true; return }
        val sx = ax + (px - ax) * 0.5f
        val sy = ay + (py - ay) * 0.5f
        val dx = (sx - ax) / w
        val dy = (sy - ay) / w
        ax = sx; ay = sy
        if (hypot(dx, dy) < 0.0015f) return
        if (g == G.PINCH) {
            st.panX = (st.panX + dx * st.panScale * 1.6f).coerceIn(-3f, 3f)
            st.panY = (st.panY - dy * st.panScale * 1.6f).coerceIn(-3f, 3f)
        } else {
            st.rotY += dx * 220f
            st.rotX = (st.rotX + dy * 220f).coerceIn(-89f, 89f)
        }
    }
}
