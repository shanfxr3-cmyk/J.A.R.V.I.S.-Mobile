package com.jarvis.aiassistant

import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.pow

/** One Euro filter: smooth when the hand is still, almost no lag when it moves fast. */
class OneEuro(private val minCut: Float, private val beta: Float, private val dCut: Float = 1f) {
    private var xp = 0f
    private var dxp = 0f
    private var tp = 0L
    private var init = false

    private fun alpha(cut: Float, dt: Float): Float {
        val tau = 1f / (2f * Math.PI.toFloat() * cut)
        return 1f / (1f + tau / dt)
    }

    fun reset() { init = false }

    fun f(x: Float, tMs: Long): Float {
        if (!init) { init = true; xp = x; dxp = 0f; tp = tMs; return x }
        val dt = ((tMs - tp) / 1000f).coerceIn(0.001f, 0.2f)
        tp = tMs
        dxp += alpha(dCut, dt) * ((x - xp) / dt - dxp)
        xp += alpha(minCut + beta * abs(dxp), dt) * (x - xp)
        return xp
    }
}

/**
 * Turns real hand landmarks into changes of the sphere state.
 *  - PINCH (thumb + index) and move  -> move the sphere
 *  - FIST and move                   -> rotate (releasing keeps momentum)
 *  - TWO hands pinching, spread/close -> scale (and move by their midpoint)
 *  - scale above ~3.2x               -> enter the core; below ~2.4x -> leave it
 *  - TWO fists held 1.5 s            -> reset
 * Hand loss shorter than 250 ms is ignored so a brief dropout does not break a gesture.
 */
class GestureController(private val st: HoloState, private val ts: TrackState) {
    private enum class G { NONE, PINCH, FIST }

    private val panGain = 2.2f
    private val rotGain = 300f
    private val pinchState = BooleanArray(2)
    private val fx = Array(2) { OneEuro(1.2f, 7f) }
    private val fy = Array(2) { OneEuro(1.2f, 7f) }
    private val fd = OneEuro(1.5f, 5f)
    private var cur = G.NONE
    private var curIdx = 0
    private var stable = 0
    private var engaged = false
    private var ax = 0f
    private var ay = 0f
    private var lastT = 0L
    private var twoDist = -1f
    private var tmx = 0f
    private var tmy = 0f
    private var fistsSince = 0L
    private var lastSeen = 0L
    private var lastCount = 0

    private fun dist(a: LmPt, b: LmPt, w: Int, hh: Int) = hypot((a.x - b.x) * w, (a.y - b.y) * hh)

    private fun curled(h: List<LmPt>, tip: Int, pip: Int, w: Int, hh: Int) =
        dist(h[tip], h[0], w, hh) < dist(h[pip], h[0], w, hh)

    private fun isFist(h: List<LmPt>, w: Int, hh: Int): Boolean {
        var c = 0
        if (curled(h, 8, 6, w, hh)) c++
        if (curled(h, 12, 10, w, hh)) c++
        if (curled(h, 16, 14, w, hh)) c++
        if (curled(h, 20, 18, w, hh)) c++
        return c >= 3
    }

    private fun classify(i: Int, h: List<LmPt>, w: Int, hh: Int): G {
        val r = pinchRatio(h, w, hh)
        pinchState[i] = if (pinchState[i]) r < 0.50f else r < 0.33f
        return if (pinchState[i]) G.PINCH else if (isFist(h, w, hh)) G.FIST else G.NONE
    }

    /** Palm centre: x in image widths, y in image widths too (so both axes share a unit). */
    private fun palm(h: List<LmPt>, w: Int, hh: Int): Pair<Float, Float> {
        var sx = 0f
        var sy = 0f
        for (i in intArrayOf(0, 5, 9, 13, 17)) { sx += h[i].x; sy += h[i].y }
        return (sx / 5f) to (sy / 5f * hh / w)
    }

    fun release() {
        cur = G.NONE; stable = 0; engaged = false; twoDist = -1f; fistsSince = 0L; lastCount = 0
        pinchState[0] = false; pinchState[1] = false
        fx.forEach { it.reset() }; fy.forEach { it.reset() }; fd.reset()
        st.handActive = false
        ts.gesture = "NONE"
    }

    fun update(hands: List<List<LmPt>>, w: Int, hh: Int) {
        val now = SystemClock.uptimeMillis()
        if (!st.gestureEnabled || w <= 0 || hh <= 0) { release(); return }
        if (hands.isEmpty()) { if (now - lastSeen > 250) release(); return }
        lastSeen = now
        val two = hands.take(2)
        if (two.size != lastCount) {
            engaged = false; twoDist = -1f; stable = 0
            fx.forEach { it.reset() }; fy.forEach { it.reset() }; fd.reset()
            lastCount = two.size
        }
        val g = two.mapIndexed { i, h -> classify(i, h, w, hh) }
        val p = two.mapIndexed { i, h ->
            val (x, y) = palm(h, w, hh)
            floatArrayOf(fx[i].f(x, now), fy[i].f(y, now))
        }

        if (two.size == 2) {
            if (g[0] == G.PINCH && g[1] == G.PINCH) { engaged = false; cur = G.NONE; twoHand(p, now); return }
            if (g[0] == G.FIST && g[1] == G.FIST) {
                engaged = false; cur = G.NONE; twoDist = -1f
                st.handActive = true
                if (fistsSince == 0L) fistsSince = now
                ts.gesture = "TWO FISTS - HOLD TO RESET"
                if (now - fistsSince > 1500) { st.reset(); fistsSince = now + 3000 }
                return
            }
        }
        fistsSince = 0L
        twoDist = -1f
        val idx = if (g[0] != G.NONE) 0 else if (g.size > 1 && g[1] != G.NONE) 1 else 0
        oneHand(idx, p[idx], g[idx], now)
    }

    private fun twoHand(p: List<FloatArray>, now: Long) {
        st.handActive = true
        st.velX = 0f; st.velY = 0f
        ts.gesture = "TWO-HAND SCALE"
        val d = fd.f(hypot(p[0][0] - p[1][0], p[0][1] - p[1][1]), now)
        val mx = (p[0][0] + p[1][0]) / 2f
        val my = (p[0][1] + p[1][1]) / 2f
        if (twoDist <= 0f) { twoDist = d; tmx = mx; tmy = my; return }
        val ratio = d / twoDist
        if (abs(ratio - 1f) > 0.002f) st.scale = (st.scale * ratio.pow(1.25f)).coerceIn(0.3f, 4f)
        st.panX = (st.panX + (mx - tmx) * st.panScale * panGain).coerceIn(-3f, 3f)
        st.panY = (st.panY - (my - tmy) * st.panScale * panGain).coerceIn(-3f, 3f)
        twoDist = d; tmx = mx; tmy = my
        if (st.scale > 3.2f) st.inside = true else if (st.inside && st.scale < 2.4f) st.inside = false
    }

    private fun oneHand(idx: Int, p: FloatArray, g: G, now: Long) {
        if (g == cur && idx == curIdx) stable++ else { cur = g; curIdx = idx; stable = 0; engaged = false }
        if (g == G.NONE) { ts.gesture = "OPEN HAND"; st.handActive = false; return }
        st.handActive = true
        ts.gesture = if (g == G.PINCH) "PINCH - GRAB" else "FIST - ROTATE"
        if (stable < 2) return
        val x = p[0]
        val y = p[1]
        if (!engaged) { ax = x; ay = y; lastT = now; engaged = true; return }
        val dt = ((now - lastT) / 1000f).coerceIn(0.008f, 0.1f)
        lastT = now
        val dx = x - ax
        val dy = y - ay
        ax = x; ay = y
        if (hypot(dx, dy) < 0.0004f) {
            if (g == G.FIST) { st.velX *= 0.8f; st.velY *= 0.8f }
            return
        }
        if (g == G.PINCH) {
            st.velX = 0f; st.velY = 0f
            st.panX = (st.panX + dx * st.panScale * panGain).coerceIn(-3f, 3f)
            st.panY = (st.panY - dy * st.panScale * panGain).coerceIn(-3f, 3f)
        } else {
            st.rotY += dx * rotGain
            st.rotX = (st.rotX + dy * rotGain).coerceIn(-89f, 89f)
            st.velY = (dx * rotGain / dt).coerceIn(-500f, 500f) * 0.6f + st.velY * 0.4f
            st.velX = (dy * rotGain / dt).coerceIn(-500f, 500f) * 0.6f + st.velX * 0.4f
        }
    }
}
