// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.os.Build
import android.os.SystemClock
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.jarvis.aiassistant.holo.HoloFx
import kotlinx.coroutines.delay

/**
 * Where the visualizer gets its amplitude. Audio threads write [target]; the frame loop reads it.
 *  - Fish / ElevenLabs playback: live FFT of the player (see PlaybackTap in FishTts.kt).
 *  - Microphone: the recognizer's loudness (Voice.kt onRmsChanged).
 *  - Phone TTS (no audio access): [synthetic] speech envelope, nudged by word boundaries.
 * Nothing here allocates after start-up, so audio callbacks cause no GC.
 */
object SpeechLevel {
    const val BANDS = SpeechDsp.BANDS
    @JvmField val target = FloatArray(BANDS)
    @Volatile @JvmField var stamp = 0L
    @Volatile @JvmField var synthetic = false
    var speaking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    /** Average level 0..100, for the numeric readout. Written by the frame loop only when it changes. */
    var pct by mutableIntStateOf(0)

    private val fft = SpeechDsp.FftBands()
    private var jitter = 0

    fun pushFft(bytes: ByteArray) {
        if (fft.process(bytes, target)) stamp = SystemClock.uptimeMillis()
    }

    fun pushRmsDb(db: Float) {
        val l = SpeechDsp.rmsDbToLevel(db)
        jitter = (jitter + 1) and 63
        for (i in 0 until BANDS) target[i] = l * SpeechDsp.shape(i, jitter)
        stamp = SystemClock.uptimeMillis()
    }

    /** Word boundary from the phone TTS: a short burst across the bands. */
    fun pulse(k: Float) {
        jitter = (jitter + 5) and 63
        for (i in 0 until BANDS) target[i] = maxOf(target[i], k * SpeechDsp.shape(i, jitter))
        stamp = SystemClock.uptimeMillis()
    }

    fun reset() { speaking = false; listening = false; synthetic = false }
}

private const val N = SpeechLevel.BANDS
private const val M_IDLE = 0
private const val M_THINK = 1
private const val M_LISTEN = 2
private const val M_SPEAK = 3

/** All per-frame data in primitive arrays, updated in place. [tick] is read only inside the draw block. */
@Stable
private class WaveState {
    var tick by mutableIntStateOf(0)
    @JvmField var mode = M_IDLE
    @JvmField val disp = FloatArray(N)
    @JvmField val peak = FloatArray(N)
    @JvmField val drive = FloatArray(N)
    private var t = 0f
    private var lastPct = -1

    fun settled(): Boolean {
        for (i in 0 until N) if (disp[i] > 0.004f || peak[i] > 0.004f) return false
        return true
    }

    fun step(dt: Float, now: Long) {
        t += dt
        val tg = SpeechLevel.target
        val real = now - SpeechLevel.stamp < 180L
        val m = mode
        for (i in 0 until N) {
            drive[i] = when {
                m == M_IDLE -> 0f
                real && (m == M_SPEAK || m == M_LISTEN) -> tg[i]
                m == M_SPEAK -> if (SpeechLevel.synthetic || !SpeechLevel.speaking) SpeechDsp.synth(t, i) else 0.05f
                m == M_LISTEN -> SpeechDsp.breath(t, i)
                else -> SpeechDsp.scan(t, i)
            }
            if (!real) tg[i] *= 0.8f
        }
        val ka = (dt * 38f).coerceAtMost(1f)   // fast attack
        val kd = (dt * 8f).coerceAtMost(1f)    // slow, fluid release
        var sum = 0f
        for (i in 0 until N) {
            val s = drive[i]; val d = disp[i]
            val n = d + (s - d) * (if (s > d) ka else kd)
            disp[i] = n
            val p = peak[i] - dt * 0.7f
            peak[i] = if (n > p) n else p
            sum += n
        }
        val pc = (sum / N * 100f).toInt()
        if (pc != lastPct) { lastPct = pc; SpeechLevel.pct = pc }
        tick++
    }
}

/** Quadratic-smoothed curve through the band heights. Mutates [p] in place; creates no objects. */
private fun curve(p: Path, ys: FloatArray, dx: Float, mid: Float, sign: Float, reverse: Boolean, move: Boolean) {
    var i = if (reverse) N - 1 else 0
    val step = if (reverse) -1 else 1
    var px = i * dx
    var py = mid + sign * ys[i]
    if (move) p.moveTo(px, py) else p.lineTo(px, py)
    for (k in 1 until N) {
        i += step
        val x = i * dx
        val y = mid + sign * ys[i]
        p.quadraticTo(px, py, (px + x) * 0.5f, (py + y) * 0.5f)
        px = x; py = y
    }
    p.lineTo(px, py)
}

/**
 * Mirrored spectrum ribbon driven by real speech amplitude. Composition runs once; the frame loop and draw block
 * do all the work. The frame loop sleeps (120 ms polls) while nothing is speaking and the bars have settled.
 * On Android 13+ the layer goes through the shared AGSL pass (chromatic aberration + glow) on the GPU.
 */
@SuppressLint("NewApi")
@Composable
fun VoiceWave(modifier: Modifier = Modifier) {
    val fx = remember { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) HoloFx() else null }
    val st = remember { WaveState() }
    val mode by remember {
        derivedStateOf {
            val ws = WakeService.state
            when {
                SpeechLevel.speaking || ws == "SPEAKING" -> M_SPEAK
                SpeechLevel.listening || ws == "LISTENING" -> M_LISTEN
                ws == "THINKING" -> M_THINK
                else -> M_IDLE
            }
        }
    }
    val modeNow by rememberUpdatedState(mode)

    LaunchWhileStarted {
        var last = 0L
        while (true) {
            st.mode = if (Fx.lite) M_IDLE else modeNow
            if (st.mode == M_IDLE && st.settled()) { last = 0L; delay(120); continue }
            withFrameNanos { now ->
                if (last != 0L) st.step(((now - last) / 1_000_000_000f).coerceAtMost(0.05f), SystemClock.uptimeMillis())
                last = now
            }
        }
    }

    Spacer(
        modifier
            .drawWithCache {
                val w = size.width; val h = size.height
                val dx = w / (N - 1)
                val mid = h * 0.5f
                val amp = h * 0.46f
                val floor = 1.2.dp.toPx()
                val top = Path()
                val fill = Path()
                val ys = FloatArray(N)
                val fillCyan = Brush.verticalGradient(listOf(Cyan.copy(alpha = 0.04f), Cyan.copy(alpha = 0.34f), Cyan.copy(alpha = 0.04f)), 0f, h)
                val fillAmber = Brush.verticalGradient(listOf(Green.copy(alpha = 0.04f), Green.copy(alpha = 0.30f), Green.copy(alpha = 0.04f)), 0f, h)
                val glowStroke = Stroke(6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                val coreStroke = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                val centerStroke = Stroke(0.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx())))
                val centerPath = Path().apply { moveTo(0f, mid); lineTo(w, mid) }
                val barW = 1.dp.toPx()
                val capHalf = dx * 0.28f
                val capW = 1.5.dp.toPx()
                onDrawBehind {
                    if (st.tick < 0) return@onDrawBehind
                    val d = st.disp
                    val pk = st.peak
                    val c = if (st.mode == M_LISTEN) Green else Cyan
                    for (i in 0 until N) {
                        val a = if (i == 0) (d[0] * 0.75f + d[1] * 0.25f)
                        else if (i == N - 1) (d[N - 1] * 0.75f + d[N - 2] * 0.25f)
                        else (d[i - 1] * 0.25f + d[i] * 0.5f + d[i + 1] * 0.25f)
                        ys[i] = floor + a * amp
                    }
                    fill.rewind()
                    curve(fill, ys, dx, mid, -1f, false, true)
                    curve(fill, ys, dx, mid, 1f, true, false)
                    fill.close()
                    drawPath(fill, if (st.mode == M_LISTEN) fillAmber else fillCyan)
                    val glowC = c.copy(alpha = 0.14f)
                    top.rewind(); curve(top, ys, dx, mid, -1f, false, true)
                    drawPath(top, glowC, style = glowStroke); drawPath(top, c, style = coreStroke)
                    top.rewind(); curve(top, ys, dx, mid, 1f, false, true)
                    drawPath(top, glowC, style = glowStroke); drawPath(top, c, style = coreStroke)
                }
            }
    )
}
