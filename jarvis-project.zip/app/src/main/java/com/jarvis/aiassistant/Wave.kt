// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

/** Animated bars that move while Jarvis is listening, thinking or speaking, and settle to a flat line when idle. */
@Composable
fun VoiceWave(modifier: Modifier = Modifier) {
    val ws = WakeService.state
    val active = (ws == "LISTENING" || ws == "SPEAKING" || ws == "THINKING") && !Fx.lite
    val amp by animateFloatAsState(if (active) 1f else 0f, tween(400), label = "waveAmp")
    val rate by rememberUpdatedState(if (ws == "SPEAKING") 7f else 4f)
    var t by remember { mutableFloatStateOf(0f) }
    LaunchWhileStarted(active) {
        if (active) {
            var last = 0L
            while (true) {
                withFrameNanos { now ->
                    if (last != 0L) t += ((now - last) / 1_000_000_000f).coerceAtMost(0.05f) * rate
                    last = now
                }
            }
        }
    }
    Canvas(modifier) {
        val n = 28
        val w = size.width / n
        val mid = size.height / 2
        val floor = 1.5.dp.toPx()
        for (i in 0 until n) {
            val h = floor + (0.15f + 0.85f * abs(sin(t + i * 0.45f)) * abs(sin(t * 0.7f + i * 0.2f))) * mid * amp
            drawRoundRect(Cyan.copy(alpha = 0.30f + 0.55f * amp), Offset(i * w + w * 0.25f, mid - h), Size(w * 0.5f, h * 2), CornerRadius(w * 0.25f))
        }
    }
}
