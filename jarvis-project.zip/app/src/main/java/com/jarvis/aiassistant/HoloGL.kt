package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Shared between the touch handler, the GL thread and the UI. Values are targets; the renderer smooths toward them. */
class HoloState {
    @Volatile var rotX = 20f
    @Volatile var rotY = -30f
    @Volatile var scale = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f
    @Volatile var inside = false
    @Volatile var autoSpin = true
    @Volatile var touching = false
    @Volatile var handActive = false
    @Volatile var gestureEnabled = true
    @Volatile var panScale = 2.4f
    @Volatile var pxToWorld = 0.005f
    @Volatile var rendered = false
    @Volatile var fps = 0
    @Volatile var error: String? = null

    fun reset() {
        rotX = 20f; rotY = -30f; scale = 1f; panX = 0f; panY = 0f; inside = false
    }
}

private class Layer(val buf: FloatBuffer, val count: Int)

/** Vertex layout: x y z size r g b a (8 floats, 32 bytes). */
private class Builder(cap: Int) {
    private val a = FloatArray(cap * 8)
    private var n = 0
    fun add(x: Float, y: Float, z: Float, size: Float, r: Float, g: Float, b: Float, al: Float) {
        val o = n * 8
        a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = size
        a[o + 4] = r; a[o + 5] = g; a[o + 6] = b; a[o + 7] = al
        n++
    }
    fun build(): Layer {
        val fb = ByteBuffer.allocateDirect(n * 32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(a, 0, n * 8)
        fb.position(0)
        return Layer(fb, n)
    }
}

private const val VERT = """
uniform mat4 uMvp;
uniform float uPx;
uniform float uMax;
attribute vec3 aPos;
attribute float aSize;
attribute vec4 aColor;
varying vec4 vColor;
void main() {
  vec4 p = uMvp * vec4(aPos, 1.0);
  gl_Position = p;
  gl_PointSize = clamp(aSize * uPx / max(p.w, 0.05), 1.0, uMax);
  vColor = aColor;
}
"""

private const val FRAG = """
precision mediump float;
varying vec4 vColor;
void main() {
  float r = length(gl_PointCoord - vec2(0.5));
  if (r > 0.5) discard;
  float a = 1.0 - smoothstep(0.0, 0.5, r);
  gl_FragColor = vec4(vColor.rgb, vColor.a * a);
}
"""

class HoloRenderer(private val st: HoloState, private val density: Float) : GLSurfaceView.Renderer {
    private var prog = 0
    private var aPos = 0
    private var aSize = 0
    private var aColor = 0
    private var uMvp = 0
    private var uPx = 0
    private var uMax = 0

    private var shell: Layer? = null
    private var mid: Layer? = null
    private var inner: Layer? = null
    private var coreCloud: Layer? = null
    private var glow: Layer? = null
    private var axes: Layer? = null
    private val rings = ArrayList<Layer>()
    private val ringTilt = arrayOf(floatArrayOf(70f, 0f), floatArrayOf(20f, 50f), floatArrayOf(-40f, -30f))
    private val ringSpeed = floatArrayOf(25f, -18f, 40f)

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private val mvp = FloatArray(16)

    private var cRotX = 20f
    private var cRotY = -30f
    private var cScale = 1f
    private var cPanX = 0f
    private var cPanY = 0f
    private var cDist = 3.2f
    private var baseDist = 3.2f
    private var aspect = 1f
    private var viewW = 1
    private val tanHalf = 0.4663f // tan(25 degrees), fov = 50
    private var startNs = 0L
    private var frames = 0
    private var lastFpsNs = 0L

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader: $log")
        }
        return s
    }

    private fun sphere(n: Int, radius: Float, jitter: Float, size: Float, seed: Long): Layer {
        val rnd = Random(seed)
        val b = Builder(n)
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val rr = sqrt(1f - y * y)
            val phi = i * 2.3999632f
            val rad = radius * (1f + (rnd.nextFloat() - 0.5f) * jitter)
            val t = rnd.nextFloat()
            val br = 0.25f + 0.75f * rnd.nextFloat().pow(2)
            b.add(cos(phi) * rr * rad, y * rad, sin(phi) * rr * rad, size,
                1f, 0.35f + 0.45f * t, 0.05f + 0.15f * t * t, br)
        }
        return b.build()
    }

    private fun buildGeometry() {
        shell = sphere(5000, 1.0f, 0.06f, 2.4f, 1)
        mid = sphere(2200, 0.72f, 0.12f, 2.8f, 2)
        inner = sphere(1400, 0.45f, 0.15f, 3.2f, 3)

        val rnd = Random(4)
        val cc = Builder(500)
        for (i in 0 until 500) {
            var x: Float; var y: Float; var z: Float
            do {
                x = rnd.nextFloat() * 2 - 1; y = rnd.nextFloat() * 2 - 1; z = rnd.nextFloat() * 2 - 1
            } while (x * x + y * y + z * z > 1f)
            cc.add(x * 0.2f, y * 0.2f, z * 0.2f, 4f, 1f, 0.8f, 0.35f, 0.9f)
        }
        coreCloud = cc.build()

        val g = Builder(3)
        g.add(0f, 0f, 0f, 150f, 1f, 0.55f, 0.1f, 0.35f)
        g.add(0f, 0f, 0f, 85f, 1f, 0.8f, 0.3f, 0.5f)
        g.add(0f, 0f, 0f, 40f, 1f, 0.95f, 0.7f, 0.85f)
        glow = g.build()

        val ax = Builder(363)
        for (i in -60..60) {
            val t = i / 60f * 1.4f
            ax.add(t, 0f, 0f, 1.6f, 0.4f, 0.85f, 1f, 0.7f)
            ax.add(0f, t, 0f, 1.6f, 1f, 0.8f, 0.3f, 0.7f)
            ax.add(0f, 0f, t, 1.6f, 1f, 0.95f, 0.8f, 0.7f)
        }
        axes = ax.build()

        rings.clear()
        val radii = floatArrayOf(1.25f, 1.12f, 0.9f)
        for (r in radii) {
            val rb = Builder(403)
            for (i in 0 until 400) {
                val a = i / 400f * 6.2831855f
                rb.add(cos(a) * r, sin(a) * r, 0f, 2.6f, 1f, 0.7f, 0.2f, 0.8f)
            }
            for (k in 0 until 3) {
                val a = k * 2.0944f
                rb.add(cos(a) * r, sin(a) * r, 0f, 9f, 1f, 0.9f, 0.6f, 0.95f)
            }
            rings.add(rb.build())
        }
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER, VERT)
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAG)
            prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Link: " + GLES20.glGetProgramInfoLog(prog))
            aPos = GLES20.glGetAttribLocation(prog, "aPos")
            aSize = GLES20.glGetAttribLocation(prog, "aSize")
            aColor = GLES20.glGetAttribLocation(prog, "aColor")
            uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
            uPx = GLES20.glGetUniformLocation(prog, "uPx")
            uMax = GLES20.glGetUniformLocation(prog, "uMax")
            buildGeometry()
            st.error = null
        } catch (e: Exception) {
            st.error = e.message ?: "unknown GL error"
            prog = 0
        }
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        GLES20.glClearColor(0.02f, 0.043f, 0.078f, 1f)
        startNs = System.nanoTime()
        lastFpsNs = startNs
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewW = max(width, 1)
        aspect = width.toFloat() / max(height, 1)
        baseDist = max(3.0f, 1.35f / (tanHalf * aspect))
        st.panScale = 2f * baseDist * tanHalf * aspect
        Matrix.perspectiveM(proj, 0, 50f, aspect, 0.05f, 40f)
    }

    private fun drawLayer(l: Layer?, m: FloatArray) {
        if (l == null) return
        Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        l.buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 32, l.buf)
        l.buf.position(3)
        GLES20.glVertexAttribPointer(aSize, 1, GLES20.GL_FLOAT, false, 32, l.buf)
        l.buf.position(4)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_FLOAT, false, 32, l.buf)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, l.count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (prog == 0) return

        if (st.autoSpin && !st.touching && !st.handActive) st.rotY += 0.12f
        val k = 0.18f
        cRotX += (st.rotX - cRotX) * k
        cRotY += (st.rotY - cRotY) * k
        cScale += (st.scale - cScale) * k
        cPanX += (st.panX - cPanX) * k
        cPanY += (st.panY - cPanY) * k
        cDist += ((if (st.inside) 0.45f else baseDist) - cDist) * 0.08f
        st.pxToWorld = 2f * cDist * tanHalf * aspect / viewW

        val t = (System.nanoTime() - startNs) / 1e9f

        GLES20.glUseProgram(prog)
        GLES20.glUniform1f(uPx, density * 3f)
        GLES20.glUniform1f(uMax, 48f)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aSize)
        GLES20.glEnableVertexAttribArray(aColor)

        Matrix.setIdentityM(view, 0)
        Matrix.translateM(view, 0, cPanX, cPanY, -cDist)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, cScale, cScale, cScale)
        Matrix.rotateM(model, 0, cRotX, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, cRotY, 0f, 1f, 0f)

        drawLayer(axes, model)
        drawLayer(shell, model)

        System.arraycopy(model, 0, tmp, 0, 16)
        Matrix.rotateM(tmp, 0, t * 6f, 0f, 1f, 0.3f)
        drawLayer(mid, tmp)

        System.arraycopy(model, 0, tmp, 0, 16)
        Matrix.rotateM(tmp, 0, -t * 10f, 0.4f, 1f, 0f)
        drawLayer(inner, tmp)
        drawLayer(coreCloud, tmp)

        for (i in rings.indices) {
            System.arraycopy(model, 0, tmp, 0, 16)
            Matrix.rotateM(tmp, 0, ringTilt[i][0], 1f, 0f, 0f)
            Matrix.rotateM(tmp, 0, ringTilt[i][1], 0f, 1f, 0f)
            Matrix.rotateM(tmp, 0, t * ringSpeed[i], 0f, 0f, 1f)
            drawLayer(rings[i], tmp)
        }

        drawLayer(glow, model)

        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aSize)
        GLES20.glDisableVertexAttribArray(aColor)

        st.rendered = true
        frames++
        val now = System.nanoTime()
        if (now - lastFpsNs >= 1_000_000_000L) {
            st.fps = frames
            frames = 0
            lastFpsNs = now
        }
    }
}

@SuppressLint("ViewConstructor")
class HoloGLView(ctx: Context, private val st: HoloState) : GLSurfaceView(ctx) {
    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean { st.reset(); return true }
    })
    private var lx = 0f
    private var ly = 0f
    private var ld = 0f
    private var lmx = 0f
    private var lmy = 0f

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        setRenderer(HoloRenderer(st, resources.displayMetrics.density))
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                st.touching = true
                lx = e.x; ly = e.y; ld = 0f
            }
            MotionEvent.ACTION_POINTER_DOWN -> ld = 0f
            MotionEvent.ACTION_POINTER_UP -> {
                ld = 0f
                val rem = if (e.actionIndex == 0) 1 else 0
                if (rem < e.pointerCount) { lx = e.getX(rem); ly = e.getY(rem) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1) {
                    val dx = e.x - lx
                    val dy = e.y - ly
                    st.rotY += dx * 0.4f
                    st.rotX = (st.rotX + dy * 0.4f).coerceIn(-89f, 89f)
                    lx = e.x; ly = e.y
                } else if (e.pointerCount >= 2) {
                    val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                    val mx = (e.getX(0) + e.getX(1)) / 2f
                    val my = (e.getY(0) + e.getY(1)) / 2f
                    if (ld <= 0f) {
                        ld = d; lmx = mx; lmy = my
                    } else {
                        st.scale = (st.scale * d / ld).coerceIn(0.3f, 4f)
                        st.panX = (st.panX + (mx - lmx) * st.pxToWorld).coerceIn(-3f, 3f)
                        st.panY = (st.panY - (my - lmy) * st.pxToWorld).coerceIn(-3f, 3f)
                        ld = d; lmx = mx; lmy = my
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> st.touching = false
        }
        return true
    }
}
