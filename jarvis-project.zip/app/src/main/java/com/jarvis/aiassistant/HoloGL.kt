// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Build
import android.os.Process
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Shared between the touch handler, the GL thread and the UI. Values are targets; the renderer smooths toward them. */
class HoloState {
    @Volatile var rotX = 20f
    @Volatile var rotY = -30f
    @Volatile var velX = 0f
    @Volatile var velY = 0f
    @Volatile var scale = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f
    @Volatile var inside = false
    @Volatile var autoSpin = true
    @Volatile var touching = false
    @Volatile var handActive = false
    @Volatile var gestureEnabled = true
    @Volatile var panScale = 2.4f
    @Volatile var pxToWorld = 0.005f
    @Volatile var panLimX = 0.7f
    @Volatile var panLimY = 1.2f
    @Volatile var frames = 0L
    @Volatile var rendered = false
    @Volatile var fps = 0
    @Volatile var error: String? = null

    fun reset() {
        rotX = 20f; rotY = -30f; scale = 1f; panX = 0f; panY = 0f; inside = false; velX = 0f; velY = 0f
    }
}

/** A range inside the single shared vertex buffer. Vertex layout: x y z size r g b a (8 floats, 32 bytes). */
private class Layer(val arr: FloatArray, val count: Int) { var first = 0 }

private class Builder(cap: Int) {
    private val a = FloatArray(cap * 8)
    private var n = 0
    fun add(x: Float, y: Float, z: Float, size: Float, r: Float, g: Float, b: Float, al: Float) {
        val o = n * 8
        a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = size
        a[o + 4] = r; a[o + 5] = g; a[o + 6] = b; a[o + 7] = al
        n++
    }
    fun build(): Layer = Layer(a, n)
}

private const val VERT = """
uniform mat4 uMvp;
uniform float uPx;
uniform float uMax;
attribute vec3 aPos;
attribute float aSize;
attribute vec4 aColor;
varying vec4 vColor;
void main() {
  vec4 p = uMvp * vec4(aPos, 1.0);
  gl_Position = p;
  gl_PointSize = clamp(aSize * uPx / max(p.w, 0.05), 1.0, uMax);
  vColor = aColor;
}
"""

private const val FRAG = """
precision mediump float;
varying vec4 vColor;
void main() {
  float r = length(gl_PointCoord - vec2(0.5));
  if (r > 0.5) discard;
  float a = 1.0 - smoothstep(0.0, 0.5, r);
  gl_FragColor = vec4(vColor.rgb, vColor.a * a);
}
"""

class HoloRenderer(private val st: HoloState, private val density: Float) : GLSurfaceView.Renderer {
    private var prog = 0
    private var vbo = 0
    private var aPos = 0
    private var aSize = 0
    private var aColor = 0
    private var uMvp = 0
    private var uPx = 0
    private var uMax = 0
    private var maxPoint = 48f
    /** Minimum time between frames in ns (0 = unlimited). Set by the view on high-refresh screens. */
    @Volatile var minFrameNs = 0L
    private var lastFrameStartNs = 0L

    private val all = ArrayList<Layer>()
    private var shell: Layer? = null
    private var mid: Layer? = null
    private var inner: Layer? = null
    private var coreCloud: Layer? = null
    private var glow: Layer? = null
    private var axes: Layer? = null
    private val rings = ArrayList<Layer>()
    private val ringTilt = arrayOf(floatArrayOf(70f, 0f), floatArrayOf(20f, 50f), floatArrayOf(-40f, -30f))
    private val ringSpeed = floatArrayOf(25f, -18f, 40f)

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private val mvp = FloatArray(16)

    // Smoothed values, targets, and an estimate of how fast each target is moving (used to look ahead).
    // Channels: 0 rotX, 1 rotY, 2 scale, 3 panX, 4 panY.
    private val cur = floatArrayOf(20f, -30f, 1f, 0f, 0f)
    private val tgt = FloatArray(5)
    private val prev = floatArrayOf(20f, -30f, 1f, 0f, 0f)
    private val vel = FloatArray(5)
    private val leadMax = floatArrayOf(20f, 25f, 0.25f, 0.4f, 0.4f)
    private var leadGain = 0f
    private var cRotX = 20f
    private var cRotY = -30f
    private var cScale = 1f
    private var cPanX = 0f
    private var cPanY = 0f
    private var cDist = 3.2f
    private var baseDist = 3.2f
    private var aspect = 1f
    private var viewW = 1
    private val tanHalf = 0.4663f // tan(25 degrees), fov = 50
    private var startNs = 0L
    private var lastNs = 0L
    private var frames = 0
    private var lastFpsNs = 0L

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader: $log")
        }
        return s
    }

    private fun reg(l: Layer): Layer { all.add(l); return l }

    private fun sphere(n: Int, radius: Float, jitter: Float, size: Float, seed: Long): Layer {
        val rnd = Random(seed)
        val b = Builder(n)
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val rr = sqrt(1f - y * y)
            val phi = i * 2.3999632f
            val rad = radius * (1f + (rnd.nextFloat() - 0.5f) * jitter)
            val t = rnd.nextFloat()
            val br = 0.25f + 0.75f * rnd.nextFloat().pow(2)
            b.add(cos(phi) * rr * rad, y * rad, sin(phi) * rr * rad, size,
                1f, 0.35f + 0.45f * t, 0.05f + 0.15f * t * t, br)
        }
        return reg(b.build())
    }

    private fun buildGeometry() {
        all.clear(); rings.clear()
        shell = sphere(5000, 1.0f, 0.06f, 2.4f, 1)
        mid = sphere(2200, 0.72f, 0.12f, 2.8f, 2)
        inner = sphere(1400, 0.45f, 0.15f, 3.2f, 3)

        val rnd = Random(4)
        val cc = Builder(500)
        for (i in 0 until 500) {
            var x: Float; var y: Float; var z: Float
            do {
                x = rnd.nextFloat() * 2 - 1; y = rnd.nextFloat() * 2 - 1; z = rnd.nextFloat() * 2 - 1
            } while (x * x + y * y + z * z > 1f)
            cc.add(x * 0.2f, y * 0.2f, z * 0.2f, 4f, 1f, 0.8f, 0.35f, 0.9f)
        }
        coreCloud = reg(cc.build())

        val g = Builder(3)
        g.add(0f, 0f, 0f, 150f, 1f, 0.55f, 0.1f, 0.35f)
        g.add(0f, 0f, 0f, 85f, 1f, 0.8f, 0.3f, 0.5f)
        g.add(0f, 0f, 0f, 40f, 1f, 0.95f, 0.7f, 0.85f)
        glow = reg(g.build())

        val ax = Builder(363)
        for (i in -60..60) {
            val t = i / 60f * 1.4f
            ax.add(t, 0f, 0f, 1.6f, 0.4f, 0.85f, 1f, 0.7f)
            ax.add(0f, t, 0f, 1.6f, 1f, 0.8f, 0.3f, 0.7f)
            ax.add(0f, 0f, t, 1.6f, 1f, 0.95f, 0.8f, 0.7f)
        }
        axes = reg(ax.build())

        val radii = floatArrayOf(1.25f, 1.12f, 0.9f)
        for (r in radii) {
            val rb = Builder(403)
            for (i in 0 until 400) {
                val a = i / 400f * 6.2831855f
                rb.add(cos(a) * r, sin(a) * r, 0f, 2.6f, 1f, 0.7f, 0.2f, 0.8f)
            }
            for (k in 0 until 3) {
                val a = k * 2.0944f
                rb.add(cos(a) * r, sin(a) * r, 0f, 9f, 1f, 0.9f, 0.6f, 0.95f)
            }
            rings.add(reg(rb.build()))
        }

        // One static vertex buffer for every layer: uploaded once, nothing is copied per frame.
        var total = 0
        for (l in all) { l.first = total; total += l.count }
        val fb = ByteBuffer.allocateDirect(total * 32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (l in all) fb.put(l.arr, 0, l.count * 8)
        fb.position(0)
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, total * 32, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER, VERT)
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAG)
            prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Link: " + GLES20.glGetProgramInfoLog(prog))
            aPos = GLES20.glGetAttribLocation(prog, "aPos")
            aSize = GLES20.glGetAttribLocation(prog, "aSize")
            aColor = GLES20.glGetAttribLocation(prog, "aColor")
            uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
            uPx = GLES20.glGetUniformLocation(prog, "uPx")
            uMax = GLES20.glGetUniformLocation(prog, "uMax")
            // The big glow sprites (150/85/40) need more than 48 px; use what this GPU allows.
            try {
                val r = FloatArray(2)
                GLES20.glGetFloatv(GLES20.GL_ALIASED_POINT_SIZE_RANGE, r, 0)
                maxPoint = r[1].coerceIn(48f, 480f)
            } catch (_: Throwable) { maxPoint = 48f }
            buildGeometry()
            st.error = null
        } catch (e: Exception) {
            st.error = e.message ?: "unknown GL error"
            prog = 0
        }
        // Render thread gets display priority so the detector's CPU threads cannot delay a frame.
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY) } catch (_: Throwable) {}
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        GLES20.glClearColor(0.02f, 0.043f, 0.078f, 1f)
        startNs = System.nanoTime()
        lastNs = startNs
        lastFpsNs = startNs
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewW = max(width, 1)
        aspect = width.toFloat() / max(height, 1)
        baseDist = max(3.0f, 1.35f / (tanHalf * aspect))
        st.panScale = 2f * baseDist * tanHalf * aspect
        st.panLimX = st.panScale * 0.5f
        st.panLimY = st.panScale * 0.5f / aspect
        Matrix.perspectiveM(proj, 0, 50f, aspect, 0.05f, 40f)
    }

    private fun drawLayer(l: Layer?, m: FloatArray) {
        if (l == null) return
        Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glDrawArrays(GLES20.GL_POINTS, l.first, l.count)
    }

    override fun onDrawFrame(gl: GL10?) {
        // setFrameRate() is only a hint, so also pace here: a 120 Hz screen would otherwise draw twice as often
        // and take GPU time away from the hand detector.
        val cap = minFrameNs
        if (cap > 0) {
            val el = System.nanoTime() - lastFrameStartNs
            if (el < cap - 1_000_000L) { try { Thread.sleep((cap - el) / 1_000_000L) } catch (_: InterruptedException) {} }
        }
        lastFrameStartNs = System.nanoTime()
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (prog == 0) return

        val nowNs = System.nanoTime()
        val dt = ((nowNs - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
        lastNs = nowNs

        // Momentum after a fist/touch release, otherwise idle spin. Time based, so it is the same at any frame rate.
        if (!st.touching && !st.handActive) {
            if (abs(st.velX) > 0.5f || abs(st.velY) > 0.5f) {
                st.rotY += st.velY * dt
                st.rotX = (st.rotX + st.velX * dt).coerceIn(-89f, 89f)
                val dec = exp(-dt * 2.2f)
                st.velX *= dec; st.velY *= dec
            } else {
                st.velX = 0f; st.velY = 0f
                if (st.autoSpin) st.rotY += 8f * dt
            }
        }
        // Time-constant smoothing with look-ahead. Hand results arrive in steps (30 per second) and are about one
        // frame old, so while the user drives the sphere we aim slightly ahead along the measured velocity.
        val driven = st.touching || st.handActive
        leadGain += ((if (driven) 1f else 0f) - leadGain) * (1f - exp(-dt / 0.08f))
        tgt[0] = st.rotX; tgt[1] = st.rotY; tgt[2] = st.scale; tgt[3] = st.panX; tgt[4] = st.panY
        val kv = 1f - exp(-dt / 0.04f)
        val tau = if (driven) 0.03f else 0.06f
        val k = 1f - exp(-dt / tau)
        for (i in 0 until 5) {
            val raw = (tgt[i] - prev[i]) / dt
            prev[i] = tgt[i]
            vel[i] += (raw - vel[i]) * kv
            val lead = (vel[i] * 0.04f * leadGain).coerceIn(-leadMax[i], leadMax[i])
            val v = cur[i] + (tgt[i] + lead - cur[i]) * k
            cur[i] = if (v.isFinite()) v else tgt[i]
        }
        cRotX = cur[0]; cRotY = cur[1]; cScale = cur[2].coerceIn(0.2f, 5f); cPanX = cur[3]; cPanY = cur[4]
        cDist += ((if (st.inside) 0.45f else baseDist) - cDist) * (1f - exp(-dt / 0.12f))
        st.pxToWorld = 2f * cDist * tanHalf * aspect / viewW

        val t = (nowNs - startNs) / 1e9f

        GLES20.glUseProgram(prog)
        GLES20.glUniform1f(uPx, density * 3f)
        GLES20.glUniform1f(uMax, maxPoint)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aSize)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 32, 0)
        GLES20.glVertexAttribPointer(aSize, 1, GLES20.GL_FLOAT, false, 32, 12)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_FLOAT, false, 32, 16)

        Matrix.setIdentityM(view, 0)
        Matrix.translateM(view, 0, cPanX, cPanY, -cDist)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, cScale, cScale, cScale)
        Matrix.rotateM(model, 0, cRotX, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, cRotY, 0f, 1f, 0f)

        drawLayer(axes, model)
        drawLayer(shell, model)

        System.arraycopy(model, 0, tmp, 0, 16)
        Matrix.rotateM(tmp, 0, t * 6f, 0f, 1f, 0.3f)
        drawLayer(mid, tmp)

        System.arraycopy(model, 0, tmp, 0, 16)
        Matrix.rotateM(tmp, 0, -t * 10f, 0.4f, 1f, 0f)
        drawLayer(inner, tmp)
        drawLayer(coreCloud, tmp)

        for (i in rings.indices) {
            System.arraycopy(model, 0, tmp, 0, 16)
            Matrix.rotateM(tmp, 0, ringTilt[i][0], 1f, 0f, 0f)
            Matrix.rotateM(tmp, 0, ringTilt[i][1], 0f, 1f, 0f)
            Matrix.rotateM(tmp, 0, t * ringSpeed[i], 0f, 0f, 1f)
            drawLayer(rings[i], tmp)
        }

        drawLayer(glow, model)

        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aSize)
        GLES20.glDisableVertexAttribArray(aColor)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        st.rendered = true
        st.frames++
        frames++
        if (nowNs - lastFpsNs >= 1_000_000_000L) {
            st.fps = frames
            frames = 0
            lastFpsNs = nowNs
        }
    }
}

@SuppressLint("ViewConstructor")
class HoloGLView(ctx: Context, private val st: HoloState) : GLSurfaceView(ctx) {
    private var renderer: HoloRenderer? = null
    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean { st.reset(); return true }
    })
    private var lx = 0f
    private var ly = 0f
    private var lt = 0L
    private var ld = 0f
    private var lmx = 0f
    private var lmy = 0f

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        val rnd = HoloRenderer(st, resources.displayMetrics.density)
        renderer = rnd
        setRenderer(rnd)
        try {
            val hz = (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.refreshRate
            if (hz > 70f) rnd.minFrameNs = 1_000_000_000L / 60L
        } catch (_: Throwable) {}
        preserveEGLContextOnPause = true
        renderMode = RENDERMODE_CONTINUOUSLY
        // Cap at 60 Hz: on a 120 Hz screen this halves GPU load, which the hand detector shares.
        holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) {
                if (Build.VERSION.SDK_INT >= 30) {
                    try { h.surface.setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT) } catch (_: Throwable) {}
                }
            }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) {}
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                st.touching = true
                st.velX = 0f; st.velY = 0f
                lx = e.x; ly = e.y; ld = 0f; lt = e.eventTime
            }
            MotionEvent.ACTION_POINTER_DOWN -> ld = 0f
            MotionEvent.ACTION_POINTER_UP -> {
                ld = 0f
                val rem = if (e.actionIndex == 0) 1 else 0
                if (rem < e.pointerCount) { lx = e.getX(rem); ly = e.getY(rem) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1) {
                    val dx = e.x - lx
                    val dy = e.y - ly
                    val dt = ((e.eventTime - lt) / 1000f).coerceIn(0.004f, 0.1f)
                    st.rotY += dx * 0.4f
                    st.rotX = (st.rotX + dy * 0.4f).coerceIn(-89f, 89f)
                    st.velY = (dx * 0.4f / dt).coerceIn(-400f, 400f) * 0.5f + st.velY * 0.5f
                    st.velX = (dy * 0.4f / dt).coerceIn(-400f, 400f) * 0.5f + st.velX * 0.5f
                    lx = e.x; ly = e.y; lt = e.eventTime
                } else if (e.pointerCount >= 2) {
                    st.velX = 0f; st.velY = 0f
                    val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                    val mx = (e.getX(0) + e.getX(1)) / 2f
                    val my = (e.getY(0) + e.getY(1)) / 2f
                    if (ld <= 0f) {
                        ld = d; lmx = mx; lmy = my
                    } else {
                        st.scale = (st.scale * d / ld).coerceIn(0.3f, 4f)
                        st.panX = (st.panX + (mx - lmx) * st.pxToWorld).coerceIn(-st.panLimX, st.panLimX)
                        st.panY = (st.panY - (my - lmy) * st.pxToWorld).coerceIn(-st.panLimY, st.panLimY)
                        ld = d; lmx = mx; lmy = my
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                st.touching = false
                if (e.eventTime - lt > 80) { st.velX = 0f; st.velY = 0f }
            }
        }
        return true
    }
}
