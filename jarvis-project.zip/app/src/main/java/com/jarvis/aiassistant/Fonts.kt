// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// Two families: Plus Jakarta Sans for titles and buttons (soft, rounded geometry), Inter for everything else.
// Inter is used with tabular figures (see MonoText) so live numbers do not jiggle when they change.

val BodyFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_regular, FontWeight.Medium),
    Font(R.font.inter_bold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold)
)

val TitleFont = FontFamily(
    Font(R.font.jakarta_medium, FontWeight.Normal),
    Font(R.font.jakarta_medium, FontWeight.Medium),
    Font(R.font.jakarta_bold, FontWeight.SemiBold),
    Font(R.font.jakarta_bold, FontWeight.Bold)
)

// Old names kept so every screen keeps compiling. They now all point at the two families above.
val MonoFont = BodyFont
val HudFont = TitleFont
val ChatFont = BodyFont
val UiFont = BodyFont

/** Width estimate of one character as a fraction of the font size (Inter tabular digits are about 0.62 em). */
const val MONO_ADVANCE = 0.66f

/** "STORED ON THIS DEVICE" -> "Stored on this device". Mixed-case text is returned untouched. */
fun String.soft(): String {
    if (isEmpty() || any { it.isLowerCase() }) return this
    val keep = mapOf("AI" to "AI", "TV" to "TV", "API" to "API", "GROQ" to "Groq", "ELEVENLABS" to "ElevenLabs", "RAM" to "RAM", "USR" to "You", "JRV" to "Jarvis", "GPT" to "GPT", "UI" to "UI")
    val words = lowercase().split(' ')
    val orig = split(' ')
    return words.mapIndexed { i, w ->
        val bare = orig[i].trim { !it.isLetterOrDigit() }
        val k = keep[bare]
        when {
            k != null -> orig[i].replace(bare, k)
            i == 0 -> w.replaceFirstChar { it.uppercase() }
            else -> w
        }
    }.joinToString(" ")
}
