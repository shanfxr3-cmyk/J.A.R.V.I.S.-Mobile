package com.jarvis.aiassistant

import android.graphics.Typeface
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

// Big titles: J.A.R.V.I.S. wordmark and screen headers.
val IronFont = FontFamily(Font(R.font.ironman_war, FontWeight.Normal))

// HUD labels, buttons, tabs and readouts.
val Stark = FontFamily(
    Font(R.font.stark, FontWeight.Normal),
    Font(R.font.stark_italic, FontWeight.Normal, FontStyle.Italic),
    Font(R.font.stark_bold, FontWeight.Bold),
    Font(R.font.stark_bold_italic, FontWeight.Bold, FontStyle.Italic)
)

// Outline accent, used only at larger sizes.
val StarkHollow = FontFamily(
    Font(R.font.stark_hollow, FontWeight.Normal),
    Font(R.font.stark_hollow_italic, FontWeight.Normal, FontStyle.Italic)
)

// Body text (chat, settings, descriptions). Android's built-in condensed
// sans: tighter and more technical than the default, and easy to read.
val BodyFont = FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))
