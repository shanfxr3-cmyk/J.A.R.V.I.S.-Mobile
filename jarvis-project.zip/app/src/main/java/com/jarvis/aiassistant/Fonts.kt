// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// Big titles: J.A.R.V.I.S. wordmark and screen headers (Orbitron).
val TitleFont = FontFamily(
    Font(R.font.orbitron_bold, FontWeight.Normal),
    Font(R.font.orbitron_extrabold, FontWeight.Bold)
)

// HUD labels, buttons, tabs and status lines (Space Grotesk).
val HudFont = FontFamily(
    Font(R.font.spacegrotesk_medium, FontWeight.Normal),
    Font(R.font.spacegrotesk_bold, FontWeight.Bold)
)

// Accent: wide subtitles such as "HOLOGRAPHIC CONTROL" (Michroma).
val AccentFont = FontFamily(Font(R.font.michroma_regular, FontWeight.Normal))

// Default body text and input fields (Inter).
val BodyFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_bold, FontWeight.Bold)
)

// Chat messages (Plus Jakarta Sans).
val ChatFont = FontFamily(
    Font(R.font.jakarta_medium, FontWeight.Normal),
    Font(R.font.jakarta_bold, FontWeight.Bold)
)

// Numbers, system values and timestamps (Space Mono).
val MonoFont = FontFamily(
    Font(R.font.spacemono_regular, FontWeight.Normal),
    Font(R.font.spacemono_bold, FontWeight.Bold)
)

// Settings descriptions and legal text (Roboto).
val UiFont = FontFamily(
    Font(R.font.roboto_regular, FontWeight.Normal),
    Font(R.font.roboto_bold, FontWeight.Bold)
)
