package com.jarvis.aiassistant

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// Big titles: J.A.R.V.I.S. wordmark and screen headers (Orbitron, wide and futuristic).
val TitleFont = FontFamily(
    Font(R.font.orbitron_extrabold, FontWeight.Normal),
    Font(R.font.orbitron_bold, FontWeight.Bold)
)

// HUD labels, buttons, tabs and status lines (Oswald, condensed).
val HudFont = FontFamily(
    Font(R.font.oswald_medium, FontWeight.Normal),
    Font(R.font.oswald_bold, FontWeight.Bold)
)

// Accent: numbers and subtitles (Russo One).
val AccentFont = FontFamily(Font(R.font.russo_one, FontWeight.Normal))

// Body text: chat, settings, descriptions (Oswald Regular).
val BodyFont = FontFamily(
    Font(R.font.oswald_regular, FontWeight.Normal),
    Font(R.font.oswald_bold, FontWeight.Bold)
)
