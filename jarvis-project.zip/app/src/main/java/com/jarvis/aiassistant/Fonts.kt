// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// The whole HUD uses two families only: Orbitron for titles and labels, Space Mono for everything else.
// Space Mono is fixed-width, so numbers and text never change size when their value changes.

// Numbers, body text, chat, inputs, timestamps, descriptions (Space Mono).
val MonoFont = FontFamily(
    Font(R.font.spacemono_regular, FontWeight.Normal),
    Font(R.font.spacemono_bold, FontWeight.Bold)
)

// Wordmark, screen headers, HUD labels, buttons, tabs (Orbitron).
val TitleFont = FontFamily(
    Font(R.font.orbitron_bold, FontWeight.Normal),
    Font(R.font.orbitron_extrabold, FontWeight.Bold)
)

val HudFont = TitleFont
val BodyFont = MonoFont
val ChatFont = MonoFont
val UiFont = MonoFont

/** Advance width of Space Mono as a fraction of the font size (612 / 1000 em). */
const val MONO_ADVANCE = 0.612f
