package com.jarvis.aiassistant.holo

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.asComposeRenderEffect

/** Post-process on the layer's own pixels: chromatic aberration, 8-tap glow, edge vignette. Static, no time uniform. */
private const val POST_AGSL = """
uniform shader content;
uniform float2 res;
uniform float aberr;
uniform float glowR;
uniform float glowK;
half4 main(float2 p) {
    float2 d = p / res - 0.5;
    float r2 = dot(d, d);
    float2 o = d * r2 * aberr * res;
    half4 c  = content.eval(p);
    half4 cr = content.eval(p + o);
    half4 cb = content.eval(p - o);
    half3 rgb = half3(cr.r, c.g, cb.b);
    half3 g = half3(0.0);
    g += content.eval(p + float2( glowR, 0.0)).rgb;
    g += content.eval(p + float2(-glowR, 0.0)).rgb;
    g += content.eval(p + float2(0.0,  glowR)).rgb;
    g += content.eval(p + float2(0.0, -glowR)).rgb;
    float k = glowR * 2.0;
    g += content.eval(p + float2( k, 0.0)).rgb * 0.5;
    g += content.eval(p + float2(-k, 0.0)).rgb * 0.5;
    g += content.eval(p + float2(0.0,  k)).rgb * 0.5;
    g += content.eval(p + float2(0.0, -k)).rgb * 0.5;
    rgb += g * glowK;
    float vig = 1.0 - smoothstep(0.30, 0.72, sqrt(r2));
    rgb *= half(0.55 + 0.45 * vig);
    half a = max(max(c.a, max(cr.a, cb.a)), max(rgb.r, max(rgb.g, rgb.b)));
    return half4(min(rgb, half3(a)), a);
}
"""

/** Animated overlay, drawn additively: moving scan band, scanline mask, cell-noise matrix, rare glitch bars. */
private const val OVERLAY_AGSL = """
uniform float2 res;
uniform float t;
uniform float k;
float h(float2 p) { return fract(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453); }
half4 main(float2 p) {
    float2 uv = p / res;
    float line = 0.5 + 0.5 * sin(p.y * 2.4);
    float a = 0.035 * line;
    float band = smoothstep(0.06, 0.0, abs(fract(uv.y - t * 0.12) - 0.5) - 0.44);
    a += 0.10 * band;
    float2 cell = floor(p / 3.0);
    float n = h(cell + floor(t * 20.0));
    a += step(0.985, n) * 0.22;
    float row = floor(uv.y * 24.0);
    float gl = step(0.965, h(float2(row, floor(t * 6.0))));
    a += gl * step(0.5, h(float2(row, 3.0))) * 0.10;
    a *= k;
    return half4(half3(0.0, 0.94, 1.0) * half(a), half(a));
}
"""

internal const val GLOW_R_DP = 1.6f

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class HoloFx {
    private val post = RuntimeShader(POST_AGSL)
    private val overlay = RuntimeShader(OVERLAY_AGSL)
    val overlayBrush = ShaderBrush(overlay)
    private var w = -1f
    private var h = -1f
    private var effect: androidx.compose.ui.graphics.RenderEffect? = null

    /** Rebuilds the RenderEffect only when the size changes (never per frame). */
    fun effect(width: Float, height: Float, density: Float): androidx.compose.ui.graphics.RenderEffect {
        val e = effect
        if (e != null && w == width && h == height) return e
        w = width; h = height
        post.setFloatUniform("res", width, height)
        post.setFloatUniform("aberr", 0.012f)
        post.setFloatUniform("glowR", GLOW_R_DP * density)
        post.setFloatUniform("glowK", 0.20f)
        val n = RenderEffect.createRuntimeShaderEffect(post, "content").asComposeRenderEffect()
        effect = n
        return n
    }

    fun overlayUniforms(width: Float, height: Float, time: Float, intensity: Float) {
        overlay.setFloatUniform("res", width, height)
        overlay.setFloatUniform("t", time)
        overlay.setFloatUniform("k", intensity)
    }
}
