package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Slider
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.sp

private val GROQ_MODELS = listOf(
    Triple("llama-3.3-70b-versatile", "Llama 3.3 70B Versatile", "Best all-round quality, 131K context."),
    Triple("llama-3.1-8b-instant", "Llama 3.1 8B Instant", "Fastest, highest free limits, short answers."),
    Triple("openai/gpt-oss-120b", "GPT-OSS 120B", "Large reasoning model, 131K context. Slower start."),
    Triple("openai/gpt-oss-20b", "GPT-OSS 20B", "Mid-size reasoning model, good for coding."),
    Triple("openai/gpt-oss-safeguard-20b", "GPT-OSS Safeguard 20B", "Safety-classification model, not for normal chat.")
)

@Composable
fun SettingsScreen(store: Store) {
    var name by remember { mutableStateOf(store.userName) }
    var confirmWipe by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var pico by remember { mutableStateOf(store.picoKey) }
    var sens by remember { mutableStateOf(store.wakeSens) }
    val ws = WakeService.state
    val wakeOn = ws != "OFF" && ws != "ERROR"
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            WakeService.start(ctx.applicationContext)
        } else {
            WakeService.error = "Microphone permission denied. Allow it in Android app settings."
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("SETTINGS", "J.A.R.V.I.S. v0.7.0")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("YOUR NAME", color = Cyan, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { store.setUser(name) }) { Text("Save") }
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("AI PROVIDER - GROQ", color = Cyan, fontSize = 13.sp)
                Text("Free key from console.groq.com. Stored on this device only and sent only to api.groq.com.", color = Dim, fontSize = 12.sp)
                OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API key") },
                    visualTransformation = PasswordVisualTransformation())
                Text("MODEL", color = Cyan, fontSize = 12.sp)
                GROQ_MODELS.forEach { (id, label, note) ->
                    HudButton(label, Modifier.fillMaxWidth(), model == id) { model = id; store.setAi(key, id); testMsg = "Model: $id" }
                    Text(note, color = Dim, fontSize = 11.sp)
                }
                OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model ID (or type a custom one)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { store.setAi(key, model); testMsg = "Saved." }) { Text("Save") }
                    Button(enabled = !testing && key.isNotBlank(), onClick = {
                        store.setAi(key, model)
                        testing = true; testMsg = "Testing..."
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try { Ai.stream(store.apiKey, store.model, "Reply with the single word OK.", listOf("user" to "ping")) {}; "Connected." }
                                catch (e: Exception) { e.message ?: "Failed." }
                            }
                            testMsg = r; testing = false
                        }
                    }) { Text("Save and test") }
                }
                testMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("VOICE", color = Cyan, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak AI replies aloud", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.speakReplies, { store.setSpeak(it) })
                }
                Text("Uses Android speech recognition (the Google app) and the phone's text-to-speech. The microphone is used while you press MIC or VOICE CHAT, or while the wake word is on.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("WAKE WORD - \"JARVIS\"", color = Cyan, fontSize = 13.sp)
                Text("Runs on the phone with Picovoice Porcupine. Needs a free AccessKey from console.picovoice.ai. While on, a notification shows and the microphone stays in use.", color = Dim, fontSize = 12.sp)
                OutlinedTextField(pico, { pico = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Picovoice AccessKey") },
                    visualTransformation = PasswordVisualTransformation())
                Text("Sensitivity ${(sens * 100).toInt()}% (higher hears more, but triggers by mistake more often)", color = Dim, fontSize = 11.sp)
                Slider(sens, { sens = it }, valueRange = 0.3f..0.95f)
                Text("STATUS: $ws", color = if (wakeOn) Green else if (ws == "ERROR") Amber else Dim, fontSize = 12.sp)
                WakeService.error?.let { Text(it, color = Amber, fontSize = 12.sp) }
                Button(enabled = wakeOn || pico.isNotBlank(), onClick = {
                    if (wakeOn) {
                        WakeService.stop(ctx.applicationContext)
                    } else {
                        store.setWake(pico, sens)
                        val need = ArrayList<String>()
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
                        if (need.isEmpty()) WakeService.start(ctx.applicationContext) else permLauncher.launch(need.toTypedArray())
                    }
                }) { Text(if (wakeOn) "Turn wake word OFF" else "Turn wake word ON") }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DATA", color = Cyan, fontSize = 13.sp)
                Text("All data stays on this device.", color = Dim, fontSize = 12.sp)
                TextButton(onClick = { confirmWipe = true }) { Text("Delete all app data") }
            }
        }
    }
    if (confirmWipe) {
        ConfirmDialog("Delete everything?", "Tasks, messages, activity and your name will be erased.", "Delete",
            { store.clearAll(); name = ""; confirmWipe = false }, { confirmWipe = false })
    }
}
