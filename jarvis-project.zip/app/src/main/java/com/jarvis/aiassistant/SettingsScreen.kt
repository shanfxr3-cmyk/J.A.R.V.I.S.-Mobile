package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(store: Store) {
    var name by remember { mutableStateOf(store.userName) }
    var confirmWipe by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("SETTINGS", "J.A.R.V.I.S. v0.6.0")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("YOUR NAME", color = Cyan, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { store.setUser(name) }) { Text("Save") }
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("AI PROVIDER - GROQ", color = Cyan, fontSize = 13.sp)
                Text("Free key from console.groq.com. Stored on this device only and sent only to api.groq.com.", color = Dim, fontSize = 12.sp)
                OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API key") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model") })
                Text("Faster, higher free limits: llama-3.1-8b-instant", color = Dim, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { store.setAi(key, model); testMsg = "Saved." }) { Text("Save") }
                    Button(enabled = !testing && key.isNotBlank(), onClick = {
                        store.setAi(key, model)
                        testing = true; testMsg = "Testing..."
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try { Ai.stream(store.apiKey, store.model, "Reply with the single word OK.", listOf("user" to "ping")) {}; "Connected." }
                                catch (e: Exception) { e.message ?: "Failed." }
                            }
                            testMsg = r; testing = false
                        }
                    }) { Text("Save and test") }
                }
                testMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("VOICE", color = Cyan, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak AI replies aloud", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.speakReplies, { store.setSpeak(it) })
                }
                Text("Uses Android speech recognition (the Google app) and the phone's text-to-speech. The microphone is used only while you press MIC or VOICE CHAT. Wake word is not available yet.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DATA", color = Cyan, fontSize = 13.sp)
                Text("All data stays on this device.", color = Dim, fontSize = 12.sp)
                TextButton(onClick = { confirmWipe = true }) { Text("Delete all app data") }
            }
        }
    }
    if (confirmWipe) {
        ConfirmDialog("Delete everything?", "Tasks, messages, activity and your name will be erased.", "Delete",
            { store.clearAll(); name = ""; confirmWipe = false }, { confirmWipe = false })
    }
}
