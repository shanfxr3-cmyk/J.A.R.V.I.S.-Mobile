// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private enum class SettingsPage { Profile, Ai, Voice, Wake, Always, Data }

private const val MSG_SAVED = "Saved."
private const val MSG_CONNECTED = "Connected."

private val GROQ_MODELS = listOf(
    Triple("openai/gpt-oss-120b", "GPT-OSS 120B", "Default. Best quality, 131K context. Slower start."),
    Triple("openai/gpt-oss-20b", "GPT-OSS 20B", "Faster, higher free limits, good for short voice answers.")
)

private fun statusColor(message: String) = if (message == MSG_CONNECTED || message == MSG_SAVED) Green else Amber

@Composable
private fun SettingsRow(icon: Ic, title: String, summary: String, onClick: () -> Unit) {
    HudCard(Modifier.fillMaxWidth(), onClick, pad = 11.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier.size(38.dp).background(Cyan.copy(alpha = 0.10f), shape).border(1.dp, Cyan.copy(alpha = 0.35f), shape),
                contentAlignment = Alignment.Center
            ) { HudIcon(icon, size = 20.dp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(summary, color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            HudIcon(Ic.Chevron, tint = Dim, size = 16.dp)
        }
    }
}

@Composable
private fun SubHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(36.dp).border(1.dp, Cyan.copy(alpha = 0.5f), CircleShape).background(Panel, CircleShape).clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { HudIcon(Ic.Back, size = 18.dp) }
        Spacer(Modifier.width(12.dp))
        Text(title, color = Cyan, fontSize = 18.sp, fontFamily = TitleFont, letterSpacing = 0.sp)
    }
}

@Composable
private fun Note(text: String) = Text(text, color = Dim, fontSize = 12.sp, fontFamily = UiFont)

@Composable
private fun CardTitle(text: String) =
    Text(text, color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)

@Composable
fun SettingsScreen(store: Store, nav: (Screen) -> Unit) {
    var page by rememberSaveable { mutableStateOf<SettingsPage?>(null) }
    BackHandler(enabled = page != null) { page = null }
    val back = { page = null }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (page) {
            null -> SettingsMenu(store, nav) { page = it }
            SettingsPage.Profile -> ProfilePage(store, back)
            SettingsPage.Ai -> AiProviderPage(store, back)
            SettingsPage.Voice -> VoicePage(store, back)
            SettingsPage.Wake -> WakeWordPage(store, back)
            SettingsPage.Always -> KeepRunningPage(store, back)
            SettingsPage.Data -> DataPage(back)
        }
    }
}

@Composable
private fun SettingsMenu(store: Store, nav: (Screen) -> Unit, open: (SettingsPage) -> Unit) {
    val hasFishVoice = store.fishKey.isNotBlank() && store.fishVoice.isNotBlank()
    ScreenHeader("SETTINGS", "J.A.R.V.I.S. v${BuildConfig.VERSION_NAME}")
    SectionTitle("ASSISTANT")
    SettingsRow(Ic.User, "Profile", store.userName.ifBlank { "Name not set" }) { open(SettingsPage.Profile) }
    SettingsRow(
        Ic.Key, "AI provider",
        (if (store.apiKey.isBlank()) "No key" else "Key set") + " - " + store.model.substringAfterLast('/')
    ) { open(SettingsPage.Ai) }
    SettingsRow(
        Ic.Voice, "Voice",
        (if (store.speakReplies) "Replies spoken" else "Replies silent") + " - " + (if (hasFishVoice) "Fish Audio" else "Phone voice")
    ) { open(SettingsPage.Voice) }
    SectionTitle("LISTENING")
    SettingsRow(Ic.Wake, "Wake word", "Hey Jarvis - " + WakeService.state.name.lowercase().replaceFirstChar { it.uppercase() }) { open(SettingsPage.Wake) }
    SettingsRow(Ic.Power, "Keep running 24/7", if (store.keepAlive) "Always-on is ON" else "Always-on is OFF") { open(SettingsPage.Always) }
    SectionTitle("APP")
    SettingsRow(Ic.Info, "About, legal and updates", "Version, updates, privacy policy, licences") { nav(Screen.About) }
    SettingsRow(Ic.Data, "Data and privacy", "Stored on this device. Delete everything.") { open(SettingsPage.Data) }
}

@Composable
private fun ProfilePage(store: Store, onBack: () -> Unit) {
    var name by remember { mutableStateOf(store.userName) }
    SubHeader("PROFILE", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Note("Jarvis uses this name when it talks to you.")
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudField(name, { name = it }, "Your name", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                HudBtn("Save") { store.setUser(name) }
            }
        }
    }
}

@Composable
private fun AiProviderPage(store: Store, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var message by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    SubHeader("AI PROVIDER", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CardTitle("GROQ")
            Note("Free key from console.groq.com. Stored on this device only and sent only to api.groq.com.")
            HudField(apiKey, { apiKey = it }, "API key", Modifier.fillMaxWidth(), secret = true)
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionTitle("MODEL")
            GROQ_MODELS.forEach { (id, label, note) ->
                HudButton(label, Modifier.fillMaxWidth(), model == id) { model = id; store.setAi(apiKey, id); message = "Model: $id" }
                Text(note, color = Dim, fontSize = 11.sp, fontFamily = UiFont)
            }
            HudField(model, { model = it }, "Model ID (or type a custom one)", Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                HudBtn("Save", Modifier.weight(1f), BtnKind.Outline) { store.setAi(apiKey, model); message = MSG_SAVED }
                HudBtn("Save & test", Modifier.weight(1f), enabled = !testing && apiKey.isNotBlank()) {
                    store.setAi(apiKey, model)
                    testing = true
                    message = "Testing..."
                    scope.launch {
                        message = withContext(Dispatchers.IO) {
                            try {
                                Ai.stream(store.apiKey, store.model, "Reply with the single word OK.", listOf("user" to "ping")) {}
                                MSG_CONNECTED
                            } catch (e: Exception) {
                                e.message ?: "Failed."
                            }
                        }
                        testing = false
                    }
                }
            }
            message?.let { Text(it, color = statusColor(it), fontSize = 12.sp) }
            store.keyWarning?.let { Text(it, color = Amber, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun VoicePage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var fishKey by remember { mutableStateOf(store.fishKey) }
    var fishVoice by remember { mutableStateOf(store.fishVoice) }
    var fishModel by remember { mutableStateOf(store.fishModel) }
    var message by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    SubHeader("VOICE", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speak AI replies aloud", Modifier.weight(1f), fontSize = 14.sp)
                HudSwitch(store.speakReplies) { store.setSpeak(it) }
            }
            Note("Uses Android speech recognition (the Google app) and the phone's text-to-speech. The microphone is used while you press MIC or VOICE CHAT, or while the wake word is on.")
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CardTitle("FISH AUDIO (OPTIONAL)")
            Note("Gives Jarvis a custom voice. Get an API key and a voice ID (from the voice's page URL) at fish.audio. Stored on this device only. If blank or it fails, the phone's built-in voice is used.")
            HudField(fishKey, { fishKey = it }, "Fish Audio API key", Modifier.fillMaxWidth(), secret = true)
            HudField(fishVoice, { fishVoice = it }, "Voice ID", Modifier.fillMaxWidth())
            SectionTitle("MODEL")
            FishTts.MODELS.forEach { (id, label, note) ->
                HudButton(label, Modifier.fillMaxWidth(), fishModel == id) { fishModel = id }
                Text(note, color = Dim, fontSize = 11.sp, fontFamily = UiFont)
            }
            HudField(fishModel, { fishModel = it }, "Model ID (or type a custom one)", Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                HudBtn("Save", Modifier.weight(1f), BtnKind.Outline) {
                    store.setFish(fishKey, fishVoice, fishModel)
                    Voice.resetFishFailure()
                    message = MSG_SAVED
                }
                HudBtn("Save & test", Modifier.weight(1.3f), enabled = !testing && fishKey.isNotBlank() && fishVoice.isNotBlank()) {
                    store.setFish(fishKey, fishVoice, fishModel)
                    Voice.resetFishFailure()
                    testing = true
                    message = "Testing..."
                    scope.launch {
                        message = withContext(Dispatchers.IO) {
                            val sample = File(ctx.cacheDir, "fish_test.mp3")
                            try {
                                FishTts.synth(store.fishKey, store.fishVoice, store.fishModel, "At your service.", sample)
                                MSG_CONNECTED
                            } catch (e: Exception) {
                                e.message ?: "Failed."
                            } finally {
                                sample.delete()
                            }
                        }
                        testing = false
                    }
                }
                HudBtn("Clear", Modifier.weight(1f), BtnKind.Danger) {
                    fishKey = ""
                    fishVoice = ""
                    fishModel = FishTts.DEFAULT_MODEL
                    store.setFish("", "", FishTts.DEFAULT_MODEL)
                    message = "Using the phone's voice."
                }
            }
            if (fishKey.isNotBlank() && fishVoice.isBlank()) {
                Text("A voice ID is also needed, otherwise the phone's voice is used.", color = Amber, fontSize = 12.sp)
            }
            message?.let { Text(it, color = statusColor(it), fontSize = 12.sp) }
        }
    }
}

@Composable
private fun WakeWordPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appContext = ctx.applicationContext
    var sensitivity by remember { mutableStateOf(store.wakeSens) }
    val state = WakeService.state
    val wakeOn = state != WakeState.OFF && state != WakeState.ERROR

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true || KeepAlive.micGranted(ctx)) {
            WakeService.start(appContext)
        } else {
            WakeService.error = "Microphone permission denied. Allow it in Android app settings."
        }
    }

    SubHeader("WAKE WORD", onBack)
    HudCard(Modifier.fillMaxWidth(), accent = if (wakeOn) Green else Cyan) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "STATUS: ${state.name}",
                color = when {
                    wakeOn -> Green
                    state == WakeState.ERROR -> Amber
                    else -> Dim
                },
                fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
            WakeService.error?.let { Text(it, color = Amber, fontSize = 12.sp) }
            if (store.initFails >= 3) {
                Text("Wake word gave up after ${store.initFails} failed starts. Fix the cause above, then turn it on again.", color = Amber, fontSize = 12.sp)
            }
            HudBtn(
                if (wakeOn) "Turn wake word OFF" else "Turn wake word ON", Modifier.fillMaxWidth(),
                if (wakeOn) BtnKind.Outline else BtnKind.Primary
            ) {
                if (wakeOn) {
                    WakeService.stop(appContext)
                } else {
                    store.setWake(sensitivity)
                    val missing = buildList {
                        if (!KeepAlive.micGranted(ctx)) add(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    if (missing.isEmpty()) WakeService.start(appContext) else permissionLauncher.launch(missing.toTypedArray())
                }
            }
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            CardTitle("SENSITIVITY ${(sensitivity * 100).toInt()}%")
            Note("Higher hears more, but triggers by mistake more often.")
            Slider(
                sensitivity, { sensitivity = it }, valueRange = 0.3f..0.9f,
                onValueChangeFinished = { store.setWake(sensitivity); WakeService.applySensitivity(sensitivity) }
            )
        }
    }
    HudCard(Modifier.fillMaxWidth()) {
        Note("Runs on the phone with openWakeWord (free, open source, no account or key). A small model (about 3 MB) downloads once the first time you turn it on. While on, a notification shows and the microphone stays in use.")
    }
}

@Composable
private fun KeepRunningPage(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appContext = ctx.applicationContext
    var unrestricted by remember { mutableStateOf(Power.ignoringBattery(ctx)) }
    var showChecklist by remember { mutableStateOf(false) }
    LaunchWhileStarted {
        while (true) {
            unrestricted = Power.ignoringBattery(ctx)
            delay(2000)
        }
    }

    SubHeader("KEEP RUNNING 24/7", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Always-on mode", Modifier.weight(1f), fontSize = 14.sp)
                HudSwitch(store.keepAlive) { enabled ->
                    store.markKeepAlive(enabled)
                    if (!enabled) KeepAlive.cancel(appContext)
                    else if (store.wakeWanted) KeepAlive.schedule(appContext, 60_000)
                    WakeService.applyKeepAlive()   // take or drop the wake lock right now
                }
            }
            Note("Keeps \"Hey Jarvis\" listening with the screen off. It uses a permanent notification, holds the CPU awake, and a watchdog brings the listener back if Android stops it. Expect extra battery use.")
        }
    }
    HudCard(Modifier.fillMaxWidth(), accent = if (unrestricted) Green else Amber) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (unrestricted) "BATTERY: UNRESTRICTED" else "BATTERY: RESTRICTED (Android may kill the listener)",
                color = if (unrestricted) Green else Amber, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp
            )
            HudBtn("Allow unrestricted battery", Modifier.fillMaxWidth()) { Power.requestIgnoreBattery(ctx) }
            HudBtn("Autostart / app launch settings", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAutostart(ctx) }
            HudBtn("Open app settings", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }
        }
    }
    HudCard(Modifier.fillMaxWidth(), onClick = { showChecklist = !showChecklist }) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Poco / Xiaomi (HyperOS) checklist", Modifier.weight(1f), color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (showChecklist) "HIDE" else "SHOW", color = Dim, fontSize = 11.sp, fontFamily = HudFont)
            }
            if (showChecklist) {
                Note("1. Tap Allow unrestricted battery.\n2. Open Autostart and switch Jarvis ON.\n3. App settings, Battery saver, set No restrictions.\n4. In Recents, long-press the Jarvis card and tap the lock.\n5. Keep notifications allowed.")
                Note("After a phone restart (and sometimes after Android kills the app) Android blocks apps from starting the microphone on their own, so Jarvis cannot always restart itself. It shows a quiet \"Resume\" notification instead: tap it once and the listener is back.")
            }
        }
    }
    if (!KeepAlive.notificationsOn(ctx)) {
        HudCard(Modifier.fillMaxWidth(), accent = Amber) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "NOTIFICATIONS ARE OFF: you will not see the Resume prompt, so the listener will stay off after a restart until you open the app.",
                    color = Amber, fontFamily = HudFont, fontSize = 12.sp
                )
                HudBtn("Allow notifications", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }
            }
        }
    }
}

@Composable
private fun DataPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var confirmWipe by remember { mutableStateOf(false) }

    SubHeader("DATA AND PRIVACY", onBack)
    HudCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Note("Everything is stored on this device. Messages you send to the AI go to Groq, spoken replies go to Fish Audio if you set it up, and speech recognition may use Google. See the Privacy Policy.")
            HudBtn("Delete all app data", Modifier.fillMaxWidth(), BtnKind.Danger) { confirmWipe = true }
        }
    }
    if (confirmWipe) {
        ConfirmDialog(
            "Delete everything?",
            "Tasks, messages, activity, API keys, downloaded models and settings will be erased and the listener will stop.",
            "Delete",
            {
                val appContext = ctx.applicationContext
                // Stop the microphone first so nothing keeps listening after the data is gone.
                WakeService.stop(appContext)
                WakeService.error = null
                Store.get(appContext).clearAll()
                runCatching {
                    File(ctx.filesDir, "oww").deleteRecursively()
                    ctx.cacheDir.deleteRecursively()
                }
                Secrets.deleteKey()
                confirmWipe = false
            },
            { confirmWipe = false }
        )
    }
}
