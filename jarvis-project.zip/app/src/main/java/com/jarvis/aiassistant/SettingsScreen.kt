package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(store: Store) {
    var name by remember { mutableStateOf(store.userName) }
    var confirmWipe by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("SETTINGS", "J.A.R.V.I.S. v0.4.0")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("YOUR NAME", color = Cyan, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { store.setUser(name) }) { Text("Save") }
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("AI PROVIDER", color = Cyan, fontSize = 13.sp)
                Text("Not configured. Provider setup arrives in Phase 6. No API key is stored in this app.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("VOICE / WAKE WORD", color = Cyan, fontSize = 13.sp)
                Text("Not available yet (Phase 6). The app does not use the microphone.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DATA", color = Cyan, fontSize = 13.sp)
                Text("All data stays on this device.", color = Dim, fontSize = 12.sp)
                TextButton(onClick = { confirmWipe = true }) { Text("Delete all app data") }
            }
        }
    }
    if (confirmWipe) {
        ConfirmDialog("Delete everything?", "Tasks, messages, activity and your name will be erased.", "Delete",
            { store.clearAll(); name = ""; confirmWipe = false }, { confirmWipe = false })
    }
}
