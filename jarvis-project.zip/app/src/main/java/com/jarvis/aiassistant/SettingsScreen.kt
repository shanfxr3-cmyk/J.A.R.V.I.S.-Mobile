// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.Slider
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.sp

private val GROQ_MODELS = listOf(
    Triple("openai/gpt-oss-120b", "GPT-OSS 120B", "Default. Best quality, 131K context. Slower start."),
    Triple("openai/gpt-oss-20b", "GPT-OSS 20B", "Faster, higher free limits, good for short voice answers.")
)

@Composable
private fun SettingsRow(ic: Ic, title: String, summary: String, onClick: () -> Unit) {
    HudCard(Modifier.fillMaxWidth(), onClick, pad = 11.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val sh = RoundedCornerShape(10.dp)
            Box(Modifier.size(38.dp).background(Cyan.copy(alpha = 0.10f), sh).border(1.dp, Cyan.copy(alpha = 0.35f), sh), contentAlignment = Alignment.Center) {
                HudIcon(ic, size = 20.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(summary, color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            HudIcon(Ic.Chevron, tint = Dim, size = 16.dp)
        }
    }
}

@Composable
private fun SubHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(36.dp).border(1.dp, Cyan.copy(alpha = 0.5f), CircleShape).background(Panel, CircleShape).clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { HudIcon(Ic.Back, size = 18.dp) }
        Spacer(Modifier.width(12.dp))
        Text(title, color = Cyan, fontSize = 18.sp, fontFamily = TitleFont, letterSpacing = 0.sp)
    }
}

@Composable
private fun Note(text: String) = Text(text, color = Dim, fontSize = 12.sp, fontFamily = UiFont)

@Composable
fun SettingsScreen(store: Store, nav: (Screen) -> Unit) {
    var name by remember { mutableStateOf(store.userName) }
    var confirmWipe by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var fKey by remember { mutableStateOf(store.fishKey) }
    var fVoice by remember { mutableStateOf(store.fishVoice) }
    var fModel by remember { mutableStateOf(store.fishModel) }
    var fMsg by remember { mutableStateOf<String?>(null) }
    var fTesting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var sens by remember { mutableStateOf(store.wakeSens) }
    val ws = WakeService.state
    val wakeOn = ws != "OFF" && ws != "ERROR"
    var page by rememberSaveable { mutableStateOf("") }
    BackHandler(enabled = page.isNotEmpty()) { page = "" }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            WakeService.start(ctx.applicationContext)
        } else {
            WakeService.error = "Microphone permission denied. Allow it in Android app settings."
        }
    }

    androidx.compose.runtime.key(page) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (page) {
            "" -> {
                ScreenHeader("SETTINGS", "J.A.R.V.I.S. v${BuildConfig.VERSION_NAME}")
                SectionTitle("ASSISTANT")
                SettingsRow(Ic.User, "Profile", if (store.userName.isBlank()) "Name not set" else store.userName) { page = "profile" }
                SettingsRow(Ic.Key, "AI provider", (if (store.apiKey.isBlank()) "No key" else "Key set") + " - " + store.model.substringAfterLast('/')) { page = "ai" }
                SettingsRow(Ic.Voice, "Voice", (if (store.speakReplies) "Replies spoken" else "Replies silent") + " - " + (if (store.fishKey.isNotBlank() && store.fishVoice.isNotBlank()) "Fish Audio" else "Phone voice")) { page = "voice" }
                SectionTitle("LISTENING")
                SettingsRow(Ic.Wake, "Wake word", "Hey Jarvis - " + ws.lowercase().replaceFirstChar { it.uppercase() }) { page = "wake" }
                SettingsRow(Ic.Power, "Keep running 24/7", if (store.keepAlive) "Always-on is ON" else "Always-on is OFF") { page = "always" }
                SectionTitle("APP")
                SettingsRow(Ic.Info, "About, legal and updates", "Version, updates, privacy policy, licences") { nav(Screen.About) }
                SettingsRow(Ic.Data, "Data and privacy", "Stored on this device. Delete everything.") { page = "data" }
            }

            "profile" -> {
                SubHeader("PROFILE") { page = "" }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Note("Jarvis uses this name when it talks to you.")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HudField(name, { name = it }, "Your name", Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            HudBtn("Save") { store.setUser(name) }
                        }
                    }
                }
            }

            "ai" -> {
                SubHeader("AI PROVIDER") { page = "" }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("GROQ", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Note("Free key from console.groq.com. Stored on this device only and sent only to api.groq.com.")
                        HudField(key, { key = it }, "API key", Modifier.fillMaxWidth(), secret = true)
                    }
                }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle("MODEL")
                        GROQ_MODELS.forEach { (id, label, note) ->
                            HudButton(label, Modifier.fillMaxWidth(), model == id) { model = id; store.setAi(key, id); testMsg = "Model: $id" }
                            Text(note, color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                        }
                        HudField(model, { model = it }, "Model ID (or type a custom one)", Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            HudBtn("Save", Modifier.weight(1f), BtnKind.Outline) { store.setAi(key, model); testMsg = "Saved." }
                            HudBtn("Save & test", Modifier.weight(1f), enabled = !testing && key.isNotBlank()) {
                                store.setAi(key, model)
                                testing = true; testMsg = "Testing..."
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) {
                                        try { Ai.stream(store.apiKey, store.model, "Reply with the single word OK.", listOf("user" to "ping")) {}; "Connected." }
                                        catch (e: Exception) { e.message ?: "Failed." }
                                    }
                                    testMsg = r; testing = false
                                }
                            }
                        }
                        testMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
                        store.keyWarning?.let { Text(it, color = Amber, fontSize = 12.sp) }
                    }
                }
            }

            "voice" -> {
                SubHeader("VOICE") { page = "" }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Speak AI replies aloud", Modifier.weight(1f), fontSize = 14.sp)
                            HudSwitch(store.speakReplies) { store.setSpeak(it) }
                        }
                        Note("Uses Android speech recognition (the Google app) and the phone's text-to-speech. The microphone is used while you press MIC or VOICE CHAT, or while the wake word is on.")
                    }
                }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("FISH AUDIO (OPTIONAL)", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Note("Gives Jarvis a custom voice. Get an API key and a voice ID (from the voice's page URL) at fish.audio. Stored on this device only. If blank or it fails, the phone's built-in voice is used.")
                        HudField(fKey, { fKey = it }, "Fish Audio API key", Modifier.fillMaxWidth(), secret = true)
                        HudField(fVoice, { fVoice = it }, "Voice ID", Modifier.fillMaxWidth())
                        SectionTitle("MODEL")
                        FishTts.MODELS.forEach { (id, label, note) ->
                            HudButton(label, Modifier.fillMaxWidth(), fModel == id) { fModel = id }
                            Text(note, color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                        }
                        HudField(fModel, { fModel = it }, "Model ID (or type a custom one)", Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            HudBtn("Save", Modifier.weight(1f), BtnKind.Outline) { store.setFish(fKey, fVoice, fModel); Voice.resetFishFailure(); fMsg = "Saved." }
                            HudBtn("Save & test", Modifier.weight(1.3f), enabled = !fTesting && fKey.isNotBlank() && fVoice.isNotBlank()) {
                                store.setFish(fKey, fVoice, fModel)
                                Voice.resetFishFailure()
                                fTesting = true; fMsg = "Testing..."
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) {
                                        try {
                                            val f = java.io.File(ctx.cacheDir, "fish_test.mp3")
                                            try { FishTts.synth(store.fishKey, store.fishVoice, store.fishModel, "At your service.", f) } finally { f.delete() }
                                            "Connected."
                                        } catch (e: Exception) { e.message ?: "Failed." }
                                    }
                                    fMsg = r; fTesting = false
                                }
                            }
                            HudBtn("Clear", Modifier.weight(1f), BtnKind.Danger) {
                                fKey = ""; fVoice = ""; fModel = FishTts.DEFAULT_MODEL; store.setFish("", "", FishTts.DEFAULT_MODEL); fMsg = "Using the phone's voice."
                            }
                        }
                        if (fKey.isNotBlank() && fVoice.isBlank()) Text("A voice ID is also needed, otherwise the phone's voice is used.", color = Amber, fontSize = 12.sp)
                        fMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
                    }
                }
            }

            "wake" -> {
                SubHeader("WAKE WORD") { page = "" }
                HudCard(Modifier.fillMaxWidth(), accent = if (wakeOn) Green else Cyan) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("STATUS: $ws", color = if (wakeOn) Green else if (ws == "ERROR") Amber else Dim, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        WakeService.error?.let { Text(it, color = Amber, fontSize = 12.sp) }
                        if (store.initFails >= 3) Text("Wake word gave up after ${store.initFails} failed starts. Fix the cause above, then turn it on again.", color = Amber, fontSize = 12.sp)
                        HudBtn(if (wakeOn) "Turn wake word OFF" else "Turn wake word ON", Modifier.fillMaxWidth(), if (wakeOn) BtnKind.Outline else BtnKind.Primary) {
                            if (wakeOn) {
                                WakeService.stop(ctx.applicationContext)
                            } else {
                                store.setWake(sens)
                                val need = ArrayList<String>()
                                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
                                if (need.isEmpty()) WakeService.start(ctx.applicationContext) else permLauncher.launch(need.toTypedArray())
                            }
                        }
                    }
                }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("SENSITIVITY ${(sens * 100).toInt()}%", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Note("Higher hears more, but triggers by mistake more often.")
                        Slider(sens, { sens = it }, valueRange = 0.3f..0.9f, onValueChangeFinished = { store.setWake(sens); WakeService.applySensitivity(sens) })
                    }
                }
                HudCard(Modifier.fillMaxWidth()) {
                    Note("Runs on the phone with openWakeWord (free, open source, no account or key). A small model (about 3 MB) downloads once the first time you turn it on. While on, a notification shows and the microphone stays in use.")
                }
            }

            "always" -> {
                SubHeader("KEEP RUNNING 24/7") { page = "" }
                var unrestricted by remember { mutableStateOf(Power.ignoringBattery(ctx)) }
                var showList by remember { mutableStateOf(false) }
                LaunchWhileStarted {
                    while (true) {
                        unrestricted = Power.ignoringBattery(ctx)
                        delay(2000)
                    }
                }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Always-on mode", Modifier.weight(1f), fontSize = 14.sp)
                            HudSwitch(store.keepAlive) {
                                store.markKeepAlive(it)
                                if (!it) KeepAlive.cancel(ctx.applicationContext)
                                else if (store.wakeWanted) KeepAlive.schedule(ctx.applicationContext, 60_000)
                                WakeService.applyKeepAlive()   // take or drop the wake lock right now
                            }
                        }
                        Note("Keeps \"Hey Jarvis\" listening with the screen off. It uses a permanent notification, holds the CPU awake, and a watchdog brings the listener back if Android stops it. Expect extra battery use.")
                    }
                }
                HudCard(Modifier.fillMaxWidth(), accent = if (unrestricted) Green else Amber) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            if (unrestricted) "BATTERY: UNRESTRICTED" else "BATTERY: RESTRICTED (Android may kill the listener)",
                            color = if (unrestricted) Green else Amber, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp
                        )
                        HudBtn("Allow unrestricted battery", Modifier.fillMaxWidth()) { Power.requestIgnoreBattery(ctx) }
                        HudBtn("Autostart / app launch settings", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAutostart(ctx) }
                        HudBtn("Open app settings", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }
                    }
                }
                HudCard(Modifier.fillMaxWidth(), onClick = { showList = !showList }) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Poco / Xiaomi (HyperOS) checklist", Modifier.weight(1f), color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(if (showList) "HIDE" else "SHOW", color = Dim, fontSize = 11.sp, fontFamily = HudFont)
                        }
                        if (showList) {
                            Note("1. Tap Allow unrestricted battery.\n2. Open Autostart and switch Jarvis ON.\n3. App settings, Battery saver, set No restrictions.\n4. In Recents, long-press the Jarvis card and tap the lock.\n5. Keep notifications allowed.")
                            Note("After a phone restart (and sometimes after Android kills the app) Android blocks apps from starting the microphone on their own, so Jarvis cannot always restart itself. It shows a quiet \"Resume\" notification instead: tap it once and the listener is back.")
                        }
                    }
                }
                if (!KeepAlive.notificationsOn(ctx)) {
                    HudCard(Modifier.fillMaxWidth(), accent = Amber) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("NOTIFICATIONS ARE OFF: you will not see the Resume prompt, so the listener will stay off after a restart until you open the app.", color = Amber, fontFamily = HudFont, fontSize = 12.sp)
                            HudBtn("Allow notifications", Modifier.fillMaxWidth(), BtnKind.Outline) { Power.openAppSettings(ctx) }
                        }
                    }
                }
            }

            "data" -> {
                SubHeader("DATA AND PRIVACY") { page = "" }
                HudCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Note("Everything is stored on this device. Messages you send to the AI go to Groq, spoken replies go to Fish Audio if you set it up, and speech recognition may use Google. See the Privacy Policy.")
                        HudBtn("Delete all app data", Modifier.fillMaxWidth(), BtnKind.Danger) { confirmWipe = true }
                    }
                }
            }
        }
    }
    }
    if (confirmWipe) {
        ConfirmDialog("Delete everything?", "Tasks, messages, activity, API keys, downloaded models and settings will be erased and the listener will stop.", "Delete",
            {
                // Stop the microphone first so nothing keeps listening after the data is gone.
                WakeService.stop(ctx.applicationContext)
                WakeService.error = null
                store.clearAll()
                ctx.getSharedPreferences("trk", android.content.Context.MODE_PRIVATE).edit().clear().apply()
                try {
                    java.io.File(ctx.filesDir, "oww").deleteRecursively()
                    ctx.cacheDir.deleteRecursively()
                } catch (_: Throwable) {}
                Secrets.deleteKey()
                name = ""; key = ""; model = DEFAULT_MODEL; testMsg = null
                fKey = ""; fVoice = ""; fModel = FishTts.DEFAULT_MODEL; fMsg = null
                sens = 0.5f
                confirmWipe = false
            }, { confirmWipe = false })
    }
}
