// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Slider
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.sp

private val GROQ_MODELS = listOf(
    Triple("openai/gpt-oss-120b", "GPT-OSS 120B", "Default. Best quality, 131K context. Slower start."),
    Triple("openai/gpt-oss-20b", "GPT-OSS 20B", "Faster, higher free limits, good for short voice answers.")
)

@Composable
fun SettingsScreen(store: Store, nav: (Screen) -> Unit) {
    var name by remember { mutableStateOf(store.userName) }
    var confirmWipe by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var fKey by remember { mutableStateOf(store.fishKey) }
    var fVoice by remember { mutableStateOf(store.fishVoice) }
    var fModel by remember { mutableStateOf(store.fishModel) }
    var fMsg by remember { mutableStateOf<String?>(null) }
    var fTesting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var sens by remember { mutableStateOf(store.wakeSens) }
    val ws = WakeService.state
    val wakeOn = ws != "OFF" && ws != "ERROR"
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            WakeService.start(ctx.applicationContext)
        } else {
            WakeService.error = "Microphone permission denied. Allow it in Android app settings."
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("SETTINGS", "J.A.R.V.I.S. v${BuildConfig.VERSION_NAME}")
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("YOUR NAME", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { store.setUser(name) }) { Text("Save") }
                }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("AI PROVIDER - GROQ", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Free key from console.groq.com. Stored on this device only and sent only to api.groq.com.", color = Dim, fontSize = 12.sp)
                OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API key") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                Text("MODEL", color = Cyan, fontFamily = HudFont, fontSize = 12.sp)
                GROQ_MODELS.forEach { (id, label, note) ->
                    HudButton(label, Modifier.fillMaxWidth(), model == id) { model = id; store.setAi(key, id); testMsg = "Model: $id" }
                    Text(note, color = Dim, fontSize = 11.sp)
                }
                OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model ID (or type a custom one)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { store.setAi(key, model); testMsg = "Saved." }) { Text("Save") }
                    Button(enabled = !testing && key.isNotBlank(), onClick = {
                        store.setAi(key, model)
                        testing = true; testMsg = "Testing..."
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try { Ai.stream(store.apiKey, store.model, "Reply with the single word OK.", listOf("user" to "ping")) {}; "Connected." }
                                catch (e: Exception) { e.message ?: "Failed." }
                            }
                            testMsg = r; testing = false
                        }
                    }) { Text("Save and test") }
                }
                testMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
                store.keyWarning?.let { Text(it, color = Amber, fontSize = 12.sp) }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("JARVIS VOICE - FISH AUDIO", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Optional. Gives Jarvis a custom voice. Get an API key and a voice ID (from the voice's page URL) at fish.audio. Stored on this device only. If blank or it fails, the phone's built-in voice is used.", color = Dim, fontSize = 12.sp)
                OutlinedTextField(fKey, { fKey = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Fish Audio API key") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                OutlinedTextField(fVoice, { fVoice = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Voice ID") })
                Text("MODEL", color = Cyan, fontFamily = HudFont, fontSize = 12.sp)
                FishTts.MODELS.forEach { (id, label, note) ->
                    HudButton(label, Modifier.fillMaxWidth(), fModel == id) { fModel = id }
                    Text(note, color = Dim, fontSize = 11.sp)
                }
                OutlinedTextField(fModel, { fModel = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model ID (or type a custom one)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { store.setFish(fKey, fVoice, fModel); Voice.resetFishFailure(); fMsg = "Saved." }) { Text("Save") }
                    Button(enabled = !fTesting && fKey.isNotBlank() && fVoice.isNotBlank(), onClick = {
                        store.setFish(fKey, fVoice, fModel)
                        Voice.resetFishFailure()
                        fTesting = true; fMsg = "Testing..."
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try {
                                    val f = java.io.File(ctx.cacheDir, "fish_test.mp3")
                                    try { FishTts.synth(store.fishKey, store.fishVoice, store.fishModel, "At your service.", f) } finally { f.delete() }
                                    "Connected."
                                } catch (e: Exception) { e.message ?: "Failed." }
                            }
                            fMsg = r; fTesting = false
                        }
                    }) { Text("Save and test") }
                    TextButton(onClick = { fKey = ""; fVoice = ""; fModel = FishTts.DEFAULT_MODEL; store.setFish("", "", FishTts.DEFAULT_MODEL); fMsg = "Using the phone's voice." }) { Text("Clear") }
                }
                if (fKey.isNotBlank() && fVoice.isBlank()) Text("A voice ID is also needed, otherwise the phone's voice is used.", color = Amber, fontSize = 12.sp)
                fMsg?.let { Text(it, color = if (it == "Connected." || it == "Saved.") Green else Amber, fontSize = 12.sp) }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("VOICE", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak AI replies aloud", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.speakReplies, { store.setSpeak(it) })
                }
                Text("Uses Android speech recognition (the Google app) and the phone's text-to-speech. The microphone is used while you press MIC or VOICE CHAT, or while the wake word is on.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("WAKE WORD - \"HEY JARVIS\"", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Runs on the phone with openWakeWord (free, open source, no account or key). A small model (about 3 MB) downloads once the first time you turn it on. While on, a notification shows and the microphone stays in use.", color = Dim, fontSize = 12.sp)
                Text("Sensitivity ${(sens * 100).toInt()}% (higher hears more, but triggers by mistake more often)", color = Dim, fontSize = 11.sp)
                Slider(sens, { sens = it }, valueRange = 0.3f..0.9f, onValueChangeFinished = { store.setWake(sens); WakeService.applySensitivity(sens) })
                Text("STATUS: $ws", color = if (wakeOn) Green else if (ws == "ERROR") Amber else Dim, fontSize = 12.sp)
                WakeService.error?.let { Text(it, color = Amber, fontSize = 12.sp) }
                if (store.initFails >= 3) Text("Wake word gave up after ${store.initFails} failed starts. Fix the cause above, then turn it on again.", color = Amber, fontSize = 12.sp)
                Button(onClick = {
                    if (wakeOn) {
                        WakeService.stop(ctx.applicationContext)
                    } else {
                        store.setWake(sens)
                        val need = ArrayList<String>()
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
                        if (need.isEmpty()) WakeService.start(ctx.applicationContext) else permLauncher.launch(need.toTypedArray())
                    }
                }) { Text(if (wakeOn) "Turn wake word OFF" else "Turn wake word ON") }
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("KEEP RUNNING 24/7", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Always-on mode", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(store.keepAlive, {
                        store.markKeepAlive(it)
                        if (!it) KeepAlive.cancel(ctx.applicationContext)
                        else if (store.wakeWanted) KeepAlive.schedule(ctx.applicationContext, 60_000)
                        WakeService.applyKeepAlive()   // take or drop the wake lock right now
                    })
                }
                Text("Keeps \"Hey Jarvis\" listening with the screen off. It uses a permanent notification, holds the CPU awake, and a watchdog brings the listener back if Android stops it. Expect extra battery use.", color = Dim, fontSize = 12.sp)
                var unrestricted by remember { mutableStateOf(Power.ignoringBattery(ctx)) }
                LaunchWhileStarted {
                    while (true) {
                        unrestricted = Power.ignoringBattery(ctx)
                        delay(2000)
                    }
                }
                Text(
                    if (unrestricted) "BATTERY: UNRESTRICTED" else "BATTERY: RESTRICTED (Android may kill the listener)",
                    color = if (unrestricted) Green else Amber, fontFamily = HudFont, fontSize = 12.sp
                )
                Button(onClick = { Power.requestIgnoreBattery(ctx) }) { Text("Allow unrestricted battery") }
                TextButton(onClick = { Power.openAutostart(ctx) }) { Text("Open Autostart / app launch settings") }
                TextButton(onClick = { Power.openAppSettings(ctx) }) { Text("Open app settings") }
                Text("Poco / Xiaomi (HyperOS) checklist:", color = Cyan, fontSize = 12.sp)
                Text("1. Tap Allow unrestricted battery.\n2. Open Autostart and switch Jarvis ON.\n3. App settings, Battery saver, set No restrictions.\n4. In Recents, long-press the Jarvis card and tap the lock.\n5. Keep notifications allowed.", color = Dim, fontSize = 12.sp)
                Text("After a phone restart (and sometimes after Android kills the app) Android blocks apps from starting the microphone on their own, so Jarvis cannot always restart itself. It shows a quiet \"Resume\" notification instead: tap it once and the listener is back.", color = Dim, fontSize = 12.sp)
                if (!KeepAlive.notificationsOn(ctx)) {
                    Text("NOTIFICATIONS ARE OFF: you will not see the Resume prompt, so the listener will stay off after a restart until you open the app.", color = Amber, fontFamily = HudFont, fontSize = 12.sp)
                    TextButton(onClick = { Power.openAppSettings(ctx) }) { Text("Allow notifications") }
                }
            }
        }
        HudCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.About) }) {
            Column {
                Text("ABOUT, LEGAL AND UPDATES", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Version, updates, privacy policy, terms, licences.", color = Dim, fontSize = 12.sp)
            }
        }
        HudCard(Modifier.fillMaxWidth()) {
            Column {
                Text("DATA", color = Cyan, fontFamily = HudFont, fontSize = 13.sp)
                Text("Everything is stored on this device. Messages you send to the AI go to Groq, spoken replies go to Fish Audio if you set it up, and speech recognition may use Google. See the Privacy Policy.", color = Dim, fontSize = 12.sp)
                TextButton(onClick = { confirmWipe = true }) { Text("Delete all app data") }
            }
        }
    }
    if (confirmWipe) {
        ConfirmDialog("Delete everything?", "Tasks, messages, activity, API keys, downloaded models and settings will be erased and the listener will stop.", "Delete",
            {
                // Stop the microphone first so nothing keeps listening after the data is gone.
                WakeService.stop(ctx.applicationContext)
                WakeService.error = null
                store.clearAll()
                ctx.getSharedPreferences("trk", android.content.Context.MODE_PRIVATE).edit().clear().apply()
                try {
                    java.io.File(ctx.filesDir, "oww").deleteRecursively()
                    java.io.File(ctx.filesDir, "hand_landmarker.task").delete()
                    ctx.cacheDir.deleteRecursively()
                } catch (_: Throwable) {}
                Secrets.deleteKey()
                name = ""; key = ""; model = DEFAULT_MODEL; testMsg = null
                fKey = ""; fVoice = ""; fModel = FishTts.DEFAULT_MODEL; fMsg = null
                sens = 0.7f
                confirmWipe = false
            }, { confirmWipe = false })
    }
}
