package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF3DE8F5)
val Bg = Color(0xFF050B14)
val Panel = Color(0xFF0B1C2C)
val Green = Color(0xFF3DF59A)
val Amber = Color(0xFFFFB020)
val Dim = Color(0xFF8AA0B2)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, onPrimary = Bg
        ),
        content = content
    )
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    var m = modifier.background(Panel, shape).border(1.dp, Cyan.copy(alpha = 0.45f), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m.padding(12.dp), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Text(title, color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Dim, fontSize = 12.sp)
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
