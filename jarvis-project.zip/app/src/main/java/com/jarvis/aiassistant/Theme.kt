// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.RuntimeShader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// ---------- palette: calm dark surfaces, one soft blue accent ----------
// Names kept from the old HUD theme so every screen keeps compiling. Cyan is now the soft sky-blue accent.
val Cyan = Color(0xFF6FB7FF)
val Bg = Color(0xFF0A0E13)
val Panel = Color(0xFF131A22)
val PanelDeep = Color(0xFF0E141A)
val PanelHi = Color(0xFF1B242E)
val Green = Color(0xFF4FD6A0)
val Amber = Color(0xFFF2B35C)
val Danger = Color(0xFFF2707A)
val Dim = Color(0xFF8C9AA8)
val Ink = Color(0xFFEAF0F6)
val Hairline = Color(0x14FFFFFF)

val CardShape = RoundedCornerShape(22.dp)
val TileShape = RoundedCornerShape(14.dp)
val PillShape = RoundedCornerShape(50)

/**
 * Whole-app size. 1.0 = the phone's own size. Lower = everything smaller (layout AND text).
 * Tuned for the Poco M6 Pro 5G, where the default looked too big. Try 0.85 to 0.95.
 */
const val UI_SCALE = 0.88f

/** Visual effects switch. Lite = no GPU shader, no tilt parallax, no press animation (saves battery on weak phones). */
object Fx { var lite by mutableStateOf(false) }

/** Phone tilt as -1..1 on each axis, smoothed. Only listens while the app is visible, and not at all in Lite mode. */
@Composable
fun rememberTilt(): State<Offset> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val out = remember { mutableStateOf(Offset.Zero) }
    val lite = Fx.lite
    DisposableEffect(owner, lite) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (lite || sm == null || sensor == null) { out.value = Offset.Zero; return@DisposableEffect onDispose { } }
        var fx = 0f
        var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                fx += (e.values[0] - fx) * 0.08f; fy += (e.values[1] - fy) * 0.08f
                out.value = Offset((-fx / 9.81f).coerceIn(-1f, 1f), (fy / 9.81f).coerceIn(-1f, 1f))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_START) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            else if (ev == Lifecycle.Event.ON_STOP) sm.unregisterListener(l)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); sm.unregisterListener(l) }
    }
    return out
}

/**
 * Runs [block] only while the app is visible (STARTED). It is cancelled when the app goes to the
 * background and started again on return, so polling loops cost nothing while the screen is off.
 */
@Composable
fun LaunchWhileStarted(key: Any? = Unit, block: suspend CoroutineScope.() -> Unit) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner, key) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) { block() }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density * UI_SCALE, d.fontScale)) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Cyan, background = Bg, surface = Panel,
                onBackground = Ink, onSurface = Ink, onPrimary = Bg,
                onSurfaceVariant = Dim, secondary = Cyan, onSecondary = Bg,
                surfaceVariant = PanelHi, outline = Hairline
            ),
            typography = jarvisTypography(),
            // Surface gives every screen (including the terms gate) a black base and default text.
            content = {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg, contentColor = Ink) {
                    ProvideTextStyle(TextStyle(fontFamily = BodyFont, color = Ink), content)
                }
            }
        )
    }
}

private fun jarvisTypography(): Typography {
    val b = Typography()
    fun hud(s: TextStyle) = s.copy(fontFamily = HudFont, letterSpacing = 0.sp)
    fun body(s: TextStyle) = s.copy(fontFamily = BodyFont)
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = TitleFont), displayMedium = b.displayMedium.copy(fontFamily = TitleFont),
        displaySmall = b.displaySmall.copy(fontFamily = TitleFont),
        headlineLarge = hud(b.headlineLarge), headlineMedium = hud(b.headlineMedium), headlineSmall = hud(b.headlineSmall),
        titleLarge = hud(b.titleLarge), titleMedium = hud(b.titleMedium), titleSmall = hud(b.titleSmall),
        bodyLarge = body(b.bodyLarge), bodyMedium = body(b.bodyMedium), bodySmall = body(b.bodySmall),
        labelLarge = hud(b.labelLarge), labelMedium = hud(b.labelMedium), labelSmall = hud(b.labelSmall)
    )
}

// ---------- backdrop: flat dark base with one soft glow at the top. No grid, no tilt, no shader. ----------
fun Modifier.hudBackdrop(): Modifier = this.background(Bg).drawWithCache {
    val c = Offset(size.width * 0.5f, 0f)
    val r = size.width * 1.1f
    val glow = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.10f), Color.Transparent), c, r)
    onDrawBehind { drawCircle(glow, r, c) }
}

// ---------- card surface: rounded, filled, one hairline border ----------
fun Modifier.hudPanel(accent: Color = Cyan, radius: Dp = 22.dp): Modifier = drawWithCache {
    val rr = androidx.compose.ui.geometry.CornerRadius(radius.toPx())
    val tint = accent != Cyan && accent != Dim
    val fill = Brush.verticalGradient(listOf(PanelHi, Panel), 0f, size.height)
    val edge = if (tint) accent.copy(alpha = 0.35f) else Hairline
    val hair = Stroke(1.dp.toPx())
    val inset = hair.width / 2f
    onDrawBehind {
        drawRoundRect(fill, cornerRadius = rr)
        drawRoundRect(
            edge, topLeft = Offset(inset, inset),
            size = androidx.compose.ui.geometry.Size(size.width - hair.width, size.height - hair.width),
            cornerRadius = rr, style = hair
        )
    }
}

/** Press feedback driven by an Animatable that is read in the graphicsLayer block: no recomposition while pressing. */
@Composable
internal fun rememberPress(src: MutableInteractionSource, to: Float): Animatable<Float, AnimationVector1D> {
    val a = remember { Animatable(1f) }
    LaunchedEffect(src) {
        src.interactions.collect { i ->
            if (Fx.lite) return@collect
            when (i) {
                is PressInteraction.Press -> launch { a.animateTo(to, spring(dampingRatio = 0.8f, stiffness = 500f)) }
                is PressInteraction.Release, is PressInteraction.Cancel -> launch { a.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 400f)) }
            }
        }
    }
    return a
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: Dp = 16.dp,
    accent: Color = Cyan,
    content: @Composable BoxScope.() -> Unit
) {
    val chrome = remember(accent) { Modifier.hudPanel(accent) }
    var m = modifier
    if (onClick != null) {
        val src = remember { MutableInteractionSource() }
        val press = rememberPress(src, 0.98f)
        val haptic = LocalHapticFeedback.current
        m = m.graphicsLayer { scaleX = press.value; scaleY = press.value }
            .then(chrome)
            .clip(CardShape)
            .clickable(interactionSource = src, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
    } else {
        m = m.then(chrome)
    }
    Box(m.padding(pad), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title.soft(), color = Ink, fontSize = 26.sp, fontFamily = TitleFont, fontWeight = FontWeight.Bold, maxLines = 1)
            if (subtitle != null) Text(subtitle.soft(), color = Dim, fontSize = 13.sp, fontFamily = BodyFont, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) { Spacer(Modifier.width(8.dp)); trailing() }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.soft(), modifier.fillMaxWidth().padding(top = 10.dp, start = 4.dp),
        color = Dim, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1
    )
}

/** Small status dot. Pulses softly; the pulse is read in the draw phase, so it never recomposes anything. */
@Composable
fun Led(color: Color, modifier: Modifier = Modifier, pulse: Boolean = true, size: Dp = 8.dp) {
    val a = if (pulse && !Fx.lite) {
        rememberInfiniteTransition(label = "led").animateFloat(
            0.45f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "ledA"
        )
    } else null
    Box(modifier.size(size).drawBehind { drawCircle(color.copy(alpha = a?.value ?: 1f)) })
}

@Composable
fun HudDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit, confirmColor: Color = Cyan, dismissLabel: String = "Cancel") {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelHi,
        shape = RoundedCornerShape(28.dp),
        tonalElevation = 0.dp,
        title = { Text(title.soft(), color = Ink, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
        text = { Text(text, color = Dim, fontFamily = BodyFont, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm.soft(), color = confirmColor, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(dismissLabel.soft(), color = Dim, fontFamily = TitleFont, fontWeight = FontWeight.Medium, fontSize = 14.sp) } }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) =
    HudDialog(title, text, confirm, onConfirm, onDismiss, Danger)

/** Selectable chip-style button (model pickers, chat toggles). Tinted when selected. */
@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val press = rememberPress(src, 0.96f)
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(if (active) Cyan.copy(alpha = 0.18f) else PanelHi, tween(160), label = "chipBg")
    Box(
        modifier.graphicsLayer { scaleX = press.value; scaleY = press.value }
            .heightIn(min = 44.dp).clip(PillShape).background(bg, PillShape)
            .border(1.dp, if (active) Cyan.copy(alpha = 0.45f) else Hairline, PillShape)
            .clickable(interactionSource = src, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label.soft(), textAlign = TextAlign.Center,
            color = if (active) Cyan else Ink, fontSize = 13.sp, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

enum class BtnKind { Primary, Outline, Danger }

@Composable
fun HudBtn(label: String, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary, enabled: Boolean = true, onClick: () -> Unit) {
    val c = if (kind == BtnKind.Danger) Danger else Cyan
    val a = if (enabled) 1f else 0.4f
    val src = remember { MutableInteractionSource() }
    val press = rememberPress(src, 0.96f)
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(16.dp)
    var m = modifier.graphicsLayer { scaleX = press.value; scaleY = press.value }.heightIn(min = 48.dp).clip(shape)
    m = if (kind == BtnKind.Primary) m.background(c.copy(alpha = a), shape)
    else m.background(c.copy(alpha = 0.12f * a), shape)
    Box(
        m.clickable(interactionSource = src, indication = null, enabled = enabled) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label.soft(), color = (if (kind == BtnKind.Primary) Bg else c).copy(alpha = a), fontSize = 14.sp, fontFamily = TitleFont,
            fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun hudFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = Hairline,
    focusedLabelColor = Cyan, unfocusedLabelColor = Dim, cursorColor = Cyan,
    focusedTextColor = Ink, unfocusedTextColor = Ink,
    focusedContainerColor = PanelDeep, unfocusedContainerColor = PanelDeep,
    focusedPlaceholderColor = Dim, unfocusedPlaceholderColor = Dim
)

private val FieldShape = RoundedCornerShape(18.dp)
private val FieldText = TextStyle(fontSize = 15.sp, fontFamily = BodyFont, color = Ink)

@Composable
fun HudField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, secret: Boolean = false) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = true,
        label = { Text(label, fontSize = 13.sp, fontFamily = BodyFont) },
        shape = FieldShape, textStyle = FieldText,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        colors = hudFieldColors()
    )
}

/** Free text input with a placeholder (chat message, new task). */
@Composable
fun HudInput(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier, singleLine: Boolean = false, maxLines: Int = 4) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = singleLine, maxLines = if (singleLine) 1 else maxLines,
        placeholder = { Text(placeholder, fontSize = 15.sp, fontFamily = BodyFont) },
        shape = FieldShape, textStyle = FieldText, colors = hudFieldColors()
    )
}

@Composable
fun HudSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked, onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Color.White, checkedBorderColor = Color.Transparent,
            uncheckedTrackColor = PanelHi, uncheckedThumbColor = Dim, uncheckedBorderColor = Hairline
        )
    )
}

@Composable
fun HudCheck(checked: Boolean, onToggle: () -> Unit) {
    Box(
        Modifier.size(26.dp).clip(CircleShape)
            .background(if (checked) Cyan else Color.Transparent, CircleShape)
            .border(1.5.dp, if (checked) Cyan else Dim.copy(alpha = 0.6f), CircleShape)
            .clickable(onClick = onToggle)
            .drawBehind {
                if (checked) {
                    val s = size.minDimension
                    val p = Path().apply {
                        moveTo(s * 0.29f, s * 0.52f); lineTo(s * 0.44f, s * 0.67f); lineTo(s * 0.72f, s * 0.36f)
                    }
                    drawPath(p, Bg, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                }
            }
    )
}
