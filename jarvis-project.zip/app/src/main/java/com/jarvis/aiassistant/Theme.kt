// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Density
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.composed
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.lifecycle.LifecycleEventObserver

val Cyan = Color(0xFF3DE8F5)
val Bg = Color(0xFF050B14)
val Panel = Color(0xFF0B1C2C)
val PanelDeep = Color(0xFF081522)
val Green = Color(0xFF3DF59A)
val Amber = Color(0xFFFFB020)
val Danger = Color(0xFFFF5370)
val Dim = Color(0xFF8AA0B2)

/**
 * Whole-app size. 1.0 = the phone's own size. Lower = everything smaller (layout AND text).
 * Tuned for the Poco M6 Pro 5G, where the default looked too big. Try 0.85 to 0.95.
 */
const val UI_SCALE = 0.88f

/** Visual effects switch. Lite = no depth shadows, no tilt parallax, no press animation (saves battery on weak phones). */
object Fx { var lite by mutableStateOf(false) }

/** Phone tilt as -1..1 on each axis, smoothed. Only listens while the app is visible, and not at all in Lite mode. */
@Composable
fun rememberTilt(): State<Offset> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val out = remember { mutableStateOf(Offset.Zero) }
    val lite = Fx.lite
    DisposableEffect(owner, lite) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (lite || sm == null || sensor == null) { out.value = Offset.Zero; return@DisposableEffect onDispose { } }
        var fx = 0f
        var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                fx += (e.values[0] - fx) * 0.08f; fy += (e.values[1] - fy) * 0.08f
                out.value = Offset((-fx / 9.81f).coerceIn(-1f, 1f), (fy / 9.81f).coerceIn(-1f, 1f))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_START) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            else if (ev == Lifecycle.Event.ON_STOP) sm.unregisterListener(l)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); sm.unregisterListener(l) }
    }
    return out
}

/**
 * Runs [block] only while the app is visible (STARTED). It is cancelled when the app goes to the
 * background and started again on return, so polling loops cost nothing while the screen is off.
 */
@Composable
fun LaunchWhileStarted(key: Any? = Unit, block: suspend CoroutineScope.() -> Unit) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner, key) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) { block() }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density * UI_SCALE, d.fontScale)) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Cyan, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White, onPrimary = Bg,
                onSurfaceVariant = Color(0xFFD5E2EC), secondary = Cyan, onSecondary = Bg,
                surfaceVariant = Panel, outline = Cyan.copy(alpha = 0.6f)
            ),
            typography = jarvisTypography(),
            // Surface gives every screen (including the terms gate) a dark base and white default text.
            content = {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
                    ProvideTextStyle(TextStyle(fontFamily = BodyFont, color = Color.White), content)
                }
            }
        )
    }
}

private fun jarvisTypography(): Typography {
    val b = Typography()
    fun hud(s: TextStyle) = s.copy(fontFamily = HudFont, letterSpacing = 0.5.sp)
    fun body(s: TextStyle) = s.copy(fontFamily = BodyFont)
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = TitleFont), displayMedium = b.displayMedium.copy(fontFamily = TitleFont),
        displaySmall = b.displaySmall.copy(fontFamily = TitleFont),
        headlineLarge = hud(b.headlineLarge), headlineMedium = hud(b.headlineMedium), headlineSmall = hud(b.headlineSmall),
        titleLarge = hud(b.titleLarge), titleMedium = hud(b.titleMedium), titleSmall = hud(b.titleSmall),
        bodyLarge = body(b.bodyLarge), bodyMedium = body(b.bodyMedium), bodySmall = body(b.bodySmall),
        labelLarge = hud(b.labelLarge), labelMedium = hud(b.labelMedium), labelSmall = hud(b.labelSmall)
    )
}

/** Dark base with a faint HUD grid and a soft cyan glow at the top. The grid and glow shift slightly as the phone tilts. */
fun Modifier.hudBackdrop(): Modifier = composed {
    val tilt = rememberTilt()
    this.background(Bg).drawWithCache {
        // Built once per size, not on every frame: grid lines as one point batch plus one cached glow brush.
        val step = 28.dp.toPx()
        val gc = Cyan.copy(alpha = 0.035f)
        val pts = ArrayList<Offset>()
        var x = -step
        while (x < size.width + step) { pts.add(Offset(x, -step)); pts.add(Offset(x, size.height + step)); x += step }
        var y = -step
        while (y < size.height + step) { pts.add(Offset(-step, y)); pts.add(Offset(size.width + step, y)); y += step }
        val c = Offset(size.width * 0.5f, 0f)
        val glow = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.12f), Color.Transparent), c, size.width * 0.9f)
        val r = size.width * 0.9f
        val reach = 12.dp.toPx()
        onDrawBehind {
            val o = tilt.value
            withTransform({ translate(o.x * reach, o.y * reach) }) {
                drawPoints(pts, PointMode.Lines, gc, 1f)
                drawCircle(glow, r, c)
            }
        }
    }
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: androidx.compose.ui.unit.Dp = 12.dp,
    accent: Color = Cyan,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed && !Fx.lite) 0.965f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "cardPress")
    val haptic = LocalHapticFeedback.current
    var m = modifier
    if (onClick != null) m = m.graphicsLayer { scaleX = press; scaleY = press }
    if (!Fx.lite) m = m.shadow(10.dp, shape, ambientColor = accent.copy(alpha = 0.25f), spotColor = accent.copy(alpha = 0.40f))
    m = m
        .background(Brush.verticalGradient(listOf(Color(0xFF11304A), Panel, PanelDeep)), shape)   // lighter top edge reads as a raised glass panel
        .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.7f), accent.copy(alpha = 0.10f))), shape)
        .clip(shape)
    if (onClick != null) m = m.clickable(interactionSource = src, indication = null) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick()
    }
    Box(m.padding(pad), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(if (subtitle != null) 34.dp else 20.dp).background(Cyan, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Cyan, fontSize = 19.sp, fontFamily = TitleFont, letterSpacing = 0.sp)
            if (subtitle != null) Text(subtitle, color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.4f), Color.Transparent))))
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = Danger) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Selectable chip-style button (model pickers). Amber when selected. */
@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 9.dp, accent = if (active) Amber else Cyan) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Amber else Color.White, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

enum class BtnKind { Primary, Outline, Danger }

@Composable
fun HudBtn(label: String, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    val c = if (kind == BtnKind.Danger) Danger else Cyan
    val a = if (enabled) 1f else 0.4f
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed && !Fx.lite) 0.95f else 1f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "btnPress")
    val haptic = LocalHapticFeedback.current
    var m = modifier.graphicsLayer { scaleX = press; scaleY = press }.heightIn(min = 38.dp).clip(shape)
    m = if (kind == BtnKind.Primary) m.background(Brush.horizontalGradient(listOf(Cyan, Color(0xFF2BB6F0))), shape, alpha = a)
    else m.background(c.copy(alpha = 0.08f), shape).border(1.dp, c.copy(alpha = 0.7f * a), shape)
    Box(m.clickable(interactionSource = src, indication = null, enabled = enabled) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label, color = (if (kind == BtnKind.Primary) Bg else c).copy(alpha = a), fontSize = 13.sp, fontFamily = HudFont,
            fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center
        )
    }
}

@Composable
fun HudField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, secret: Boolean = false) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = true,
        label = { Text(label, fontSize = 12.sp) },
        shape = RoundedCornerShape(10.dp),
        textStyle = TextStyle(fontSize = 14.sp, fontFamily = BodyFont, color = Color.White),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f),
            focusedLabelColor = Cyan, unfocusedLabelColor = Dim, cursorColor = Cyan,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White
        )
    )
}

@Composable
fun HudSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked, onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Bg, checkedBorderColor = Cyan,
            uncheckedTrackColor = PanelDeep, uncheckedThumbColor = Dim, uncheckedBorderColor = Cyan.copy(alpha = 0.4f)
        )
    )
}
