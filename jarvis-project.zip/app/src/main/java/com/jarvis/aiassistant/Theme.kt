// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF3DE8F5)
val Bg = Color(0xFF050B14)
val Panel = Color(0xFF0B1C2C)
val Green = Color(0xFF3DF59A)
val Amber = Color(0xFFFFB020)
val Dim = Color(0xFF8AA0B2)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, onPrimary = Bg
        ),
        typography = jarvisTypography(),
        content = { ProvideTextStyle(TextStyle(fontFamily = BodyFont), content) }
    )
}

private fun jarvisTypography(): Typography {
    val b = Typography()
    fun hud(s: TextStyle) = s.copy(fontFamily = HudFont, letterSpacing = 0.5.sp)
    fun body(s: TextStyle) = s.copy(fontFamily = BodyFont)
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = TitleFont), displayMedium = b.displayMedium.copy(fontFamily = TitleFont),
        displaySmall = b.displaySmall.copy(fontFamily = TitleFont),
        headlineLarge = hud(b.headlineLarge), headlineMedium = hud(b.headlineMedium), headlineSmall = hud(b.headlineSmall),
        titleLarge = hud(b.titleLarge), titleMedium = hud(b.titleMedium), titleSmall = hud(b.titleSmall),
        bodyLarge = body(b.bodyLarge), bodyMedium = body(b.bodyMedium), bodySmall = body(b.bodySmall),
        labelLarge = hud(b.labelLarge), labelMedium = hud(b.labelMedium), labelSmall = hud(b.labelSmall)
    )
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: androidx.compose.ui.unit.Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    var m = modifier.background(Panel, shape).border(1.dp, Cyan.copy(alpha = 0.45f), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m.padding(pad), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Text(title, color = Cyan, fontSize = 20.sp, fontFamily = TitleFont, letterSpacing = 0.sp)
        if (subtitle != null) Text(subtitle, color = Dim, fontSize = 12.sp)
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 10.dp) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Amber else Color.White, fontSize = 11.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}
