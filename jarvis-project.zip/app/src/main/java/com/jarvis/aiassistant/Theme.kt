// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.RuntimeShader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// ---------- palette: AMOLED black base, neon cyan structure, amber warnings ----------
val Cyan = Color(0xFF00F0FF)
val Bg = Color(0xFF000000)
val Panel = Color(0xFF080D10)
val PanelDeep = Color(0xFF000000)
val Green = Color(0xFF00FF9C)
val Amber = Color(0xFFFFB800)
val Danger = Color(0xFFFF3B5C)
val Dim = Color(0xFF6E8794)
val Ink = Color(0xFFE6FBFF)

/**
 * Whole-app size. 1.0 = the phone's own size. Lower = everything smaller (layout AND text).
 * Tuned for the Poco M6 Pro 5G, where the default looked too big. Try 0.85 to 0.95.
 */
const val UI_SCALE = 0.88f

/** Visual effects switch. Lite = no GPU shader, no tilt parallax, no press animation (saves battery on weak phones). */
object Fx { var lite by mutableStateOf(false) }

/** Phone tilt as -1..1 on each axis, smoothed. Only listens while the app is visible, and not at all in Lite mode. */
@Composable
fun rememberTilt(): State<Offset> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val out = remember { mutableStateOf(Offset.Zero) }
    val lite = Fx.lite
    DisposableEffect(owner, lite) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (lite || sm == null || sensor == null) { out.value = Offset.Zero; return@DisposableEffect onDispose { } }
        var fx = 0f
        var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                fx += (e.values[0] - fx) * 0.08f; fy += (e.values[1] - fy) * 0.08f
                out.value = Offset((-fx / 9.81f).coerceIn(-1f, 1f), (fy / 9.81f).coerceIn(-1f, 1f))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_START) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            else if (ev == Lifecycle.Event.ON_STOP) sm.unregisterListener(l)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); sm.unregisterListener(l) }
    }
    return out
}

/**
 * Runs [block] only while the app is visible (STARTED). It is cancelled when the app goes to the
 * background and started again on return, so polling loops cost nothing while the screen is off.
 */
@Composable
fun LaunchWhileStarted(key: Any? = Unit, block: suspend CoroutineScope.() -> Unit) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner, key) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) { block() }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density * UI_SCALE, d.fontScale)) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Cyan, background = Bg, surface = Panel,
                onBackground = Ink, onSurface = Ink, onPrimary = Bg,
                onSurfaceVariant = Color(0xFFBFD3DC), secondary = Cyan, onSecondary = Bg,
                surfaceVariant = Panel, outline = Cyan.copy(alpha = 0.6f)
            ),
            typography = jarvisTypography(),
            // Surface gives every screen (including the terms gate) a black base and default text.
            content = {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg, contentColor = Ink) {
                    ProvideTextStyle(TextStyle(fontFamily = BodyFont, color = Ink), content)
                }
            }
        )
    }
}

private fun jarvisTypography(): Typography {
    val b = Typography()
    fun hud(s: TextStyle) = s.copy(fontFamily = HudFont, letterSpacing = 0.5.sp)
    fun body(s: TextStyle) = s.copy(fontFamily = BodyFont)
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = TitleFont), displayMedium = b.displayMedium.copy(fontFamily = TitleFont),
        displaySmall = b.displaySmall.copy(fontFamily = TitleFont),
        headlineLarge = hud(b.headlineLarge), headlineMedium = hud(b.headlineMedium), headlineSmall = hud(b.headlineSmall),
        titleLarge = hud(b.titleLarge), titleMedium = hud(b.titleMedium), titleSmall = hud(b.titleSmall),
        bodyLarge = body(b.bodyLarge), bodyMedium = body(b.bodyMedium), bodySmall = body(b.bodySmall),
        labelLarge = hud(b.labelLarge), labelMedium = hud(b.labelMedium), labelSmall = hud(b.labelSmall)
    )
}

// ---------- GPU backdrop: grid, major lines, top glow and vignette in one AGSL pass (Adreno), no CPU geometry ----------
private const val GRID_AGSL = """
uniform float2 res;
uniform float2 off;
uniform float step;
half4 main(float2 p) {
    float2 q = p - off;
    float2 g = abs(fract(q / step + 0.5) - 0.5) * step;
    float minor = 1.0 - smoothstep(0.0, 1.0, min(g.x, g.y));
    float s4 = step * 4.0;
    float2 g4 = abs(fract(q / s4 + 0.5) - 0.5) * s4;
    float major = 1.0 - smoothstep(0.0, 1.2, min(g4.x, g4.y));
    float2 uv = p / res;
    float top = exp(-uv.y * 5.0);
    float vig = 1.0 - smoothstep(0.55, 1.1, length((uv - 0.5) * float2(1.0, 1.4)));
    float a = (0.030 * minor + 0.070 * major) * (0.35 + 0.65 * vig) + 0.09 * top;
    return half4(half3(0.0, 0.94, 1.0) * half(a), half(a));
}
"""

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class GridFx {
    private val sh = RuntimeShader(GRID_AGSL)
    val brush = ShaderBrush(sh)
    fun size(w: Float, h: Float, step: Float) { sh.setFloatUniform("res", w, h); sh.setFloatUniform("step", step) }
    fun offset(x: Float, y: Float) { sh.setFloatUniform("off", x, y) }
}

/** Black base with an Adreno-drawn HUD grid. The grid shifts slightly as the phone tilts. Older phones get a cached point grid. */
@SuppressLint("NewApi")
fun Modifier.hudBackdrop(): Modifier = composed {
    val tilt = rememberTilt()
    val gridFx = remember { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) GridFx() else null }
    this.background(Bg).drawWithCache {
        val step = 28.dp.toPx()
        val reach = 12.dp.toPx()
        if (gridFx != null) {
            gridFx.size(size.width, size.height, step)
            onDrawBehind {
                val o = tilt.value
                gridFx.offset(o.x * reach, o.y * reach)
                drawRect(gridFx.brush)
            }
        } else {
            val gc = Cyan.copy(alpha = 0.04f)
            val pts = ArrayList<Offset>()
            var x = -step
            while (x < size.width + step) { pts.add(Offset(x, -step)); pts.add(Offset(x, size.height + step)); x += step }
            var y = -step
            while (y < size.height + step) { pts.add(Offset(-step, y)); pts.add(Offset(size.width + step, y)); y += step }
            val c = Offset(size.width * 0.5f, 0f)
            val r = size.width * 0.9f
            val glow = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.10f), Color.Transparent), c, r)
            onDrawBehind {
                val o = tilt.value
                withTransform({ translate(o.x * reach, o.y * reach) }) {
                    drawPoints(pts, PointMode.Lines, gc, 1f)
                    drawCircle(glow, r, c)
                }
            }
        }
    }
}

// ---------- panel chrome: chamfered body, 0.5dp micro border, corner brackets, dashed baseline ----------
/**
 * Everything is built once per size inside drawWithCache (paths, gradients, strokes). The draw block only issues draw calls,
 * so a panel costs no heap allocation per frame. Wrap the call in remember(accent) so the cache survives recomposition.
 */
fun Modifier.hudPanel(accent: Color = Cyan, cut: Dp = 8.dp, bracket: Dp = 11.dp): Modifier = drawWithCache {
    val c = cut.toPx(); val b = bracket.toPx()
    val w = size.width; val h = size.height
    val body = Path().apply {
        moveTo(c, 0f); lineTo(w, 0f); lineTo(w, h - c); lineTo(w - c, h); lineTo(0f, h); lineTo(0f, c); close()
    }
    val br = Path().apply {
        moveTo(c, 0f); lineTo(c + b, 0f); moveTo(0f, c); lineTo(0f, c + b)
        moveTo(w - b, 0f); lineTo(w, 0f); lineTo(w, b)
        moveTo(0f, h - b); lineTo(0f, h); lineTo(b, h)
        moveTo(w, h - c - b); lineTo(w, h - c); moveTo(w - c - b, h); lineTo(w - c, h)
    }
    val dash = Path().apply { moveTo(c + b + 6.dp.toPx(), h - 0.5f); lineTo(w - c - b - 6.dp.toPx(), h - 0.5f) }
    val fill = Brush.verticalGradient(listOf(Color(0xFF0B1317), Color(0xFF030506), Color.Black), 0f, h)
    val glow = Brush.verticalGradient(listOf(accent.copy(alpha = 0.14f), Color.Transparent), 0f, h * 0.55f)
    val hair = Stroke(0.5.dp.toPx())
    val thick = Stroke(1.5.dp.toPx(), cap = StrokeCap.Square)
    val dashed = Stroke(0.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
    val showDash = w > 90.dp.toPx()
    val edge = accent.copy(alpha = 0.45f)
    val faint = accent.copy(alpha = 0.30f)
    onDrawBehind {
        drawPath(body, fill)
        drawPath(body, glow)
        drawPath(body, edge, style = hair)
        drawPath(br, accent, style = thick)
        if (showDash) drawPath(dash, faint, style = dashed)
    }
}

/** Press feedback driven by an Animatable that is read in the graphicsLayer block: no recomposition while pressing. */
@Composable
internal fun rememberPress(src: MutableInteractionSource, to: Float): Animatable<Float, AnimationVector1D> {
    val a = remember { Animatable(1f) }
    LaunchedEffect(src) {
        src.interactions.collect { i ->
            if (Fx.lite) return@collect
            when (i) {
                is PressInteraction.Press -> launch { a.animateTo(to, spring(dampingRatio = 0.6f, stiffness = 700f)) }
                is PressInteraction.Release, is PressInteraction.Cancel -> launch { a.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 500f)) }
            }
        }
    }
    return a
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: Dp = 12.dp,
    accent: Color = Cyan,
    content: @Composable BoxScope.() -> Unit
) {
    val chrome = remember(accent) { Modifier.hudPanel(accent) }
    var m = modifier
    if (onClick != null) {
        val src = remember { MutableInteractionSource() }
        val press = rememberPress(src, 0.97f)
        val haptic = LocalHapticFeedback.current
        m = m.graphicsLayer { scaleX = press.value; scaleY = press.value }
            .then(chrome)
            .clickable(interactionSource = src, indication = null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
    } else {
        m = m.then(chrome)
    }
    Box(m.padding(pad), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(if (subtitle != null) 34.dp else 20.dp).background(Cyan))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Cyan, fontSize = 17.sp, fontFamily = TitleFont, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1)
            if (subtitle != null) Text(subtitle, color = Dim, fontSize = 10.sp, fontFamily = MonoFont, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) { Spacer(Modifier.width(8.dp)); trailing() }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("//", color = Amber, fontFamily = MonoFont, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(Modifier.width(6.dp))
        Text(text, color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp, maxLines = 1)
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.weight(1f).height(1.dp).drawWithCache {
                val st = Stroke(0.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
                val p = Path().apply { moveTo(0f, size.height / 2f); lineTo(size.width, size.height / 2f) }
                val c = Cyan.copy(alpha = 0.5f)
                onDrawBehind { drawPath(p, c, style = st) }
            }
        )
    }
}

/** Small blinking status square. The blink is read in the draw phase, so it never recomposes anything. */
@Composable
fun Led(color: Color, modifier: Modifier = Modifier, pulse: Boolean = true, size: Dp = 8.dp) {
    val a = if (pulse && !Fx.lite) {
        rememberInfiniteTransition(label = "led").animateFloat(
            0.35f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "ledA"
        )
    } else null
    Box(modifier.size(size).drawBehind { drawRect(color.copy(alpha = a?.value ?: 1f)) })
}

@Composable
fun HudDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit, confirmColor: Color = Cyan, dismissLabel: String = "CANCEL") {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp),
        tonalElevation = 0.dp,
        title = { Text(title, color = Cyan, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
        text = { Text(text, fontFamily = MonoFont, fontSize = 12.sp) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = confirmColor, fontFamily = TitleFont, fontWeight = FontWeight.Bold, fontSize = 12.sp) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(dismissLabel, color = Dim, fontFamily = TitleFont, fontSize = 12.sp) } }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) =
    HudDialog(title, text, confirm, onConfirm, onDismiss, Danger)

private val ChipShape = CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp)

/** Selectable chip-style button (model pickers). Amber when selected. */
@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 9.dp, accent = if (active) Amber else Cyan) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Amber else Ink, fontSize = 10.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

enum class BtnKind { Primary, Outline, Danger }

@Composable
fun HudBtn(label: String, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary, enabled: Boolean = true, onClick: () -> Unit) {
    val c = if (kind == BtnKind.Danger) Danger else Cyan
    val a = if (enabled) 1f else 0.4f
    val src = remember { MutableInteractionSource() }
    val press = rememberPress(src, 0.95f)
    val haptic = LocalHapticFeedback.current
    var m = modifier.graphicsLayer { scaleX = press.value; scaleY = press.value }.heightIn(min = 38.dp).clip(ChipShape)
    m = if (kind == BtnKind.Primary) m.background(c.copy(alpha = a), ChipShape)
    else m.background(c.copy(alpha = 0.07f), ChipShape).border(0.5.dp, c.copy(alpha = 0.8f * a), ChipShape)
    Box(
        m.clickable(interactionSource = src, indication = null, enabled = enabled) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = (if (kind == BtnKind.Primary) Bg else c).copy(alpha = a), fontSize = 11.sp, fontFamily = HudFont,
            fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center, letterSpacing = 0.8.sp
        )
    }
}

@Composable
private fun hudFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f),
    focusedLabelColor = Cyan, unfocusedLabelColor = Dim, cursorColor = Cyan,
    focusedTextColor = Ink, unfocusedTextColor = Ink,
    focusedContainerColor = Color.Black, unfocusedContainerColor = Color.Black,
    focusedPlaceholderColor = Dim, unfocusedPlaceholderColor = Dim
)

private val FieldShape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)
private val FieldText = TextStyle(fontSize = 13.sp, fontFamily = MonoFont, color = Ink)

@Composable
fun HudField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, secret: Boolean = false) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = true,
        label = { Text(label, fontSize = 11.sp, fontFamily = MonoFont) },
        shape = FieldShape, textStyle = FieldText,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        colors = hudFieldColors()
    )
}

/** Free text input with a placeholder (chat message, new task). */
@Composable
fun HudInput(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier, singleLine: Boolean = false, maxLines: Int = 4) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = singleLine, maxLines = if (singleLine) 1 else maxLines,
        placeholder = { Text(placeholder, fontSize = 12.sp, fontFamily = MonoFont) },
        shape = FieldShape, textStyle = FieldText, colors = hudFieldColors()
    )
}

@Composable
fun HudSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked, onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Bg, checkedBorderColor = Cyan,
            uncheckedTrackColor = Color.Black, uncheckedThumbColor = Dim, uncheckedBorderColor = Cyan.copy(alpha = 0.4f)
        )
    )
}

@Composable
fun HudCheck(checked: Boolean, onToggle: () -> Unit) {
    val sh = CutCornerShape(topStart = 4.dp, bottomEnd = 4.dp)
    Box(Modifier.size(22.dp).border(0.5.dp, if (checked) Cyan else Dim, sh).clickable(onClick = onToggle).padding(5.dp)) {
        if (checked) Box(Modifier.fillMaxSize().background(Cyan))
    }
}
