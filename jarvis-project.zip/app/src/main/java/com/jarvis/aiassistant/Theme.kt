// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Density
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF3DE8F5)
val Bg = Color(0xFF050B14)
val Panel = Color(0xFF0B1C2C)
val PanelDeep = Color(0xFF081522)
val Green = Color(0xFF3DF59A)
val Amber = Color(0xFFFFB020)
val Red = Color(0xFFFF5370)
val Dim = Color(0xFF8AA0B2)

/**
 * Whole-app size. 1.0 = the phone's own size. Lower = everything smaller (layout AND text).
 * Tuned for the Poco M6 Pro 5G, where the default looked too big. Try 0.85 to 0.95.
 */
const val UI_SCALE = 0.88f

/**
 * Runs [block] only while the app is visible (STARTED). It is cancelled when the app goes to the
 * background and started again on return, so polling loops cost nothing while the screen is off.
 */
@Composable
fun LaunchWhileStarted(key: Any? = Unit, block: suspend CoroutineScope.() -> Unit) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner, key) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) { block() }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density * UI_SCALE, d.fontScale)) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Cyan, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White, onPrimary = Bg,
                onSurfaceVariant = Color(0xFFD5E2EC), secondary = Cyan, onSecondary = Bg,
                surfaceVariant = Panel, outline = Cyan.copy(alpha = 0.6f)
            ),
            typography = jarvisTypography(),
            // Surface gives every screen (including the terms gate) a dark base and white default text.
            content = {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
                    ProvideTextStyle(TextStyle(fontFamily = BodyFont, color = Color.White), content)
                }
            }
        )
    }
}

private fun jarvisTypography(): Typography {
    val b = Typography()
    fun hud(s: TextStyle) = s.copy(fontFamily = HudFont, letterSpacing = 0.5.sp)
    fun body(s: TextStyle) = s.copy(fontFamily = BodyFont)
    return Typography(
        displayLarge = b.displayLarge.copy(fontFamily = TitleFont), displayMedium = b.displayMedium.copy(fontFamily = TitleFont),
        displaySmall = b.displaySmall.copy(fontFamily = TitleFont),
        headlineLarge = hud(b.headlineLarge), headlineMedium = hud(b.headlineMedium), headlineSmall = hud(b.headlineSmall),
        titleLarge = hud(b.titleLarge), titleMedium = hud(b.titleMedium), titleSmall = hud(b.titleSmall),
        bodyLarge = body(b.bodyLarge), bodyMedium = body(b.bodyMedium), bodySmall = body(b.bodySmall),
        labelLarge = hud(b.labelLarge), labelMedium = hud(b.labelMedium), labelSmall = hud(b.labelSmall)
    )
}

/** Dark base with a faint HUD grid and a soft cyan glow at the top. */
fun Modifier.hudBackdrop(): Modifier = this.background(Bg).drawBehind {
    val step = 28.dp.toPx()
    val gc = Cyan.copy(alpha = 0.035f)
    var x = 0f
    while (x < size.width) { drawLine(gc, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
    var y = 0f
    while (y < size.height) { drawLine(gc, Offset(0f, y), Offset(size.width, y), 1f); y += step }
    val c = Offset(size.width * 0.5f, 0f)
    drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.10f), Color.Transparent), c, size.width * 0.9f), size.width * 0.9f, c)
}

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    pad: androidx.compose.ui.unit.Dp = 12.dp,
    accent: Color = Cyan,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    var m = modifier
        .background(Brush.verticalGradient(listOf(Panel, PanelDeep)), shape)
        .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.65f), accent.copy(alpha = 0.12f))), shape)
        .clip(shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m.padding(pad), content = content)
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(if (subtitle != null) 34.dp else 20.dp).background(Cyan, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Cyan, fontSize = 19.sp, fontFamily = TitleFont, letterSpacing = 0.sp)
            if (subtitle != null) Text(subtitle, color = Dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.4f), Color.Transparent))))
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = Red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Selectable chip-style button (model pickers). Amber when selected. */
@Composable
fun HudButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    HudCard(modifier, onClick, pad = 9.dp, accent = if (active) Amber else Cyan) {
        Text(
            label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = if (active) Amber else Color.White, fontSize = 12.sp, fontFamily = HudFont, fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

enum class BtnKind { Primary, Outline, Danger }

@Composable
fun HudBtn(label: String, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.Primary, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    val c = if (kind == BtnKind.Danger) Red else Cyan
    val a = if (enabled) 1f else 0.4f
    var m = modifier.heightIn(min = 38.dp).clip(shape)
    m = if (kind == BtnKind.Primary) m.background(Brush.horizontalGradient(listOf(Cyan, Color(0xFF2BB6F0))), shape, alpha = a)
    else m.background(c.copy(alpha = 0.08f), shape).border(1.dp, c.copy(alpha = 0.7f * a), shape)
    Box(m.clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label, color = (if (kind == BtnKind.Primary) Bg else c).copy(alpha = a), fontSize = 13.sp, fontFamily = HudFont,
            fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center
        )
    }
}

@Composable
fun HudField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, secret: Boolean = false) {
    OutlinedTextField(
        value, onChange, modifier, singleLine = true,
        label = { Text(label, fontSize = 12.sp) },
        shape = RoundedCornerShape(10.dp),
        textStyle = TextStyle(fontSize = 14.sp, fontFamily = BodyFont, color = Color.White),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.35f),
            focusedLabelColor = Cyan, unfocusedLabelColor = Dim, cursorColor = Cyan,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White
        )
    )
}

@Composable
fun HudSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked, onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = Cyan, checkedThumbColor = Bg, checkedBorderColor = Cyan,
            uncheckedTrackColor = PanelDeep, uncheckedThumbColor = Dim, uncheckedBorderColor = Cyan.copy(alpha = 0.4f)
        )
    )
}
