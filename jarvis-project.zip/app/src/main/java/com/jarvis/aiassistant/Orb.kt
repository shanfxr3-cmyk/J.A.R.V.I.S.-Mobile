// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

private const val ORB_TAU = 6.2831855f

/** 0 idle, 1 thinking, 2 listening, 3 speaking. */
internal fun orbMode(): Int {
    val ws = WakeService.state
    return when {
        SpeechLevel.speaking || ws == "SPEAKING" -> 3
        SpeechLevel.listening || ws == "LISTENING" -> 2
        ws == "THINKING" -> 1
        else -> 0
    }
}

internal fun orbLabel(mode: Int) = when (mode) {
    3 -> "Speaking"
    2 -> "Listening"
    1 -> "Thinking"
    else -> "Ready"
}

/**
 * A glassy sphere that breathes, sends soft ripples with the speech level, carries a slow comet ring and a floor glow.
 * Green while listening, amber while thinking. Tap to open chat. Everything is read in the draw phase.
 */
@Composable
fun SoftOrb(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val mode by remember { derivedStateOf { orbMode() } }
    val phase = if (!Fx.lite) {
        rememberInfiniteTransition(label = "orb").animateFloat(
            0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart), label = "orbPhase"
        )
    } else null
    val tap = if (onClick != null) Modifier.clickable(remember { MutableInteractionSource() }, null) { onClick() } else Modifier

    Spacer(
        modifier.then(tap).drawWithCache {
            val c = Offset(size.width / 2f, size.height * 0.40f)
            val r = minOf(size.width, size.height) * 0.26f
            fun bodyOf(col: Color) = Brush.radialGradient(
                listOf(lerp(col, Color.White, 0.80f), col, lerp(col, Color.Black, 0.50f)),
                center = Offset(c.x - r * 0.35f, c.y - r * 0.40f), radius = r * 1.6f
            )
            val bodies = arrayOf(bodyOf(Cyan), bodyOf(Amber), bodyOf(Green))
            val shine = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.42f), Color.Transparent),
                center = Offset(c.x - r * 0.32f, c.y - r * 0.40f), radius = r * 0.55f
            )
            val rim = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.Transparent, Color.White.copy(alpha = 0.12f)),
                Offset(c.x - r, c.y - r), Offset(c.x + r, c.y + r)
            )
            fun glowOf(col: Color) = Brush.radialGradient(listOf(col.copy(alpha = 0.34f), Color.Transparent), c, r * 2.3f)
            val glows = arrayOf(glowOf(Cyan), glowOf(Amber), glowOf(Green))
            fun cometOf(col: Color) = Brush.sweepGradient(0f to Color.Transparent, 0.55f to Color.Transparent, 1f to col.copy(alpha = 0.9f), center = c)
            val comets = arrayOf(cometOf(Cyan), cometOf(Amber), cometOf(Green))
            val floorC = Offset(c.x, c.y + r * 1.45f)
            val floor = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.30f), Color.Transparent), floorC, r * 1.5f)
            val ripple = Stroke(1.5.dp.toPx())
            val ring = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
            val rimStroke = Stroke(1.5.dp.toPx())
            val ringR = r * 1.38f
            val dot = 3.dp.toPx()
            onDrawBehind {
                val ph = phase?.value ?: 0f
                val m = mode
                val lvl = (SpeechLevel.pct / 100f).coerceIn(0f, 1f)
                val breath = 0.5f + 0.5f * sin(ph * ORB_TAU)
                val k = if (m == 2) 2 else if (m == 1) 1 else 0   // index into the colour sets: blue, amber, green
                val idx = if (m == 2) 2 else if (m == 1) 1 else 0
                val accent = if (k == 2) Green else if (k == 1) Amber else Cyan

                drawCircle(glows[idx], r * 2.3f * (1f + 0.05f * breath + 0.12f * lvl), c, alpha = 0.7f + 0.3f * breath)

                // soft floor glow under the sphere
                scale(1f, 0.16f, floorC) { drawCircle(floor, r * 1.5f, floorC, alpha = 0.6f + 0.25f * breath + 0.15f * lvl) }

                val rippleA = if (m == 0) 0.12f else 0.30f
                for (i in 0 until 3) {
                    val t = (ph + i / 3f) % 1f
                    drawCircle(accent, r * (1.10f + 0.75f * t), c, alpha = (1f - t) * rippleA, style = ripple)
                }

                // slow comet ring; spins twice as fast while thinking
                val deg = ph * (if (m == 1) 720f else 360f)
                rotate(deg, c) { drawCircle(comets[idx], ringR, c, style = ring) }
                val ang = deg * 0.017453292f
                drawCircle(accent, dot, Offset(c.x + kotlin.math.cos(ang) * ringR, c.y + kotlin.math.sin(ang) * ringR))

                scale(1f + 0.025f * breath + 0.09f * lvl, c) {
                    drawCircle(bodies[idx], r, c)
                    drawCircle(shine, r, c)
                    drawCircle(rim, r - rimStroke.width / 2f, c, style = rimStroke)
                }
            }
        }
    )
}
