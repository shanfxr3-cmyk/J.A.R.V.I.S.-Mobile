// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import kotlin.math.sin

private const val ORB_TAU = 6.2831855f

/** 0 idle, 1 thinking, 2 listening, 3 speaking. */
internal fun orbMode(): Int {
    val ws = WakeService.state
    return when {
        SpeechLevel.speaking || ws == "SPEAKING" -> 3
        SpeechLevel.listening || ws == "LISTENING" -> 2
        ws == "THINKING" -> 1
        else -> 0
    }
}

internal fun orbLabel(mode: Int) = when (mode) {
    3 -> "Speaking"
    2 -> "Listening"
    1 -> "Thinking"
    else -> "Ready"
}

/**
 * A calm, breathing orb. It swells and sends soft ripples with the speech level, and tints green while listening
 * and amber while thinking. Everything is read in the draw phase, so composition runs once.
 */
@Composable
fun SoftOrb(modifier: Modifier = Modifier) {
    val mode by remember { derivedStateOf { orbMode() } }
    val phase = if (!Fx.lite) {
        rememberInfiniteTransition(label = "orb").animateFloat(
            0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart), label = "orbPhase"
        )
    } else null

    Spacer(
        modifier.drawWithCache {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = minOf(size.width, size.height) * 0.26f
            val body = Brush.radialGradient(
                listOf(Color(0xFFE3F1FF), Cyan, Color(0xFF2C6BB5)),
                center = Offset(c.x - r * 0.35f, c.y - r * 0.40f), radius = r * 1.55f
            )
            val shine = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.38f), Color.Transparent),
                center = Offset(c.x - r * 0.32f, c.y - r * 0.38f), radius = r * 0.55f
            )
            fun glowOf(col: Color) = Brush.radialGradient(listOf(col.copy(alpha = 0.34f), Color.Transparent), c, r * 2.3f)
            val glowBlue = glowOf(Cyan); val glowGreen = glowOf(Green); val glowAmber = glowOf(Amber)
            val ripple = Stroke(1.5.dp.toPx())
            val arc = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            val arcR = r * 1.28f
            onDrawBehind {
                val ph = phase?.value ?: 0f
                val m = mode
                val lvl = (SpeechLevel.pct / 100f).coerceIn(0f, 1f)
                val breath = 0.5f + 0.5f * sin(ph * ORB_TAU)
                val accent = if (m == 2) Green else if (m == 1) Amber else Cyan
                val glow = if (m == 2) glowGreen else if (m == 1) glowAmber else glowBlue

                drawCircle(glow, r * 2.3f * (1f + 0.05f * breath + 0.12f * lvl), c, alpha = 0.7f + 0.3f * breath)

                val rippleA = if (m == 0) 0.12f else 0.30f
                for (k in 0 until 3) {
                    val t = (ph + k / 3f) % 1f
                    drawCircle(accent, r * (1.10f + 0.75f * t), c, alpha = (1f - t) * rippleA, style = ripple)
                }
                if (m == 1) {
                    drawArc(
                        accent, ph * 720f, 100f, false,
                        topLeft = Offset(c.x - arcR, c.y - arcR), size = Size(arcR * 2f, arcR * 2f), style = arc
                    )
                }
                scale(1f + 0.025f * breath + 0.09f * lvl, c) {
                    drawCircle(body, r, c)
                    drawCircle(shine, r, c)
                }
            }
        }
    )
}
