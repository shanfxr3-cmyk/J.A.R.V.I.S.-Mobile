package com.jarvis.aiassistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Groq chat completions (OpenAI-compatible), streamed. Blocking: call from a background thread. */
object Ai {
    private const val URL_CHAT = "https://api.groq.com/openai/v1/chat/completions"

    private fun errMsg(code: Int, body: String): String {
        val m = try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { body.take(200) }
        return when (code) {
            401 -> "Invalid API key (401). Check it in Settings."
            429 -> "Rate limit reached (429). Wait a moment or switch to llama-3.1-8b-instant. $m"
            else -> "AI error $code: $m"
        }
    }

    fun stream(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, onDelta: (String) -> Unit
    ): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("messages", msgs)
            .put("stream", true).put("temperature", 0.6)
        if (model.startsWith("openai/gpt-oss")) {
            // Reasoning models: keep thinking short so the spoken answer arrives quickly and is not cut off.
            body.put("max_tokens", 1500).put("reasoning_effort", "low")
        } else {
            body.put("max_tokens", 700)
        }
        val c = URL(URL_CHAT).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "text/event-stream")
            c.setRequestProperty("User-Agent", "Jarvis/0.6 (Android)")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val e = try { c.errorStream?.bufferedReader()?.readText().orEmpty() } catch (_: Exception) { "" }
                throw IOException(errMsg(code, e))
            }
            val sb = StringBuilder()
            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.substring(5).trim()
                    if (d == "[DONE]") break
                    try {
                        val delta = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: continue
                        if (delta.isNull("content")) continue
                        val piece = delta.getString("content")
                        if (piece.isNotEmpty()) { sb.append(piece); onDelta(piece) }
                    } catch (_: JSONException) {}
                }
            }
            if (sb.isEmpty()) throw IOException("The AI returned an empty reply.")
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }
}
