// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTP failure with the server's suggested wait (Retry-After) so callers can back off. */
class AiHttpException(val code: Int, val retryAfterMs: Long, message: String) : IOException(message)

/** Handle for one running request, so the Stop button can really abort the download. */
class AiCall {
    @Volatile var cancelled = false
        private set
    @Volatile internal var conn: HttpURLConnection? = null
    fun cancel() { cancelled = true; try { conn?.disconnect() } catch (_: Throwable) {} }
}

data class ToolCall(val id: String, val name: String, val args: String)
class AiResult(val text: String, val toolCalls: List<ToolCall>)

/** Groq and Gemini chat completions (both OpenAI-compatible), streamed, through the hub or directly. Blocking: call from a background thread. */
object Ai {
    private const val URL_GROQ = "https://api.groq.com/openai/v1/chat/completions"
    private const val URL_GEMINI = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"

    /** Provider keys kept on the phone. Used when there is no hub, and when the hub or its tunnel is down. Set by Store. */
    @Volatile var groqKey: String = ""
    @Volatile var geminiKey: String = ""
    private val noReasoning = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()   // Gemini models that rejected reasoning_effort

    private fun isGemini(m: String) = ModelLadder.providerOf(m) == "gemini"
    private fun keyFor(m: String) = if (isGemini(m)) geminiKey else groqKey
    internal fun hasDirect() = groqKey.isNotBlank() || geminiKey.isNotBlank()

    /** True when a failure means "the hub or its tunnel is not answering" (or its own daily limit is spent), so going direct to Groq or Gemini makes sense. */
    internal fun hubDown(e: IOException): Boolean {
        val http = e as? AiHttpException ?: return true   // could not connect, DNS failure, timeout before any reply
        if (http.code == 429) return e.message?.contains("daily AI limit") == true
        return http.code in listOf(502, 503, 504, 520, 521, 522, 523, 524, 530)
    }

    /** Removes <think>...</think> blocks some reasoning models put in the text (they must not be spoken). */
    private fun stripThink(t: String): String =
        t.replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("(?s)<think>.*$"), "").trim()

    private fun errMsg(code: Int, body: String): String {
        val m = try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) {
            try { JSONArray(body).getJSONObject(0).getJSONObject("error").getString("message") } catch (_: Exception) { body.take(200) }
        }
        return when (code) {
            401 -> "Invalid API key (401). Check it in Settings, AI provider."
            429 -> "Rate limit reached (429). Wait a moment, Jarvis will try the next model. $m"
            530, 502, 503, 504, 1033 -> "Cannot reach the hub (HTTP $code). Check that the hub and its tunnel are running, or add a Groq or Gemini key in Settings, AI provider, so Jarvis keeps answering."
            else -> "AI error $code: " + (if (m.trimStart().startsWith("<")) "unexpected web page returned" else m)
        }
    }

    /** Streams a plain reply (no tools). */
    fun stream(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, call: AiCall? = null, onDelta: (String) -> Unit
    ): String {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        return chat(key, model, system, msgs, null, call, onDelta).text
    }

    /**
     * One model round. Uses the hub when a hub token is set; if the hub or tunnel is down (or no hub is set) it answers
     * directly with the keys on the phone, walking the model ladder on rate limits, outages and retired models.
     * [msgs] are the conversation messages without the system prompt; [tools] is an OpenAI-style tools array.
     * [key] is the hub token (blank when there is no hub).
     */
    fun chat(
        key: String, model: String, system: String, msgs: JSONArray, tools: JSONArray?,
        call: AiCall? = null, onDelta: (String) -> Unit
    ): AiResult {
        val preferred = migrateModel(model)
        val hubOn = key.isNotBlank() && Hub.chatUrl.startsWith("https://")
        if (hubOn) {
            try { return walk(key, true, preferred, system, msgs, tools, call, onDelta) }
            catch (e: IOException) { if (call?.cancelled == true || !hasDirect() || !hubDown(e)) throw e }
        }
        if (!hasDirect()) throw IOException("No AI key is set. Add a Groq or Gemini key in Settings, AI provider.")
        return walk(key, false, preferred, system, msgs, tools, call, onDelta)
    }

    private fun walk(
        hubKey: String, viaHub: Boolean, preferred: String, system: String, msgs: JSONArray, tools: JSONArray?,
        call: AiCall?, onDelta: (String) -> Unit
    ): AiResult {
        val usable: (String) -> Boolean = if (viaHub) { _ -> true } else { m -> keyFor(m).isNotBlank() }
        var useModel = ModelLadder.best(preferred, usable)
        if (!usable(useModel)) throw IOException("No key matches the models in your ladder. Add a Groq or Gemini key in Settings, AI provider.")
        var attempt = 0
        while (true) {
            try {
                return streamOnce(if (viaHub) hubKey else keyFor(useModel), viaHub, useModel, system, msgs, tools, call, onDelta)
            } catch (e: IOException) {
                if (call?.cancelled == true) throw e
                val http = e as? AiHttpException
                // Gemini rejected the reasoning field (or a strict tool schema): retry once without it, then move on.
                if (!viaHub && http?.code == 400 && isGemini(useModel)) {
                    if (noReasoning.add(useModel)) continue
                    ModelLadder.rest(useModel, 120_000)
                    useModel = ModelLadder.next(useModel, preferred, usable) ?: throw e
                    continue
                }
                // Network blip before any text arrived: retry the same model once, fast, before walking the ladder.
                if (http == null && attempt < 1) { attempt++; Thread.sleep(400); continue }
                // A short rate-limit pause is worth waiting for once before switching models.
                if (http != null && (http.code == 429 || http.code in 500..599) && attempt < 1 && http.retryAfterMs in 1..4000) {
                    attempt++
                    var waited = 0L
                    while (waited < http.retryAfterMs && call?.cancelled != true) { Thread.sleep(200); waited += 200 }
                    continue
                }
                val rest = ModelLadder.classify(e) ?: throw e
                ModelLadder.rest(useModel, rest)
                useModel = ModelLadder.next(useModel, preferred, usable) ?: throw e
                attempt = 0
            }
        }
    }

    private fun streamOnce(
        key: String, viaHub: Boolean, model: String, system: String, history: JSONArray, tools: JSONArray?,
        call: AiCall?, onDelta: (String) -> Unit
    ): AiResult {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until history.length()) msgs.put(history.get(i))
        val body = JSONObject().put("model", model).put("messages", msgs)
            .put("stream", true).put("temperature", if (tools != null && tools.length() > 0) 0.3 else 0.6)
        if (tools != null && tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
        val reasons = model.startsWith("openai/gpt-oss") || (isGemini(model) && model.startsWith("gemini-3", true) && model !in noReasoning)
        if (reasons) {
            // Reasoning models: keep thinking short so the spoken answer arrives quickly and is not cut off.
            body.put("max_tokens", 1500).put("reasoning_effort", "low")
        } else {
            body.put("max_tokens", 700)
        }
        val target = if (viaHub) Hub.chatUrl else if (isGemini(model)) URL_GEMINI else URL_GROQ
        if (!target.startsWith("https://")) throw IOException("No https hub address is set. Fix it in Settings, Hub.")
        val c = URL(target).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "text/event-stream")
            c.setRequestProperty("Accept-Encoding", "identity")   // gzip would make the stream arrive in lumps
            c.setRequestProperty("User-Agent", "Jarvis/${BuildConfig.VERSION_NAME} (Android)")
            call?.conn = c
            if (call?.cancelled == true) throw IOException("Cancelled.")
            val payload = body.toString().toByteArray(Charsets.UTF_8)
            c.useCaches = false
            c.setFixedLengthStreamingMode(payload.size)   // sends at once, no chunk buffering
            c.outputStream.use { it.write(payload) }
            val code = c.responseCode
            if (code !in 200..299) {
                val e = try { c.errorStream?.bufferedReader()?.readText().orEmpty() } catch (_: Exception) { "" }
                val retryAfter = (c.getHeaderField("Retry-After")?.trim()?.toDoubleOrNull() ?: 0.0) * 1000
                throw AiHttpException(code, retryAfter.toLong(), errMsg(code, e))
            }
            val sb = StringBuilder()
            val tcIds = HashMap<Int, String>(); val tcNames = HashMap<Int, String>(); val tcArgs = HashMap<Int, StringBuilder>()
            var cut = false
            try {
                c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        if (call?.cancelled == true) throw IOException("Cancelled.")
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val d = line.substring(5).trim()
                        if (d == "[DONE]") break
                        try {
                            val obj = JSONObject(d)
                            // The server can report an error in the middle of the stream.
                            obj.optJSONObject("error")?.let { throw IOException("AI error: " + it.optString("message", "stream failed")) }
                            val ch = obj.optJSONArray("choices")?.optJSONObject(0) ?: continue
                            if (ch.optString("finish_reason") == "length") cut = true
                            val delta = ch.optJSONObject("delta") ?: continue
                            delta.optJSONArray("tool_calls")?.let { arr ->
                                for (k in 0 until arr.length()) {
                                    val t = arr.optJSONObject(k) ?: continue
                                    val idx = t.optInt("index", k)
                                    t.optString("id", "").takeIf { it.isNotEmpty() }?.let { tcIds[idx] = it }
                                    val f = t.optJSONObject("function") ?: continue
                                    f.optString("name", "").takeIf { it.isNotEmpty() }?.let { tcNames[idx] = it }
                                    f.optString("arguments", "").takeIf { it.isNotEmpty() }?.let { tcArgs.getOrPut(idx) { StringBuilder() }.append(it) }
                                }
                            }
                            if (delta.isNull("content") || !delta.has("content")) continue
                            val piece = delta.getString("content")
                            if (piece.isNotEmpty()) { sb.append(piece); onDelta(piece) }
                        } catch (_: JSONException) {}
                    }
                }
            } catch (e: IOException) {
                if (call?.cancelled == true) throw IOException("Cancelled.")
                // Connection dropped part-way: keep what arrived instead of throwing it away.
                if (sb.isEmpty()) throw e
                cut = true
            }
            val out = stripThink(sb.toString())
            val calls = tcNames.keys.sorted().map { i -> ToolCall(tcIds[i] ?: "call_$i", tcNames[i] ?: "", tcArgs[i]?.toString().orEmpty()) }
            if (calls.isNotEmpty() && !cut) return AiResult(out, calls)
            if (out.isEmpty()) throw IOException(if (cut) "The AI ran out of room before answering. Try again." else "The AI returned an empty reply.")
            return AiResult(if (cut) "$out ..." else out, emptyList())
        } finally {
            call?.conn = null
            c.disconnect()
        }
    }
}
