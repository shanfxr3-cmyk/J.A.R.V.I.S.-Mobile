// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTP failure with the server's suggested wait (Retry-After) so callers can back off. */
class AiHttpException(val code: Int, val retryAfterMs: Long, message: String) : IOException(message)

/** Handle for one running request, so the Stop button can really abort the download. */
class AiCall {
    @Volatile var cancelled = false
        private set
    @Volatile internal var conn: HttpURLConnection? = null
    fun cancel() { cancelled = true; try { conn?.disconnect() } catch (_: Throwable) {} }
}

data class ToolCall(val id: String, val name: String, val args: String)
class AiResult(val text: String, val toolCalls: List<ToolCall>)

/** Groq chat completions (OpenAI-compatible), streamed. Blocking: call from a background thread. */
object Ai {
    private const val URL_GROQ = "https://api.groq.com/openai/v1/chat/completions"

    /** Removes <think>...</think> blocks some reasoning models put in the text (they must not be spoken). */
    private fun stripThink(t: String): String =
        t.replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("(?s)<think>.*$"), "").trim()

    private fun errMsg(code: Int, body: String): String {
        val m = try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { body.take(200) }
        return when (code) {
            401 -> "Invalid API key (401). Check it in Settings."
            429 -> "Rate limit reached (429). Wait a moment or switch to $FAST_MODEL in Settings. $m"
            else -> "AI error $code: $m"
        }
    }

    /** Streams a plain reply (no tools). */
    fun stream(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, call: AiCall? = null, onDelta: (String) -> Unit
    ): String {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        return chat(key, model, system, msgs, null, call, onDelta).text
    }

    /**
     * One model round. Walks the model ladder on rate limits, outages and retired models.
     * [msgs] are the conversation messages without the system prompt; [tools] is an OpenAI-style tools array.
     */
    fun chat(
        key: String, model: String, system: String, msgs: JSONArray, tools: JSONArray?,
        call: AiCall? = null, onDelta: (String) -> Unit
    ): AiResult {
        val preferred = migrateModel(model)
        var useModel = ModelLadder.best(preferred)
        var attempt = 0
        while (true) {
            try {
                return streamOnce(key, useModel, system, msgs, tools, call, onDelta)
            } catch (e: IOException) {
                if (call?.cancelled == true) throw e
                val http = e as? AiHttpException
                // A short rate-limit pause is worth waiting for once before switching models.
                if (http != null && (http.code == 429 || http.code in 500..599) && attempt < 1 && http.retryAfterMs in 1..4000) {
                    attempt++
                    var waited = 0L
                    while (waited < http.retryAfterMs && call?.cancelled != true) { Thread.sleep(200); waited += 200 }
                    continue
                }
                val rest = ModelLadder.classify(e) ?: throw e
                ModelLadder.rest(useModel, rest)
                useModel = ModelLadder.next(useModel, preferred) ?: throw e
                attempt = 0
            }
        }
    }

    private fun streamOnce(
        key: String, model: String, system: String, history: JSONArray, tools: JSONArray?,
        call: AiCall?, onDelta: (String) -> Unit
    ): AiResult {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until history.length()) msgs.put(history.get(i))
        val body = JSONObject().put("model", model).put("messages", msgs)
            .put("stream", true).put("temperature", 0.6)
        if (tools != null && tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
        if (model.startsWith("openai/gpt-oss")) {
            // Reasoning models: keep thinking short so the spoken answer arrives quickly and is not cut off.
            body.put("max_tokens", 1500).put("reasoning_effort", "low")
        } else {
            body.put("max_tokens", 700)
        }
        val target = if (key.startsWith("gsk_")) URL_GROQ else Hub.chatUrl
        if (!target.startsWith("https://")) throw IOException("The hub address must start with https:// (your chats and token would travel unencrypted). Fix it in Settings.")
        val c = URL(target).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "text/event-stream")
            c.setRequestProperty("Accept-Encoding", "identity")   // gzip would make the stream arrive in lumps
            c.setRequestProperty("User-Agent", "Jarvis/${BuildConfig.VERSION_NAME} (Android)")
            call?.conn = c
            if (call?.cancelled == true) throw IOException("Cancelled.")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val e = try { c.errorStream?.bufferedReader()?.readText().orEmpty() } catch (_: Exception) { "" }
                val retryAfter = (c.getHeaderField("Retry-After")?.trim()?.toDoubleOrNull() ?: 0.0) * 1000
                throw AiHttpException(code, retryAfter.toLong(), errMsg(code, e))
            }
            val sb = StringBuilder()
            val tcIds = HashMap<Int, String>(); val tcNames = HashMap<Int, String>(); val tcArgs = HashMap<Int, StringBuilder>()
            var cut = false
            try {
                c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        if (call?.cancelled == true) throw IOException("Cancelled.")
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val d = line.substring(5).trim()
                        if (d == "[DONE]") break
                        try {
                            val obj = JSONObject(d)
                            // The server can report an error in the middle of the stream.
                            obj.optJSONObject("error")?.let { throw IOException("AI error: " + it.optString("message", "stream failed")) }
                            val ch = obj.optJSONArray("choices")?.optJSONObject(0) ?: continue
                            if (ch.optString("finish_reason") == "length") cut = true
                            val delta = ch.optJSONObject("delta") ?: continue
                            delta.optJSONArray("tool_calls")?.let { arr ->
                                for (k in 0 until arr.length()) {
                                    val t = arr.optJSONObject(k) ?: continue
                                    val idx = t.optInt("index", k)
                                    t.optString("id", "").takeIf { it.isNotEmpty() }?.let { tcIds[idx] = it }
                                    val f = t.optJSONObject("function") ?: continue
                                    f.optString("name", "").takeIf { it.isNotEmpty() }?.let { tcNames[idx] = it }
                                    f.optString("arguments", "").takeIf { it.isNotEmpty() }?.let { tcArgs.getOrPut(idx) { StringBuilder() }.append(it) }
                                }
                            }
                            if (delta.isNull("content") || !delta.has("content")) continue
                            val piece = delta.getString("content")
                            if (piece.isNotEmpty()) { sb.append(piece); onDelta(piece) }
                        } catch (_: JSONException) {}
                    }
                }
            } catch (e: IOException) {
                if (call?.cancelled == true) throw IOException("Cancelled.")
                // Connection dropped part-way: keep what arrived instead of throwing it away.
                if (sb.isEmpty()) throw e
                cut = true
            }
            val out = stripThink(sb.toString())
            val calls = tcNames.keys.sorted().map { i -> ToolCall(tcIds[i] ?: "call_$i", tcNames[i] ?: "", tcArgs[i]?.toString().orEmpty()) }
            if (calls.isNotEmpty() && !cut) return AiResult(out, calls)
            if (out.isEmpty()) throw IOException(if (cut) "The AI ran out of room before answering. Try again." else "The AI returned an empty reply.")
            return AiResult(if (cut) "$out ..." else out, emptyList())
        } finally {
            call?.conn = null
            c.disconnect()
        }
    }
}
