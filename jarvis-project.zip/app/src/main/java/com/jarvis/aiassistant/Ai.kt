// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTP failure with the server's suggested wait (Retry-After) so callers can back off. */
class AiHttpException(val code: Int, val retryAfterMs: Long, message: String) : IOException(message)

/** Handle for one running request, so the Stop button can really abort the download. */
class AiCall {
    @Volatile var cancelled = false
        private set
    @Volatile internal var conn: HttpURLConnection? = null
    fun cancel() { cancelled = true; try { conn?.disconnect() } catch (_: Throwable) {} }
}

/** Groq chat completions (OpenAI-compatible), streamed. Blocking: call from a background thread. */
object Ai {
    private const val URL_CHAT = "https://api.groq.com/openai/v1/chat/completions"

    /** Removes <think>...</think> blocks some reasoning models put in the text (they must not be spoken). */
    private fun stripThink(t: String): String =
        t.replace(Regex("(?s)<think>.*?</think>"), "").replace(Regex("(?s)<think>.*$"), "").trim()

    private fun errMsg(code: Int, body: String): String {
        val m = try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { body.take(200) }
        return when (code) {
            401 -> "Invalid API key (401). Check it in Settings."
            429 -> "Rate limit reached (429). Wait a moment or switch to $FAST_MODEL in Settings. $m"
            else -> "AI error $code: $m"
        }
    }

    /** Streams a reply. If the saved model has been shut down, retries once with the current default. */
    fun stream(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, call: AiCall? = null, onDelta: (String) -> Unit
    ): String {
        var useModel = migrateModel(model)
        var attempt = 0
        while (true) {
            try {
                return streamOnce(key, useModel, system, history, call, onDelta)
            } catch (e: IOException) {
                if (call?.cancelled == true) throw e
                val m = (e.message ?: "").lowercase()
                val gone = "decommission" in m || "model_not_found" in m || "does not exist" in m || "no longer supported" in m
                if (gone && useModel != DEFAULT_MODEL) { useModel = DEFAULT_MODEL; continue }
                val http = e as? AiHttpException
                val retryable = http != null && (http.code == 429 || http.code in 500..599)
                if (retryable && attempt < 2) {
                    attempt++
                    val wait = (http!!.retryAfterMs.takeIf { it > 0 } ?: (1500L * attempt)).coerceAtMost(8000L)
                    var waited = 0L
                    while (waited < wait && call?.cancelled != true) { Thread.sleep(200); waited += 200 }
                    continue
                }
                // Still rate limited on the big model: try the lighter one once.
                if (http != null && http.code == 429 && useModel != FAST_MODEL) { useModel = FAST_MODEL; attempt = 0; continue }
                throw e
            }
        }
    }

    private fun streamOnce(
        key: String, model: String, system: String,
        history: List<Pair<String, String>>, call: AiCall?, onDelta: (String) -> Unit
    ): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("messages", msgs)
            .put("stream", true).put("temperature", 0.6)
        if (model.startsWith("openai/gpt-oss")) {
            // Reasoning models: keep thinking short so the spoken answer arrives quickly and is not cut off.
            body.put("max_tokens", 1500).put("reasoning_effort", "low")
        } else {
            body.put("max_tokens", 700)
        }
        val c = URL(URL_CHAT).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "text/event-stream")
            c.setRequestProperty("Accept-Encoding", "identity")   // gzip would make the stream arrive in lumps
            c.setRequestProperty("User-Agent", "Jarvis/${BuildConfig.VERSION_NAME} (Android)")
            call?.conn = c
            if (call?.cancelled == true) throw IOException("Cancelled.")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val e = try { c.errorStream?.bufferedReader()?.readText().orEmpty() } catch (_: Exception) { "" }
                val retryAfter = (c.getHeaderField("Retry-After")?.trim()?.toDoubleOrNull() ?: 0.0) * 1000
                throw AiHttpException(code, retryAfter.toLong(), errMsg(code, e))
            }
            val sb = StringBuilder()
            var cut = false
            try {
                c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        if (call?.cancelled == true) throw IOException("Cancelled.")
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val d = line.substring(5).trim()
                        if (d == "[DONE]") break
                        try {
                            val obj = JSONObject(d)
                            // The server can report an error in the middle of the stream.
                            obj.optJSONObject("error")?.let { throw IOException("AI error: " + it.optString("message", "stream failed")) }
                            val ch = obj.optJSONArray("choices")?.optJSONObject(0) ?: continue
                            if (ch.optString("finish_reason") == "length") cut = true
                            val delta = ch.optJSONObject("delta") ?: continue
                            if (delta.isNull("content")) continue
                            val piece = delta.getString("content")
                            if (piece.isNotEmpty()) { sb.append(piece); onDelta(piece) }
                        } catch (_: JSONException) {}
                    }
                }
            } catch (e: IOException) {
                if (call?.cancelled == true) throw IOException("Cancelled.")
                // Connection dropped part-way: keep what arrived instead of throwing it away.
                if (sb.isEmpty()) throw e
                cut = true
            }
            val out = stripThink(sb.toString())
            if (out.isEmpty()) throw IOException(if (cut) "The AI ran out of room before answering. Try again." else "The AI returned an empty reply.")
            return if (cut) "$out ..." else out
        } finally {
            call?.conn = null
            c.disconnect()
        }
    }
}
