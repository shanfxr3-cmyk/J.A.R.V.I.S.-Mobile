// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatController(
    private val ctx: Context,
    private val store: Store,
    private val scope: CoroutineScope
) {
    var nav: (Screen) -> Unit = {}
    var live by mutableStateOf("")
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var partial by mutableStateOf("")
    var voiceMode by mutableStateOf(false)
    var err by mutableStateOf<String?>(null)
    var speaking by mutableStateOf(false)

    /** A risky action waiting for the person's answer. Only the dialog can resolve it; the AI cannot. */
    class Pending(val title: String, val detail: String) {
        val latch = java.util.concurrent.CountDownLatch(1)
        @Volatile var ok = false
        fun answer(v: Boolean) { ok = v; latch.countDown() }
    }
    var pending by mutableStateOf<Pending?>(null)

    private val confirmer = Confirmer { title, detail ->
        val p = Pending(title, detail)
        main.post { pending = p }
        val got = try { p.latch.await(60, java.util.concurrent.TimeUnit.SECONDS) } catch (_: InterruptedException) { false }
        main.post { if (pending === p) pending = null }
        got && p.ok
    }

    private var call: AiCall? = null
    private val voice = Voice(ctx)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var misses = 0

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun localCommand(raw: String): String? = Assistant.localCommand(store, raw, nav)

    private fun systemPrompt(): String = Assistant.systemPrompt(store)

    fun send(raw: String, viaVoice: Boolean) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        err = null
        store.addMessage(true, text)
        val local = if (Assistant.isWakeOff(text)) {
            WakeService.stop(ctx.applicationContext)
            Assistant.WAKE_OFF_REPLY
        } else localCommand(text)
        if (local != null) {
            store.addMessage(false, local)
            reply(local, viaVoice)
            return
        }
        val key = store.apiKey
        val model = store.model
        if (key.isBlank()) {
            err = "No AI key. Add a free Groq or Gemini key in Settings to enable AI replies."
            voiceMode = false
            return
        }
        busy = true
        live = ""
        val sys = systemPrompt()
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        val myCall = AiCall()
        call = myCall
        val speakIt = store.speakReplies || viaVoice
        val cutter = SentenceCutter()
        if (speakIt) {
            // Jarvis talks while the reply is still being written: each finished sentence is spoken at once.
            speaking = true
            WakeService.hold(true)   // the wake detector must not hear (or fight over) the speaker and microphone
            voice.streamStart { speaking = false; if (voiceMode) startListen() }
        }
        job = scope.launch {
            try {
                val sb = StringBuilder()
                var last = 0L
                var acked = false
                val full = withContext(Dispatchers.IO) {
                    Agent.run(ctx.applicationContext, store, sys, hist, ToolMode.FULL, confirmer, myCall, onStatus = { st ->
                        main.post { live = st }
                        if (speakIt && !acked) { acked = true; main.post { voice.streamAdd("On it, sir.") } }
                    }) { d ->
                        sb.append(d)
                        val n = SystemClock.uptimeMillis()
                        if (n - last > 60) { last = n; val snap = sb.toString(); main.post { live = snap } }
                        if (speakIt) {
                            val ready = cutter.feed(SentenceCutter.visible(sb.toString()))
                            if (ready.isNotEmpty()) main.post { ready.forEach { voice.streamAdd(it) } }
                        }
                    }
                }
                busy = false
                live = ""
                val src = Web.takeSources()
                store.addMessage(false, if (src.isEmpty()) full else full + "\n\nSources:\n" + src.joinToString("\n"))
                if (speakIt) {
                    cutter.feed(SentenceCutter.visible(sb.toString()))
                    cutter.flush()?.let { voice.streamAdd(it) }
                    voice.streamEnd()
                } else if (voiceMode) startListen()
            } catch (e: CancellationException) {
                busy = false; live = ""
                if (speakIt) { voice.stopSpeaking(); speaking = false }
                throw e
            } catch (e: Exception) {
                busy = false; live = ""
                if (speakIt) { voice.stopSpeaking(); speaking = false }
                if (myCall.cancelled) return@launch   // the person pressed Stop: not an error
                voiceMode = false
                err = e.message ?: "AI request failed."
            } finally {
                if (call === myCall) call = null
            }
        }
    }

    /** Stop button: really aborts the running request (so it stops using the rate limit). */
    fun stopAi() {
        call?.cancel()
        job?.cancel()
        pending?.answer(false)
        voice.stopSpeaking(); speaking = false
        busy = false; live = ""
    }

    private fun reply(text: String, viaVoice: Boolean) {
        if (store.speakReplies || viaVoice) {
            speaking = true
            WakeService.hold(true)   // the wake detector must not hear (or fight over) the speaker and microphone
            voice.speak(text) { speaking = false; if (voiceMode) startListen() }
        } else if (voiceMode) startListen()
    }

    /** Barge-in: cut Jarvis off mid-sentence (also aborts a reply that is still being written) and listen right away. */
    fun interrupt() {
        call?.cancel()
        job?.cancel()
        busy = false; live = ""
        voice.stopSpeaking(); speaking = false
        if (hasMic()) startListen()
    }

    fun startListen() {
        if (listening || busy) return
        voice.stopSpeaking()
        speaking = false
        WakeService.hold(true)
        err = null
        partial = ""
        listening = true
        voice.listen(
            onPartial = { partial = it },
            onResult = { t -> listening = false; partial = ""; misses = 0; send(t, true) },
            onFail = { msg, retry ->
                listening = false
                partial = ""
                if (voiceMode && retry && ++misses < 3) {
                    main.postDelayed({ if (voiceMode && !busy && !listening) startListen() }, 300)
                } else {
                    voiceMode = false
                    err = msg
                }
            }
        )
    }

    fun toggleVoiceMode() {
        if (voiceMode) {
            voiceMode = false
            voice.stopListening(); voice.stopSpeaking()
            listening = false; speaking = false; partial = ""
        } else {
            voiceMode = true
            misses = 0
            startListen()
        }
    }

    fun stopAll() {
        voiceMode = false
        voice.stopListening(); voice.stopSpeaking()
        listening = false; speaking = false; partial = ""
    }

    fun destroy() {
        voiceMode = false
        call?.cancel()
        job?.cancel()
        voice.destroy()
        WakeService.hold(false)
    }
}

/** Running token estimate. The sources are read through derivedStateOf inside the readout, so streaming text never recomposes the screen. */
@Composable
private fun TokenTicker(ctl: ChatController, store: Store) {
    val baseTk by remember { derivedStateOf { store.messages.sumOf { (it.text.length + 3) / 4 } } }
    val liveTk by remember { derivedStateOf { ctl.live.length / 4 } }
    Row(
        Modifier.background(PanelHi, PillShape).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LiveMono({ "${baseTk + liveTk}" }, 3, color = Ink, size = 12.sp, bold = true)
        Spacer(Modifier.width(4.dp))
        MonoText("tokens", color = Dim, size = 12.sp)
    }
}

private val BubbleUser = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp)
private val BubbleJarvis = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 20.dp)

@Composable
private fun Bubble(m: Msg) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.fillMaxWidth(0.88f).background(if (m.fromUser) Cyan.copy(alpha = 0.18f) else PanelHi, if (m.fromUser) BubbleUser else BubbleJarvis)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            SelectionContainer { Text(m.text, fontSize = 15.sp, fontFamily = ChatFont, lineHeight = 22.sp) }
            Spacer(Modifier.height(4.dp))
            MonoText(monoTime(m.time), color = Dim, size = 11.sp)
        }
    }
}

@Composable
private fun LiveBubble(ctl: ChatController) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
        Column(Modifier.fillMaxWidth(0.88f).background(PanelHi, BubbleJarvis).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(ctl.live.ifEmpty { "Thinking..." }, fontSize = 15.sp, fontFamily = ChatFont, lineHeight = 22.sp, color = if (ctl.live.isEmpty()) Dim else Ink)
        }
    }
}

@Composable
fun ChatScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ctl = remember { ChatController(ctx, store, scope) }
    ctl.nav = nav
    DisposableEffect(Unit) { onDispose { ctl.destroy() } }

    var input by remember { mutableStateOf("") }
    var wantLoop by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { if (wantLoop) ctl.toggleVoiceMode() else ctl.startListen() }
        else ctl.err = "Microphone permission denied. Allow it in Android app settings."
    }
    val listState = rememberLazyListState()
    // Give the wake detector the microphone back as soon as chat is idle again.
    LaunchedEffect(Launch.voice) {
        if (Launch.voice) {
            Launch.voice = false
            if (!ctl.voiceMode) { if (ctl.hasMic()) ctl.toggleVoiceMode() else { wantLoop = true; perm.launch(Manifest.permission.RECORD_AUDIO) } }
        }
    }
    LaunchedEffect(ctl.listening, ctl.speaking, ctl.voiceMode) {
        if (!(ctl.listening || ctl.speaking || ctl.voiceMode)) WakeService.hold(false)
    }
    // Always land on the newest message: when the chat opens, when you send, when a reply arrives, and when the keyboard opens.
    // Streaming text and the keyboard only follow if you are already near the bottom, so reading older messages is not interrupted.
    val imeUp = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current) > 0
    var firstScroll by remember { mutableStateOf(true) }
    suspend fun toBottom(n: Int) { listState.scrollToItem(n - 1); listState.scrollBy(1_000_000f) }
    fun nearBottom(n: Int): Boolean { val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1; return last < 0 || last >= n - 2 }
    LaunchedEffect(store.messages.size) {
        val n = store.messages.size + (if (ctl.busy) 1 else 0)
        if (n > 0 && (firstScroll || store.messages.lastOrNull()?.fromUser == true || nearBottom(n))) toBottom(n)
        firstScroll = false
    }
    LaunchedEffect(ctl.live.length / 40, ctl.busy, imeUp) {
        val n = store.messages.size + (if (ctl.busy) 1 else 0)
        if (n > 0 && nearBottom(n)) toBottom(n)
    }

    val status = when {
        ctl.listening -> "Listening..."
        ctl.busy -> "Thinking..."
        !store.aiReady -> "No AI key. Add a Groq or Gemini key in Settings."
        else -> "${store.model.substringAfterLast('/')}, voice ${if (store.speakReplies) "on" else "off"}"
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
        ScreenHeader("Chat", status, trailing = { TokenTicker(ctl, store) })
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(store.messages) { m -> Bubble(m) }
            if (ctl.busy) item { LiveBubble(ctl) }
        }
        ctl.pending?.let { p ->
            HudDialog(p.title, p.detail, "Allow", { p.answer(true) }, { p.answer(false) }, Cyan, "Deny")
        }
        ctl.err?.let { Text(it, color = Danger, fontSize = 13.sp, fontFamily = BodyFont, modifier = Modifier.padding(vertical = 6.dp)) }
        if (ctl.listening && ctl.partial.isNotEmpty()) Text(ctl.partial, color = Green, fontSize = 14.sp, fontFamily = ChatFont, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(6.dp))
        VoiceWave(Modifier.fillMaxWidth().height(32.dp))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton(if (ctl.speaking) "Interrupt" else if (ctl.listening && !ctl.voiceMode) "Stop mic" else "Mic", Modifier.weight(1f), ctl.speaking || (ctl.listening && !ctl.voiceMode)) {
                if (ctl.speaking) ctl.interrupt()
                else if (ctl.listening) ctl.stopAll()
                else if (ctl.hasMic()) ctl.startListen()
                else { wantLoop = false; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (ctl.voiceMode) "Voice chat on" else "Voice chat off", Modifier.weight(1.4f), ctl.voiceMode) {
                if (ctl.voiceMode) ctl.toggleVoiceMode()
                else if (ctl.hasMic()) ctl.toggleVoiceMode()
                else { wantLoop = true; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (store.speakReplies) "Speak on" else "Speak off", Modifier.weight(1f), store.speakReplies) {
                store.setSpeak(!store.speakReplies)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            HudInput(input, { input = it }, "Message Jarvis", Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            HudBtn(if (ctl.busy) "Stop" else "Send", Modifier.height(56.dp), if (ctl.busy) BtnKind.Danger else BtnKind.Primary) {
                if (ctl.busy) {
                    ctl.stopAi()
                } else {
                    val text = input.trim()
                    if (text.isNotEmpty()) { input = ""; ctl.send(text, false) }
                }
            }
        }
    }
}
