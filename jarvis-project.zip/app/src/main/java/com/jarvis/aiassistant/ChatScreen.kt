package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatController(
    private val ctx: Context,
    private val store: Store,
    private val scope: CoroutineScope
) {
    var nav: (Screen) -> Unit = {}
    var live by mutableStateOf("")
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var partial by mutableStateOf("")
    var voiceMode by mutableStateOf(false)
    var err by mutableStateOf<String?>(null)

    private val voice = Voice(ctx)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var misses = 0

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun localCommand(raw: String): String? {
        val o = raw.trim().trimEnd('.', '!', '?')
        val s = o.lowercase(Locale.ROOT)
        Regex("^(?:please )?(?:add|create|new) (?:a )?task(?: to| called| named)?:? (.+)$").find(s)?.let {
            val r = it.groups[1]!!.range
            val title = o.substring(r.first.coerceAtMost(o.length), (r.last + 1).coerceAtMost(o.length))
            store.addTask(title)
            return "Task added: $title"
        }
        if (Regex("^(?:what are|list|what's|whats)(?: me)?(?: my)? (?:open |pending )?tasks$").matches(s)) {
            val open = store.tasks.filter { !it.done }
            return if (open.isEmpty()) "You have no open tasks." else "You have ${open.size} open: " + open.take(8).joinToString("; ") { it.title } + "."
        }
        if (s.contains("what time is it") || s.contains("what's the time") || s.contains("current time")) {
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        }
        if (s.contains("what's the date") || s.contains("what is the date") || s.contains("today's date")) {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + "."
        }
        Regex("^(?:please )?(?:open|show|go to|take me to)(?: the| my)? (.+)$").find(s)?.let {
            val x = it.groupValues[1]
            val t = when {
                "holo" in x || "3d" in x || "sphere" in x -> Screen.Holo
                "task" in x -> Screen.Tasks
                "memory" in x || "history" in x -> Screen.Memory
                "setting" in x -> Screen.Settings
                "tool" in x -> Screen.Tools
                "home" in x || "dashboard" in x -> Screen.Home
                else -> null
            }
            if (t != null) { nav(t); return "Opening ${t.label}." }
        }
        return null
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        val open = store.tasks.filter { !it.done }.take(10).joinToString("; ") { it.title }
        return "You are J.A.R.V.I.S., a personal AI assistant inside the user's Android app. " +
            "Reply concisely, in plain text without markdown, in a way that sounds natural when spoken aloud. " +
            "Use 1 to 4 sentences unless the user asks for detail. " +
            "You cannot control the phone; the app itself handles commands like opening screens and adding tasks. " +
            (if (store.userName.isNotBlank()) "The user's name is ${store.userName}. " else "") +
            "Now: $now. " + (if (open.isNotEmpty()) "User's open tasks: $open." else "The user has no open tasks.")
    }

    fun send(raw: String, viaVoice: Boolean) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        err = null
        store.addMessage(true, text)
        store.log("Chat message sent")
        val local = localCommand(text)
        if (local != null) {
            store.addMessage(false, local)
            reply(local, viaVoice)
            return
        }
        val key = store.apiKey
        val model = store.model
        if (key.isBlank()) {
            err = "No API key. Add a free Groq key in Settings to enable AI replies."
            voiceMode = false
            return
        }
        busy = true
        live = ""
        val sys = systemPrompt()
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        job = scope.launch {
            try {
                val sb = StringBuilder()
                var last = 0L
                val full = withContext(Dispatchers.IO) {
                    Ai.stream(key, model, sys, hist) { d ->
                        sb.append(d)
                        val n = SystemClock.uptimeMillis()
                        if (n - last > 60) { last = n; val snap = sb.toString(); main.post { live = snap } }
                    }
                }
                busy = false
                live = ""
                store.addMessage(false, full)
                store.log("AI replied")
                reply(full, viaVoice)
            } catch (e: CancellationException) {
                busy = false; live = ""
                throw e
            } catch (e: Exception) {
                busy = false; live = ""
                voiceMode = false
                err = e.message ?: "AI request failed."
            }
        }
    }

    private fun reply(text: String, viaVoice: Boolean) {
        if (store.speakReplies || viaVoice) {
            voice.speak(text) { if (voiceMode) startListen() }
        } else if (voiceMode) startListen()
    }

    fun startListen() {
        if (listening || busy) return
        voice.stopSpeaking()
        err = null
        partial = ""
        listening = true
        voice.listen(
            onPartial = { partial = it },
            onResult = { t -> listening = false; partial = ""; misses = 0; send(t, true) },
            onFail = { msg, retry ->
                listening = false
                partial = ""
                if (voiceMode && retry && ++misses < 3) {
                    main.postDelayed({ if (voiceMode && !busy && !listening) startListen() }, 300)
                } else {
                    voiceMode = false
                    err = msg
                }
            }
        )
    }

    fun toggleVoiceMode() {
        if (voiceMode) {
            voiceMode = false
            voice.stopListening(); voice.stopSpeaking()
            listening = false; partial = ""
        } else {
            voiceMode = true
            misses = 0
            startListen()
        }
    }

    fun stopAll() {
        voiceMode = false
        voice.stopListening(); voice.stopSpeaking()
        listening = false; partial = ""
    }

    fun destroy() {
        voiceMode = false
        job?.cancel()
        voice.destroy()
    }
}

@Composable
fun ChatScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ctl = remember { ChatController(ctx, store, scope) }
    ctl.nav = nav
    DisposableEffect(Unit) { onDispose { ctl.destroy() } }

    var input by remember { mutableStateOf("") }
    var wantLoop by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { if (wantLoop) ctl.toggleVoiceMode() else ctl.startListen() }
        else ctl.err = "Microphone permission denied. Allow it in Android app settings."
    }
    val listState = rememberLazyListState()
    LaunchedEffect(store.messages.size, ctl.live.length / 40) {
        val n = store.messages.size + (if (ctl.busy) 1 else 0)
        if (n > 0) listState.scrollToItem(n - 1)
    }

    val status = when {
        ctl.listening -> "LISTENING..."
        ctl.busy -> "THINKING..."
        store.apiKey.isBlank() -> "No API key - add one in Settings"
        else -> "${store.model} - voice: ${if (store.speakReplies) "speaks replies" else "silent"}"
    }

    Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
        ScreenHeader("AI CHAT", status)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(store.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    HudCard(Modifier.widthIn(max = 300.dp)) {
                        Column {
                            Text(if (m.fromUser) "YOU" else "JARVIS", color = Cyan, fontSize = 11.sp)
                            Text(m.text, fontSize = 14.sp)
                            Text(timeStr(m.time), color = Dim, fontSize = 10.sp)
                        }
                    }
                }
            }
            if (ctl.busy) item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                    HudCard(Modifier.widthIn(max = 300.dp)) {
                        Column {
                            Text("JARVIS", color = Cyan, fontSize = 11.sp)
                            Text(ctl.live.ifEmpty { "..." }, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
        ctl.err?.let { Text(it, color = Color(0xFFFF5555), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
        if (ctl.listening && ctl.partial.isNotEmpty()) Text(ctl.partial, color = Green, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HudButton(if (ctl.listening && !ctl.voiceMode) "STOP MIC" else "MIC", Modifier.weight(1f), ctl.listening && !ctl.voiceMode) {
                if (ctl.listening) ctl.stopAll()
                else if (ctl.hasMic()) ctl.startListen()
                else { wantLoop = false; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (ctl.voiceMode) "VOICE CHAT: ON" else "VOICE CHAT: OFF", Modifier.weight(1.5f), ctl.voiceMode) {
                if (ctl.voiceMode) ctl.toggleVoiceMode()
                else if (ctl.hasMic()) ctl.toggleVoiceMode()
                else { wantLoop = true; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (store.speakReplies) "SPEAK: ON" else "SPEAK: OFF", Modifier.weight(1f), store.speakReplies) {
                store.setSpeak(!store.speakReplies)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Type a message") }
            )
            Spacer(Modifier.width(8.dp))
            Button(enabled = !ctl.busy, onClick = {
                val text = input.trim()
                if (text.isNotEmpty()) { input = ""; ctl.send(text, false) }
            }) { Text("Send") }
        }
    }
}
