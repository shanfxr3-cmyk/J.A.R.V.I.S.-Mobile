package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val NO_AI = "No AI provider is connected yet, so I can't answer. Your message was saved on this device."

@Composable
fun ChatScreen(store: Store) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(store.messages.size) {
        if (store.messages.isNotEmpty()) listState.animateScrollToItem(store.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
        ScreenHeader("AI CHAT", "No AI provider connected. Replies are placeholders until Phase 6.")
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(store.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    HudCard(Modifier.widthIn(max = 300.dp)) {
                        Column {
                            Text(if (m.fromUser) "YOU" else "JARVIS", color = Cyan, fontSize = 11.sp)
                            Text(m.text, fontSize = 14.sp)
                            Text(timeStr(m.time), color = Dim, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Type a message") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                val text = input.trim()
                if (text.isNotEmpty()) {
                    store.addMessage(true, text)
                    store.addMessage(false, NO_AI)
                    store.log("Chat message sent")
                    input = ""
                }
            }) { Text("Send") }
        }
    }
}
