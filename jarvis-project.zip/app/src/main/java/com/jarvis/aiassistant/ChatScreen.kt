// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatController(
    private val ctx: Context,
    private val store: Store,
    private val scope: CoroutineScope
) {
    var nav: (Screen) -> Unit = {}
    var live by mutableStateOf("")
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var partial by mutableStateOf("")
    var voiceMode by mutableStateOf(false)
    var err by mutableStateOf<String?>(null)
    var speaking by mutableStateOf(false)

    /** A risky action waiting for the person's answer. Only the dialog can resolve it; the AI cannot. */
    class Pending(val title: String, val detail: String) {
        val latch = java.util.concurrent.CountDownLatch(1)
        @Volatile var ok = false
        fun answer(v: Boolean) { ok = v; latch.countDown() }
    }
    var pending by mutableStateOf<Pending?>(null)

    private val confirmer = Confirmer { title, detail ->
        val p = Pending(title, detail)
        main.post { pending = p }
        val got = try { p.latch.await(60, java.util.concurrent.TimeUnit.SECONDS) } catch (_: InterruptedException) { false }
        main.post { if (pending === p) pending = null }
        got && p.ok
    }

    private var call: AiCall? = null
    private val voice = Voice(ctx)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var misses = 0

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun localCommand(raw: String): String? = Assistant.localCommand(store, raw, nav)

    private fun systemPrompt(): String = Assistant.systemPrompt(store)

    fun send(raw: String, viaVoice: Boolean) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        err = null
        store.addMessage(true, text)
        val local = if (Assistant.isWakeOff(text)) {
            WakeService.stop(ctx.applicationContext)
            Assistant.WAKE_OFF_REPLY
        } else localCommand(text)
        if (local != null) {
            store.addMessage(false, local)
            reply(local, viaVoice)
            return
        }
        val key = store.apiKey
        val model = store.model
        if (key.isBlank()) {
            err = "No API key. Add a free Groq key in Settings to enable AI replies."
            voiceMode = false
            return
        }
        busy = true
        live = ""
        val sys = systemPrompt()
        val hist = store.messages.takeLast(20).map { (if (it.fromUser) "user" else "assistant") to it.text }
        val myCall = AiCall()
        call = myCall
        val speakIt = store.speakReplies || viaVoice
        val cutter = SentenceCutter()
        if (speakIt) {
            // Jarvis talks while the reply is still being written: each finished sentence is spoken at once.
            speaking = true
            WakeService.hold(true)   // the wake detector must not hear (or fight over) the speaker and microphone
            voice.streamStart { speaking = false; if (voiceMode) startListen() }
        }
        job = scope.launch {
            try {
                val sb = StringBuilder()
                var last = 0L
                var acked = false
                val full = withContext(Dispatchers.IO) {
                    Agent.run(ctx.applicationContext, store, sys, hist, ToolMode.FULL, confirmer, myCall, onStatus = { st ->
                        main.post { live = st }
                        if (speakIt && !acked) { acked = true; main.post { voice.streamAdd("On it, sir.") } }
                    }) { d ->
                        sb.append(d)
                        val n = SystemClock.uptimeMillis()
                        if (n - last > 60) { last = n; val snap = sb.toString(); main.post { live = snap } }
                        if (speakIt) {
                            val ready = cutter.feed(SentenceCutter.visible(sb.toString()))
                            if (ready.isNotEmpty()) main.post { ready.forEach { voice.streamAdd(it) } }
                        }
                    }
                }
                busy = false
                live = ""
                val src = Web.takeSources()
                store.addMessage(false, if (src.isEmpty()) full else full + "\n\nSources:\n" + src.joinToString("\n"))
                if (speakIt) {
                    cutter.feed(SentenceCutter.visible(sb.toString()))
                    cutter.flush()?.let { voice.streamAdd(it) }
                    voice.streamEnd()
                } else if (voiceMode) startListen()
            } catch (e: CancellationException) {
                busy = false; live = ""
                if (speakIt) { voice.stopSpeaking(); speaking = false }
                throw e
            } catch (e: Exception) {
                busy = false; live = ""
                if (speakIt) { voice.stopSpeaking(); speaking = false }
                if (myCall.cancelled) return@launch   // the person pressed Stop: not an error
                voiceMode = false
                err = e.message ?: "AI request failed."
            } finally {
                if (call === myCall) call = null
            }
        }
    }

    /** Stop button: really aborts the running request (so it stops using the rate limit). */
    fun stopAi() {
        call?.cancel()
        job?.cancel()
        pending?.answer(false)
        voice.stopSpeaking(); speaking = false
        busy = false; live = ""
    }

    private fun reply(text: String, viaVoice: Boolean) {
        if (store.speakReplies || viaVoice) {
            speaking = true
            WakeService.hold(true)   // the wake detector must not hear (or fight over) the speaker and microphone
            voice.speak(text) { speaking = false; if (voiceMode) startListen() }
        } else if (voiceMode) startListen()
    }

    /** Barge-in: cut Jarvis off mid-sentence (also aborts a reply that is still being written) and listen right away. */
    fun interrupt() {
        call?.cancel()
        job?.cancel()
        busy = false; live = ""
        voice.stopSpeaking(); speaking = false
        if (hasMic()) startListen()
    }

    fun startListen() {
        if (listening || busy) return
        voice.stopSpeaking()
        speaking = false
        WakeService.hold(true)
        err = null
        partial = ""
        listening = true
        voice.listen(
            onPartial = { partial = it },
            onResult = { t -> listening = false; partial = ""; misses = 0; send(t, true) },
            onFail = { msg, retry ->
                listening = false
                partial = ""
                if (voiceMode && retry && ++misses < 3) {
                    main.postDelayed({ if (voiceMode && !busy && !listening) startListen() }, 300)
                } else {
                    voiceMode = false
                    err = msg
                }
            }
        )
    }

    fun toggleVoiceMode() {
        if (voiceMode) {
            voiceMode = false
            voice.stopListening(); voice.stopSpeaking()
            listening = false; speaking = false; partial = ""
        } else {
            voiceMode = true
            misses = 0
            startListen()
        }
    }

    fun stopAll() {
        voiceMode = false
        voice.stopListening(); voice.stopSpeaking()
        listening = false; speaking = false; partial = ""
    }

    fun destroy() {
        voiceMode = false
        call?.cancel()
        job?.cancel()
        voice.destroy()
        WakeService.hold(false)
    }
}

@Composable
fun ChatScreen(store: Store, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ctl = remember { ChatController(ctx, store, scope) }
    ctl.nav = nav
    DisposableEffect(Unit) { onDispose { ctl.destroy() } }

    var input by remember { mutableStateOf("") }
    var wantLoop by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { if (wantLoop) ctl.toggleVoiceMode() else ctl.startListen() }
        else ctl.err = "Microphone permission denied. Allow it in Android app settings."
    }
    val listState = rememberLazyListState()
    // Give the wake detector the microphone back as soon as chat is idle again.
    LaunchedEffect(Launch.voice) {
        if (Launch.voice) {
            Launch.voice = false
            if (!ctl.voiceMode) { if (ctl.hasMic()) ctl.toggleVoiceMode() else { wantLoop = true; perm.launch(Manifest.permission.RECORD_AUDIO) } }
        }
    }
    LaunchedEffect(ctl.listening, ctl.speaking, ctl.voiceMode) {
        if (!(ctl.listening || ctl.speaking || ctl.voiceMode)) WakeService.hold(false)
    }
    LaunchedEffect(store.messages.size, ctl.live.length / 40) {
        val n = store.messages.size + (if (ctl.busy) 1 else 0)
        // Follow new text only if the person is already at the bottom; don't yank them away while reading.
        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        if (n > 0 && (last < 0 || last >= n - 2)) listState.scrollToItem(n - 1)
    }

    val status = when {
        ctl.listening -> "LISTENING..."
        ctl.busy -> "THINKING..."
        store.apiKey.isBlank() -> "No API key - add one in Settings"
        else -> "${store.model} - voice: ${if (store.speakReplies) "speaks replies" else "silent"}"
    }

    Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
        ScreenHeader("AI CHAT", status)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(store.messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    HudCard(Modifier.widthIn(max = 300.dp)) {
                        Column {
                            Text(if (m.fromUser) "YOU" else "JARVIS", color = Cyan, fontFamily = HudFont, fontSize = 11.sp)
                            SelectionContainer { Text(m.text, fontSize = 14.sp, fontFamily = ChatFont) }
                            Text(timeStr(m.time), color = Dim, fontSize = 10.sp, fontFamily = MonoFont)
                        }
                    }
                }
            }
            if (ctl.busy) item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                    HudCard(Modifier.widthIn(max = 300.dp)) {
                        Column {
                            Text("JARVIS", color = Cyan, fontFamily = HudFont, fontSize = 11.sp)
                            Text(ctl.live.ifEmpty { "..." }, fontSize = 14.sp, fontFamily = ChatFont)
                        }
                    }
                }
            }
        }
        ctl.pending?.let { p ->
            AlertDialog(
                onDismissRequest = { p.answer(false) },
                title = { Text(p.title) },
                text = { Text(p.detail) },
                confirmButton = { TextButton(onClick = { p.answer(true) }) { Text("Allow") } },
                dismissButton = { TextButton(onClick = { p.answer(false) }) { Text("Deny") } }
            )
        }
        ctl.err?.let { Text(it, color = Color(0xFFFF5555), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
        if (ctl.listening && ctl.partial.isNotEmpty()) Text(ctl.partial, color = Green, fontSize = 13.sp, fontFamily = ChatFont, modifier = Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HudButton(if (ctl.speaking) "INTERRUPT" else if (ctl.listening && !ctl.voiceMode) "STOP MIC" else "MIC", Modifier.weight(1f), ctl.speaking || (ctl.listening && !ctl.voiceMode)) {
                if (ctl.speaking) ctl.interrupt()
                else if (ctl.listening) ctl.stopAll()
                else if (ctl.hasMic()) ctl.startListen()
                else { wantLoop = false; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (ctl.voiceMode) "VOICE CHAT: ON" else "VOICE CHAT: OFF", Modifier.weight(1.5f), ctl.voiceMode) {
                if (ctl.voiceMode) ctl.toggleVoiceMode()
                else if (ctl.hasMic()) ctl.toggleVoiceMode()
                else { wantLoop = true; perm.launch(Manifest.permission.RECORD_AUDIO) }
            }
            HudButton(if (store.speakReplies) "SPEAK: ON" else "SPEAK: OFF", Modifier.weight(1f), store.speakReplies) {
                store.setSpeak(!store.speakReplies)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Type a message") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (ctl.busy) {
                    ctl.stopAi()
                } else {
                    val text = input.trim()
                    if (text.isNotEmpty()) { input = ""; ctl.send(text, false) }
                }
            }) { Text(if (ctl.busy) "Stop" else "Send") }
        }
    }
}
