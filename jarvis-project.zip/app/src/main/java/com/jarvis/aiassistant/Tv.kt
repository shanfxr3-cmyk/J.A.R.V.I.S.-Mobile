// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Remote control for a Fire TV (Xiaomi FX Pro L43MB-FPIN) over the home Wi-Fi, using the same code-paired remote service
 * that Amazon's own Fire TV app uses. No ADB, no developer options, no root. The TV must be on the same network as this phone.
 * Cannot do volume, power-off or typing: on Fire TV those only exist through ADB.
 */
object Tv {
    private const val API_KEY = "0987654321"   // public identifier of the protocol, not a secret
    private val KEYS = mapOf("home" to "home", "back" to "back", "menu" to "menu", "select" to "select", "ok" to "select",
        "up" to "dpad_up", "down" to "dpad_down", "left" to "dpad_left", "right" to "dpad_right")
    val ACTIONS = listOf("home", "back", "menu", "select", "up", "down", "left", "right", "play", "pause", "forward", "rewind", "open_app", "list_apps", "wake")
    private val FALLBACK = mapOf("netflix" to "com.netflix.ninja", "youtube" to "com.amazon.firetv.youtube")
    private val PKG = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
    private val NAME_KEYS = setOf("name", "title", "label", "appname", "displayname", "display_name", "friendlyname")

    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun ip(c: Context): String = sp(c).getString("tvIp", "") ?: ""
    private fun token(c: Context): String = Secrets.decrypt(sp(c).getString("tvToken", ""))
    fun configured(c: Context) = ip(c).isNotBlank() && token(c).isNotBlank()
    fun saveIp(c: Context, ip: String) { sp(c).edit().putString("tvIp", ip.trim()).apply() }
    fun forget(c: Context) { sp(c).edit().remove("tvToken").apply() }

    /** Only local network addresses are allowed, because the TV's certificate is self-signed and is accepted without a check. */
    fun privateIp(ip: String): Boolean {
        val p = ip.trim().split(".").mapNotNull { it.toIntOrNull() }
        if (p.size != 4 || p.any { it !in 0..255 }) return false
        return p[0] == 10 || (p[0] == 172 && p[1] in 16..31) || (p[0] == 192 && p[1] == 168)
    }

    private val ssl: SSLContext by lazy {
        SSLContext.getInstance("TLS").apply {
            init(null, arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }), SecureRandom())
        }
    }

    private fun call(ip: String, method: String, path: String, body: String?, tok: String?): Pair<Int, String> {
        require(privateIp(ip)) { "the TV address must be a local network address" }
        val c = URL("https://$ip:8080$path").openConnection() as HttpsURLConnection
        try {
            c.sslSocketFactory = ssl.socketFactory
            c.hostnameVerifier = HostnameVerifier { _, _ -> true }
            c.connectTimeout = 4000; c.readTimeout = 6000
            c.requestMethod = method
            c.setRequestProperty("X-Api-Key", API_KEY)
            c.setRequestProperty("User-Agent", "okhttp/4.10.0")
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (tok != null) c.setRequestProperty("X-Client-Token", tok)
            if (method == "POST") { c.doOutput = true; c.outputStream.use { it.write((body ?: "").toByteArray()) } }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            return code to text
        } finally { c.disconnect() }
    }

    /** The TV's remote service sleeps with the TV. A plain-HTTP request to port 8009 wakes it (raw socket: cleartext rules do not apply). */
    fun wake(ip: String): Boolean = try {
        if (!privateIp(ip)) false else Socket().use { s ->
            s.connect(InetSocketAddress(ip, 8009), 3000); s.soTimeout = 4000
            s.getOutputStream().apply { write("POST /apps/FireTVRemote HTTP/1.1\r\nHost: $ip:8009\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); flush() }
            s.getInputStream().bufferedReader().readLine() != null
        }
    } catch (_: Exception) { false }

    private fun send(ip: String, tok: String?, method: String, path: String, body: String?): Pair<Int, String> =
        try { call(ip, method, path, body, tok) }
        catch (_: IOException) { wake(ip); Thread.sleep(3000); call(ip, method, path, body, tok) }   // asleep: wake once, retry once

    private fun reply(r: Pair<Int, String>, ok: String) = when {
        r.first in 200..299 -> ok
        r.first == 401 || r.first == 403 -> "The TV rejected the pairing. Pair again in Settings, TV remote."
        else -> "The TV answered HTTP ${r.first}."
    }

    // ---------- pairing ----------
    fun showPin(ip: String): String = try {
        wake(ip); Thread.sleep(1500)
        val r = send(ip, null, "POST", "/v1/FireTV/pin/display", JSONObject().put("friendlyName", "Jarvis").toString())
        if (r.first in 200..299) "Look at the TV: it shows a 4-digit code." else "The TV answered HTTP ${r.first}."
    } catch (e: Exception) { "Could not reach the TV at $ip: ${e.message}. Check the address and that the phone is on the TV's Wi-Fi." }

    private fun tokenFrom(text: String): String {
        val t = text.trim()
        return try {
            val j = JSONObject(t)
            listOf("description", "clientToken", "token", "authorization").map { j.optString(it) }.firstOrNull { it.isNotBlank() } ?: ""
        } catch (_: Exception) { t.trim('"') }
    }

    fun verifyPin(c: Context, ip: String, pin: String): String = try {
        val r = send(ip, null, "POST", "/v1/FireTV/pin/verify", JSONObject().put("pin", pin).toString())
        val tok = tokenFrom(r.second)
        if (r.first in 200..299 && tok.isNotBlank() && tok.length < 200) {
            saveIp(c, ip)
            sp(c).edit().putString("tvToken", Secrets.encrypt(tok) ?: "").apply()
            "Paired."
        } else "Pairing failed (HTTP ${r.first}). Show a new code and try again."
    } catch (e: Exception) { "Pairing failed: ${e.message}" }

    // ---------- apps ----------
    private fun walk(x: Any?, out: MutableList<Pair<String, String>>) {
        when (x) {
            is JSONObject -> {
                var name = ""; var pkg = ""
                for (k in x.keys()) {
                    val v = x.opt(k)
                    if (v is String) {
                        if (name.isEmpty() && k.lowercase() in NAME_KEYS) name = v
                        if (pkg.isEmpty() && PKG.matches(v)) pkg = v
                    }
                }
                if (name.isNotEmpty() && pkg.isNotEmpty()) out.add(name to pkg)
                for (k in x.keys()) walk(x.opt(k), out)
            }
            is JSONArray -> for (i in 0 until x.length()) walk(x.opt(i), out)
        }
    }

    private fun apps(ip: String, tok: String): List<Pair<String, String>> {
        val r = send(ip, tok, "GET", "/v1/FireTV/appsV2", null)
        val out = mutableListOf<Pair<String, String>>()
        if (r.first in 200..299) try { walk(if (r.second.trim().startsWith("[")) JSONArray(r.second) else JSONObject(r.second), out) } catch (_: Exception) {}
        return out
    }

    private fun open(ip: String, tok: String, want: String): String {
        val w = want.trim()
        if (w.isEmpty()) return "Which app?"
        var pkg: String? = if (w.contains('.')) w else null
        var label = w
        if (pkg == null) {
            val lw = w.lowercase()
            val list = apps(ip, tok)
            val hit = list.firstOrNull { it.first.lowercase() == lw } ?: list.firstOrNull { it.first.lowercase().startsWith(lw) }
                ?: list.firstOrNull { it.first.lowercase().contains(lw) }
            if (hit != null) { pkg = hit.second; label = hit.first } else pkg = FALLBACK[lw]
        }
        if (pkg == null) return "I could not find an app called $w on the TV. Ask for list_apps to see what is installed."
        return reply(send(ip, tok, "POST", "/v1/FireTV/app/" + URLEncoder.encode(pkg, "UTF-8"), null), "Opening $label.")
    }

    private fun scan(ip: String, tok: String, dir: String, secs: Int): String {
        fun body(t: String) = """{"direction":"$dir","keyAction":{"keyActionType":"$t"}}"""
        val r = send(ip, tok, "POST", "/v1/media?action=scan", body("keyDown"))
        Thread.sleep(secs * 1000L)
        send(ip, tok, "POST", "/v1/media?action=scan", body("keyUp"))
        return reply(r, if (dir == "forward") "Skipped forward." else "Rewound.")
    }

    /** Runs one remote action and returns a short sentence. Blocking: call from a background thread. */
    fun run(c: Context, action: String, arg: String = ""): String {
        val ip = ip(c); val tok = token(c)
        if (ip.isBlank() || tok.isBlank()) return "The TV is not paired yet. Open Settings, TV remote, and pair it with the code on the screen."
        if (!privateIp(ip)) return "The TV address must be a local network address."
        val a = action.trim().lowercase().replace(' ', '_')
        return try {
            when {
                a == "wake" -> if (wake(ip)) "The TV is waking up." else "The TV did not answer. Is it on the same Wi-Fi as this phone?"
                a in KEYS -> reply(send(ip, tok, "POST", "/v1/FireTV?action=${KEYS[a]}", null), "Sent $a.")
                a == "play" || a == "pause" -> reply(send(ip, tok, "POST", "/v1/media?action=$a", null), if (a == "play") "Playing." else "Paused.")
                a == "forward" || a == "rewind" -> scan(ip, tok, if (a == "forward") "forward" else "backward", arg.trim().toIntOrNull()?.coerceIn(1, 30) ?: 3)
                a == "list_apps" -> apps(ip, tok).map { it.first }.distinct().take(40).joinToString(", ").ifEmpty { "I could not read the app list." }
                a == "open_app" -> open(ip, tok, arg)
                a.startsWith("volume") || a == "mute" || a == "power_off" || a == "type" ->
                    "Volume, power-off and typing need ADB, which is switched off, so the TV remote cannot do them."
                else -> "Unknown TV action: $action."
            }
        } catch (_: IOException) { "Could not reach the TV. It must be on, on the same Wi-Fi as this phone, with the right address in Settings." }
        catch (e: Exception) { "TV error: ${e.message}" }
    }

    val tools: List<ToolDef> = listOf(
        ToolDef("tv_control", "Control the living-room Xiaomi Fire TV over Wi-Fi: navigation keys, play/pause, skip, and opening apps by name (Netflix, YouTube, Prime Video, Hotstar...). " +
            "It cannot change volume, power the TV off, or type text.",
            listOf(
                ToolDef.Param("action", "string", "What to do", true, ACTIONS),
                ToolDef.Param("arg", "string", "App name for open_app, or seconds (1-30) for forward/rewind", false)
            )) { c, _, a -> run(c, a.optString("action"), a.optString("arg")) }
    )
}
