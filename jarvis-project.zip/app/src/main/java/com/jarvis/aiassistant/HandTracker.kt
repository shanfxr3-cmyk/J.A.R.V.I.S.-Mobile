// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import android.os.Process
import android.os.SystemClock
import android.util.Range
import android.util.Size
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.hypot

/** One hand = 21 landmarks stored flat as x0,y0,z0,x1,y1,z1,... (x, y normalised 0..1 in the upright image). */
const val LM = 21
class HandData(val hands: List<FloatArray>, val imgW: Int, val imgH: Int)

/** State written by the tracker, read by the UI. Nothing here is faked: it only changes when real frames/results arrive. */
class TrackState {
    @Volatile var status = "OFF"        // OFF, STARTING, CAMERA ACTIVE, ERROR
    @Volatile var error: String? = null
    @Volatile var data: HandData? = null
    @Volatile var handCount = 0
    @Volatile var confidence = 0f
    @Volatile var fps = 0
    @Volatile var latency = 0
    @Volatile var dropped = 0
    @Volatile var delegate = "--"
    @Volatile var gesture = "NONE"
}

val HAND_CONNECTIONS = intArrayOf(
    0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
    9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17
)

/** Thumb-tip to index-tip distance divided by palm size (wrist to middle knuckle). Small = pinching. */
fun pinchRatio(h: FloatArray, w: Int, hgt: Int): Float {
    if (h.size < LM * 3) return 1f
    fun d(a: Int, b: Int) = hypot((h[a * 3] - h[b * 3]) * w, (h[a * 3 + 1] - h[b * 3 + 1]) * hgt)
    val palm = d(0, 9)
    return if (palm > 0f) d(4, 8) / palm else 1f
}

/**
 * Low-latency hand tracker.
 *  - Exactly one frame is in the detector at a time and it is always the newest camera frame, so latency cannot build up.
 *  - Camera frames are copied into two re-used bitmaps: no per-frame allocation, no garbage collector stutter.
 *  - The detector runs on the CPU by default. On this class of phone the GPU delegate competes with the 3D renderer
 *    and the screen compositor, which is what makes the display stutter or blank out.
 *  - The camera preview stream is optional and off by default (one camera stream and one TextureView less).
 */
class HandTracker(private val ctx: Context, private val ts: TrackState) {
    @Volatile private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var exec: ExecutorService? = null
    @Volatile private var active = false
    @Volatile private var mirror = false
    @Volatile private var gpuPending = false
    @Volatile var onHands: ((List<FloatArray>, Int, Int) -> Unit)? = null
    @Volatile var onFrame: (() -> Unit)? = null
    private val sp = ctx.getSharedPreferences("trk", Context.MODE_PRIVATE)

    private val inFlight = AtomicInteger(0)
    @Volatile private var submitAt = 0L
    @Volatile private var curW = 1
    @Volatile private var curH = 1
    private var lastTs = 0L
    private var results = 0
    private var lastFpsMs = 0L
    private var dropCount = 0

    private var srcBmp: Bitmap? = null
    private var dstBmp: Bitmap? = null
    private var dstCanvas: Canvas? = null
    private val rotM = Matrix()

    private var boundOwner: LifecycleOwner? = null
    private var boundFront = true
    private var boundPreview = false

    fun clearGpuBad() { sp.edit().putBoolean("gpu_bad", false).putBoolean("gpu_pending", false).apply() }
    fun markGpuBad() { sp.edit().putBoolean("gpu_bad", true).putBoolean("gpu_pending", false).apply() }

    /** Full readable cause of a failure (type, message, causes, first stack frames) so it can be fixed in one go. */
    private fun describe(e: Throwable): String {
        val sb = StringBuilder()
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth < 4) {
            sb.append(if (depth == 0) "" else "caused by ").append(t.javaClass.name).append(": ").append(t.message ?: "(no message)").append('\n')
            t.stackTrace.take(3).forEach { sb.append("   at ").append(it.toString()).append('\n') }
            t = t.cause
            depth++
        }
        return sb.toString().trimEnd()
    }

    private fun build(gpu: Boolean): HandLandmarker {
        val bb = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) bb.setDelegate(Delegate.GPU)
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(bb.build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.35f)
            .setMinHandPresenceConfidence(0.35f)
            .setMinTrackingConfidence(0.35f)
            .setResultListener { r, img -> onResult(r, img) }
            .setErrorListener { e -> inFlight.set(0); ts.error = "Detector: ${e.message}" }
            .build()
        return HandLandmarker.createFromOptions(ctx, opts)
    }

    @SuppressLint("UnsafeOptInUsageError")
    fun start(owner: LifecycleOwner, previewView: PreviewView?, front: Boolean, wantGpu: Boolean) {
        stop()
        ts.error = null
        ts.status = "STARTING"
        mirror = front

        // If the previous GPU start never produced a result, the GPU path crashed: disable it.
        if (sp.getBoolean("gpu_pending", false)) sp.edit().putBoolean("gpu_bad", true).putBoolean("gpu_pending", false).apply()
        val useGpu = wantGpu && !sp.getBoolean("gpu_bad", false)
        try {
            if (useGpu) {
                sp.edit().putBoolean("gpu_pending", true).commit()
                gpuPending = true
                landmarker = try {
                    build(true).also { ts.delegate = "GPU" }
                } catch (e: Throwable) {
                    sp.edit().putBoolean("gpu_pending", false).apply()
                    gpuPending = false
                    build(false).also { ts.delegate = "CPU" }
                }
            } else {
                landmarker = build(false)
                ts.delegate = "CPU"
            }
        } catch (e: Throwable) {
            android.util.Log.e("HandTracker", "Hand model failed to load", e)
            ts.error = "Hand model failed to load:\n" + describe(e)
            ts.status = "ERROR"
            return
        }

        active = true
        inFlight.set(0)
        dropCount = 0
        exec = Executors.newSingleThreadExecutor { r ->
            Thread {
                try { Process.setThreadPriority(Process.THREAD_PRIORITY_FOREGROUND) } catch (_: Throwable) {}
                r.run()
            }
        }
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                if (!active) return@addListener
                provider = future.get()
                boundOwner = owner
                boundFront = front
                bindCamera(owner, previewView, front)
            } catch (e: Throwable) {
                ts.error = "Camera failed: ${e.message}"
                ts.status = "ERROR"
                stop()
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    /** Switch the camera preview on or off without reloading the detector. Call from the main thread. */
    fun setPreview(previewView: PreviewView?) {
        val o = boundOwner ?: return
        if (!active || provider == null) return
        if ((previewView != null) == boundPreview) return
        try { bindCamera(o, previewView, boundFront) } catch (e: Throwable) { ts.error = "Camera failed: ${e.message}" }
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun bindCamera(owner: LifecycleOwner, previewView: PreviewView?, front: Boolean) {
        val p = provider ?: return
        val ex = exec ?: return
        p.unbindAll()
        // 4:3 uses the full sensor area (16:9 crops the field of view). 640x480 keeps far hands detectable.
        val rs = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
            .build()
        val ab = ImageAnalysis.Builder()
            .setResolutionSelector(rs)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
        try {
            // Fixed 30 fps (low light cannot drop it to 15) and no video stabilisation (it crops the view and adds delay).
            Camera2Interop.Extender(ab)
                .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(30, 30))
                .setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
        } catch (_: Throwable) {}
        val analysis = ab.build()
        analysis.setAnalyzer(ex) { proxy -> analyze(proxy) }
        val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val cam = if (previewView != null) {
            val preview = Preview.Builder().setResolutionSelector(rs).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            p.bindToLifecycle(owner, sel, preview, analysis)
        } else {
            p.bindToLifecycle(owner, sel, analysis)
        }
        boundPreview = previewView != null
        // Widest field of view the camera offers (only differs on multi-lens logical cameras).
        try { cam.cameraInfo.zoomState.value?.let { cam.cameraControl.setZoomRatio(it.minZoomRatio) } } catch (_: Throwable) {}
    }

    private fun rotateInto(src: Bitmap, deg: Int): Bitmap {
        val swap = deg % 180 != 0
        val dw = if (swap) src.height else src.width
        val dh = if (swap) src.width else src.height
        var d = dstBmp
        if (d == null || d.width != dw || d.height != dh) {
            d?.recycle()
            d = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
            dstBmp = d
            dstCanvas = Canvas(d)
        }
        rotM.reset()
        rotM.postRotate(deg.toFloat())
        when (deg) {
            90 -> rotM.postTranslate(src.height.toFloat(), 0f)
            180 -> rotM.postTranslate(src.width.toFloat(), src.height.toFloat())
            270 -> rotM.postTranslate(0f, src.width.toFloat())
        }
        dstCanvas?.drawBitmap(src, rotM, null)
        return d
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val lm = landmarker
            if (!active || lm == null) return
            val now = SystemClock.uptimeMillis()
            if (inFlight.get() > 0) {
                // Detector still busy: drop this frame so the next one is the freshest. Recover if a result never came back.
                if (now - submitAt < 500) { dropCount++; ts.dropped = dropCount; return }
                inFlight.set(0)
            }
            val deg = ((proxy.imageInfo.rotationDegrees % 360) + 360) % 360
            val w = proxy.width
            val h = proxy.height
            val plane = proxy.planes[0]
            val upright: Bitmap
            if (plane.pixelStride == 4 && plane.rowStride == w * 4) {
                var s = srcBmp
                if (s == null || s.width != w || s.height != h) {
                    s?.recycle()
                    s = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    srcBmp = s
                }
                val buf = plane.buffer
                buf.rewind()
                s.copyPixelsFromBuffer(buf)
                upright = if (deg == 0) s else rotateInto(s, deg)
            } else {
                val b = proxy.toBitmap()
                upright = if (deg == 0) b else rotateInto(b, deg).also { b.recycle() }
            }
            if (ts.status != "CAMERA ACTIVE") ts.status = "CAMERA ACTIVE"
            var t = SystemClock.uptimeMillis()
            if (t <= lastTs) t = lastTs + 1
            lastTs = t
            curW = upright.width
            curH = upright.height
            submitAt = t
            inFlight.set(1)
            try {
                lm.detectAsync(BitmapImageBuilder(upright).build(), t)
            } catch (e: Throwable) {
                inFlight.set(0)
                throw e
            }
        } catch (e: Throwable) {
            if (active) ts.error = "Frame error: ${e.message}"
        } finally {
            proxy.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult, img: MPImage) {
        inFlight.set(0)
        if (!active) return
        if (gpuPending) {
            gpuPending = false
            sp.edit().putBoolean("gpu_pending", false).apply()
        }
        val mir = mirror
        val hands = ArrayList<FloatArray>(2)
        for (h in r.landmarks()) {
            if (h.size < LM) continue
            val a = FloatArray(LM * 3)
            for (i in 0 until LM) {
                val p = h[i]
                a[i * 3] = if (mir) 1f - p.x() else p.x()
                a[i * 3 + 1] = p.y()
                a[i * 3 + 2] = p.z()
            }
            hands.add(a)
        }
        // Left-to-right so hand slot 0/1 stay stable between frames.
        if (hands.size == 2 && hands[0][0] > hands[1][0]) { val t = hands[0]; hands[0] = hands[1]; hands[1] = t }
        val w = curW
        val hh = curH
        ts.data = HandData(hands, w, hh)
        ts.handCount = hands.size
        onHands?.invoke(hands, w, hh)
        var sum = 0f
        var n = 0
        for (hd in r.handedness()) { val s = hd.firstOrNull()?.score(); if (s != null) { sum += s; n++ } }
        ts.confidence = if (n == 0) 0f else sum / n
        val now = SystemClock.uptimeMillis()
        ts.latency = (now - r.timestampMs()).toInt().coerceAtLeast(0)
        results++
        if (now - lastFpsMs >= 1000) {
            ts.fps = results
            results = 0
            lastFpsMs = now
        }
        onFrame?.invoke()
    }

    fun stop() {
        active = false
        try { provider?.unbindAll() } catch (_: Throwable) {}
        provider = null
        boundOwner = null
        boundPreview = false
        exec?.shutdown()
        exec = null
        try { landmarker?.close() } catch (_: Throwable) {}
        landmarker = null
        inFlight.set(0)
        if (gpuPending) { gpuPending = false; sp.edit().putBoolean("gpu_pending", false).apply() }
        srcBmp = null
        dstBmp = null; dstCanvas = null
        ts.status = "OFF"
        ts.data = null
        ts.handCount = 0
        ts.confidence = 0f
        ts.fps = 0
        ts.latency = 0
        ts.dropped = 0
        ts.gesture = "NONE"
        onHands?.invoke(emptyList(), 1, 1)
        onFrame?.invoke()
    }
}
