package com.jarvis.aiassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

data class LmPt(val x: Float, val y: Float, val z: Float)
class HandData(val hands: List<List<LmPt>>, val imgW: Int, val imgH: Int)

/** State written by the tracker, read by the UI. Nothing here is faked: it only changes when real frames/results arrive. */
class TrackState {
    @Volatile var status = "OFF"        // OFF, STARTING, CAMERA ACTIVE, ERROR
    @Volatile var error: String? = null
    @Volatile var data: HandData? = null
    @Volatile var handCount = 0
    @Volatile var confidence = 0f
    @Volatile var fps = 0
}

val HAND_CONNECTIONS = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

/** Thumb-tip to index-tip distance divided by palm size (wrist to middle knuckle). Small = pinching. */
fun pinchRatio(h: List<LmPt>, w: Int, hgt: Int): Float {
    if (h.size < 21) return 1f
    fun d(a: LmPt, b: LmPt) = hypot((a.x - b.x) * w, (a.y - b.y) * hgt)
    val palm = d(h[0], h[9])
    return if (palm > 0f) d(h[4], h[8]) / palm else 1f
}

class HandTracker(private val ctx: Context, private val ts: TrackState) {
    @Volatile private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var exec: ExecutorService? = null
    @Volatile private var active = false
    private var lastTs = 0L
    private var results = 0
    private var lastFpsMs = 0L

    fun start(owner: LifecycleOwner, previewView: PreviewView, front: Boolean) {
        stop()
        ts.error = null
        ts.status = "STARTING"
        try {
            val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { r, img -> onResult(r, img) }
                .setErrorListener { e -> ts.error = "Detector: ${e.message}" }
                .build()
            landmarker = HandLandmarker.createFromOptions(ctx, opts)
        } catch (e: Throwable) {
            ts.error = "Hand model failed to load: ${e.message}"
            ts.status = "ERROR"
            return
        }
        active = true
        val executor = Executors.newSingleThreadExecutor()
        exec = executor
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                if (!active) return@addListener
                val p = future.get()
                provider = p
                p.unbindAll()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { proxy -> analyze(proxy, front) }
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                p.bindToLifecycle(owner, sel, preview, analysis)
            } catch (e: Throwable) {
                ts.error = "Camera failed: ${e.message}"
                ts.status = "ERROR"
                stop()
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun analyze(proxy: ImageProxy, front: Boolean) {
        try {
            val lm = landmarker
            if (!active || lm == null) return
            val bmp = proxy.toBitmap()
            val m = Matrix()
            m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
            if (front) m.postScale(-1f, 1f)
            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rot !== bmp) bmp.recycle()
            if (ts.status != "CAMERA ACTIVE") ts.status = "CAMERA ACTIVE"
            var t = SystemClock.uptimeMillis()
            if (t <= lastTs) t = lastTs + 1
            lastTs = t
            lm.detectAsync(BitmapImageBuilder(rot).build(), t)
        } catch (e: Throwable) {
            if (active) ts.error = "Frame error: ${e.message}"
        } finally {
            proxy.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult, img: MPImage) {
        val hands = r.landmarks().map { h -> h.map { LmPt(it.x(), it.y(), it.z()) } }
        ts.data = HandData(hands, img.width, img.height)
        ts.handCount = hands.size
        val scores = r.handedness().mapNotNull { it.firstOrNull()?.score() }
        ts.confidence = if (scores.isEmpty()) 0f else scores.average().toFloat()
        results++
        val now = SystemClock.uptimeMillis()
        if (now - lastFpsMs >= 1000) {
            ts.fps = results
            results = 0
            lastFpsMs = now
        }
    }

    fun stop() {
        active = false
        try { provider?.unbindAll() } catch (_: Throwable) {}
        provider = null
        exec?.shutdown()
        exec = null
        try { landmarker?.close() } catch (_: Throwable) {}
        landmarker = null
        ts.status = "OFF"
        ts.data = null
        ts.handCount = 0
        ts.confidence = 0f
        ts.fps = 0
    }
}
