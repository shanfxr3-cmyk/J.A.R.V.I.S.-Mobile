package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import android.os.Process
import android.os.SystemClock
import android.util.Range
import android.util.Size
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

data class LmPt(val x: Float, val y: Float, val z: Float)
class HandData(val hands: List<List<LmPt>>, val imgW: Int, val imgH: Int)

/** State written by the tracker, read by the UI. Nothing here is faked: it only changes when real frames/results arrive. */
class TrackState {
    @Volatile var status = "OFF"        // OFF, STARTING, CAMERA ACTIVE, ERROR
    @Volatile var error: String? = null
    @Volatile var data: HandData? = null
    @Volatile var handCount = 0
    @Volatile var confidence = 0f
    @Volatile var fps = 0
    @Volatile var latency = 0
    @Volatile var delegate = "--"
    @Volatile var gesture = "NONE"
}

val HAND_CONNECTIONS = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

/** Thumb-tip to index-tip distance divided by palm size (wrist to middle knuckle). Small = pinching. */
fun pinchRatio(h: List<LmPt>, w: Int, hgt: Int): Float {
    if (h.size < 21) return 1f
    fun d(a: LmPt, b: LmPt) = hypot((a.x - b.x) * w, (a.y - b.y) * hgt)
    val palm = d(h[0], h[9])
    return if (palm > 0f) d(h[4], h[8]) / palm else 1f
}

class HandTracker(private val ctx: Context, private val ts: TrackState) {
    @Volatile private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var exec: ExecutorService? = null
    @Volatile private var active = false
    @Volatile private var mirror = false
    @Volatile private var gpuPending = false
    @Volatile var onHands: ((List<List<LmPt>>, Int, Int) -> Unit)? = null
    private val sp = ctx.getSharedPreferences("trk", Context.MODE_PRIVATE)
    private var lastSubmit = 0L
    private var lastTs = 0L
    private var results = 0
    private var lastFpsMs = 0L

    /** Call when the user explicitly re-enables GPU after it was auto-disabled. */
    fun clearGpuBad() { sp.edit().putBoolean("gpu_bad", false).putBoolean("gpu_pending", false).apply() }

    private fun build(gpu: Boolean): HandLandmarker {
        val bb = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) bb.setDelegate(Delegate.GPU)
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(bb.build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.35f)
            .setMinHandPresenceConfidence(0.35f)
            .setMinTrackingConfidence(0.35f)
            .setResultListener { r, img -> onResult(r, img) }
            .setErrorListener { e -> ts.error = "Detector: ${e.message}" }
            .build()
        return HandLandmarker.createFromOptions(ctx, opts)
    }

    @SuppressLint("UnsafeOptInUsageError")
    fun start(owner: LifecycleOwner, previewView: PreviewView, front: Boolean, wantGpu: Boolean) {
        stop()
        ts.error = null
        ts.status = "STARTING"
        mirror = front

        // If the previous GPU start never produced a result, the GPU path crashed: disable it.
        if (sp.getBoolean("gpu_pending", false)) sp.edit().putBoolean("gpu_bad", true).putBoolean("gpu_pending", false).apply()
        val useGpu = wantGpu && !sp.getBoolean("gpu_bad", false)
        try {
            if (useGpu) {
                sp.edit().putBoolean("gpu_pending", true).commit()
                gpuPending = true
                landmarker = try {
                    build(true).also { ts.delegate = "GPU" }
                } catch (e: Throwable) {
                    sp.edit().putBoolean("gpu_pending", false).apply()
                    gpuPending = false
                    build(false).also { ts.delegate = "CPU" }
                }
            } else {
                landmarker = build(false)
                ts.delegate = "CPU"
            }
        } catch (e: Throwable) {
            ts.error = "Hand model failed to load: ${e.message}"
            ts.status = "ERROR"
            return
        }

        active = true
        val executor = Executors.newSingleThreadExecutor { r ->
            Thread {
                try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (_: Throwable) {}
                r.run()
            }
        }
        exec = executor
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                if (!active) return@addListener
                val p = future.get()
                provider = p
                p.unbindAll()
                // 4:3 uses the full sensor area (16:9 crops the field of view).
                val rs = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                    .build()
                val preview = Preview.Builder().setResolutionSelector(rs).build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val ab = ImageAnalysis.Builder()
                    .setResolutionSelector(rs)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                // Lock 30 fps so low light cannot drop the camera to 15 fps.
                try {
                    Camera2Interop.Extender(ab).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(30, 30))
                } catch (_: Throwable) {}
                val analysis = ab.build()
                analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val cam = p.bindToLifecycle(owner, sel, preview, analysis)
                // Widest field of view the camera offers (only differs on multi-lens logical cameras).
                try {
                    cam.cameraInfo.zoomState.value?.let { cam.cameraControl.setZoomRatio(it.minZoomRatio) }
                } catch (_: Throwable) {}
            } catch (e: Throwable) {
                ts.error = "Camera failed: ${e.message}"
                ts.status = "ERROR"
                stop()
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val lm = landmarker
            if (!active || lm == null) return
            val nowMs = SystemClock.uptimeMillis()
            if (nowMs - lastSubmit < 12) return
            lastSubmit = nowMs
            val bmp = proxy.toBitmap()
            val deg = proxy.imageInfo.rotationDegrees
            val rot = if (deg == 0) bmp else {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, false)
                if (r !== bmp) bmp.recycle()
                r
            }
            if (ts.status != "CAMERA ACTIVE") ts.status = "CAMERA ACTIVE"
            var t = SystemClock.uptimeMillis()
            if (t <= lastTs) t = lastTs + 1
            lastTs = t
            lm.detectAsync(BitmapImageBuilder(rot).build(), t)
        } catch (e: Throwable) {
            if (active) ts.error = "Frame error: ${e.message}"
        } finally {
            proxy.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult, img: MPImage) {
        if (!active) return
        if (gpuPending) {
            gpuPending = false
            sp.edit().putBoolean("gpu_pending", false).apply()
        }
        val mir = mirror
        // Sorted left-to-right so hand slot 0/1 stay stable between frames.
        val hands = r.landmarks()
            .map { h -> h.map { LmPt(if (mir) 1f - it.x() else it.x(), it.y(), it.z()) } }
            .filter { it.size >= 21 }
            .sortedBy { it[0].x }
        ts.data = HandData(hands, img.width, img.height)
        ts.handCount = hands.size
        onHands?.invoke(hands, img.width, img.height)
        val scores = r.handedness().mapNotNull { it.firstOrNull()?.score() }
        ts.confidence = if (scores.isEmpty()) 0f else scores.average().toFloat()
        val now = SystemClock.uptimeMillis()
        ts.latency = (now - r.timestampMs()).toInt().coerceAtLeast(0)
        results++
        if (now - lastFpsMs >= 1000) {
            ts.fps = results
            results = 0
            lastFpsMs = now
        }
    }

    fun stop() {
        active = false
        try { provider?.unbindAll() } catch (_: Throwable) {}
        provider = null
        exec?.shutdown()
        exec = null
        try { landmarker?.close() } catch (_: Throwable) {}
        landmarker = null
        if (gpuPending) { gpuPending = false; sp.edit().putBoolean("gpu_pending", false).apply() }
        ts.status = "OFF"
        ts.data = null
        ts.handCount = 0
        ts.confidence = 0f
        ts.fps = 0
        ts.latency = 0
        ts.gesture = "NONE"
        onHands?.invoke(emptyList(), 1, 1)
    }
}
