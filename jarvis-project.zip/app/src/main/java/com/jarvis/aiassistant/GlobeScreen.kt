// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/** Live globe: aircraft, satellites, earthquakes, radar, rail and 3D cities, rendered by CesiumJS in a WebView. */
object GlobeBridge {
    private var view: WebView? = null
    private var ready = false
    private val pending = ArrayList<String>()
    fun attach(v: WebView) { synchronized(pending) { view = v; ready = false } }
    fun detach() { synchronized(pending) { view = null; ready = false } }
    fun onLoaded() { synchronized(pending) { ready = true; pending.forEach { view?.evaluateJavascript(it, null) }; pending.clear() } }
    /** Lets voice/chat drive the globe, e.g. run("jarvis.fly('Tokyo')"); queued until the page is loaded. */
    fun run(js: String) {
        synchronized(pending) {
            val v = view
            if (v != null && ready) v.post { v.evaluateJavascript(js, null) } else pending.add(js)
        }
    }
}

/** Lets the globe page call the Windy Webcams API through the app (no CORS limits). Only api.windy.com is allowed. */
class NetBridge(private val wv: WebView) {
    @android.webkit.JavascriptInterface
    fun get(id: String, url: String, key: String) {
        Thread {
            var code = 0
            var body = ""
            try {
                if (java.net.URL(url).host == "api.windy.com") {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 20000
                    if (key.isNotEmpty()) c.setRequestProperty("x-windy-api-key", key)
                    code = c.responseCode
                    body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                }
            } catch (e: Exception) { code = 0 }
            val b64 = android.util.Base64.encodeToString(body.toByteArray(), android.util.Base64.NO_WRAP)
            wv.post { wv.evaluateJavascript("__nr('$id',$code,'$b64')", null) }
        }.start()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GlobeScreen() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                setBackgroundColor(android.graphics.Color.BLACK)
                webViewClient = object : WebViewClient() { override fun onPageFinished(w: WebView?, u: String?) { GlobeBridge.onLoaded() } }
                webChromeClient = WebChromeClient()
                val html = c.assets.open("globe.html").bufferedReader().use { it.readText() }
                loadDataWithBaseURL("https://jarvis.local/", html, "text/html", "utf-8", null)
                addJavascriptInterface(NetBridge(this), "Net")
                GlobeBridge.attach(this)
            }
        },
        onRelease = { GlobeBridge.detach(); it.destroy() }
    )
}
