// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/** Live globe: aircraft, satellites, earthquakes, radar, rail and 3D cities, rendered by CesiumJS in a WebView. */
object GlobeBridge {
    @Volatile var view: WebView? = null
    /** Lets voice/chat drive the globe, e.g. run("jarvis.fly('Tokyo')"). */
    fun run(js: String) { view?.post { view?.evaluateJavascript(js, null) } }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GlobeScreen() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                setBackgroundColor(android.graphics.Color.BLACK)
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                val html = c.assets.open("globe.html").bufferedReader().use { it.readText() }
                loadDataWithBaseURL("https://jarvis.local/", html, "text/html", "utf-8", null)
                GlobeBridge.view = this
            }
        },
        onRelease = { GlobeBridge.view = null; it.destroy() }
    )
}
