// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/** Live globe: aircraft, satellites, earthquakes, radar, rail and 3D cities, rendered by CesiumJS in a WebView. */
object GlobeBridge {
    private var view: WebView? = null
    private var ready = false
    private val pending = ArrayList<String>()
    fun attach(v: WebView) { synchronized(pending) { view = v; ready = false } }
    fun detach() { synchronized(pending) { view = null; ready = false } }
    fun onLoaded() { synchronized(pending) { ready = true; pending.forEach { view?.evaluateJavascript(it, null) }; pending.clear() } }
    /** Lets voice/chat drive the globe, e.g. run("jarvis.fly('Tokyo')"); queued until the page is loaded. */
    fun run(js: String) {
        synchronized(pending) {
            val v = view
            if (v != null && ready) v.post { v.evaluateJavascript(js, null) } else pending.add(js)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GlobeScreen() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                setBackgroundColor(android.graphics.Color.BLACK)
                webViewClient = object : WebViewClient() { override fun onPageFinished(w: WebView?, u: String?) { GlobeBridge.onLoaded() } }
                webChromeClient = WebChromeClient()
                val html = c.assets.open("globe.html").bufferedReader().use { it.readText() }
                loadDataWithBaseURL("https://jarvis.local/", html, "text/html", "utf-8", null)
                GlobeBridge.attach(this)
            }
        },
        onRelease = { GlobeBridge.detach(); it.destroy() }
    )
}
