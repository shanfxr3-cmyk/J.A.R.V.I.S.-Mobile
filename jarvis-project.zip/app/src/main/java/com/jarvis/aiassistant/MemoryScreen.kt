// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoryScreen(store: Store) {
    var confirmClear by remember { mutableStateOf(false) }
    val log by remember { derivedStateOf { store.messages.reversed() } }
    val facts by remember { derivedStateOf { store.memories.toList() } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ScreenHeader("MEMORY", "STORED ON THIS DEVICE / MESSAGES ALSO GO TO GROQ")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CounterCell("MESSAGES", store.messages.size, 4, Green, Modifier.weight(1f))
            CounterCell("TASKS", store.tasks.size, 3, Green, Modifier.weight(1f))
            CounterCell("FACTS", store.memories.size, 3, Cyan, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item { SectionTitle("WHAT I KNOW ABOUT YOU") }
            if (facts.isEmpty()) item { Text("Nothing yet. Say \"remember that ...\" and it appears here.", color = Dim, fontSize = 11.sp, fontFamily = MonoFont) }
            itemsIndexed(facts) { i, f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IndexTag(i + 1)
                    Spacer(Modifier.width(8.dp))
                    Text(f, Modifier.weight(1f), fontSize = 12.sp, fontFamily = MonoFont)
                    Spacer(Modifier.width(8.dp))
                    MiniBtn("FORGET", Amber) { store.forgetMemory(f) }
                }
            }
            item { Spacer(Modifier.height(6.dp)); SectionTitle("CONVERSATION LOG") }
            if (log.isEmpty()) item { Text("Empty.", color = Dim, fontSize = 11.sp, fontFamily = MonoFont) }
            itemsIndexed(log) { i, m ->
                Column(Modifier.padding(vertical = 3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IndexTag(log.size - i, digits = 4)
                        Spacer(Modifier.width(8.dp))
                        MonoText(if (m.fromUser) "USR" else "JRV", color = if (m.fromUser) Dim else Cyan, size = 10.sp, bold = true, chars = 3)
                        Spacer(Modifier.weight(1f))
                        MonoText(monoTime(m.time), color = Dim, size = 9.sp, chars = 11)
                    }
                    Text(m.text, fontSize = 12.sp, fontFamily = MonoFont)
                }
            }
        }
        if (store.messages.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            HudBtn("CLEAR CONVERSATION LOG", Modifier.fillMaxWidth(), BtnKind.Danger) { confirmClear = true }
        }
    }
    if (confirmClear) {
        ConfirmDialog(
            "CLEAR HISTORY?", "This permanently deletes all saved messages.", "CLEAR",
            { store.clearMessages(); confirmClear = false }, { confirmClear = false }
        )
    }
}
