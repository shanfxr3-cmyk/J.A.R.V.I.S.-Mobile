package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoryScreen(store: Store) {
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ScreenHeader("MEMORY", "Everything here is stored on this device only.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudCard(Modifier.weight(1f)) { Column { Text("MESSAGES", color = Dim, fontSize = 11.sp); Text("${store.messages.size}", color = Green, fontSize = 20.sp) } }
            HudCard(Modifier.weight(1f)) { Column { Text("TASKS", color = Dim, fontSize = 11.sp); Text("${store.tasks.size}", color = Green, fontSize = 20.sp) } }
            HudCard(Modifier.weight(1f)) { Column { Text("ACTIVITY", color = Dim, fontSize = 11.sp); Text("${store.activity.size}", color = Green, fontSize = 20.sp) } }
        }
        Spacer(Modifier.height(10.dp))
        Text("CONVERSATION HISTORY", color = Cyan, fontFamily = Stark, fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (store.messages.isEmpty()) item { Text("Empty.", color = Dim) }
            items(store.messages.reversed()) { m ->
                Column(Modifier.padding(vertical = 4.dp)) {
                    Text("${if (m.fromUser) "YOU" else "JARVIS"} - ${timeStr(m.time)}", color = Dim, fontSize = 10.sp)
                    Text(m.text, fontSize = 13.sp)
                }
            }
        }
        if (store.messages.isNotEmpty()) {
            TextButton(onClick = { confirmClear = true }) { Text("Clear conversation history") }
        }
    }
    if (confirmClear) {
        ConfirmDialog(
            "Clear history?", "This permanently deletes all saved messages.", "Clear",
            { store.clearMessages(); confirmClear = false }, { confirmClear = false }
        )
    }
}
