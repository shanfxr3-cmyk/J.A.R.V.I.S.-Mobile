// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoryScreen(store: Store) {
    var confirmClear by remember { mutableStateOf(false) }
    val log by remember { derivedStateOf { store.messages.reversed() } }
    val facts by remember { derivedStateOf { store.memories.toList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        ScreenHeader("Memory", "Stored on this device. Messages are also sent to Groq or Gemini.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CounterCell("Messages", store.messages.size, 4, Green, Modifier.weight(1f))
            CounterCell("Tasks", store.tasks.size, 3, Green, Modifier.weight(1f))
            CounterCell("Facts", store.memories.size, 3, Cyan, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SectionTitle("What I know about you") }
            if (facts.isEmpty()) item { Text("Nothing yet. Say \"remember that ...\" and it appears here.", color = Dim, fontSize = 14.sp, fontFamily = BodyFont, modifier = Modifier.padding(horizontal = 4.dp)) }
            itemsIndexed(facts) { _, f ->
                HudCard(Modifier.fillMaxWidth(), pad = 14.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(f, Modifier.weight(1f), fontSize = 14.sp, fontFamily = BodyFont)
                        Spacer(Modifier.width(10.dp))
                        MiniBtn("Forget", Amber) { store.forgetMemory(f) }
                    }
                }
            }
            item { Spacer(Modifier.height(6.dp)); SectionTitle("Conversation log") }
            if (log.isEmpty()) item { Text("No messages yet.", color = Dim, fontSize = 14.sp, fontFamily = BodyFont, modifier = Modifier.padding(horizontal = 4.dp)) }
            itemsIndexed(log) { _, m ->
                Column(Modifier.padding(vertical = 4.dp, horizontal = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (m.fromUser) "You" else "Jarvis", color = if (m.fromUser) Dim else Cyan, fontSize = 13.sp, fontFamily = BodyFont, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        MonoText(monoTime(m.time), color = Dim, size = 12.sp)
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(m.text, fontSize = 14.sp, fontFamily = BodyFont)
                }
            }
        }
        if (store.messages.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            HudBtn("Clear conversation log", Modifier.fillMaxWidth(), BtnKind.Danger) { confirmClear = true }
        }
    }
    if (confirmClear) {
        ConfirmDialog(
            "Clear history?", "This permanently deletes all saved messages.", "Clear",
            { store.clearMessages(); confirmClear = false }, { confirmClear = false }
        )
    }
}
