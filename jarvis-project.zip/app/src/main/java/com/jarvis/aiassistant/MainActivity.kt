// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Voice Only. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class Screen(val label: String, val glyph: String) {
    Home("Home", "H"), Chat("AI", "AI"), Memory("Memory", "M"),
    Tasks("Tasks", "T"), Tools("Tools", "X"), Settings("Settings", "S"),
    About("About", "i"), Legal("Legal", "L")
}

private val bottomTabs = listOf(Screen.Home, Screen.Chat, Screen.Memory, Screen.Settings)

class MainActivity : ComponentActivity() {
    private val store by lazy { Store.get(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The app is always dark, so the bars must always use light icons, whatever the system theme is.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        store.log("App opened")
        setContent {
            JarvisTheme {
                if (Legal.isAccepted(store)) JarvisApp(store)
                else ConsentScreen(store, onDecline = { finish() })
            }
        }
        if (store.updateCheck && Legal.isAccepted(store)) Updater.check(applicationContext)
    }

    override fun onResume() {
        super.onResume()
        // Visible app: Android allows starting the listener now. Bring it back if it should be on.
        if (Legal.isAccepted(store) && store.wakeWanted && store.keepAlive && store.initFails < 3 &&
            !WakeService.running && KeepAlive.micGranted(this)
        ) {
            KeepAlive.clearResume(this)
            WakeService.start(applicationContext, user = false)
        }
    }
}

@Composable
fun JarvisApp(store: Store) {
    // Saved across rotation / process recreation, so the person stays on the same screen.
    val stack: SnapshotStateList<Screen> = rememberSaveable(
        saver = listSaver<SnapshotStateList<Screen>, String>(
            save = { it.map { s -> s.name } },
            restore = { names ->
                val l = mutableStateListOf<Screen>()
                names.forEach { n -> try { l.add(Screen.valueOf(n)) } catch (_: Throwable) {} }
                if (l.isEmpty()) l.add(Screen.Home)
                l
            }
        )
    ) { mutableStateListOf(Screen.Home) }
    val current = stack.last()

    fun open(s: Screen) {
        // Read the live top of the stack (not the value captured at composition), so a voice command
        // that arrives later still compares against the screen that is showing now.
        if (s == stack.last()) return
        if (s in bottomTabs) {
            stack.clear()
            stack.add(Screen.Home)
            if (s != Screen.Home) stack.add(s)
        } else {
            stack.add(s)
        }
    }

    // Hand-gesture control of the home sphere (camera runs invisibly; nothing from it is shown).
    val ctx = LocalContext.current
    var handOn by rememberSaveable { mutableStateOf(false) }
    var frontCam by rememberSaveable { mutableStateOf(true) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { handOn = true; open(Screen.Home) }
    }
    fun toggleHand() {
        if (handOn) { handOn = false; return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) { handOn = true; open(Screen.Home) }
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    // Lets the wake-word service switch screens while the app is open.
    DisposableEffect(Unit) {
        WakeService.navHook = { s -> open(s) }
        onDispose { WakeService.navHook = null }
    }

    BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }

    Scaffold(
        containerColor = Bg,
        contentColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                bottomTabs.forEach { s ->
                    NavigationBarItem(
                        selected = current == s,
                        onClick = { open(s) },
                        icon = { Text(s.glyph, color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, modifier = Modifier.clearAndSetSemantics { }) },
                        label = { Text(s.label, fontSize = 12.sp, fontFamily = HudFont, maxLines = 1) }
                    )
                }
                NavigationBarItem(
                    selected = handOn,
                    onClick = { toggleHand() },
                    icon = { Text("HD", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, modifier = Modifier.clearAndSetSemantics { }) },
                    label = { Text("Hand", fontSize = 12.sp, fontFamily = HudFont, maxLines = 1) }
                )
                NavigationBarItem(
                    selected = false,
                    enabled = handOn,
                    onClick = { frontCam = !frontCam },
                    icon = { Text("CM", color = Cyan, fontFamily = HudFont, fontWeight = FontWeight.Bold, modifier = Modifier.clearAndSetSemantics { }) },
                    label = { Text(if (frontCam) "Front" else "Back", fontSize = 12.sp, fontFamily = HudFont, maxLines = 1) }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).consumeWindowInsets(pad).fillMaxSize().background(Bg)) {
            when (current) {
                Screen.Home -> HomeScreen(store, ::open, handOn, frontCam)
                Screen.Chat -> ChatScreen(store, ::open)
                Screen.Memory -> MemoryScreen(store)
                Screen.Tasks -> TasksScreen(store)
                Screen.Tools -> ToolsScreen(store)
                Screen.Settings -> SettingsScreen(store, ::open)
                Screen.About -> AboutScreen(store, ::open)
                Screen.Legal -> LegalScreen()
            }
        }
    }
}
