package com.jarvis.aiassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class Screen(val label: String, val glyph: String) {
    Home("Home", "H"), Chat("AI", "AI"), Holo("Holo", "3D"), Memory("Memory", "M"),
    Tasks("Tasks", "T"), Tools("Tools", "X"), Settings("Settings", "S")
}

private val bottomTabs = listOf(Screen.Home, Screen.Chat, Screen.Memory, Screen.Settings)

class MainActivity : ComponentActivity() {
    private val store by lazy { Store(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        store.log("App opened")
        setContent {
            JarvisTheme { JarvisApp(store) }
        }
    }
}

@Composable
fun JarvisApp(store: Store) {
    val stack: SnapshotStateList<Screen> = remember { mutableStateListOf(Screen.Home) }
    val current = stack.last()

    fun open(s: Screen) {
        if (s == current) return
        if (s in bottomTabs) {
            stack.clear()
            stack.add(Screen.Home)
            if (s != Screen.Home) stack.add(s)
        } else {
            stack.add(s)
        }
    }

    BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }

    Scaffold(
        containerColor = Bg,
        contentColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                bottomTabs.forEach { s ->
                    NavigationBarItem(
                        selected = current == s,
                        onClick = { open(s) },
                        icon = { Text(s.glyph, color = Cyan, fontWeight = FontWeight.Bold) },
                        label = { Text(s.label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
            when (current) {
                Screen.Home -> HomeScreen(store, ::open)
                Screen.Chat -> ChatScreen(store, ::open)
                Screen.Holo -> HoloScreen()
                Screen.Memory -> MemoryScreen(store)
                Screen.Tasks -> TasksScreen(store)
                Screen.Tools -> ToolsScreen(store)
                Screen.Settings -> SettingsScreen(store)
            }
        }
    }
}
