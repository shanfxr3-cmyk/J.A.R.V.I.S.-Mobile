// Copyright 2026 Shan Akhter. J.A.R.V.I.S. Mobile. Licensed under the Apache License 2.0 (see LICENSE and NOTICE).
package com.jarvis.aiassistant

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.BackHandler
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class Screen(val label: String, val glyph: String) {
    Home("Home", "H"), Chat("AI", "AI"), Memory("Memory", "M"),
    Tasks("Tasks", "T"), Tools("Tools", "X"), Settings("Settings", "S"),
    About("About", "i"), Legal("Legal", "L"), World("World", "W")
}

private val bottomTabs = listOf(Screen.Home, Screen.Chat, Screen.Memory, Screen.Settings)

class MainActivity : ComponentActivity() {
    private val store by lazy { Store.get(applicationContext) }
    private var locked by mutableStateOf(false)
    private var lockNote by mutableStateOf<String?>(null)
    private var leftAt = 0L

    private fun handleLaunch(i: android.content.Intent?) {
        if (i?.getBooleanExtra("voice", false) == true) Launch.voice = true
    }

    private fun unlock() = AppLock.prompt(this, { locked = false; lockNote = null }, { lockNote = it })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The app is always dark, so the bars must always use light icons, whatever the system theme is.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        locked = store.appLock && Legal.isAccepted(store) && AppLock.available(this)
        if (store.appLock) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)   // no screenshots or Recents preview
        handleLaunch(intent)
        setContent {
            JarvisTheme {
                if (locked) LockScreen(lockNote) { unlock() }
                else if (Legal.isAccepted(store)) JarvisApp(store)
                else ConsentScreen(store, onDecline = { finish() })
            }
        }
        if (store.updateCheck && Legal.isAccepted(store)) Updater.check(applicationContext)
        Briefing.reschedule(applicationContext, store)
        AlertService.sync(applicationContext)
        if (Legal.isAccepted(store)) {
            val sp = getSharedPreferences("jarvis", MODE_PRIVATE)
            val need = (Phone.RUNTIME + (if (android.os.Build.VERSION.SDK_INT >= 33) arrayOf(android.Manifest.permission.POST_NOTIFICATIONS) else emptyArray<String>()))
                .filter { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty() && !sp.getBoolean("permAsked2", false)) { sp.edit().putBoolean("permAsked2", true).apply(); requestPermissions(need.toTypedArray(), 77) }
        }
        // The Phone integration page was removed: make sure the app lock and floating bar cannot stay on without a switch.
        if (store.appLock) store.setAppLock(false)
        if (store.overlayOn) store.setOverlay(false)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunch(intent)
    }

    override fun onStop() {
        super.onStop()
        leftAt = android.os.SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        if (store.appLock && leftAt != 0L && AppLock.shouldRelock(android.os.SystemClock.elapsedRealtime() - leftAt) && AppLock.available(this)) locked = true
    }

    override fun onResume() {
        super.onResume()
        Updater.sync(applicationContext)
        // Visible app: Android allows starting the listener now. Bring it back if it should be on.
        if (Legal.isAccepted(store) && store.wakeWanted && store.keepAlive && store.initFails < 3 &&
            !WakeService.running && KeepAlive.micGranted(this)
        ) {
            KeepAlive.clearResume(this)
            WakeService.start(applicationContext, user = false)
        }
    }
}

@Composable
fun JarvisApp(store: Store) {
    // Saved across rotation / process recreation, so the person stays on the same screen.
    val stack: SnapshotStateList<Screen> = rememberSaveable(
        saver = listSaver<SnapshotStateList<Screen>, String>(
            save = { it.map { s -> s.name } },
            restore = { names ->
                val l = mutableStateListOf<Screen>()
                names.forEach { n -> try { l.add(Screen.valueOf(n)) } catch (_: Throwable) {} }
                if (l.isEmpty()) l.add(Screen.Home)
                l
            }
        )
    ) { mutableStateListOf(Screen.Home) }
    val current = stack.last()

    fun open(s: Screen) {
        // Read the live top of the stack (not the value captured at composition), so a voice command
        // that arrives later still compares against the screen that is showing now.
        if (s == stack.last()) return
        if (s in bottomTabs) {
            stack.clear()
            stack.add(Screen.Home)
            if (s != Screen.Home) stack.add(s)
        } else {
            stack.add(s)
        }
    }

    // Lets the wake-word service switch screens while the app is open.
    DisposableEffect(Unit) {
        WakeService.navHook = { s -> open(s) }
        onDispose { WakeService.navHook = null }
    }

    BackHandler(enabled = stack.size > 1) { stack.removeAt(stack.lastIndex) }

    // Tile, widget or the assistant button asked for voice: show the chat screen (it starts listening).
    LaunchedEffect(Launch.voice) { if (Launch.voice) open(Screen.Chat) }

    val tab = when (current) {
        Screen.About, Screen.Legal -> Screen.Settings
        Screen.Tasks, Screen.Tools, Screen.World -> Screen.Home
        else -> current
    }

    // World view fullscreen: hide the status bar, navigation bar, camera-cutout padding and the bottom bar.
    // Swiping from a screen edge shows the system bars briefly. Leaving the screen restores everything.
    var worldFull by rememberSaveable { mutableStateOf(true) }
    val immersive = current == Screen.World && worldFull
    val view = LocalView.current
    DisposableEffect(immersive) {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val ctrl = WindowCompat.getInsetsController(window, view)
            if (immersive) {
                ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctrl.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                ctrl.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (window != null) WindowCompat.getInsetsController(window, view).show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Scaffold(
        containerColor = Bg,
        contentColor = Color.White,
        contentWindowInsets = if (immersive) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        bottomBar = { if (!immersive) HudNavBar(tab) { open(it) } }
    ) { pad ->
        Box(Modifier.padding(pad).consumeWindowInsets(pad).fillMaxSize().hudBackdrop()) {
            AnimatedContent(
                targetState = current,
                transitionSpec = {
                    // No fade to or from the World screen: a fading layer makes the WebView's WebGL globe draw black.
                    if (targetState == Screen.World || initialState == Screen.World) EnterTransition.None togetherWith ExitTransition.None
                    else fadeIn(tween(180)) togetherWith fadeOut(tween(90))
                },
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.Home -> HomeScreen(store, ::open)
                    Screen.Chat -> ChatScreen(store, ::open)
                    Screen.Memory -> MemoryScreen(store)
                    Screen.Tasks -> TasksScreen(store)
                    Screen.Tools -> ToolsScreen(store, ::open)
                    Screen.World -> WorldScreen(store, full = worldFull, onFull = { worldFull = it })
                    Screen.Settings -> SettingsScreen(store, ::open)
                    Screen.About -> AboutScreen(store, ::open)
                    Screen.Legal -> LegalScreen()
                }
            }
        }
    }
}

private fun tabIcon(s: Screen) = when (s) {
    Screen.Chat -> Ic.Chat
    Screen.Memory -> Ic.Memory
    Screen.Settings -> Ic.Settings
    else -> Ic.Home
}

@Composable
private fun HudNavBar(selected: Screen, onSelect: (Screen) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Panel, Color(0xFF060F19))))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Cyan.copy(alpha = 0.6f), Color.Transparent))))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp)) {
            bottomTabs.forEach { s ->
                val sel = selected == s
                val tint by animateColorAsState(if (sel) Cyan else Dim, tween(200), label = "tint")
                val pillW by animateDpAsState(if (sel) 52.dp else 30.dp, tween(200), label = "pill")
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onSelect(s) }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.width(pillW).height(26.dp).background(if (sel) Cyan.copy(alpha = 0.16f) else Color.Transparent, RoundedCornerShape(13.dp)),
                        contentAlignment = Alignment.Center
                    ) { HudIcon(tabIcon(s), tint = tint, size = 20.dp, modifier = Modifier.clearAndSetSemantics { }) }
                    Text(s.label, color = tint, fontSize = 11.sp, fontFamily = HudFont, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                }
            }
        }
    }
}
