package com.jarvis.aiassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos

private val Cyan = Color(0xFF3DE8F5)
private val Bg = Color(0xFF050B14)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) {
                JarvisApp()
            }
        }
    }
}

private val tabs = listOf("Home", "Chat", "Holo", "Memory", "Tasks", "Tools", "Settings")

@Composable
fun JarvisApp() {
    var selected by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A1826)) {
                tabs.forEachIndexed { i, name ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Text(name.take(1), color = Cyan, fontWeight = FontWeight.Bold) },
                        label = { Text(name, fontSize = 9.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
            if (selected == 0) HomeScreen() else
                Text("${tabs[selected]}: not implemented yet", color = Color.White)
        }
    }
}

@Composable
fun HomeScreen() {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "a")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("J.A.R.V.I.S.", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("PERSONAL AI", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
        Canvas(Modifier.size(260.dp)) {
            val c = center
            val r = size.minDimension / 2.2f
            drawCircle(Cyan.copy(alpha = 0.08f), r)
            drawCircle(Cyan, r, style = Stroke(2f))
            for (k in 0 until 6) {
                val a = Math.toRadians((angle + k * 30.0))
                val w = abs((r * cos(a)).toFloat())
                drawOval(Cyan.copy(alpha = 0.5f), Offset(c.x - w, c.y - r), Size(2 * w, 2 * r), style = Stroke(1.5f))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Phase 1 build check. Voice, AI and tracking are NOT implemented.", color = Color.Gray, fontSize = 11.sp)
    }
}
