// Starts the unmodified God's Eye View server code (providers, MCP, Host checks, embed framing)
// without Vite. Vite is only a dev tool there: every route is a plain middleware that takes
// `server.middlewares` and `server.httpServer`, so a small stand-in object is enough.
// Run: node gev-launcher.mjs   (cwd is irrelevant; it changes into its own folder)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
process.chdir(ROOT);
const log = (...a) => console.log('[gev]', ...a);

// ---- .env (the same file Provider Settings writes), without overriding real environment ----
function loadDotenv() {
  const file = path.join(ROOT, '.env');
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const raw of text.split(/\r?\n/)) {
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(raw);
    if (!m || raw.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadDotenv();

const PORT = Number.parseInt(process.env.PORT, 10) || 4173;
const HOST = process.env.HOST || '127.0.0.1';
const DIST = path.join(ROOT, 'dist');
const imp = (rel) => import(pathToFileURL(path.join(ROOT, rel)).href);

// ---- minimal connect-style middleware stack (same mount rules as `connect`) ----
function createStack() {
  const layers = [];
  const app = (req, res, done) => {
    let i = 0;
    const originalUrl = req.originalUrl || req.url;
    req.originalUrl = originalUrl;
    let removed = '';
    const next = (err) => {
      if (removed) { req.url = removed + req.url; removed = ''; }
      const layer = layers[i++];
      if (!layer) return done(err);
      const pathname = String(req.url || '/').split(/[?#]/, 1)[0];
      const route = layer.route;
      if (route) {
        if (pathname.slice(0, route.length).toLowerCase() !== route.toLowerCase()) return next(err);
        const c = pathname.length > route.length ? pathname[route.length] : undefined;
        if (c !== undefined && c !== '/' && c !== '.') return next(err);
        removed = route;
        req.url = req.url.slice(route.length);
        if (req.url[0] !== '/') req.url = '/' + req.url;
      }
      if (err) return next(err);
      try {
        const r = layer.fn(req, res, next);
        if (r && typeof r.catch === 'function') r.catch(next);
      } catch (e) { next(e); }
    };
    next();
  };
  app.use = (a, b) => {
    let route = '', fn = a;
    if (typeof a !== 'function') { route = String(a).replace(/\/+$/, ''); fn = b; }
    layers.push({ route, fn });
    return app;
  };
  app.layers = layers;
  return app;
}

// ---- stand-in for Vite's preview server ----
const middlewares = createStack();
const httpServer = http.createServer((req, res) => middlewares(req, res, (err) => {
  if (res.headersSent) return res.end();
  res.statusCode = err ? 500 : 404;
  res.setHeader('Content-Type', 'text/plain');
  res.end(err ? 'Server error' : 'Not found');
  if (err) console.warn('[gev] request error:', err?.message || err);
}));
httpServer.keepAliveTimeout = 30_000;

const failures = [];
const mounts = [];
const recordMiddlewares = {
  use(a, b) { if (typeof a === 'string') mounts.push(a); return middlewares.use(a, b); },
};

// ---- keys the build could not know: replaced in served JavaScript at read time ----
const SENTINELS = {
  __GEV_GOOGLE_MAPS_API_KEY__: 'GOOGLE_MAPS_API_KEY',
  __GEV_CESIUM_ION_TOKEN__: 'CESIUM_ION_TOKEN',
  __GEV_MAPILLARY_CLIENT_TOKEN__: 'MAPILLARY_CLIENT_TOKEN',
};
const jsCache = new Map();
const sentinelFiles = new Set();
function scanSentinels(dir) {
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name !== 'panel') scanSentinels(p); continue; }
    if (!/\.(m?js|html)$/.test(e.name)) continue;
    try { if (fs.readFileSync(p, 'latin1').includes('__GEV_')) sentinelFiles.add(p); } catch {}
  }
}
function withKeys(file) {
  const hit = jsCache.get(file);
  if (hit) return hit;
  let text = fs.readFileSync(file, 'utf8');
  for (const [s, envName] of Object.entries(SENTINELS)) {
    const v = JSON.stringify(String(process.env[envName] ?? '').trim()).slice(1, -1);
    text = text.split(s).join(v);
  }
  const buf = Buffer.from(text, 'utf8');
  jsCache.set(file, buf);
  return buf;
}

const server = {
  middlewares: recordMiddlewares,
  httpServer,
  config: { root: ROOT, server: {}, preview: {} },
  async restart() { loadDotenv(); jsCache.clear(); log('settings reloaded'); },
};

let headers = { browser: {}, api: {} };
try { headers = JSON.parse(fs.readFileSync(path.join(ROOT, 'gev-headers.json'), 'utf8')); } catch { log('gev-headers.json missing, using no extra headers'); }
const API_CSP = headers.api['Content-Security-Policy'] || "default-src 'none'; sandbox";
const isApiPath = (url) => /^\/api(?:$|[/.])/i.test(String(url || '/').split(/[?#]/, 1)[0].replace(/\\/g, '/'));

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.gif': 'image/gif', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.glb': 'model/gltf-binary',
  '.gltf': 'model/gltf+json', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml', '.geojsonl': 'application/geo+json-seq', '.mp3': 'audio/mpeg', '.ktx2': 'image/ktx2', '.b3dm': 'application/octet-stream',
};

function sendFile(req, res, file, stat) {
  const ext = path.extname(file).toLowerCase();
  res.setHeader('Content-Type', TYPES[ext] || 'application/octet-stream');
  res.setHeader('Cache-Control', ext === '.html' ? 'no-cache' : 'public, max-age=3600');
  for (const [k, v] of Object.entries(headers.browser)) res.setHeader(k, v);
  if (sentinelFiles.has(file)) {
    const buf = withKeys(file);
    res.setHeader('Content-Length', buf.length);
    res.statusCode = 200;
    return req.method === 'HEAD' ? res.end() : res.end(buf);
  }
  res.setHeader('Content-Length', stat.size);
  res.statusCode = 200;
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
}

function staticMiddleware(req, res, next) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { res.statusCode = 400; return res.end('Bad path'); }
  let file = path.resolve(DIST, '.' + pathname);
  if (file !== DIST && !file.startsWith(DIST + path.sep)) return next();
  let stat = null;
  try { stat = fs.statSync(file); } catch {}
  if (stat?.isDirectory()) { file = path.join(file, 'index.html'); try { stat = fs.statSync(file); } catch { stat = null; } }
  if (stat?.isFile()) return sendFile(req, res, file, stat);
  // Single-page fallback (share links like /share/<code>), never for files or the API.
  if (!path.extname(pathname) && !isApiPath(req.url)) {
    const index = path.join(DIST, 'index.html');
    try { return sendFile(req, res, index, fs.statSync(index)); } catch {}
  }
  next();
}

async function install() {
  // 1. API response headers, first so every answer carries them.
  middlewares.use((req, res, next) => {
    if (!isApiPath(req.url)) return next();
    for (const [k, v] of Object.entries(headers.api)) res.setHeader(k, v);
    const set = res.setHeader.bind(res);
    res.setHeader = (name, value) =>
      String(name).toLowerCase() === 'content-security-policy' && String(value) !== API_CSP ? set(name, `${API_CSP}, ${value}`) : set(name, value);
    next();
  });

  // 2. Launcher status for Jarvis (before the Host check; loopback only anyway).
  middlewares.use('/gev-health', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Cache-Control', 'no-store');
    res.end(JSON.stringify({ ok: failures.length === 0, node: process.version, port: PORT, uptime: Math.round(process.uptime()), distPresent: fs.existsSync(path.join(DIST, 'index.html')), failures, mounts }));
  });

  // 3. Host check, same rule as the app's own.
  const { isAllowedHost, resolveAllowedHosts, DEFAULT_ALLOWED_HOSTS } = await imp('build/allowedHosts.js');
  const allowed = resolveAllowedHosts(process.env.GEV_ALLOWED_HOSTS) || [...DEFAULT_ALLOWED_HOSTS];
  middlewares.use((req, res, next) => {
    if (isAllowedHost(req.headers.host, allowed, [HOST])) return next();
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Blocked request. This host is not allowed.');
  });

  // 4. The app's own plugins, in the order of server/standalone/vite.config.js.
  const plugins = [];
  const add = async (name, make) => {
    try { const list = await make(); plugins.push(...[].concat(list)); }
    catch (e) { failures.push(`${name}: ${e?.message || e}`); console.warn('[gev] could not load', name, e?.stack || e); }
  };
  await add('voiceTools+providers', async () => {
    const { standaloneVoiceTools } = await imp('server/standalone/voiceTools.js');
    const { localProviderPlugins } = await imp('server/providers/local.js');
    const tools = standaloneVoiceTools();
    return localProviderPlugins({ realtime: { tools }, gemini: { tools } });
  });
  await add('mcp', async () => (await imp('server/mcp/plugin.js')).localMcpPlugin());
  await add('google-token', async () => (await imp('server/standalone/google-token-unavailable.js')).googleTokenUnavailablePlugin());
  await add('api-not-found', async () => (await imp('server/standalone/api-not-found.js')).apiNotFoundPlugin());
  await add('embed-framing', async () => (await imp('build/embed-framing.js')).embedFramingPlugin());
  for (const p of plugins) {
    try {
      // Provider Settings is dev-server only upstream; here it is wanted, so it installs via configureServer.
      const hook = p.name === 'gev-key-setup' ? p.configureServer : (p.configurePreviewServer || null);
      if (hook) await hook.call({}, server);
    } catch (e) { failures.push(`${p.name}: ${e?.message || e}`); console.warn('[gev] plugin failed', p.name, e?.stack || e); }
  }

  // 5. The built app.
  scanSentinels(DIST);
  middlewares.use(staticMiddleware);
}

await install();
httpServer.on('error', (e) => { console.error('[gev] listen error:', e?.message || e); process.exit(1); });
httpServer.listen(PORT, HOST, () => log(`READY http://${HOST}:${PORT} mounts=${mounts.length} failures=${failures.length}`));
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => { httpServer.close(); setTimeout(() => process.exit(0), 200).unref(); });
