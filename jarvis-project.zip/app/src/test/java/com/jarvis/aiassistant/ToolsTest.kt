package com.jarvis.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolsTest {
    private fun names(mode: ToolMode): List<String> {
        val a = Tools.specs(mode.allows)
        return (0 until a.length()).map { a.getJSONObject(it).getJSONObject("function").getString("name") }
    }

    @Test fun toolNamesAreUnique() {
        val n = Tools.all().map { it.name }
        assertEquals(n.size, n.toSet().size)
    }

    @Test fun riskyToolsNeedConfirmationAndNeverRunUnattended() {
        val risky = listOf("dial_number", "compose_sms", "open_settings")
        assertTrue(names(ToolMode.FULL).containsAll(risky))
        risky.forEach { assertFalse(it in names(ToolMode.VOICE)); assertFalse(it in names(ToolMode.READ_ONLY)) }
    }

    @Test fun unattendedRunsOnlyGetReadOnlyTools() {
        val ro = Tools.all().filter { it.readOnly }.map { it.name }
        assertEquals(ro.sorted(), names(ToolMode.READ_ONLY).sorted())
        assertFalse("set_timer" in names(ToolMode.READ_ONLY))
    }

    @Test fun timersAreSpokenNaturally() {
        assertEquals("5 minutes", Tools.spoken(300))
        assertEquals("1 hour", Tools.spoken(3600))
        assertEquals("90 seconds", Tools.spoken(90))
    }
}
