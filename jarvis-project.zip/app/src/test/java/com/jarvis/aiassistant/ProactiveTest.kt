package com.jarvis.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProactiveTest {
    @Test fun quietHours() {
        assertTrue(Proactive.isQuiet(23, 0)); assertTrue(Proactive.isQuiet(3, 10)); assertTrue(Proactive.isQuiet(6, 29))
        assertFalse(Proactive.isQuiet(6, 30)); assertFalse(Proactive.isQuiet(12, 0)); assertFalse(Proactive.isQuiet(22, 59))
    }
    @Test fun homeHasHysteresis() {
        assertTrue(Proactive.atHome(false, 100.0)); assertFalse(Proactive.atHome(false, 200.0))
        assertTrue(Proactive.atHome(true, 200.0)); assertFalse(Proactive.atHome(true, 300.0))
    }
    @Test fun distanceIsRoughlyRight() {
        val d = Proactive.distanceM(0.0, 0.0, 0.0, 0.001)   // about 111 m
        assertTrue(d in 105.0..117.0)
    }
    @Test fun eventLines() {
        assertEquals("Sir, Standup starts in 15 minutes.", Proactive.eventLine("Standup", 15, ""))
        assertTrue(Proactive.eventLine("Dentist", 20, "Main St").contains("leave soon"))
        assertTrue(Proactive.eventLine("Call", 0, "").contains("starting now"))
        assertEquals(30, Proactive.leadMinutes("Main St")); assertEquals(15, Proactive.leadMinutes(""))
    }
    @Test fun travelTime() {
        assertEquals(8, Proactive.travelMinutes(0.0))
        assertEquals(43, Proactive.travelMinutes(10_000.0))
        assertEquals(120, Proactive.travelMinutes(500_000.0))
        assertEquals(30, Proactive.leaveLead(null)); assertEquals(15, Proactive.leaveLead(3)); assertEquals(53, Proactive.leaveLead(43)); assertEquals(150, Proactive.leaveLead(145))
        assertEquals(53, Proactive.leadMinutes("Main St", 43)); assertEquals(15, Proactive.leadMinutes("", 43))
    }
    @Test fun travelLine() {
        val l = Proactive.eventLine("Dentist", 50, "Main St", 40)
        assertTrue(l.contains("about 40 minutes away")); assertTrue(l.contains("leave now"))
    }
    @Test fun chargingHabit() {
        assertEquals(null, Proactive.usualHour(listOf(22, 22, 22, 22)))                 // too few samples
        assertEquals(22, Proactive.usualHour(listOf(22, 22, 23, 22, 21)))
        assertEquals(23, Proactive.usualHour(listOf(23, 23, 0, 23, 0, 23)))             // wraps past midnight
        assertEquals(null, Proactive.usualHour(listOf(1, 5, 9, 13, 17, 21)))            // no pattern
    }
}
