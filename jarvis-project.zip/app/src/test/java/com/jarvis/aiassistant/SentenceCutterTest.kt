package com.jarvis.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SentenceCutterTest {
    @Test fun cutsOnlyFinishedSentences() {
        val c = SentenceCutter()
        assertEquals(emptyList<String>(), c.feed("Good evening, sir"))
        assertEquals(listOf("Good evening, sir."), c.feed("Good evening, sir. All sys"))
        assertEquals(listOf("All systems online!"), c.feed("Good evening, sir. All systems online! Rea"))
        assertEquals("Rea", c.flush())
    }

    @Test fun decimalsAreNotSentenceEnds() {
        assertEquals(emptyList<String>(), SentenceCutter().feed("You have 3.5 million views"))
    }

    @Test fun restartsWhenTextRestarts() {
        val c = SentenceCutter()
        c.feed("Checking now. ")
        assertEquals(listOf("Done, sir."), c.feed("Done, sir. "))
    }

    @Test fun flushIsNullWhenNothingLeft() {
        val c = SentenceCutter()
        c.feed("All done. ")
        assertNull(c.flush())
    }

    @Test fun thinkBlocksAreNeverSpoken() {
        assertEquals("Hello.", SentenceCutter.visible("<think>plan</think>Hello."))
        assertEquals("", SentenceCutter.visible("<think>still thinking"))
    }
}
