package com.jarvis.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HudFormatTest {
    @Test fun padClampsAndFills() {
        assertEquals("007", Mono.pad(7, 3)); assertEquals("999", Mono.pad(12345, 3)); assertEquals("000", Mono.pad(-4, 3))
    }

    @Test fun rateIsAlwaysFiveCharacters() {
        assertEquals("0412K", Mono.rate(412)); assertEquals("9999K", Mono.rate(9999)); assertEquals("11.7M", Mono.rate(12000)); assertEquals("99.9M", Mono.rate(9_999_999))
        for (v in listOf(0, 5, 999, 10000, 50000, 1_000_000)) assertEquals(5, Mono.rate(v).length)
    }

    @Test fun labelAndTokens() {
        assertEquals("abc  ", Mono.label("abc", 5)); assertEquals("abcde", Mono.label("abcdefg", 5))
        assertEquals("00000", Mono.tokens(0)); assertEquals("00100", Mono.tokens(400)); assertEquals(68, Mono.pctOf(0.684f))
    }

    @Test fun fftBandsStayInRangeAndSilenceStaysFlat() {
        val d = SpeechDsp.FftBands(); val out = FloatArray(SpeechDsp.BANDS)
        assertTrue(d.process(ByteArray(512), out)); assertTrue(out.all { it == 0f })
        assertTrue(d.process(ByteArray(512) { if (it % 2 == 0) 90 else 40 }, out))
        assertTrue(out.all { it in 0f..1f }); assertTrue(out.max() > 0.5f)
        assertFalse(d.process(ByteArray(10), out))
        for (n in listOf(130, 256, 512, 1024)) assertTrue(d.process(ByteArray(n) { 5 }, out))
    }

    @Test fun envelopesStayInRange() {
        for (b in 0 until SpeechDsp.BANDS) {
            assertTrue(SpeechDsp.synth(1.3f, b) in 0f..1f); assertTrue(SpeechDsp.scan(2f, b) in 0f..1.5f); assertTrue(SpeechDsp.breath(1f, b) in 0f..0.2f)
        }
    }
}
