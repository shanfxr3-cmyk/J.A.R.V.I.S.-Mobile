package com.jarvis.aiassistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class AiFallbackTest {
    @Test fun hubOutagesFallBackToTheBackupKey() {
        assertTrue(Ai.hubDown(IOException("Unable to resolve host")))
        assertTrue(Ai.hubDown(AiHttpException(502, 0, "bad gateway")))
        assertTrue(Ai.hubDown(AiHttpException(530, 0, "tunnel down")))
        assertTrue(Ai.hubDown(AiHttpException(429, 0, "Rate limit reached (429). The hub's daily AI limit is used up.")))
    }

    @Test fun wrongTokenOrOrdinaryRateLimitDoNotFallBack() {
        assertFalse(Ai.hubDown(AiHttpException(401, 0, "Invalid API key (401).")))
        assertFalse(Ai.hubDown(AiHttpException(429, 0, "Rate limit reached (429).")))
        assertFalse(Ai.hubDown(AiHttpException(400, 0, "bad request")))
    }
}
