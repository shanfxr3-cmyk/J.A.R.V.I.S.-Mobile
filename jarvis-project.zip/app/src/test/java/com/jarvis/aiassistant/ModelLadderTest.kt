package com.jarvis.aiassistant

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ModelLadderTest {
    @After fun clean() { ModelLadder.reset(); ModelLadder.now = { System.currentTimeMillis() } }

    @Test fun rateLimitAndOutageRestForDifferentTimes() {
        assertEquals(ModelLadder.QUOTA_MS, ModelLadder.classify(AiHttpException(429, 0, "Rate limit reached (429)")))
        assertEquals(10_000L, ModelLadder.classify(AiHttpException(429, 10_000, "Rate limit")))
        assertEquals(ModelLadder.OUTAGE_MS, ModelLadder.classify(AiHttpException(503, 0, "AI error 503")))
        assertEquals(ModelLadder.MISSING_MS, ModelLadder.classify(AiHttpException(404, 0, "model_not_found")))
    }

    @Test fun notTheModelsFault() {
        assertNull(ModelLadder.classify(AiHttpException(401, 0, "Invalid API key (401)")))
        assertNull(ModelLadder.classify(RuntimeException("processed 5000 items")))
        assertNull(ModelLadder.classify(java.io.IOException("Unable to resolve host")))
    }

    @Test fun wholeStatusCodesOnly() {
        assertEquals(ModelLadder.OUTAGE_MS, ModelLadder.classify(RuntimeException("server returned 503")))
        assertNull(ModelLadder.classify(RuntimeException("id 15030 failed")))
    }

    @Test fun restingModelIsSkippedThenComesBack() {
        var t = 1_000L
        ModelLadder.now = { t }
        val (a, b) = DEFAULT_LADDER
        assertEquals(a, ModelLadder.best(a))
        ModelLadder.rest(a, 5_000)
        assertEquals(b, ModelLadder.best(a))
        t += 6_000
        assertEquals(a, ModelLadder.best(a))
    }

    @Test fun ladderWalksAllSixThenRunsOut() {
        var cur = DEFAULT_LADDER[0]
        repeat(5) { ModelLadder.rest(cur, 5_000); cur = ModelLadder.next(cur, DEFAULT_LADDER[0])!! }
        assertEquals("openai/gpt-oss-120b", cur)
        ModelLadder.rest(cur, 5_000)
        assertNull(ModelLadder.next(cur, DEFAULT_LADDER[0]))
    }

    @Test fun providerIsPickedByModelName() {
        assertEquals("gemini", ModelLadder.providerOf("gemini-3.8-flash"))
        assertEquals("gemini", ModelLadder.providerOf("gemma-3-27b-it"))
        assertEquals("groq", ModelLadder.providerOf("openai/gpt-oss-20b"))
    }

    @Test fun modelsWithoutAKeyAreSkipped() {
        val groqOnly: (String) -> Boolean = { ModelLadder.providerOf(it) == "groq" }
        assertEquals("openai/gpt-oss-20b", ModelLadder.best(DEFAULT_LADDER[0], groqOnly))
        assertEquals("openai/gpt-oss-120b", ModelLadder.next("openai/gpt-oss-20b", DEFAULT_LADDER[0], groqOnly))
    }

    @Test fun preferredCustomModelGoesFirstThenTheLadder() {
        assertEquals("custom/x", ModelLadder.best("custom/x"))
        ModelLadder.rest("custom/x", 5_000)
        assertEquals(DEFAULT_LADDER[0], ModelLadder.next("custom/x", "custom/x"))
    }
}
