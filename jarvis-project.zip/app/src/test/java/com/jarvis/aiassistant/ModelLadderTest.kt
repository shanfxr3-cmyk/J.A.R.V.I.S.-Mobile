package com.jarvis.aiassistant

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ModelLadderTest {
    @After fun clean() { ModelLadder.reset(); ModelLadder.now = { System.currentTimeMillis() } }

    @Test fun rateLimitAndOutageRestForDifferentTimes() {
        assertEquals(ModelLadder.QUOTA_MS, ModelLadder.classify(AiHttpException(429, 0, "Rate limit reached (429)")))
        assertEquals(10_000L, ModelLadder.classify(AiHttpException(429, 10_000, "Rate limit")))
        assertEquals(ModelLadder.OUTAGE_MS, ModelLadder.classify(AiHttpException(503, 0, "AI error 503")))
        assertEquals(ModelLadder.MISSING_MS, ModelLadder.classify(AiHttpException(404, 0, "model_not_found")))
    }

    @Test fun notTheModelsFault() {
        assertNull(ModelLadder.classify(AiHttpException(401, 0, "Invalid API key (401)")))
        assertNull(ModelLadder.classify(RuntimeException("processed 5000 items")))
        assertNull(ModelLadder.classify(java.io.IOException("Unable to resolve host")))
    }

    @Test fun wholeStatusCodesOnly() {
        assertEquals(ModelLadder.OUTAGE_MS, ModelLadder.classify(RuntimeException("server returned 503")))
        assertNull(ModelLadder.classify(RuntimeException("id 15030 failed")))
    }

    @Test fun restingModelIsSkippedThenComesBack() {
        var t = 1_000L
        ModelLadder.now = { t }
        assertEquals(DEFAULT_MODEL, ModelLadder.best(DEFAULT_MODEL))
        ModelLadder.rest(DEFAULT_MODEL, 5_000)
        assertEquals(FAST_MODEL, ModelLadder.best(DEFAULT_MODEL))
        assertNull(ModelLadder.next(FAST_MODEL.also { ModelLadder.rest(FAST_MODEL, 5_000) }, DEFAULT_MODEL))
        t += 6_000
        assertEquals(DEFAULT_MODEL, ModelLadder.best(DEFAULT_MODEL))
    }

    @Test fun preferredCustomModelGoesFirstThenDefaults() {
        assertEquals("custom/x", ModelLadder.best("custom/x"))
        ModelLadder.rest("custom/x", 5_000)
        assertEquals(DEFAULT_MODEL, ModelLadder.next("custom/x", "custom/x"))
    }
}
