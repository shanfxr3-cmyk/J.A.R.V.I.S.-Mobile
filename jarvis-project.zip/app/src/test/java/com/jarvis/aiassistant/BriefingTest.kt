package com.jarvis.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.util.Calendar

class BriefingTest {
    @Test fun nextOccurrenceIsTodayIfStillAhead_otherwiseTomorrow() {
        val base = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 1, 6, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val today = Calendar.getInstance().apply { timeInMillis = Briefing.nextOccurrence(base, 7, 30) }
        assertEquals(1, today.get(Calendar.DAY_OF_MONTH)); assertEquals(7, today.get(Calendar.HOUR_OF_DAY))
        val later = Calendar.getInstance().apply { timeInMillis = Briefing.nextOccurrence(base, 5, 0) }
        assertEquals(2, later.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun webNeverOpensPrivateAddresses() {
        listOf("127.0.0.1", "10.0.0.5", "192.168.1.1", "169.254.1.1", "100.64.0.1").forEach {
            assertTrue(it, Web.isPrivate(InetAddress.getByName(it)))
        }
        assertFalse(Web.isPrivate(InetAddress.getByName("93.184.216.34")))
        assertTrue(Web.blockedHost("localhost"))
        assertTrue(Web.blockedHost("printer.local"))
    }

    @Test fun duckDuckGoRedirectLinksAreUnwrapped() {
        assertEquals("https://example.com/a b", Web.unwrapDdg("//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fa%20b&rut=x"))
        assertEquals("https://example.org/x", Web.unwrapDdg("https://example.org/x"))
    }
}

class AppLockTest {
    @org.junit.Test fun relocksOnlyAfterTheGracePeriod() {
        org.junit.Assert.assertFalse(AppLock.shouldRelock(10_000))
        org.junit.Assert.assertTrue(AppLock.shouldRelock(31_000))
    }
}
