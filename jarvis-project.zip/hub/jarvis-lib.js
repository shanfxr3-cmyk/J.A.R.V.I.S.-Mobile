"use strict";
const net = require("net");
// jarvis-lib.js: pure helpers with no network or disk access (calculator, unit converter, RSS parser,
// quiet-hours windows, schedule parsing, memory scoring). Needs Node 18+. Used by index.js.

// ---------- quiet hours: proactive messages only 06:35-07:00 and 15:00-22:00 ----------
const WINDOWS = [[395, 420], [900, 1320]];
const allowed = m => WINDOWS.some(([a, b]) => m >= a && m <= b);
function clamp(m) {
  if (allowed(m)) return m;
  if (m < 395) return 395;
  if (m > 1320) return 1320;
  return (m - 420 <= 900 - m) ? 420 : 900;
}
const hhmm = m => String((m / 60) | 0).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");

// ---------- persona ----------
const sirify = s => { s = String(s || "").trim(); return !s || /\bsir\b/i.test(s) ? s : s.replace(/[.!?\s]*$/, ", sir."); };

// ---------- schedule parsing ----------
function parseTime(s) {
  const x = /^\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*$/i.exec(String(s || ""));
  if (!x) return null;
  let h = +x[1]; const n = +(x[2] || 0), p = (x[3] || "").toLowerCase();
  if (p && (h < 1 || h > 12)) return null;
  if (p === "pm" && h < 12) h += 12;
  if (p === "am" && h === 12) h = 0;
  return h < 24 && n < 60 ? h * 60 + n : null;
}
function parseWhen(s) {   // "8pm take medicine" -> { m: 1200, rest: "take medicine" }
  const x = /^\s*(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)\s+(.+)$/i.exec(String(s || ""));
  if (!x) return null;
  const m = parseTime(x[1]);
  return m == null ? null : { m, rest: x[2].trim() };
}
const DOWS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
function parseDays(s) {
  const k = String(s || "").toLowerCase().trim();
  if (k === "once" || k === "today" || k === "one-off") return "once";
  if (k === "daily" || k === "everyday" || k === "every day") return "daily";
  if (k === "weekdays" || k === "weekday") return "weekdays";
  return DOWS.find(d => d.toLowerCase() === k.slice(0, 3)) || null;
}
const runsOn = (t, dow, day) => t.on ? t.on === day : t.days === "daily" || (t.days === "weekdays" && dow !== "Sat" && dow !== "Sun") || t.days === dow;
const addDay = (day, k) => new Date(Date.parse(day + "T00:00:00Z") + 864e5 * k).toISOString().slice(0, 10);

// ---------- number formatting ----------
function fmt(x) {
  if (!Number.isFinite(x)) return String(x);
  const a = Math.abs(x);
  return a !== 0 && (a >= 1e9 || a < 1e-4) ? x.toPrecision(6) : String(+x.toPrecision(8));
}

// ---------- calculator (no eval) ----------
const FN = { sqrt: Math.sqrt, cbrt: Math.cbrt, sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
  log: Math.log10, log10: Math.log10, log2: Math.log2, ln: Math.log, abs: Math.abs, round: Math.round, floor: Math.floor, ceil: Math.ceil,
  exp: Math.exp, min: Math.min, max: Math.max, pow: Math.pow };
const CONST = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI };
function calc(src) {
  let s = String(src || "").toLowerCase().trim();
  if (!s || s.length > 200) throw new Error("give me a short expression");
  s = s.replace(/(\d),(?=\d{3}\b)/g, "$1").replace(/×/g, "*").replace(/÷/g, "/").replace(/(\d)\s*x\s*(\d)/g, "$1*$2")
    .replace(/(\d+(?:\.\d+)?)\s*%\s*of\s+/g, "($1/100)*").replace(/^(what is|calculate|calc)\s+/, "").replace(/=\s*\??$/, "");
  const re = /\s*(?:(\d+\.?\d*(?:e[+-]?\d+)?|\.\d+)|([a-z_][a-z_0-9]*)|(\*\*|[-+*\/^%(),]))/y;
  const t = []; let pos = 0;
  while (pos < s.length) {
    re.lastIndex = pos;
    const m = re.exec(s);
    if (!m) { if (/^\s*$/.test(s.slice(pos))) break; throw new Error("I could not read that expression"); }
    pos = re.lastIndex;
    t.push(m[1] !== undefined ? { n: parseFloat(m[1]) } : m[2] !== undefined ? { w: m[2] } : { o: m[3] });
  }
  let i = 0;
  const isOp = o => t[i] && t[i].o === o;
  const bad = () => { throw new Error("I could not read that expression"); };
  function expr() { let v = term(); while (isOp("+") || isOp("-")) { const o = t[i++].o, r = term(); v = o === "+" ? v + r : v - r; } return v; }
  function term() {
    let v = unary();
    for (;;) {
      if (isOp("*")) { i++; v *= unary(); } else if (isOp("/")) { i++; v /= unary(); } else if (isOp("%")) { i++; v %= unary(); } else break;
    }
    return v;
  }
  function unary() { if (isOp("-")) { i++; return -unary(); } if (isOp("+")) { i++; return unary(); } return power(); }
  function power() { const b = postfix(); if (isOp("^") || isOp("**")) { i++; return Math.pow(b, unary()); } return b; }
  function postfix() {
    let v = primary();
    while (isOp("%")) { const n = t[i + 1]; if (n === undefined || (n.o && n.o !== "(")) { i++; v /= 100; } else break; }
    return v;
  }
  function primary() {
    const k = t[i++];
    if (!k) bad();
    if (k.n !== undefined) return k.n;
    if (k.o === "(") { const v = expr(); if (!isOp(")")) bad(); i++; return v; }
    if (k.w !== undefined) {
      if (k.w in CONST && !isOp("(")) return CONST[k.w];
      if (!(k.w in FN) || !isOp("(")) bad();
      i++;
      const a = [];
      if (!isOp(")")) { a.push(expr()); while (isOp(",")) { i++; a.push(expr()); } }
      if (!isOp(")")) bad();
      i++;
      return FN[k.w](...a);
    }
    return bad();
  }
  const v = expr();
  if (i < t.length) bad();
  if (!Number.isFinite(v)) throw new Error("that has no finite result");
  return v;
}

// ---------- unit converter ----------
const DIM = {
  length: { m: 1, km: 1000, cm: .01, mm: .001, mi: 1609.344, ft: .3048, in: .0254, yd: .9144, nmi: 1852 },
  mass: { kg: 1, g: .001, mg: 1e-6, lb: .45359237, oz: .028349523125, t: 1000, st: 6.35029318 },
  volume: { l: 1, ml: .001, gal: 3.785411784, qt: .946352946, pt: .473176473, cup: .2365882365, floz: .0295735296, tbsp: .0147867648, tsp: .00492892159 },
  speed: { ms: 1, kmh: 1 / 3.6, mph: .44704, kn: .514444 },
  area: { m2: 1, km2: 1e6, ha: 1e4, acre: 4046.8564224, ft2: .09290304, mi2: 2589988.110336 },
  data: { byte: 1, kb: 1e3, mb: 1e6, gb: 1e9, tb: 1e12, kib: 1024, mib: 1048576, gib: 1073741824, tib: 1099511627776 },
  time: { s: 1, min: 60, h: 3600, d: 86400, wk: 604800 },
  temp: { c: 1, f: 1, k: 1 }
};
const ALIAS = {
  meter: "m", meters: "m", metre: "m", metres: "m", kilometer: "km", kilometers: "km", kilometre: "km", kilometres: "km", kms: "km", centimeter: "cm", centimeters: "cm", centimetre: "cm", centimetres: "cm",
  millimeter: "mm", millimeters: "mm", mile: "mi", miles: "mi", foot: "ft", feet: "ft", inch: "in", inches: "in", yard: "yd", yards: "yd", yds: "yd", "nautical mile": "nmi", "nautical miles": "nmi",
  kilogram: "kg", kilograms: "kg", kilo: "kg", kilos: "kg", kgs: "kg", gram: "g", grams: "g", gm: "g", milligram: "mg", milligrams: "mg", pound: "lb", pounds: "lb", lbs: "lb", ounce: "oz", ounces: "oz",
  tonne: "t", tonnes: "t", ton: "t", tons: "t", stone: "st",
  litre: "l", litres: "l", liter: "l", liters: "l", ltr: "l", milliliter: "ml", milliliters: "ml", millilitre: "ml", millilitres: "ml", gallon: "gal", gallons: "gal", quart: "qt", quarts: "qt", pint: "pt", pints: "pt",
  cups: "cup", "fl oz": "floz", "fluid ounce": "floz", "fluid ounces": "floz", tablespoon: "tbsp", tablespoons: "tbsp", teaspoon: "tsp", teaspoons: "tsp",
  "km/h": "kmh", kph: "kmh", kmph: "kmh", "m/s": "ms", knot: "kn", knots: "kn", kt: "kn",
  sqm: "m2", "sq m": "m2", "square meter": "m2", "square meters": "m2", "square metre": "m2", "square metres": "m2", sqkm: "km2", "square kilometer": "km2", "square kilometers": "km2", hectare: "ha", hectares: "ha", acres: "acre",
  sqft: "ft2", "sq ft": "ft2", "square foot": "ft2", "square feet": "ft2", "square mile": "mi2", "square miles": "mi2",
  bytes: "byte", kilobyte: "kb", kilobytes: "kb", megabyte: "mb", megabytes: "mb", gigabyte: "gb", gigabytes: "gb", terabyte: "tb", terabytes: "tb",
  second: "s", seconds: "s", sec: "s", secs: "s", minute: "min", minutes: "min", mins: "min", hour: "h", hours: "h", hr: "h", hrs: "h", day: "d", days: "d", week: "wk", weeks: "wk", wks: "wk",
  celsius: "c", centigrade: "c", fahrenheit: "f", kelvin: "k"
};
function unitOf(raw) {
  let u = String(raw || "").toLowerCase().replace(/°|degrees?|deg\b/g, "").replace(/\s+/g, " ").trim();
  if (ALIAS[u]) u = ALIAS[u];
  for (const [dim, tbl] of Object.entries(DIM)) if (u in tbl) return { dim, u };
  return null;
}
function toTemp(v, from, to) {
  const c = from === "c" ? v : from === "f" ? (v - 32) * 5 / 9 : v - 273.15;
  return to === "c" ? c : to === "f" ? c * 9 / 5 + 32 : c + 273.15;
}
function convertUnits(v, from, to) {   // returns a sentence, or null when a unit is unknown (so currency can be tried)
  const a = unitOf(from), b = unitOf(to);
  if (!a || !b) return null;
  if (a.dim !== b.dim) return "Those units measure different things (" + a.dim + " vs " + b.dim + ").";
  const r = a.dim === "temp" ? toTemp(v, a.u, b.u) : v * DIM[a.dim][a.u] / DIM[b.dim][b.u];
  return fmt(v) + " " + a.u + " = " + fmt(r) + " " + b.u;
}
function parseConvert(text) {   // "10 km to miles" -> { value, from, to }
  const x = /^\s*(-?[\d.,]+)\s*([^\d]+?)\s+(?:to|in|into|->)\s+(.+?)\s*$/i.exec(String(text || ""));
  return x ? { value: x[1].replace(/,/g, ""), from: x[2].trim(), to: x[3].trim() } : null;
}
const CUR_WORDS = { rupee: "INR", rupees: "INR", dollar: "USD", dollars: "USD", usd: "USD", euro: "EUR", euros: "EUR", yen: "JPY", "pound sterling": "GBP", "pounds sterling": "GBP", dirham: "AED", dirhams: "AED", yuan: "CNY", riyal: "SAR", riyals: "SAR" };
function curCode(s, rates) {
  const k = String(s || "").toLowerCase().trim();
  if (CUR_WORDS[k]) return CUR_WORDS[k];
  const up = k.toUpperCase();
  return /^[A-Z]{3}$/.test(up) && rates && rates[up] ? up : null;
}

// ---------- Google News RSS ----------
const ENT = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": "\"", "&#39;": "'", "&apos;": "'" };
const ent = s => String(s).replace(/&(amp|lt|gt|quot|apos|#39);/g, m => ENT[m] || m)
  .replace(/&#(\d{1,6});/g, (m, n) => { try { return String.fromCodePoint(+n); } catch (_) { return m; } })
  .replace(/&#x([0-9a-f]{1,6});/gi, (m, n) => { try { return String.fromCodePoint(parseInt(n, 16)); } catch (_) { return m; } });
function parseRss(xml, max) {
  const out = [];
  for (const blk of String(xml).split(/<item[ >]/i).slice(1)) {
    const g = tag => { const m = blk.match(new RegExp("<" + tag + "[^>]*>([\\s\\S]*?)</" + tag + ">", "i")); return m ? m[1].replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "").trim() : ""; };
    const title = ent(g("title")), link = g("link");
    if (title && /^https:\/\//.test(link)) out.push({ title, link, date: g("pubDate"), src: ent(g("source")) });
    if (out.length >= (max || 6)) break;
  }
  return out;
}

// ---------- memory scoring: recent and often-confirmed facts rank higher, unused ones fade ----------
const HALF_LIFE = 60 * 86400000;
const STOP = new Set("the and for with that this have has are was were you your his her its our their from into about like just very much more some any not but can will would could should been being also than then them they what when where who how why".split(" "));
function toks(s) { return new Set(String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f ]/g, " ").split(/\s+/).filter(w => w.length > 2 && !STOP.has(w))); }
function shared(a, b) { const A = toks(a), B = toks(b); let n = 0; for (const w of A) if (B.has(w)) n++; return n; }
function jaccard(a, b) { const A = toks(a), B = toks(b); if (!A.size || !B.size) return 0; let n = 0; for (const w of A) if (B.has(w)) n++; return n / (A.size + B.size - n); }
function score(m, now) { return m.pin ? 1e9 : (1 + Math.log2(1 + (m.hits || 0))) * Math.pow(0.5, ((now || Date.now()) - (m.last || m.t || 0)) / HALF_LIFE); }

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b < 128) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b < 32) ||
      (a === 192 && b === 168) || (a === 192 && b === 0) || (a === 198 && (b === 18 || b === 19)) || a >= 224;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === "::" || x === "::1") return true;
    const n64 = x.match(/^64:ff9b::(\d+\.\d+\.\d+\.\d+)$/), n64h = x.match(/^64:ff9b::([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);   // NAT64: judge the IPv4 address inside
    if (n64) return isPrivateIp(n64[1]);
    if (n64h) { const h = parseInt(n64h[1], 16), l = parseInt(n64h[2], 16); return isPrivateIp((h >> 8) + "." + (h & 255) + "." + (l >> 8) + "." + (l & 255)); }
    const m = x.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (m) return isPrivateIp(m[1]);
    const m2 = x.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
    if (m2) { const h = parseInt(m2[1], 16), l = parseInt(m2[2], 16); return isPrivateIp((h >> 8) + "." + (h & 255) + "." + (l >> 8) + "." + (l & 255)); }
    const first = parseInt(x.split(":")[0] || "0", 16);
    return (first & 0xfe00) === 0xfc00 || (first & 0xffc0) === 0xfe80 || (first & 0xff00) === 0xff00;
  }
  return true;
}

// ---------- AI providers: one ladder, each rung picks its provider by model name ----------
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";
const DEFAULT_LADDER = ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "openai/gpt-oss-20b", "openai/gpt-oss-120b"];
function cleanModel(m) { return String(m || "").trim().replace(/^models\//, ""); }
function validModel(m) { return /^[A-Za-z0-9._\/:-]{1,80}$/.test(String(m || "")); }
function providerOf(m) { return /^(gemini|gemma)/i.test(cleanModel(m)) ? "gemini" : "groq"; }
// cfg.ladder wins; else the old model + fallbackModel; else the default six. Rungs whose provider has no key are dropped.
function buildLadder(cfg) {
  const raw = Array.isArray(cfg.ladder) && cfg.ladder.length ? cfg.ladder : (cfg.model || cfg.fallbackModel) ? [cfg.model, cfg.fallbackModel] : DEFAULT_LADDER;
  const keys = { groq: !!cfg.groqKey, gemini: !!cfg.geminiKey };
  return raw.map(cleanModel).filter((m, i, a) => m && validModel(m) && a.indexOf(m) === i && keys[providerOf(m)]);
}
function providerCfg(m, cfg) { return providerOf(m) === "gemini" ? { name: "Gemini", url: GEMINI_URL, key: cfg.geminiKey } : { name: "Groq", url: GROQ_URL, key: cfg.groqKey }; }

module.exports = { isPrivateIp,  allowed, clamp, hhmm, sirify, parseTime, parseWhen, parseDays, runsOn, addDay, DOWS, fmt, calc, convertUnits, parseConvert, curCode, parseRss, toks, shared, jaccard, score, providerOf, cleanModel, validModel, buildLadder, providerCfg, DEFAULT_LADDER };
