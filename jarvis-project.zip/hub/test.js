"use strict";
// Run with: node test.js   (no dependencies, no network)
const assert = require("assert"), L = require("./jarvis-lib");
let n = 0; const t = (name, f) => { try { f(); n++; } catch (e) { console.log("FAIL:", name, "-", e.message); process.exitCode = 1; } };
t("private IPv4", () => { for (const a of ["10.0.0.1", "127.0.0.1", "192.168.1.1", "172.16.0.1", "169.254.1.1", "100.64.0.1", "0.0.0.0", "224.0.0.1"]) assert(L.isPrivateIp(a), a); });
t("public IPv4", () => { for (const a of ["8.8.8.8", "1.1.1.1", "172.32.0.1", "142.250.1.1"]) assert(!L.isPrivateIp(a), a); });
t("IPv6", () => { assert(L.isPrivateIp("::1")); assert(L.isPrivateIp("fe80::1")); assert(L.isPrivateIp("fc00::1")); assert(L.isPrivateIp("::ffff:127.0.0.1")); assert(!L.isPrivateIp("2606:4700::1111")); });
t("NAT64 judges embedded IPv4", () => { assert(L.isPrivateIp("64:ff9b::10.0.0.1")); assert(L.isPrivateIp("64:ff9b::a00:1")); assert(!L.isPrivateIp("64:ff9b::808:808")); });
t("not an IP is blocked", () => assert(L.isPrivateIp("nonsense")));
t("calc", () => { assert.strictEqual(L.calc("12*(3+4)"), 84); assert.strictEqual(L.calc("20% of 450"), 90); assert.strictEqual(L.calc("2^10"), 1024); assert.throws(() => L.calc("process.exit()")); });
t("convert", () => { assert(/10 km = 6\.2137\d* mi/.test(L.convertUnits(10, "km", "miles"))); assert(/= 212 f/.test(L.convertUnits(100, "C", "F"))); assert.strictEqual(L.convertUnits(1, "foo", "bar"), null); });
t("parseTime", () => { assert.strictEqual(L.parseTime("8pm"), 1200); assert.strictEqual(L.parseTime("20:30"), 1230); assert.strictEqual(L.parseTime("12am"), 0); assert.strictEqual(L.parseTime("25:00"), null); });
t("clamp stays in windows", () => { for (let m = 0; m < 1440; m++) assert(L.allowed(L.clamp(m)), "m=" + m); });
t("jaccard memory merge", () => { assert(L.jaccard("Brother Ravi lives Delhi", "Brother Ravi works Delhi") < 0.7); assert(L.jaccard("Likes strong masala tea", "Likes strong masala tea a lot") >= 0.7); });
t("rss entities", () => { const r = L.parseRss("<item><title>Tom &amp; Jerry&#8217;s</title><link>https://x.com/a</link></item>", 3); assert.strictEqual(r[0].title, "Tom & Jerry\u2019s"); });
t("sirify", () => { assert.strictEqual(L.sirify("Done."), "Done, sir."); assert.strictEqual(L.sirify("Yes sir."), "Yes sir."); });
t("provider by model name", () => { assert.strictEqual(L.providerOf("gemini-3.8-flash"), "gemini"); assert.strictEqual(L.providerOf("models/gemma-4"), "gemini"); assert.strictEqual(L.providerOf("openai/gpt-oss-20b"), "groq"); assert.strictEqual(L.providerOf("llama-3.3-70b-versatile"), "groq"); });
t("ladder default and key filtering", () => {
  assert.deepStrictEqual(L.buildLadder({ groqKey: "a", geminiKey: "b" }), L.DEFAULT_LADDER);
  assert.deepStrictEqual(L.buildLadder({ groqKey: "a" }), ["openai/gpt-oss-20b", "openai/gpt-oss-120b"]);
  assert.deepStrictEqual(L.buildLadder({ geminiKey: "b" }), ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]);
  assert.deepStrictEqual(L.buildLadder({ groqKey: "a", model: "openai/gpt-oss-120b", fallbackModel: "openai/gpt-oss-20b" }), ["openai/gpt-oss-120b", "openai/gpt-oss-20b"]);
  assert.deepStrictEqual(L.buildLadder({ groqKey: "a", ladder: ["openai/gpt-oss-20b", "openai/gpt-oss-20b", "bad model!"] }), ["openai/gpt-oss-20b"]);
});
t("provider config", () => { assert(/groq\.com/.test(L.providerCfg("openai/gpt-oss-20b", { groqKey: "k" }).url)); assert.strictEqual(L.providerCfg("gemini-3.8-flash", { geminiKey: "g" }).key, "g"); });
console.log(n + " checks passed" + (process.exitCode ? " (with failures)" : ""));
