# jarvis-hub

The optional server behind J.A.R.V.I.S. Mobile. It is one file (`index.js`) plus `jarvis-lib.js`, needs Node 18 or newer and **no npm packages**.

What it does for you:
- Speaks things on your phone even when it is locked: morning briefing, finished background jobs, watched-topic alerts, reminders.
- Runs a Telegram bot with the same tools as the app (notes, to-dos, reminders, news, weather, calculator, converter, TV remote, memory).
- Shares notes, to-dos, calculator, converter, news and reminders with the phone app too (`POST /v1/tools/run`, whitelist in `APP_TOOLS`). One list of notes and to-dos, whichever side you use.
- **Every proactive message arrives once.** Briefings, reminders, alerts, rain warnings and finished jobs go to the phone (spoken) while it is connected, and to Telegram only when it is not. Replies to something you asked on Telegram stay on Telegram. `/speak` goes to the phone only.
- Optionally proxies the phone's AI chat to Gemini and Groq through a six-model ladder, so the phone only needs the hub token.
- Keeps its memory, reminders, notes and to-dos in `data.json` (a copy is saved daily as `data.json.bak`).

## Files

| File | Keep private? | What |
|---|---|---|
| `index.js`, `jarvis-lib.js` | no | the program |
| `config.json` | **yes** | your settings and keys (copy `config.example.json`) |
| `creds.json` | **yes** | Cloudflare tunnel credentials (only if you use a tunnel) |
| `data.json`, `data.json.bak` | yes | the hub's memory, created by itself |

`.gitignore` in this folder already excludes the private files.

## Settings (`config.json`)

| Key | Meaning |
|---|---|
| `token` | Required. The password the phone sends. Use a long random string. Paste the same value into the app (Settings, Hub) |
| `groqKey`, `geminiKey` | Your Groq key (gsk_...) and your Google AI Studio Gemini key. Set at least one. A model with no matching key is skipped |
| `ladder` | Optional list of model ids tried top to bottom. Default: gemini-3.8-flash, gemini-3.6-flash, gemini-3.5-flash-lite, gemini-3.1-flash-lite, openai/gpt-oss-20b, openai/gpt-oss-120b. Gemini and Gemma ids use `geminiKey`, the rest use `groqKey` |
| `telegramToken`, `allowedIds` | Optional. Bot token from BotFather and the numeric Telegram user ids that may talk to it. Nobody else is answered |
| `tavilyKey` | Optional. Better web search. Without it a free scraper is used |
| `model`, `fallbackModel` | Older settings, still read: put first in the ladder when set |
| `timezone`, `city` | Used for the date, weather and the briefing |
| `briefTime` | Morning briefing time, `HH:MM` |
| `watchEveryHours` | How often watched topics are checked |
| `rpm`, `dailyLimit` | Requests per minute per client address, and AI calls per day for the whole hub |
| `tunnelHost` | The public hostname of your Cloudflare tunnel (for example `hub.example.com`) |
| `tvWakeWebhook` | Optional. An https URL (smart plug / IFTTT / Home Assistant Cloud) the hub calls once when a TV command arrives and the TV app is offline, then waits up to 25 s for the TV to come back |
| `bind` | Address to listen on. Default `127.0.0.1` (right when you use a tunnel). Use `0.0.0.0` only if you deliberately expose the port |
| `cloudflaredVersion` | Optional. A cloudflared release tag to download (for example `2025.1.0`) instead of the latest |
| `cloudflaredSha256` | Optional but recommended with the version above. The downloaded program must match this SHA-256 |
| `allowedModels` | Optional list of extra model ids the app may pick. Every model in the ladder is always allowed |

## Jarvis TV app (optional)

A small Android TV / Fire TV app (`tv/` module, release file `Jarvis-TV-...apk`) links to the hub as its own device, so TV control works from any network and adds volume. It never listens (no microphone permission): voice, replies and alerts all stay on the phone.

1. Install the APK on the TV and open it. It shows a 6-digit code.
2. On Telegram send `/pair 123456`. The TV links within seconds and keeps itself linked across reboots.
3. One time on the TV: tap "Show code on TV", type the 4-digit code it shows, tap Pair. This allows keys and media buttons.

`/devices` lists linked TVs, `/unpair name` revokes one at once. A device token only works for the TV channel and is stored on the hub as a hash. With no TV online, commands fall back to the phone relay (same Wi-Fi).

## Quiet hours

Proactive speech (scheduled tasks, rain alert, nudges, briefing, watch alerts) happens only between **06:35 and 07:00** and **15:00 and 22:00**. A scheduled task set for another time is moved to the nearest window and Jarvis says so. Reminders set by delay ("in 20 minutes") are exact during the day and, if they fall overnight, wait until 06:35 and start with "Belated reminder". The windows are in `jarvis-lib.js` (`WINDOWS`).

## Running it

```
node index.js
```

It reads the port from `SERVER_PORT` or `PORT` (default 16712). On a game-style panel host (for example Wispbyte) upload the files, create `config.json`, set the start command to `node index.js` and start it. Do not rely on the host to expose the port: use the tunnel below, so the app talks to `https://your-hostname`.

### Cloudflare tunnel (gives you the https address the app needs)

1. Create a tunnel and a public hostname for it in Cloudflare, pointing at `http://127.0.0.1:<port>`.
2. Save the tunnel's credentials file as `creds.json` next to `index.js` and set `tunnelHost` in `config.json`.
3. Start the hub. If `cloudflared` is missing it is downloaded (Linux, amd64 or arm64), checked to be a real Linux program (and against `cloudflaredSha256` if you set it), and started. It restarts by itself if it stops.

### Connecting the phone

In the app: Settings, Hub. Enter the hub address (`https://your-hostname`) and the hub token. Then in Settings, AI provider, choose a setup:

- **Hub as the AI (when a hub token is set):** chat goes through the hub, which walks the ladder. If the hub or tunnel is down, Jarvis answers directly using the Groq and Gemini keys saved on the phone.
- **Phone only:** leave the hub token empty. Chat goes straight from the phone to Gemini or Groq using the same six-model ladder.

The hub and the phone can both speak a morning briefing. Keep only one on.

## Telegram commands

`/brief /status /reset /loc`, `/speak text` (phone says it), `/tv home|back|up|down|select|play|pause|open netflix|apps`, `/remind 8pm text`, `/every weekdays 9am text`, `/tasks /del id`, `/todo /todos /done /deltodo`, `/note /notes /delnote`, `/calc`, `/convert 10 km to miles`, `/news [topic]`, `/watch /unwatch /watches`, `/memories /forget`, `/job task`, `/pair code`, `/devices`, `/unpair name`. Anything else is a normal conversation.

## Safety built in

- Token check is timing-safe. Wrong guesses are limited per **real client address** (read from Cloudflare's header, trusted only from localhost). A correct token is never locked out.
- Listens on localhost by default.
- Web access refuses private network addresses, on DNS answers and on every redirect, https only.
- Text from web pages is treated as data. Once a request has read the web, actions that change memory, watches, background jobs or the TV are refused for the rest of that request. Ask again as a separate message.
- `remember` and automatic memory skip anything that looks like a password, key or long number.
- Per-day AI call cap (`dailyLimit`) protects your free Gemini and Groq quota.
- State is written atomically; a corrupt `data.json` is kept as `data.json.bad` and `data.json.bak` is restored.

## Backups

Download `data.json.bak` now and then if you care about the memory. A host that wipes its disk takes the state with it.

## Troubleshooting
- **The app says "Cannot reach the hub (HTTP 530)"**: the tunnel is not running. Read the hub log (the first lines say `TUNNEL NOT STARTED` and why), or send `/status` on Telegram (it shows the tunnel state). The usual cause is a missing `tunnelHost` in `config.json` or a missing `creds.json`.
- **"CONFIG WARNING: unknown key"** in the log means a setting is misspelled and is being ignored.
- Run `node test.js` in this folder to check the helper code (no network needed).
