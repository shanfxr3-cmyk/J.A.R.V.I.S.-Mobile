# Jarvis TV (tv/ module)

Output-only TV companion. Package `com.jarvis.tv`. No microphone permission, no voice or assistant hooks: the TV never listens.

- Links to the hub with its own revocable token (pair with the on-screen code, approve on Telegram: `/pair CODE`).
- Auto-starts at boot, reconnects with backoff, runs each hub command and reports the result back to Jarvis on the phone.
- Actions: home, back, menu, select, up/down/left/right, play, pause, forward, rewind, open_app, list_apps, volume_up, volume_down, mute.
- Universal APK (no native libraries) because many Fire TVs run a 32-bit userland.

## Not yet verified on a real TV (written without a device)
1. Volume: uses the system music volume; should drive the built-in speakers of a Fire TV.
2. Keys and media via the TV's own remote service (same protocol as the phone's Tv.kt, but called from the TV itself).
3. Staying connected while the TV is in standby; fully powered off cannot work (optional `tvWakeWebhook` can power it on via a smart plug).
4. Launching apps from the background service.

Power-off and typing are still not possible without ADB or an accessibility service.
