# Jarvis TV (tv/ module)

Output-only TV companion. Package `com.jarvis.tv`. No microphone permission, no voice or assistant hooks: the TV never listens.

- Links to the hub with its own revocable token (pair with the on-screen code, approve on Telegram: `/pair CODE`).
- Auto-starts at boot, reconnects with backoff, runs each hub command and reports the result back to Jarvis on the phone.
- Actions: home, back, menu, select, up/down/left/right, play, pause, forward, rewind, open_app, list_apps, volume_up, volume_down, mute.
- **Updates itself.** When the TV app is opened it checks the latest GitHub Release (every 20 min at most). A newer Jarvis-TV APK shows an UPDATE AVAILABLE pop-up with Update now / Later (D-pad friendly); it downloads, checks it is signed with the same key, and opens Android's installer. "Check for updates" on the main screen does it by hand. The first install of this version still has to be sideloaded once; every update after that needs no files sent to the TV. If Android asks, allow "Install unknown apps" for Jarvis TV once.
- **Main screen buttons:** System, Settings, Diagnostics (D-pad only; Back returns).
- **System:** live CPU (with core count), memory, storage and network speed with download/upload curves, in the phone's HUD style. Android hides the system-wide CPU counters from apps on newer versions; then the CPU line is labelled APP CPU and shows how busy Jarvis TV itself is.
- **Settings:** TV name (used the next time you pair), hub address, update check on/off, start at boot on/off, volume limit (40-100%), night mode (from, to, lower limit), idle screen on/off and delay, alert cards on/off, re-pair remote control.
- **Diagnostics:** version, hub address, link state and last contact, remote-control state, test buttons (hub connection with timing, volume, Home key, app list, alert card) and the last 20 commands. Use it to work through the "not yet verified" list below.
- **Idle screen:** after 2 minutes (setting) without a key press while the app is open and linked, a black screen shows a big clock, date, weather, the next calendar events and next reminder (from the hub) and the live system readout. It drifts slightly every minute and keeps the screen awake. Any button wakes it and does nothing else.
- **Alert cards:** briefings, reminders, rain and calendar alerts that the hub speaks on the phone are also shown on the TV as text (a card at the top of the app, or a toast over other apps). The TV never speaks. Turn off in Settings or with `"tvCards": false` in the hub's config.json.
- Universal APK (no native libraries) because many Fire TVs run a 32-bit userland.

## Not yet verified on a real TV (written without a device)
1. Volume: uses the system music volume; should drive the built-in speakers of a Fire TV.
2. Keys and media via the TV's own remote service (same protocol as the phone's Tv.kt, but called from the TV itself).
3. Staying connected while the TV is in standby; fully powered off cannot work (optional `tvWakeWebhook` can power it on via a smart plug).
4. Launching apps from the background service.

Power-off and typing are still not possible without ADB or an accessibility service.
