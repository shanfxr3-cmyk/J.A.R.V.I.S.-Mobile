plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

// Jarvis TV: a tiny, dependency-free Android TV / Fire TV app. It links to the hub as its own device and carries out commands.
// No native libraries, so no ABI filter: Fire OS often runs a 32-bit userland even on a 64-bit chip.
android {
    namespace = "com.jarvis.tv"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.jarvis.tv"
        minSdk = 24
        targetSdk = 33   // sideloaded; avoids the newer foreground-service type rules that older Fire OS does not know about
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0.0"
        buildConfigField("String", "DEFAULT_HUB_URL", "\"" + ((project.findProperty("JARVIS_DEFAULT_HUB") as String?) ?: "").trim() + "\"")
    }
    val ksPath = System.getenv("KEYSTORE_PATH")
    val hasReleaseKey = ksPath != null && file(ksPath).exists()
    if (hasReleaseKey) {
        signingConfigs {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}
