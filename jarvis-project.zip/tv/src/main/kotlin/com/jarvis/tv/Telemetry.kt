package com.jarvis.tv

import android.app.ActivityManager
import android.content.Context
import android.net.TrafficStats
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import java.io.File

/**
 * Live readout of this TV: CPU, memory, storage and network speed. Sampled once a second while a screen shows it.
 * Android hides the system-wide CPU counters from apps on newer versions; when /proc/stat cannot be read the
 * figure falls back to how busy Jarvis TV itself is, and cpuLabel says so.
 */
object Telemetry {
    const val N = 60
    @JvmField val rx = FloatArray(N)
    @JvmField val tx = FloatArray(N)
    @JvmField var head = 0
    var cores = Runtime.getRuntime().availableProcessors(); private set
    var cpuPct = 0; private set
    var cpuLabel = "CPU"; private set
    var ramPct = 0; private set
    var ramFreeMb = 0; private set
    var ramTotalMb = 0; private set
    var diskFreeGb = 0f; private set
    var diskTotalGb = 0f; private set
    var rxKbps = 0; private set
    var txKbps = 0; private set

    private var lastRx = -1L; private var lastTx = -1L; private var lastT = 0L
    private var lastTotal = -1L; private var lastIdle = -1L
    private var lastProc = -1L

    /** (total, idle) jiffies from /proc/stat, or null when Android does not let this app read it. */
    private fun stat(): Pair<Long, Long>? {
        return try {
            val line = File("/proc/stat").bufferedReader().use { it.readLine() } ?: return null
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 6 || p[0] != "cpu") return null
            val v = p.drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size < 5) return null
            Pair(v.sum(), v[3] + v[4])
        } catch (_: Throwable) { null }
    }

    fun sample(c: Context) {
        val now = SystemClock.elapsedRealtime()
        val dtMs = if (lastT == 0L) 0L else (now - lastT).coerceAtLeast(1L)

        // memory
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        ramTotalMb = (mi.totalMem / 1048576L).toInt()
        ramFreeMb = (mi.availMem / 1048576L).toInt()
        ramPct = if (mi.totalMem > 0) (100L - mi.availMem * 100L / mi.totalMem).toInt().coerceIn(0, 100) else 0

        // storage
        try {
            val sf = StatFs(Environment.getDataDirectory().path)
            diskFreeGb = sf.availableBytes / 1073741824f; diskTotalGb = sf.totalBytes / 1073741824f
        } catch (_: Throwable) {}

        // cpu: whole system if readable, else this app only
        val st = stat()
        if (st != null) {
            cpuLabel = "CPU"
            if (lastTotal >= 0 && st.first > lastTotal) cpuPct = (100L * ((st.first - lastTotal) - (st.second - lastIdle)) / (st.first - lastTotal)).toInt().coerceIn(0, 100)
            lastTotal = st.first; lastIdle = st.second
        } else {
            cpuLabel = "APP CPU"
            val p = Process.getElapsedCpuTime()
            if (lastProc >= 0 && dtMs > 0) cpuPct = (100L * (p - lastProc) / (dtMs * cores)).toInt().coerceIn(0, 100)
            lastProc = p
        }

        // network
        val r = TrafficStats.getTotalRxBytes(); val t = TrafficStats.getTotalTxBytes()
        var dr = 0; var dt = 0
        if (dtMs > 0 && r >= 0 && t >= 0 && lastRx >= 0 && lastTx >= 0) {
            dr = ((r - lastRx) * 1000L / dtMs / 1024L).toInt().coerceAtLeast(0)
            dt = ((t - lastTx) * 1000L / dtMs / 1024L).toInt().coerceAtLeast(0)
        }
        lastRx = r; lastTx = t; lastT = now
        rxKbps = dr; txKbps = dt
        rx[head] = dr.toFloat(); tx[head] = dt.toFloat()
        head = (head + 1) % N
    }

    fun rate(kbps: Int): String = if (kbps < 1024) "$kbps KB/s" else String.format(java.util.Locale.US, "%.1f MB/s", kbps / 1024f)
}
