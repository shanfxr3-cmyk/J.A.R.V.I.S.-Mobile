package com.jarvis.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Idle screen: big clock, date, weather, next events and reminder from the hub, and the live system readout.
 * Output only. The whole block drifts a little every minute so nothing burns into the screen.
 */
class HudView(c: Context) : FrameLayout(c) {
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private val body = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val clock = TextClock(c)
    private val date = TextClock(c)
    private val wx = Ui.label(c, "", 20f, Ui.CYAN)
    private val agenda = Ui.label(c, "", 18f, android.graphics.Color.WHITE)
    private val note = Ui.label(c, "", 16f, Ui.DIM)

    init {
        setBackgroundColor(android.graphics.Color.BLACK)
        isFocusable = true
        clock.apply { format24Hour = "HH:mm"; format12Hour = "HH:mm"; setTextColor(Ui.CYAN); textSize = 96f; gravity = Gravity.CENTER; typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD) }
        date.apply { format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"; setTextColor(Ui.DIM); textSize = 24f; gravity = Gravity.CENTER }
        body.addView(clock); body.addView(date)
        body.addView(wx, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 18) })
        body.addView(agenda); body.addView(note)
        val tv = TelemetryView(c)
        body.addView(tv, LinearLayout.LayoutParams(Ui.dp(c, 560), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 28) })
        addView(body, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        note.text = "Press any button to wake"
    }

    private val drift = object : Runnable {
        override fun run() {
            val a = Ui.dp(context, 24)
            body.translationX = (Math.random() * 2 - 1).toFloat() * a
            body.translationY = (Math.random() * 2 - 1).toFloat() * a
            ui.postDelayed(this, 60000)
        }
    }
    private val refresh = object : Runnable {
        override fun run() { fetch(); ui.postDelayed(this, 10 * 60000L) }
    }

    fun start() { running = true; ui.post(drift); ui.post(refresh) }
    fun stop() { running = false; ui.removeCallbacks(drift); ui.removeCallbacks(refresh) }

    private fun fetch() {
        val hub = Prefs.hub(context); val tok = Prefs.token(context)
        if (hub.isBlank() || tok.isBlank()) return
        Thread {
            var weather = ""; var lines = ""; var next = ""; var tz = ""
            try {
                val r = Hub.call(hub, "GET", "/v1/tv/info", tok, null, 20000)
                if (r.code != 200) throw java.io.IOException("hub answered HTTP ${r.code}")
                val j = JSONObject(r.body)
                weather = j.optString("weather"); tz = j.optString("tz")
                val f = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone(j.optString("tz").ifBlank { "UTC" }) }
                val ev = j.optJSONArray("events")
                if (ev != null) for (i in 0 until ev.length()) { val e = ev.getJSONObject(i); lines += f.format(Date(e.getLong("t"))) + "  " + e.optString("title") + "\n" }
                val n = j.optJSONObject("next")
                if (n != null) next = "Next reminder  " + n.optString("hm") + "  " + n.optString("text")
                val td = j.optInt("todos")
                if (td > 0) next += (if (next.isEmpty()) "" else "     ") + "$td open to-do" + (if (td == 1) "" else "s")
            } catch (e: Exception) { weather = "Hub not reachable right now"; }
            ui.post {
                if (!running) return@post
                if (tz.isNotBlank()) { clock.timeZone = tz; date.timeZone = tz }
                wx.text = weather
                agenda.text = lines.trim()
                note.text = (if (next.isEmpty()) "" else next + "\n") + "Press any button to wake"
            }
        }.start()
    }
}
