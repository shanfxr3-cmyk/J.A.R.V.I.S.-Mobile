package com.jarvis.tv

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.view.KeyEvent

/** Carries out one command from the hub and returns a short sentence for Jarvis to say on the phone. Blocking: call from a background thread. */
object Cmd {
    private val FALLBACK = mapOf("netflix" to "com.netflix.ninja", "youtube" to "com.amazon.firetv.youtube")
    private const val NEED_PAIR = "Remote control is not allowed yet. Open the Jarvis TV app on the TV and finish step 2."

    private fun audio(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun mediaKey(c: Context, code: Int) {
        val am = audio(c)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** (label, package) of every app that can be launched from the TV home screen. */
    private fun launchables(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val out = LinkedHashMap<String, String>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (!out.containsKey(pkg)) out[pkg] = ri.loadLabel(pm).toString()
            }
        }
        return out.entries.map { it.value to it.key }
    }

    private fun launch(c: Context, pkg: String): Boolean {
        val pm = c.packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        return true
    }

    private fun openApp(c: Context, want: String): String {
        val w = want.trim()
        if (w.isEmpty()) return "Which app?"
        val lw = w.lowercase()
        val list = launchables(c)
        val hit = list.firstOrNull { it.first.lowercase() == lw } ?: list.firstOrNull { it.first.lowercase().startsWith(lw) }
            ?: list.firstOrNull { it.first.lowercase().contains(lw) }
        val pkg = hit?.second ?: (if (w.contains('.')) w else FALLBACK[lw])
        if (pkg != null && launch(c, pkg)) return "Opening ${hit?.first ?: w}."
        if (FireTv.paired(c)) {
            val p = FireTv.appPackage(c, w)
            if (p != null) return FireTv.openByPackage(c, p)
        }
        return "I could not find an app called $w on the TV."
    }

    fun run(c: Context, action: String, arg: String): String {
        val a = action.trim().lowercase().replace(' ', '_')
        return try {
            when {
                a == "volume_up" || a == "volume_down" -> {
                    val n = arg.trim().toIntOrNull()?.coerceIn(1, 15) ?: 2
                    val am = audio(c)
                    for (k in 1..n) am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        if (a == "volume_up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                        if (k == n) AudioManager.FLAG_SHOW_UI else 0)
                    if (a == "volume_up") "Volume up." else "Volume down."
                }
                a == "mute" -> { audio(c).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); "Mute toggled." }
                a == "wake" -> "The TV is already on."
                a == "list_apps" -> launchables(c).map { it.first }.distinct().take(40).joinToString(", ").ifEmpty { "I could not read the app list." }
                a == "open_app" -> openApp(c, arg)
                a in FireTv.KEYS -> if (FireTv.paired(c)) FireTv.key(c, a) else NEED_PAIR
                a == "play" || a == "pause" ->
                    if (FireTv.paired(c)) FireTv.media(c, a)
                    else { mediaKey(c, if (a == "play") KeyEvent.KEYCODE_MEDIA_PLAY else KeyEvent.KEYCODE_MEDIA_PAUSE); if (a == "play") "Playing." else "Paused." }
                a == "forward" || a == "rewind" ->
                    if (FireTv.paired(c)) FireTv.scan(c, a == "forward", arg.trim().toIntOrNull()?.coerceIn(1, 30) ?: 3)
                    else { mediaKey(c, if (a == "forward") KeyEvent.KEYCODE_MEDIA_FAST_FORWARD else KeyEvent.KEYCODE_MEDIA_REWIND); if (a == "forward") "Skipped forward." else "Rewound." }
                else -> "Unknown TV action: $action."
            }
        } catch (e: Exception) { "TV error: ${e.message}" }
    }
}
