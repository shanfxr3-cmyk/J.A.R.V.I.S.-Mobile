package com.jarvis.tv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Starts the link again after the TV boots (or after an update), so a restart never breaks it. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.token(c).isBlank()) return
        val s = Intent(c, HubService::class.java)
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s) else c.startService(s)
    }
}
