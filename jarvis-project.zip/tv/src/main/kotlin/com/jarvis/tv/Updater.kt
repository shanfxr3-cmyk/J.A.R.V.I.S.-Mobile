package com.jarvis.tv

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Self-updater for the TV app, so nothing has to be copied to the TV by hand.
 * Looks at the latest GitHub Release, downloads the Jarvis-TV APK, checks that it is signed with the same key
 * as the installed app, then hands it to Android's PackageInstaller. Same key + same application id means the
 * update installs over the old app and keeps the link to the hub. No libraries: only framework classes.
 */
object Updater {
    data class Info(val code: Int, val label: String, val url: String, val size: Long)

    private val ui = Handler(Looper.getMainLooper())

    /** Called on the main thread whenever anything below changes. The screen sets it while it is visible. */
    @Volatile var onChange: (() -> Unit)? = null

    @Volatile var info: Info? = null; private set
    @Volatile var status = ""; private set
    @Volatile var busy = false; private set
    /** 0..100 while downloading, -1 otherwise. */
    @Volatile var progress = -1; private set
    @Volatile var downloaded: File? = null; private set
    @Volatile var failed = false; private set
    /** Release the person chose "Later" for: the pop-up stays away for this version until they check by hand. */
    @Volatile var dismissed = 0

    @Volatile private var current = 0
    @Volatile private var lastCheck = 0L

    val available: Info? get() = info?.takeIf { it.code > current }

    private fun changed() { ui.post { onChange?.invoke() } }

    private fun set(s: String, err: Boolean = false) { status = s; failed = err; changed() }

    /** Version code of what is installed right now, and cleanup of a downloaded APK that is no longer newer. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        current = installedCode(app)
        val f = downloaded ?: return
        val apk = if (f.exists()) archive(app, f) else null
        if (apk == null || codeOf(apk) <= current) {
            runCatching { f.delete() }
            downloaded = null
            progress = -1
            set("")
        }
    }

    @Suppress("DEPRECATION")
    private fun codeOf(p: PackageInfo): Int = if (Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else p.versionCode

    private fun installedCode(app: Context): Int = try { codeOf(app.packageManager.getPackageInfo(app.packageName, 0)) } catch (_: Throwable) { BuildConfig.VERSION_CODE }

    private fun archive(app: Context, f: File, flags: Int = 0): PackageInfo? = try { app.packageManager.getPackageArchiveInfo(f.absolutePath, flags) } catch (_: Throwable) { null }

    private fun updateFile(ctx: Context) = File(File(ctx.cacheDir, "updates"), "jarvis-tv-update.apk")

    private fun ua() = "JarvisTV/" + BuildConfig.VERSION_NAME

    /** Only https links on GitHub's own hosts are accepted as a download, whatever the release data says. */
    private fun trusted(url: String): Boolean = try {
        val u = URL(url); val h = u.host.lowercase()
        u.protocol == "https" && (h == "github.com" || h.endsWith(".github.com") || h.endsWith(".githubusercontent.com"))
    } catch (_: Throwable) { false }

    // ---------- signature check: same key as the installed app ----------
    private fun sha(b: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    @Suppress("DEPRECATION")
    private fun signers(p: PackageInfo?): List<String> {
        if (p == null) return emptyList()
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val si = p.signingInfo
            if (si == null) null else if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
        } else p.signatures
        return sigs?.map { sha(it.toByteArray()) } ?: emptyList()
    }

    @Suppress("DEPRECATION")
    private fun sameSigner(app: Context, f: File): Boolean {
        val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val mine = try { signers(app.packageManager.getPackageInfo(app.packageName, flag)) } catch (_: Throwable) { emptyList() }
        val theirs = signers(archive(app, f, flag))
        return mine.isNotEmpty() && theirs.any { it in mine }
    }

    // ---------- check ----------
    /** Checks at most every 20 minutes unless [force]. [done] runs on the main thread when the check has finished. */
    fun check(ctx: Context, force: Boolean = false, done: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (busy || (!force && now - lastCheck < 20 * 60 * 1000L)) { if (done != null) ui.post { done() }; return }
        lastCheck = now
        busy = true
        set("Checking for updates...")
        val app = ctx.applicationContext
        Thread {
            var msg = ""; var err = false; var found: Info? = null
            var conn: HttpURLConnection? = null
            try {
                val c = URL("https://api.github.com/repos/${BuildConfig.REPO_OWNER}/${BuildConfig.REPO_NAME}/releases/latest").openConnection() as HttpURLConnection
                conn = c
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", ua())
                c.connectTimeout = 10000; c.readTimeout = 15000
                when (c.responseCode) {
                    200 -> {
                        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                        // Release tags look like "build-N"; the TV's version code is the same run number N.
                        val code = j.optString("tag_name").removePrefix("build-").toIntOrNull()
                        var url = ""; var size = 0L; var name = ""
                        val assets = j.optJSONArray("assets")
                        if (assets != null) for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            val n = a.optString("name")
                            if (n.startsWith("Jarvis-TV") && n.endsWith(".apk")) { url = a.optString("browser_download_url"); size = a.optLong("size"); name = n; break }
                        }
                        if (code == null || url.isEmpty()) { msg = "The latest release has no TV app."; err = true }
                        else if (!trusted(url)) { msg = "Blocked: the update link does not point to GitHub."; err = true }
                        else {
                            val m = Regex("""Jarvis-TV-v(.+)-build(\d+)\.apk""").find(name)
                            val label = if (m != null) "Version ${m.groupValues[1]} (build ${m.groupValues[2]})" else "Build $code"
                            found = Info(code, label, url, size)
                            msg = if (code > current) "Update available: $label" else "You're on the latest version."
                        }
                    }
                    404 -> msg = "No update published yet."
                    403, 429 -> { msg = "GitHub is limiting update checks from this network. Try again later."; err = true }
                    else -> { msg = "Update check failed (HTTP ${c.responseCode})."; err = true }
                }
            } catch (e: Throwable) {
                msg = "Couldn't check for updates: ${e.message ?: "no connection"}"; err = true
            } finally { runCatching { conn?.disconnect() } }
            // An update downloaded earlier (the app may have been restarted since) is picked up again.
            var again: File? = null
            val f = found
            if (f != null && f.code > current) {
                val old = updateFile(app)
                if (old.exists() && f.size > 0 && old.length() == f.size && sameSigner(app, old)) again = old
            }
            ui.post {
                info = found ?: info
                if (again != null && downloaded == null) downloaded = again
                busy = false
                set(msg, err)
                done?.invoke()
            }
        }.start()
    }

    // ---------- download ----------
    /** Downloads the update, verifies it, and opens Android's installer. */
    fun download(ctx: Context) {
        val i = available ?: return
        if (busy) return
        val app = ctx.applicationContext
        busy = true; progress = 0
        set("Downloading update...")
        Thread {
            var msg = ""; var err = false; var file: File? = null
            var conn: HttpURLConnection? = null
            try {
                if (!trusted(i.url)) throw java.io.IOException("the update link does not point to GitHub.")
                val out = updateFile(app)
                val dir = out.parentFile!!
                dir.mkdirs()
                if (out.exists() && i.size > 0 && out.length() == i.size && sameSigner(app, out)) {
                    file = out   // already complete from an earlier try
                } else {
                    dir.listFiles()?.forEach { it.delete() }
                    val c = URL(i.url).openConnection() as HttpURLConnection
                    conn = c
                    c.setRequestProperty("User-Agent", ua())
                    c.instanceFollowRedirects = true
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    if (c.responseCode != 200) throw java.io.IOException("GitHub answered HTTP ${c.responseCode}.")
                    val total = if (c.contentLengthLong > 0) c.contentLengthLong else i.size
                    var done = 0L; var last = -1
                    c.inputStream.use { inp ->
                        out.outputStream().use { os ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                os.write(buf, 0, n)
                                done += n
                                val p = if (total > 0) (done * 100 / total).toInt() else 0
                                if (p != last) { last = p; ui.post { progress = p; onChange?.invoke() } }
                            }
                        }
                    }
                    val pi = archive(app, out)
                    if (total > 0 && done != total) { out.delete(); msg = "Download failed: the file was cut off. Try again."; err = true }
                    else if (!sameSigner(app, out)) { out.delete(); msg = "Blocked: that APK is not signed with the same key as this app."; err = true }
                    else if (pi != null && pi.packageName != app.packageName) { out.delete(); msg = "Blocked: that APK is a different app."; err = true }
                    else if (pi != null && codeOf(pi) <= current) { out.delete(); msg = "Download failed: that APK is not newer than the installed version."; err = true }
                    else file = out
                }
            } catch (e: Throwable) {
                msg = "Download failed: ${e.message ?: "no connection"}"; err = true
                runCatching { updateFile(app).delete() }   // a half-written file must never be kept
            } finally { runCatching { conn?.disconnect() } }
            ui.post {
                downloaded = file
                busy = false; progress = -1
                if (file != null) { set("Downloaded. Opening the installer..."); install(app) } else set(msg, err)
            }
        }.start()
    }

    // ---------- install (PackageInstaller session: needs no FileProvider and no libraries) ----------
    fun install(ctx: Context) {
        val f = downloaded ?: return
        val app = ctx.applicationContext
        try {
            if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
                set("Allow \"Install unknown apps\" for Jarvis TV, then come back and choose Install.", true)
                try {
                    app.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Throwable) {
                    // Some Fire OS builds have no such page: fall back to the general settings list.
                    runCatching { app.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
                return
            }
            val pi = app.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            params.setAppPackageName(app.packageName)
            val id = pi.createSession(params)
            val s = pi.openSession(id)
            try {
                f.inputStream().use { inp ->
                    s.openWrite("jarvis-tv.apk", 0, f.length()).use { os -> inp.copyTo(os); s.fsync(os) }
                }
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pend = PendingIntent.getBroadcast(app, id, Intent(app, InstallReceiver::class.java).setAction("com.jarvis.tv.INSTALL_RESULT"), flags)
                s.commit(pend.intentSender)
            } catch (e: Throwable) {
                runCatching { s.abandon() }
                throw e
            } finally { runCatching { s.close() } }
        } catch (e: Throwable) {
            set("Couldn't open the installer: ${e.message}", true)
        }
    }

    internal fun installResult(text: String?) { if (text != null) set(text, true) }
}

/** Receives the result of the install session. Android asks the person to confirm; on success the app is replaced and restarts itself. */
class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val ask = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java) else i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                try { if (ask != null) c.startActivity(ask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) { Updater.installResult("Couldn't open the installer: ${e.message}") }
            }
            PackageInstaller.STATUS_SUCCESS -> {}   // the process is replaced by the new version
            PackageInstaller.STATUS_FAILURE_BLOCKED -> Updater.installResult("Blocked: allow \"Install unknown apps\" for Jarvis TV, then try again.")
            PackageInstaller.STATUS_FAILURE_CONFLICT, PackageInstaller.STATUS_FAILURE_INCOMPATIBLE ->
                Updater.installResult("The installer refused it: that APK does not match the installed app.")
            else -> Updater.installResult("Install failed: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "unknown reason"))
        }
    }
}
