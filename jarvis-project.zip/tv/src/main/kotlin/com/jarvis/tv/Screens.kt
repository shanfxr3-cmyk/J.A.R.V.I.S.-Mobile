package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.text.InputFilter
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Settings, System and Diagnostics screens. Every control is a button, so the TV remote's D-pad is all that is needed. */
object Screens {
    private fun lp(a: Activity, w: Int = 640) = LinearLayout.LayoutParams(Ui.dp(a, w), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(a, 6) }

    private fun page(a: Activity, title: String, body: LinearLayout.() -> Unit, onBack: () -> Unit): ScrollView {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 24)) }
        col.addView(Ui.label(a, title, 28f, Ui.CYAN, true))
        col.body()
        col.addView(Ui.button(a, "Back", onBack), lp(a).apply { topMargin = Ui.dp(a, 20) })
        return ScrollView(a).apply { addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); isFillViewport = true }
    }

    /** A button that steps through the allowed values each time it is pressed. */
    private fun cycle(a: Activity, col: LinearLayout, title: String, key: String, opts: List<Int>, show: (Int) -> String) {
        val b = Ui.button(a, "") {}
        fun refresh() { b.text = title + ":   " + show(Prefs.int(a, key)) }
        b.setOnClickListener {
            val i = opts.indexOf(Prefs.int(a, key))
            Prefs.setInt(a, key, opts[(i + 1) % opts.size]); refresh()
        }
        refresh(); col.addView(b, lp(a))
    }

    private fun toggle(a: Activity, col: LinearLayout, title: String, key: String) = cycle(a, col, title, key, listOf(1, 0)) { if (it == 1) "ON" else "OFF" }

    private fun field(a: Activity, col: LinearLayout, title: String, hint: String, value: String, save: (String) -> String) {
        col.addView(Ui.label(a, title, 16f, Ui.DIM), lp(a))
        val e = EditText(a).apply { setText(value); this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(Ui.DIM); gravity = Gravity.CENTER; setSingleLine(); filters = arrayOf(InputFilter.LengthFilter(120)) }
        col.addView(e, lp(a))
        col.addView(Ui.button(a, "Save") { Toast.makeText(a, save(e.text.toString().trim()), Toast.LENGTH_LONG).show() }, lp(a))
    }

    private fun hour(h: Int) = String.format("%02d:00", h)

    // ---------------------------------------------------------------------------------------------
    fun settings(a: Activity, onBack: () -> Unit): ScrollView = page(a, "SETTINGS", {
        field(a, this, "Name of this TV (shown in Telegram; used the next time you pair)", "TV", Prefs.deviceName(a)) { v -> Prefs.setDeviceName(a, v); "Saved. Unlink and pair again to use the new name." }
        field(a, this, "Hub address", "https://your-hub-address", Prefs.hub(a)) { v ->
            if (v.startsWith("https://")) { Prefs.setHub(a, v); "Saved. The TV reconnects to this address." } else "The address must start with https://"
        }
        addView(Ui.label(a, "UPDATES AND START", 16f, Ui.AMBER, true), lp(a))
        toggle(a, this, "Check for updates when the app opens", "autoUpdate")
        toggle(a, this, "Start the link when the TV starts", "bootStart")
        addView(Ui.label(a, "VOLUME", 16f, Ui.AMBER, true), lp(a))
        cycle(a, this, "Highest volume Jarvis may set", "volCap", listOf(100, 90, 80, 70, 60, 50, 40)) { "$it%" }
        toggle(a, this, "Night mode (lower limit at night)", "nightOn")
        cycle(a, this, "Night starts", "nightFrom", listOf(20, 21, 22, 23, 0)) { hour(it) }
        cycle(a, this, "Night ends", "nightTo", listOf(5, 6, 7, 8, 9)) { hour(it) }
        cycle(a, this, "Night volume limit", "nightCap", listOf(10, 20, 30, 40, 50)) { "$it%" }
        addView(Ui.label(a, "SCREEN", 16f, Ui.AMBER, true), lp(a))
        toggle(a, this, "Idle screen (clock, weather, system)", "idleOn")
        cycle(a, this, "Idle screen starts after", "idleMin", listOf(1, 2, 5, 10, 20)) { "$it min" }
        toggle(a, this, "Show alerts and reminders as cards", "cards")
        addView(Ui.label(a, "REMOTE CONTROL", 16f, Ui.AMBER, true), lp(a))
        addView(Ui.button(a, "Pair remote control again") { Prefs.setTvToken(a, ""); Toast.makeText(a, "Done. Open the main screen and follow step 2.", Toast.LENGTH_LONG).show() }, lp(a))
    }, onBack)

    fun system(a: Activity, onBack: () -> Unit): ScrollView = page(a, "SYSTEM", {
        addView(TelemetryView(a), LinearLayout.LayoutParams(Ui.dp(a, 720), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(a, 8) })
        addView(Ui.label(a, "Android ${Build.VERSION.RELEASE}  ·  ${Build.MANUFACTURER} ${Build.MODEL}", 16f, Ui.DIM))
        addView(Ui.label(a, "When Android hides the system-wide CPU counters, the CPU line shows how busy Jarvis TV itself is.", 14f, Ui.DIM))
    }, onBack)

    fun diagnostics(a: Activity, onBack: () -> Unit): ScrollView {
        val ui = android.os.Handler(android.os.Looper.getMainLooper())
        val result = Ui.label(a, "", 15f, Color.WHITE, false, false, true)
        val log = Ui.label(a, "", 14f, Ui.DIM, false, false, true)
        fun showLog() { log.text = CmdLog.all().joinToString("\n").ifEmpty { "No commands yet." } }
        fun say(s: String) = ui.post { result.text = s; showLog() }
        fun test(name: String, f: () -> String): () -> Unit = {
            result.text = "$name ..."
            Thread { val out = try { f() } catch (e: Exception) { "failed: ${e.message}" }; CmdLog.add("test $name > ${out.take(50)}"); say("$name: $out") }.start()
        }
        return page(a, "DIAGNOSTICS", {
            val age = if (Status.lastOk == 0L) "never" else ((System.currentTimeMillis() - Status.lastOk) / 1000).toString() + " s ago"
            val info = listOf(
                "Version      ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})",
                "Hub          ${Prefs.hub(a).ifBlank { "not set" }}",
                "Link         " + (if (Prefs.token(a).isBlank()) "not paired" else if (Status.online) "online" else "reconnecting") + ", last contact $age",
                "Remote ctrl  " + (if (FireTv.paired(a)) "allowed" else "not allowed yet (step 2)"),
                "Name         ${Prefs.deviceName(a)}"
            ).joinToString("\n")
            addView(Ui.label(a, info, 16f, Color.WHITE, false, false, true), lp(a, 720))
            addView(Ui.button(a, "Test hub connection", test("hub") {
                val t0 = System.currentTimeMillis()
                val r = Hub.call(Prefs.hub(a), "GET", "/v1/tv/info", Prefs.token(a), null, 20000)
                val ms = System.currentTimeMillis() - t0
                if (r.code == 200) "reachable, answered in $ms ms" else if (r.code == 401) "the hub does not know this TV (unlinked)" else "hub answered HTTP ${r.code}"
            }), lp(a))
            addView(Ui.button(a, "Test volume (up one, then down)", test("volume") { Cmd.run(a, "volume_up", "1") + " " + Cmd.run(a, "volume_down", "1") }), lp(a))
            addView(Ui.button(a, "Test Home key", test("home key") { Cmd.run(a, "home", "") }), lp(a))
            addView(Ui.button(a, "Test app list", test("apps") { val s = Cmd.run(a, "list_apps", ""); (s.count { it == ',' } + 1).toString() + " apps: " + s.take(70) }), lp(a))
            addView(Ui.button(a, "Test alert card", test("card") { Cards.show(a, "This is a test card from Jarvis TV.") }), lp(a))
            addView(result, lp(a, 720))
            addView(Ui.label(a, "LAST COMMANDS", 16f, Ui.AMBER, true), lp(a))
            showLog()
            addView(log, lp(a, 720))
            addView(Ui.button(a, "Refresh log") { showLog() }, lp(a))
        }, onBack)
    }
}
