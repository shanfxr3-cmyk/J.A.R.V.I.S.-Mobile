package com.jarvis.tv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Talks to this TV's own built-in remote service (the one Amazon's Fire TV phone app uses), over the TV's own address.
 * Same protocol as the phone app's Tv.kt. UNVERIFIED: whether the service accepts a call from the TV itself.
 * If it does not, only the keys and media buttons are affected (volume, apps and the hub link do not use it).
 */
object FireTv {
    private const val API_KEY = "0987654321"   // public identifier of the protocol, not a secret
    val KEYS = mapOf("home" to "home", "back" to "back", "menu" to "menu", "select" to "select",
        "up" to "dpad_up", "down" to "dpad_down", "left" to "dpad_left", "right" to "dpad_right")
    private val PKG = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
    private val NAME_KEYS = setOf("name", "title", "label", "appname", "displayname", "display_name", "friendlyname")

    fun paired(c: Context) = Prefs.tvToken(c).isNotBlank()

    /** This TV's own private network address (the TLS check is switched off for it, so it must never be anyone else's). */
    fun host(): String {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return "127.0.0.1"
            for (ni in java.util.Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in java.util.Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: continue
                }
            }
        } catch (_: Exception) {}
        return "127.0.0.1"
    }

    private val ssl: SSLContext by lazy {
        SSLContext.getInstance("TLS").apply {
            init(null, arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }), SecureRandom())
        }
    }

    private fun call(ip: String, method: String, path: String, body: String?, tok: String?): Pair<Int, String> {
        require(ip == host() || ip == "127.0.0.1") { "only this TV's own address is allowed" }
        val c = URL("https://$ip:8080$path").openConnection() as HttpsURLConnection
        try {
            c.sslSocketFactory = ssl.socketFactory
            c.hostnameVerifier = HostnameVerifier { _, _ -> true }
            c.connectTimeout = 4000; c.readTimeout = 6000
            c.requestMethod = method
            c.setRequestProperty("X-Api-Key", API_KEY)
            c.setRequestProperty("User-Agent", "okhttp/4.10.0")
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (tok != null) c.setRequestProperty("X-Client-Token", tok)
            if (method == "POST") { c.doOutput = true; c.outputStream.use { it.write((body ?: "").toByteArray()) } }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            return code to text
        } finally { c.disconnect() }
    }

    private fun wake(ip: String): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, 8009), 3000); s.soTimeout = 4000
            s.getOutputStream().apply { write("POST /apps/FireTVRemote HTTP/1.1\r\nHost: $ip:8009\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); flush() }
            s.getInputStream().bufferedReader().readLine() != null
        }
    } catch (_: Exception) { false }

    private fun send(ip: String, tok: String?, method: String, path: String, body: String?): Pair<Int, String> =
        try { call(ip, method, path, body, tok) }
        catch (_: IOException) { wake(ip); Thread.sleep(2000); call(ip, method, path, body, tok) }

    private fun reply(r: Pair<Int, String>, ok: String) = when {
        r.first in 200..299 -> ok
        r.first == 401 || r.first == 403 -> "The TV rejected the remote pairing. Pair again in the Jarvis TV app (step 2)."
        else -> "The TV answered HTTP ${r.first}."
    }

    // ---------- pairing (one time, on the TV itself) ----------
    fun showPin(): String = try {
        val ip = host()
        val r = send(ip, null, "POST", "/v1/FireTV/pin/display", JSONObject().put("friendlyName", "Jarvis TV").toString())
        if (r.first in 200..299) "A 4-digit code is on the screen. Type it below." else "The TV answered HTTP ${r.first}."
    } catch (e: Exception) { "Could not reach the TV's remote service: ${e.message}" }

    private fun tokenFrom(text: String): String {
        val t = text.trim()
        return try {
            val j = JSONObject(t)
            listOf("description", "clientToken", "token", "authorization").map { j.optString(it) }.firstOrNull { it.isNotBlank() } ?: ""
        } catch (_: Exception) { t.trim('"') }
    }

    fun verifyPin(c: Context, pin: String): String = try {
        val r = send(host(), null, "POST", "/v1/FireTV/pin/verify", JSONObject().put("pin", pin.trim()).toString())
        val tok = tokenFrom(r.second)
        if (r.first in 200..299 && tok.isNotBlank() && tok.length < 200) { Prefs.setTvToken(c, tok); "Paired." }
        else "Pairing failed (HTTP ${r.first}). Show a new code and try again."
    } catch (e: Exception) { "Pairing failed: ${e.message}" }

    // ---------- actions ----------
    private fun walk(x: Any?, out: MutableList<Pair<String, String>>) {
        when (x) {
            is JSONObject -> {
                var name = ""; var pkg = ""
                for (k in x.keys()) {
                    val v = x.opt(k)
                    if (v is String) {
                        if (name.isEmpty() && k.lowercase() in NAME_KEYS) name = v
                        if (pkg.isEmpty() && PKG.matches(v)) pkg = v
                    }
                }
                if (name.isNotEmpty() && pkg.isNotEmpty()) out.add(name to pkg)
                for (k in x.keys()) walk(x.opt(k), out)
            }
            is JSONArray -> for (i in 0 until x.length()) walk(x.opt(i), out)
        }
    }

    fun key(c: Context, action: String): String =
        reply(send(host(), Prefs.tvToken(c), "POST", "/v1/FireTV?action=${KEYS[action]}", null), "Sent $action.")

    fun media(c: Context, action: String): String =
        reply(send(host(), Prefs.tvToken(c), "POST", "/v1/media?action=$action", null), if (action == "play") "Playing." else "Paused.")

    fun scan(c: Context, forward: Boolean, secs: Int): String {
        val ip = host(); val tok = Prefs.tvToken(c); val dir = if (forward) "forward" else "backward"
        fun body(t: String) = """{"direction":"$dir","keyAction":{"keyActionType":"$t"}}"""
        val r = send(ip, tok, "POST", "/v1/media?action=scan", body("keyDown"))
        Thread.sleep(secs * 1000L)
        send(ip, tok, "POST", "/v1/media?action=scan", body("keyUp"))
        return reply(r, if (forward) "Skipped forward." else "Rewound.")
    }

    /** Package name of an app by display name, from the remote service's own app list (used when the app is not found locally). */
    fun appPackage(c: Context, want: String): String? {
        val ip = host(); val tok = Prefs.tvToken(c)
        val r = send(ip, tok, "GET", "/v1/FireTV/appsV2", null)
        val list = mutableListOf<Pair<String, String>>()
        if (r.first in 200..299) try { walk(if (r.second.trim().startsWith("[")) JSONArray(r.second) else JSONObject(r.second), list) } catch (_: Exception) {}
        val lw = want.lowercase()
        return (list.firstOrNull { it.first.lowercase() == lw } ?: list.firstOrNull { it.first.lowercase().contains(lw) })?.second
    }

    fun openByPackage(c: Context, pkg: String): String =
        reply(send(host(), Prefs.tvToken(c), "POST", "/v1/FireTV/app/" + URLEncoder.encode(pkg, "UTF-8"), null), "Opening it.")
}
