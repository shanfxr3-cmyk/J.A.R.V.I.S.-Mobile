package com.jarvis.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import org.json.JSONObject

/** Keeps the TV linked: long-polls the hub for commands, runs each one, and posts the result back. Output only, never listens. */
class HubService : Service() {
    @Volatile private var running = true
    private var worker: Thread? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notification())
        if (worker == null) worker = Thread { loop() }.apply { isDaemon = true; start() }
        return START_STICKY
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun notification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b = if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("jarvis_tv", "Jarvis TV link", NotificationManager.IMPORTANCE_MIN))
            Notification.Builder(this, "jarvis_tv")
        } else Notification.Builder(this)
        return b.setContentTitle("Jarvis TV").setContentText("Linked to your hub").setSmallIcon(android.R.drawable.stat_notify_sync).build()
    }

    private fun loop() {
        var after = 0L
        var backoff = 2000L
        while (running) {
            val tok = Prefs.token(this); val hub = Prefs.hub(this)
            if (tok.isBlank() || hub.isBlank()) { stopSelf(); return }
            try {
                val r = Hub.call(hub, "GET", "/v1/tv/next?after=$after", tok, null, 40000)
                if (r.code == 401) { Prefs.setToken(this, ""); Status.set(false, "Unlinked from the hub"); stopSelf(); return }
                if (r.code !in 200..299) throw java.io.IOException("hub answered HTTP ${r.code}")
                Status.set(true)
                backoff = 2000L
                val cmds = JSONObject(r.body).optJSONArray("cmds") ?: continue
                for (n in 0 until cmds.length()) {
                    val cmd = cmds.getJSONObject(n)
                    val id = cmd.getLong("id")
                    if (id > after) after = id
                    val action = cmd.optString("action"); val arg = cmd.optString("arg")
                    Thread {
                        val out = try { if (action == "card") Cards.show(applicationContext, arg) else Cmd.run(applicationContext, action, arg) } catch (e: Exception) { "TV error: ${e.message}" }
                        CmdLog.add((action + " " + arg.take(30)).trim() + "  >  " + out.take(60))
                        if (action != "card") Status.set(true, (action + " " + arg).trim() + "  >  " + out.take(70))
                        try { Hub.call(hub, "POST", "/v1/tv/result", tok, JSONObject().put("id", id).put("text", out.take(500)).toString(), 15000) } catch (_: Exception) {}
                    }.start()
                }
            } catch (e: Exception) {
                Status.set(false)
                try { Thread.sleep(backoff) } catch (_: InterruptedException) {}
                backoff = minOf(backoff * 2, 60000L)
            }
        }
    }
}
