package com.jarvis.tv

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.TextView

/** Small view helpers shared by the screens. Plain Android views: the TV app has no libraries. */
object Ui {
    val CYAN = Color.parseColor("#00F0FF")
    val AMBER = Color.parseColor("#FFB800")
    val RED = Color.parseColor("#FF3D5A")
    val DIM = Color.parseColor("#7FA6B5")
    val BG = Color.rgb(0, 12, 26)

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun label(c: Context, t: String, sp: Float, color: Int, bold: Boolean = false, center: Boolean = true, mono: Boolean = false): TextView = TextView(c).apply {
        text = t; setTextColor(color); textSize = sp
        gravity = if (center) Gravity.CENTER else Gravity.START
        if (mono) typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
        else if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(c, 4), 0, dp(c, 4))
    }

    /** Button with a cyan outline that lights up when the D-pad focus is on it. */
    fun button(c: Context, t: String, onClick: () -> Unit): Button = Button(c).apply {
        text = t; isFocusable = true; isAllCaps = false; setTextColor(Color.WHITE); textSize = 18f
        background = GradientDrawable().apply { setColor(Color.rgb(0, 40, 60)); setStroke(dp(c, 2), CYAN); cornerRadius = dp(c, 6).toFloat() }
        setOnFocusChangeListener { v, f -> (v.background as? GradientDrawable)?.setColor(if (f) Color.rgb(0, 110, 140) else Color.rgb(0, 40, 60)) }
        setOnClickListener { onClick() }
    }
}
