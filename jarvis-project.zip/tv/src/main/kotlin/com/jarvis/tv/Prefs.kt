package com.jarvis.tv

import android.content.Context
import java.util.Calendar

/** Settings kept in the app's private storage. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis_tv", Context.MODE_PRIVATE)
    fun hub(c: Context): String = sp(c).getString("hub", null) ?: BuildConfig.DEFAULT_HUB_URL
    fun setHub(c: Context, v: String) { sp(c).edit().putString("hub", v.trim().trimEnd('/')).apply() }
    /** This TV's own token for the hub (valid for the TV channel only). Blank = not linked. */
    fun token(c: Context): String = sp(c).getString("devToken", "") ?: ""
    fun setToken(c: Context, v: String) { sp(c).edit().putString("devToken", v).apply() }
    /** Token of the Fire TV's built-in remote service (step 2 pairing). Blank = not allowed yet. */
    fun tvToken(c: Context): String = sp(c).getString("tvToken", "") ?: ""
    fun setTvToken(c: Context, v: String) { sp(c).edit().putString("tvToken", v).apply() }

    /** Name shown in Telegram /devices. Read when the TV is paired, so a new name applies after the next pairing. */
    fun deviceName(c: Context): String = sp(c).getString("devName", null)?.takeIf { it.isNotBlank() } ?: "TV"
    fun setDeviceName(c: Context, v: String) {
        val clean = v.filter { it.isLetterOrDigit() || it == ' ' || it == '-' }.trim().take(20)
        sp(c).edit().putString("devName", clean).apply()
    }

    // ---------- simple on/off and number settings (booleans are 0 or 1) ----------
    private val DEFAULTS = mapOf(
        "autoUpdate" to 1,   // look for a new version whenever the app opens
        "bootStart" to 1,    // link to the hub again after the TV starts
        "cards" to 1,        // show alerts and reminders from the hub as a card
        "idleOn" to 1,       // idle screen with clock, weather and system readout
        "idleMin" to 2,      // minutes without a key press before the idle screen
        "volCap" to 100,     // highest volume Jarvis may set, in percent
        "nightOn" to 0,      // lower volume cap at night
        "nightFrom" to 22, "nightTo" to 7, "nightCap" to 30
    )
    fun int(c: Context, k: String): Int = sp(c).getInt(k, DEFAULTS[k] ?: 0)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun on(c: Context, k: String): Boolean = int(c, k) == 1

    private fun inNight(c: Context): Boolean {
        if (!on(c, "nightOn")) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val a = int(c, "nightFrom"); val b = int(c, "nightTo")
        return if (a <= b) h in a until b else h >= a || h < b
    }

    /** Highest music volume step Jarvis may raise the TV to (the person's own remote is not limited). */
    fun volumeCapSteps(c: Context, maxSteps: Int): Int {
        var pct = int(c, "volCap")
        if (inNight(c)) pct = minOf(pct, int(c, "nightCap"))
        return (maxSteps * pct / 100).coerceIn(1, maxSteps)
    }
}

/** What the screen shows about the link. */
object Status {
    @Volatile var online = false
    @Volatile var last = ""
    /** Time of the last successful contact with the hub (ms), 0 = never since the app started. */
    @Volatile var lastOk = 0L
    @Volatile var onChange: (() -> Unit)? = null
    fun set(o: Boolean, l: String? = null) { online = o; if (o) lastOk = System.currentTimeMillis(); if (l != null) last = l; onChange?.invoke() }
}

/** The last commands this TV carried out, newest first, for the Diagnostics screen. */
object CmdLog {
    private val items = ArrayList<String>()
    @Synchronized fun add(line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        items.add(0, "$t  $line".take(120))
        while (items.size > 20) items.removeAt(items.size - 1)
    }
    @Synchronized fun all(): List<String> = items.toList()
}
