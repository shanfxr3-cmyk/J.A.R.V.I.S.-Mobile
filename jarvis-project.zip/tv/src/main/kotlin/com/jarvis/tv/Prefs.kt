package com.jarvis.tv

import android.content.Context

/** Settings kept in the app's private storage. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis_tv", Context.MODE_PRIVATE)
    fun hub(c: Context): String = sp(c).getString("hub", null) ?: BuildConfig.DEFAULT_HUB_URL
    fun setHub(c: Context, v: String) { sp(c).edit().putString("hub", v.trim().trimEnd('/')).apply() }
    /** This TV's own token for the hub (valid for the TV channel only). Blank = not linked. */
    fun token(c: Context): String = sp(c).getString("devToken", "") ?: ""
    fun setToken(c: Context, v: String) { sp(c).edit().putString("devToken", v).apply() }
    /** Token of the Fire TV's built-in remote service (step 2 pairing). Blank = not allowed yet. */
    fun tvToken(c: Context): String = sp(c).getString("tvToken", "") ?: ""
    fun setTvToken(c: Context, v: String) { sp(c).edit().putString("tvToken", v).apply() }
    fun deviceName(): String = "TV"   // shown in Telegram /devices
}

/** What the screen shows about the link. */
object Status {
    @Volatile var online = false
    @Volatile var last = ""
    @Volatile var onChange: (() -> Unit)? = null
    fun set(o: Boolean, l: String? = null) { online = o; if (l != null) last = l; onChange?.invoke() }
}
