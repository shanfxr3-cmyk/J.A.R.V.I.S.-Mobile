package com.jarvis.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Alerts, reminders and briefings from the hub, shown as text. The TV never speaks or listens: the phone does the talking. */
object Cards {
    /** Set by the main screen while it is visible, so the card can look like part of the screen. Otherwise a toast shows over whatever is playing. */
    @Volatile var sink: ((String) -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())

    fun show(c: Context, text: String): String {
        if (!Prefs.on(c, "cards")) return "Cards are off on this TV."
        val t = text.trim()
        if (t.isEmpty()) return "Nothing to show."
        val app = c.applicationContext
        ui.post {
            val s = sink
            if (s != null) s(t) else Toast.makeText(app, "J.A.R.V.I.S.:  $t", Toast.LENGTH_LONG).show()
        }
        return "Shown."
    }
}
