package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import java.util.Locale

/** Draws the Telemetry readout in the HUD style: segmented bars for CPU and memory, download/upload curves. */
class TelemetryView(c: Context) : View(c) {
    private val ui = Handler(Looper.getMainLooper())
    private val d = c.resources.displayMetrics.density
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    private val monoB = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.CYAN; typeface = monoB; textSize = 15f * d }
    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.DIM; typeface = mono; textSize = 14f * d }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; typeface = monoB; textSize = 16f * d }
    private val seg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d; color = Color0.faint }
    private val pr = Path(); private val pt = Path(); private val pf = Path()
    private val pts = FloatArray(Telemetry.N * 2)
    private var shaderH = -1f

    private object Color0 { val faint = android.graphics.Color.argb(90, 0, 240, 255) }

    private val tick = object : Runnable {
        override fun run() { Telemetry.sample(context); invalidate(); ui.postDelayed(this, 1000) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); ui.removeCallbacks(tick); ui.post(tick) }
    override fun onDetachedFromWindow() { ui.removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((520 * d).toInt(), w), resolveSize((250 * d).toInt(), h))
    }

    private fun bar(cv: Canvas, x: Float, y: Float, w: Float, h: Float, frac: Float, warn: Float) {
        val n = 24; val gap = 3f * d; val sw = (w - gap * (n - 1)) / n
        val on = Math.round(frac.coerceIn(0f, 1f) * n)
        val col = if (frac >= 0.95f) Ui.RED else if (frac >= warn) Ui.AMBER else Ui.CYAN
        for (i in 0 until n) {
            seg.color = if (i < on) col else android.graphics.Color.argb(50, 0, 240, 255)
            cv.drawRect(x + i * (sw + gap), y, x + i * (sw + gap) + sw, y + h, seg)
        }
    }

    private fun smooth(p: Path, first: Boolean) {
        var px = pts[0]; var py = pts[1]
        if (first) p.moveTo(px, py) else p.lineTo(px, py)
        var i = 2
        while (i < pts.size) { val x = pts[i]; val y = pts[i + 1]; p.quadTo(px, py, (px + x) / 2, (py + y) / 2); px = x; py = y; i += 2 }
        p.lineTo(px, py)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val pad = 14f * d
        cv.drawRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, frame)
        val barW = w * 0.42f; var y = pad + 14f * d
        cv.drawText("SYSTEM", pad, y, title)
        y += 26f * d
        val t = Telemetry
        // CPU
        cv.drawText(t.cpuLabel, pad, y, dim); bar(cv, pad + 84f * d, y - 12f * d, barW, 12f * d, t.cpuPct / 100f, 0.8f)
        cv.drawText("${t.cpuPct}%  ·  ${t.cores} cores", pad + 92f * d + barW, y, ink)
        y += 26f * d
        // memory
        cv.drawText("MEMORY", pad, y, dim); bar(cv, pad + 84f * d, y - 12f * d, barW, 12f * d, t.ramPct / 100f, 0.9f)
        cv.drawText("${t.ramPct}%  ·  ${t.ramFreeMb} of ${t.ramTotalMb} MB free", pad + 92f * d + barW, y, ink)
        y += 26f * d
        // storage
        cv.drawText("STORAGE", pad, y, dim)
        cv.drawText(String.format(Locale.US, "%.1f of %.1f GB free", t.diskFreeGb, t.diskTotalGb), pad + 84f * d, y, ink)
        y += 28f * d
        // network
        cv.drawText("NETWORK", pad, y, dim)
        ink.color = Ui.CYAN; cv.drawText("DOWN " + Telemetry.rate(t.rxKbps), pad + 84f * d, y, ink)
        ink.color = Ui.AMBER; cv.drawText("UP " + Telemetry.rate(t.txKbps), pad + 84f * d + 230f * d, y, ink)
        ink.color = android.graphics.Color.WHITE
        val top = y + 10f * d; val sh = h - top - pad
        if (sh < 20f * d) return
        var mx = 64f
        for (i in 0 until Telemetry.N) { if (Telemetry.rx[i] > mx) mx = Telemetry.rx[i]; if (Telemetry.tx[i] > mx) mx = Telemetry.tx[i] }
        val sw = w - pad * 2; val dx = sw / (Telemetry.N - 1); val k = (sh - 6f) / mx
        if (shaderH != sh) {
            shaderH = sh
            fill.shader = LinearGradient(0f, top, 0f, top + sh, android.graphics.Color.argb(80, 0, 240, 255), android.graphics.Color.TRANSPARENT, Shader.TileMode.CLAMP)
        }
        fun load(a: FloatArray) { for (j in 0 until Telemetry.N) { val i = (Telemetry.head + j) % Telemetry.N; pts[j * 2] = pad + j * dx; pts[j * 2 + 1] = top + sh - 3f - a[i] * k } }
        load(Telemetry.rx); pr.rewind(); pf.rewind(); smooth(pr, true)
        pf.moveTo(pad, top + sh); smooth(pf, false); pf.lineTo(pad + sw, top + sh); pf.close()
        cv.drawPath(pf, fill); line.color = Ui.CYAN; cv.drawPath(pr, line)
        load(Telemetry.tx); pt.rewind(); smooth(pt, true); line.color = Ui.AMBER; cv.drawPath(pt, line)
    }
}
