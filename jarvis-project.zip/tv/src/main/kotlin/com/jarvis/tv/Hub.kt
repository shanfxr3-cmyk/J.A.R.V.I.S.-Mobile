package com.jarvis.tv

import java.net.HttpURLConnection
import java.net.URL

/** Minimal https client for the hub (normal certificate checks). */
object Hub {
    class Reply(val code: Int, val body: String)

    fun call(base: String, method: String, path: String, token: String?, body: String?, readMs: Int): Reply {
        require(base.startsWith("https://")) { "the hub address must start with https://" }
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000
            c.readTimeout = readMs
            c.requestMethod = method
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            return Reply(code, text)
        } finally {
            c.disconnect()
        }
    }
}
