package com.jarvis.tv

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.graphics.drawable.GradientDrawable
import android.view.Window
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Minimal screen: the big logo, one status line, and the one-time setup steps. No voice, no microphone. */
class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private lateinit var root: FrameLayout
    private lateinit var cardView: TextView
    private var mode = "main"   // main, settings, system or diagnostics
    private var hud: HudView? = null
    private val hideCard = Runnable { cardView.visibility = ViewGroup.GONE }
    private val idleTick = Runnable { showHud() }
    private var statusView: TextView? = null
    private var codeView: TextView? = null
    private var hintView: TextView? = null
    @Volatile private var alive = false
    @Volatile private var pairing = false
    private var dlg: Dialog? = null
    private var dlgBody: TextView? = null
    private var dlgPrimary: Button? = null
    private var dlgSecondary: Button? = null
    private var dlgState = ""
    private val cyan = Color.parseColor("#00E5FF")
    private val dim = Color.parseColor("#7FA6B5")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(0, 12, 26))
            setPadding(dp(40), dp(24), dp(40), dp(24))
        }
        root = FrameLayout(this)
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cardView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER; visibility = ViewGroup.GONE
            setPadding(dp(28), dp(16), dp(28), dp(16))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.argb(235, 0, 12, 26)); setStroke(dp(2), cyan); cornerRadius = dp(10).toFloat() }
        }
        root.addView(cardView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(28) })
        setContentView(root)
    }

    // ---------- alert cards from the hub ----------
    private fun showCard(t: String) {
        cardView.text = "J.A.R.V.I.S.\n$t"
        cardView.visibility = ViewGroup.VISIBLE
        cardView.bringToFront()
        ui.removeCallbacks(hideCard); ui.postDelayed(hideCard, 9000)
    }

    // ---------- idle screen: starts after a while without a key press, any key wakes it ----------
    private fun armIdle() {
        ui.removeCallbacks(idleTick)
        if (alive && Prefs.on(this, "idleOn") && Prefs.token(this).isNotBlank()) ui.postDelayed(idleTick, Prefs.int(this, "idleMin") * 60000L)
    }

    private fun showHud() {
        if (!alive || hud != null || mode != "main" || dlg != null) { armIdle(); return }
        val h = HudView(this)
        root.addView(h, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cardView.bringToFront()
        hud = h; h.start()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideHud(): Boolean {
        val h = hud ?: return false
        h.stop(); root.removeView(h); hud = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        return true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val woke = hud != null
        if (woke) hideHud()
        armIdle()
        return if (woke) true else super.dispatchKeyEvent(e)   // the key that wakes the screen does nothing else
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (mode != "main") { mode = "main"; render() } else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        alive = true
        Status.onChange = { ui.post { statusView?.text = statusText() } }
        Updater.sync(this)
        Updater.onChange = { updateUi() }
        Cards.sink = { t -> showCard(t) }
        render()
        if (Prefs.token(this).isNotBlank()) startLink()
        if (Prefs.on(this, "autoUpdate")) Updater.check(this) { updateUi() } else updateUi()
        armIdle()
    }

    override fun onPause() {
        alive = false
        Status.onChange = null
        Updater.onChange = null
        Cards.sink = null
        ui.removeCallbacks(idleTick); ui.removeCallbacks(hideCard); cardView.visibility = ViewGroup.GONE
        hideHud()
        dlg?.dismiss(); dlg = null; dlgState = ""
        super.onPause()
    }

    private fun startLink() {
        val i = Intent(this, HubService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    // ---------- small view helpers ----------
    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; setTextColor(color); textSize = sp; gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun btn(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t; isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun logo(): ImageView {
        val dm = resources.displayMetrics
        val s = (minOf(dm.widthPixels, dm.heightPixels) * 0.42f).toInt()   // sized from the screen, so it is big on a TV
        val v = ImageView(this)
        v.setImageResource(R.drawable.tv_logo)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(s, s)
        ObjectAnimator.ofFloat(v, "alpha", 1f, 0.72f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }
        return v
    }

    private fun statusText(): String =
        (if (Status.online) "LINKED  -  ONLINE" else "LINKED  -  RECONNECTING") + (if (Status.last.isNotBlank()) "\n" + Status.last else "")

    // ---------- screens ----------
    private fun render() {
        box.removeAllViews(); statusView = null; codeView = null; hintView = null
        if (mode != "main" && Prefs.token(this).isBlank()) mode = "main"
        val back = { mode = "main"; render() }
        when (mode) {
            "settings" -> { box.addView(Screens.settings(this, back), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return }
            "system" -> { box.addView(Screens.system(this, back), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return }
            "diagnostics" -> { box.addView(Screens.diagnostics(this, back), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return }
        }
        box.addView(logo())
        box.addView(label("J.A.R.V.I.S.  TV", 30f, cyan, true))
        when {
            Prefs.hub(this).isBlank() -> hubForm()
            Prefs.token(this).isBlank() -> { pairScreen(); startPairing() }
            else -> linked()
        }
        footer()
    }

    /** Version line and a button to look for a new version by hand. */
    private fun footer() {
        box.addView(label("Version ${BuildConfig.VERSION_NAME}  (build ${BuildConfig.VERSION_CODE})", 14f, dim))
        box.addView(btn("Check for updates") {
            toast("Checking for updates...")
            Updater.check(this, true) {
                val a = Updater.available
                if (a == null) toast(Updater.status.ifBlank { "You're on the latest version." }) else Updater.dismissed = 0
                updateUi()
            }
        })
    }

    // ---------- update pop-up ----------
    private fun popBtn(t: String, onClick: () -> Unit): Button = btn(t, onClick).apply {
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.rgb(0, 40, 60)); setStroke(dp(2), cyan); cornerRadius = dp(6).toFloat() }
        setOnFocusChangeListener { v, f -> (v.background as? GradientDrawable)?.setColor(if (f) Color.rgb(0, 110, 140) else Color.rgb(0, 40, 60)) }
    }

    private fun buildDialog(): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(36), dp(28), dp(36), dp(28))
            background = GradientDrawable().apply { setColor(Color.rgb(0, 12, 26)); setStroke(dp(2), cyan); cornerRadius = dp(10).toFloat() }
        }
        col.addView(label("UPDATE AVAILABLE", 26f, Color.parseColor("#FFB800"), true))
        dlgBody = label("", 18f, Color.WHITE)
        col.addView(dlgBody)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0) }
        dlgPrimary = popBtn("") {}
        dlgSecondary = popBtn("") {}
        row.addView(dlgPrimary, LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(8), 0, dp(8), 0) })
        row.addView(dlgSecondary, LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(8), 0, dp(8), 0) })
        col.addView(row)
        d.setContentView(col)
        d.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.6f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.setOnCancelListener { Updater.dismissed = Updater.info?.code ?: 0 }   // Back = "Later" for this version
        return d
    }

    /** Shows, updates or hides the pop-up from the updater's state. Works with the D-pad: both buttons are focusable. */
    private fun updateUi() {
        if (!alive) return
        val a = Updater.available
        if (a == null || Updater.dismissed == a.code) { dlg?.dismiss(); dlg = null; dlgState = ""; return }
        val mb = if (a.size > 0) "  (" + (a.size / 1048576) + " MB)" else ""
        val state: String; val body: String
        when {
            Updater.busy && Updater.progress >= 0 -> { state = "download"; body = "Downloading ${a.label}...  ${Updater.progress}%" }
            Updater.failed -> { state = "error"; body = Updater.status }
            Updater.downloaded != null -> { state = "ready"; body = "${a.label} is downloaded. Choose Install to finish. Your link to the hub stays." }
            else -> { state = "new"; body = "${a.label}$mb is ready.\nUpdate now from here. Your link to the hub stays." }
        }
        val d = dlg ?: buildDialog().also { dlg = it; dlgState = ""; it.show() }
        dlgBody?.text = body
        if (state == dlgState) return   // only the progress text changed: keep the focus where it is
        dlgState = state
        val p = dlgPrimary!!; val s = dlgSecondary!!
        fun later() { Updater.dismissed = a.code; d.dismiss(); dlg = null; dlgState = "" }
        when (state) {
            "download" -> { p.visibility = ViewGroup.GONE; s.visibility = ViewGroup.VISIBLE; s.text = "Hide"; s.setOnClickListener { later() }; s.requestFocus() }
            "error" -> { p.visibility = ViewGroup.VISIBLE; p.text = "Retry"; p.setOnClickListener { Updater.download(this) }; s.visibility = ViewGroup.VISIBLE; s.text = "Close"; s.setOnClickListener { later() }; p.requestFocus() }
            "ready" -> { p.visibility = ViewGroup.VISIBLE; p.text = "Install"; p.setOnClickListener { Updater.install(this) }; s.visibility = ViewGroup.VISIBLE; s.text = "Later"; s.setOnClickListener { later() }; p.requestFocus() }
            else -> { p.visibility = ViewGroup.VISIBLE; p.text = "Update now"; p.setOnClickListener { Updater.download(this) }; s.visibility = ViewGroup.VISIBLE; s.text = "Later"; s.setOnClickListener { later() }; p.requestFocus() }
        }
    }

    private fun hubForm() {
        box.addView(label("Enter your hub address", 18f, dim))
        val e = EditText(this).apply { hint = "https://your-hub-address"; setTextColor(Color.WHITE); setHintTextColor(dim); gravity = Gravity.CENTER; setSingleLine() }
        box.addView(e, LinearLayout.LayoutParams(dp(480), ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(btn("Continue") {
            val v = e.text.toString().trim()
            if (v.startsWith("https://")) { Prefs.setHub(this, v); render() } else toast("The address must start with https://")
        })
    }

    private fun pairScreen() {
        codeView = label("...", 54f, Color.WHITE, true)
        hintView = label("Contacting your hub", 18f, dim)
        box.addView(codeView)
        box.addView(hintView)
    }

    private fun showCode(code: String) {
        codeView?.text = code.substring(0, 3) + " " + code.substring(3)
        hintView?.text = "On Telegram, send:  /pair $code"
    }

    private fun linked() {
        statusView = label(statusText(), 20f, cyan)
        box.addView(statusView)
        if (!FireTv.paired(this)) {
            box.addView(label("Step 2 (one time): allow remote control", 18f, dim))
            box.addView(btn("Show code on TV") { Thread { val m = FireTv.showPin(); ui.post { toast(m) } }.start() })
            val pin = EditText(this).apply {
                hint = "4-digit code from the TV"; inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE); setHintTextColor(dim); gravity = Gravity.CENTER
                filters = arrayOf(InputFilter.LengthFilter(4))
            }
            box.addView(pin, LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(btn("Pair") {
                val p = pin.text.toString()
                Thread { val m = FireTv.verifyPin(this, p); ui.post { toast(m); if (alive) render() } }.start()
            })
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for ((t, m) in listOf("System" to "system", "Settings" to "settings", "Diagnostics" to "diagnostics")) {
            row.addView(Ui.button(this, t) { mode = m; render() }, LinearLayout.LayoutParams(dp(210), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(8), dp(6), dp(8), dp(6)) })
        }
        box.addView(row)
        box.addView(btn("Unlink this TV") {
            Prefs.setToken(this, ""); Status.set(false, "")
            stopService(Intent(this, HubService::class.java))
            render()
        })
    }

    // ---------- pairing with the hub: the TV shows a code, you approve it on Telegram ----------
    private fun startPairing() {
        if (pairing) return
        pairing = true
        Thread {
            var linkedNow = false
            try {
                val hub = Prefs.hub(this)
                val r = Hub.call(hub, "POST", "/v1/devices/pair/request", null, JSONObject().put("name", Prefs.deviceName(this)).toString(), 15000)
                if (r.code != 200) throw java.io.IOException("hub answered HTTP ${r.code}")
                val j = JSONObject(r.body)
                val id = j.getString("id")
                ui.post { showCode(j.getString("code")) }
                val until = System.currentTimeMillis() + 590000
                var done = false
                while (alive && !done && System.currentTimeMillis() < until) {
                    Thread.sleep(3000)
                    val s = JSONObject(Hub.call(hub, "GET", "/v1/devices/pair/status?id=$id", null, null, 15000).body)
                    when (s.optString("status")) {
                        "approved" -> { Prefs.setToken(this, s.getString("token")); linkedNow = true; done = true }
                        "expired" -> done = true
                    }
                }
            } catch (e: Exception) {
                ui.post { hintView?.text = "Cannot reach the hub: ${e.message}. Retrying..." }
                try { Thread.sleep(6000) } catch (_: InterruptedException) {}
            }
            pairing = false
            if (linkedNow) { startLink(); ui.post { if (alive) render() } }
            else if (alive && Prefs.token(this).isBlank()) ui.postDelayed({ if (alive && Prefs.token(this).isBlank()) startPairing() }, 1500)
        }.start()
    }
}
