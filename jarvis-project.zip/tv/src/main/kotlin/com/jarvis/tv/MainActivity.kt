package com.jarvis.tv

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Minimal screen: the big logo, one status line, and the one-time setup steps. No voice, no microphone. */
class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var statusView: TextView? = null
    private var codeView: TextView? = null
    private var hintView: TextView? = null
    @Volatile private var alive = false
    @Volatile private var pairing = false
    private val cyan = Color.parseColor("#00E5FF")
    private val dim = Color.parseColor("#7FA6B5")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(0, 12, 26))
            setPadding(dp(40), dp(24), dp(40), dp(24))
        }
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        alive = true
        Status.onChange = { ui.post { statusView?.text = statusText() } }
        render()
        if (Prefs.token(this).isNotBlank()) startLink()
    }

    override fun onPause() {
        alive = false
        Status.onChange = null
        super.onPause()
    }

    private fun startLink() {
        val i = Intent(this, HubService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    // ---------- small view helpers ----------
    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; setTextColor(color); textSize = sp; gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun btn(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t; isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun logo(): ImageView {
        val dm = resources.displayMetrics
        val s = (minOf(dm.widthPixels, dm.heightPixels) * 0.42f).toInt()   // sized from the screen, so it is big on a TV
        val v = ImageView(this)
        v.setImageResource(R.drawable.tv_logo)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(s, s)
        ObjectAnimator.ofFloat(v, "alpha", 1f, 0.72f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }
        return v
    }

    private fun statusText(): String =
        (if (Status.online) "LINKED  -  ONLINE" else "LINKED  -  RECONNECTING") + (if (Status.last.isNotBlank()) "\n" + Status.last else "")

    // ---------- screens ----------
    private fun render() {
        box.removeAllViews(); statusView = null; codeView = null; hintView = null
        box.addView(logo())
        box.addView(label("J.A.R.V.I.S.  TV", 30f, cyan, true))
        when {
            Prefs.hub(this).isBlank() -> hubForm()
            Prefs.token(this).isBlank() -> { pairScreen(); startPairing() }
            else -> linked()
        }
    }

    private fun hubForm() {
        box.addView(label("Enter your hub address", 18f, dim))
        val e = EditText(this).apply { hint = "https://your-hub-address"; setTextColor(Color.WHITE); setHintTextColor(dim); gravity = Gravity.CENTER; setSingleLine() }
        box.addView(e, LinearLayout.LayoutParams(dp(480), ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(btn("Continue") {
            val v = e.text.toString().trim()
            if (v.startsWith("https://")) { Prefs.setHub(this, v); render() } else toast("The address must start with https://")
        })
    }

    private fun pairScreen() {
        codeView = label("...", 54f, Color.WHITE, true)
        hintView = label("Contacting your hub", 18f, dim)
        box.addView(codeView)
        box.addView(hintView)
    }

    private fun showCode(code: String) {
        codeView?.text = code.substring(0, 3) + " " + code.substring(3)
        hintView?.text = "On Telegram, send:  /pair $code"
    }

    private fun linked() {
        statusView = label(statusText(), 20f, cyan)
        box.addView(statusView)
        if (!FireTv.paired(this)) {
            box.addView(label("Step 2 (one time): allow remote control", 18f, dim))
            box.addView(btn("Show code on TV") { Thread { val m = FireTv.showPin(); ui.post { toast(m) } }.start() })
            val pin = EditText(this).apply {
                hint = "4-digit code from the TV"; inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE); setHintTextColor(dim); gravity = Gravity.CENTER
                filters = arrayOf(InputFilter.LengthFilter(4))
            }
            box.addView(pin, LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(btn("Pair") {
                val p = pin.text.toString()
                Thread { val m = FireTv.verifyPin(this, p); ui.post { toast(m); if (alive) render() } }.start()
            })
        }
        box.addView(btn("Unlink this TV") {
            Prefs.setToken(this, ""); Status.set(false, "")
            stopService(Intent(this, HubService::class.java))
            render()
        })
    }

    // ---------- pairing with the hub: the TV shows a code, you approve it on Telegram ----------
    private fun startPairing() {
        if (pairing) return
        pairing = true
        Thread {
            var linkedNow = false
            try {
                val hub = Prefs.hub(this)
                val r = Hub.call(hub, "POST", "/v1/devices/pair/request", null, JSONObject().put("name", Prefs.deviceName()).toString(), 15000)
                if (r.code != 200) throw java.io.IOException("hub answered HTTP ${r.code}")
                val j = JSONObject(r.body)
                val id = j.getString("id")
                ui.post { showCode(j.getString("code")) }
                val until = System.currentTimeMillis() + 590000
                var done = false
                while (alive && !done && System.currentTimeMillis() < until) {
                    Thread.sleep(3000)
                    val s = JSONObject(Hub.call(hub, "GET", "/v1/devices/pair/status?id=$id", null, null, 15000).body)
                    when (s.optString("status")) {
                        "approved" -> { Prefs.setToken(this, s.getString("token")); linkedNow = true; done = true }
                        "expired" -> done = true
                    }
                }
            } catch (e: Exception) {
                ui.post { hintView?.text = "Cannot reach the hub: ${e.message}. Retrying..." }
                try { Thread.sleep(6000) } catch (_: InterruptedException) {}
            }
            pairing = false
            if (linkedNow) { startLink(); ui.post { if (alive) render() } }
            else if (alive && Prefs.token(this).isBlank()) ui.postDelayed({ if (alive && Prefs.token(this).isBlank()) startPairing() }, 1500)
        }.start()
    }
}
