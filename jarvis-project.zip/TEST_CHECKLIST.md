# Device test checklist (nothing here has been run on a phone yet)

Tick each one on the Poco and write what broke next to it.

- [ ] Build passes in CI. If GeckoView breaks it, set `geckoview.version` in gradle.properties to an older exact version.
- [ ] Ask "weather in Karachi and set a timer for 2 minutes": both happen, "On it, sir." is spoken first.
- [ ] Lock the phone. Send `/speak hello` to the Telegram bot: the phone speaks it within ~30 s.
- [ ] Lock the phone. Say "research the best budget phones, tell me when done": spoken result arrives.
- [ ] Set briefing time 2 minutes ahead: it speaks while locked.
- [ ] Unplug charger and let battery cross 20 percent (or use `adb shell dumpsys battery set level 19`): warning is spoken once.
- [ ] "Remember that I like tea": appears on Memory screen; Forget removes it.
- [ ] "Open YouTube", "what is on my calendar today", "where am I", "what notifications did I get" (enable notification access first).
- [ ] Reboot the phone: alerts still work without opening the app.
- [ ] Add and remove a watch topic: "watch the Mars mission".
