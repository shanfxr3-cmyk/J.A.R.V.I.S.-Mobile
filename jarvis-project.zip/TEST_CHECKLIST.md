# Device test checklist

The core path (chat, hub, Telegram, spoken alerts) has been tried on the author's phone and server and works. Tick everything else on the Poco and write what broke next to it.
The 4 Nov 2026 changes (backup key, hub default, consent screen) were written without an Android build and are compiled for the first time by CI, so test those first.

- [ ] Build passes in CI.
- [ ] Ask "weather in Karachi and set a timer for 2 minutes": both happen, "On it, sir." is spoken first.
- [ ] Lock the phone. Send `/speak hello` to the Telegram bot: the phone speaks it within ~30 s.
- [ ] Lock the phone. Say "research the best budget phones, tell me when done": spoken result arrives.
- [ ] Set briefing time 2 minutes ahead: it speaks while locked.
- [ ] Unplug charger and let battery cross 20 percent (or use `adb shell dumpsys battery set level 19`): warning is spoken once.
- [ ] "Remember that I like tea": appears on Memory screen; Forget removes it.
- [ ] "Open YouTube", "what is on my calendar today", "where am I", "what notifications did I get" (enable notification access first).
- [ ] Reboot the phone: alerts still work without opening the app.
- [ ] Add and remove a watch topic: "watch the Mars mission".

## Added 4 Nov 2026 (hardening)
- [ ] Update installs over the old app.
- [ ] Telegram `/speak hello` while the phone is locked: the phone says it.
- [ ] Telegram: "search the news about Mars and then switch the TV to home": the news comes back, the TV action is refused with a plain explanation. Then `/tv home` on its own still works.
- [ ] Send 9 wrong tokens to the hub from another network, then use the app: the app still works.
- [ ] Hub log after start says `jarvis-hub on 127.0.0.1:<port>` and the app still reaches it through the tunnel.
- [ ] Reminder set by delay ("remind me in 2 minutes") speaks on time in the daytime. Delay reminders that fall between 22:00 and 06:35 wait until 06:35 and start with "Belated reminder".

## Added 4 Nov 2026 (proactive, phone control)
Proactive (Settings, Spoken alerts: "Speak first" switch on):
- [ ] Say "Jarvis, this is home" at home: it confirms "Home saved".
- [ ] Settings, Exact location: pause sharing. Walk 300 m away and back: "Leaving home" and "Welcome home" are still spoken, and nothing reaches the hub.
- [ ] Add a calendar event with no place 16 minutes ahead: heads-up is spoken once, about 15 minutes before.
- [ ] Add an event with a real address far away (turn "Warn by travel time" on, location allowed): the line says "about N minutes away, so leave now" and comes earlier than 30 minutes. Turn the switch off: back to the plain 30-minute line.
- [ ] Add an event with a place Android cannot find ("zzzz nowhere"): the plain 30-minute line, no crash.
- [ ] Charge to 100 percent while plugged in: "fully charged, unplug" once. Unplug and plug in again: no repeat until it has dropped and reached 100 again.
- [ ] Plug in around the same hour on 5 different days (or use `adb shell am broadcast` to fake it): then unplugged below 60 percent at that hour, "you usually put the phone on charge around now" is spoken once that day.
- [ ] 21:30 evening summary speaks once (battery and tomorrow's first event).
- [ ] Quiet hours: nothing speaks 23:00 to 06:30, except an event starting within 10 minutes.
- [ ] Do Not Disturb on, or in a call: nothing speaks. No more than one line every 4 minutes and 12 a day.
- [ ] Switch "Speak first" off: all of the above stops, including home detection.
- [ ] Mute during events (needs Shizuku "Ready, shell"): switch it on, add a 15-minute event starting in 2 minutes. The heads-up ends with "I will mute the phone when it starts", DND turns on at the start and off at the end.
- [ ] Mute during events: turn DND off by hand in the middle of the event. It stays off (no fighting).
- [ ] Mute during events with Shizuku stopped: nothing mutes, nothing crashes.
- [ ] Reboot: after Shizuku is restarted, proactive lines and mute work again without opening the app.

Phone control (Settings, Phone control):
- [ ] Shizuku running, "Allow Jarvis": status reads "Ready, shell".
- [ ] "Grant ALL permissions now": report shows permissions x/y, accessibility on.
- [ ] "Test: read the screen" lists items. "Test: press Home" goes home.
- [ ] "Turn on the flashlight", "Set brightness to 40 percent", "Turn Wi-Fi off, then on", "Scroll down".
- [ ] With "Act without asking" off: each tap, key or setting asks Allow in chat. Voice cannot use them.
- [ ] Uninstall, clear data, reboot, shell, call and text always ask in chat, even with "Act without asking" on.
- [ ] Banking and UPI apps still open with accessibility on.
- [ ] Reboot: "Hey Jarvis" works again without opening the app (Android 15 may block the microphone service).
- [ ] Settings, AI provider: two key fields (Groq, Gemini) and six model rungs. Settings, Hub: address and token.
- [ ] With only a Gemini key saved and no hub, Save & test says Connected. With only a Groq key, rungs 1-4 are skipped and it still works.
- [ ] Stop the hub (or the tunnel) with keys saved on the phone: Jarvis still answers directly. Start the hub: answers go through it again.
- [ ] Upgrade from an older version: an old gsk_ key appears as the Groq key; an old hub-token key appears as the Hub token.
