# Device test checklist

The core path (chat, hub, Telegram, spoken alerts) has been tried on the author's phone and server and works. Tick everything else on the Poco and write what broke next to it.
The 4 Nov 2026 changes (backup key, hub default, consent screen) were written without an Android build and are compiled for the first time by CI, so test those first.

- [ ] Build passes in CI.
- [ ] Ask "weather in Karachi and set a timer for 2 minutes": both happen, "On it, sir." is spoken first.
- [ ] Lock the phone. Send `/speak hello` to the Telegram bot: the phone speaks it within ~30 s.
- [ ] Lock the phone. Say "research the best budget phones, tell me when done": spoken result arrives.
- [ ] Set briefing time 2 minutes ahead: it speaks while locked.
- [ ] Unplug charger and let battery cross 20 percent (or use `adb shell dumpsys battery set level 19`): warning is spoken once.
- [ ] "Remember that I like tea": appears on Memory screen; Forget removes it.
- [ ] "Open YouTube", "what is on my calendar today", "where am I", "what notifications did I get" (enable notification access first).
- [ ] Reboot the phone: alerts still work without opening the app.
- [ ] Add and remove a watch topic: "watch the Mars mission".

## Added 4 Nov 2026 (hardening)
- [ ] Update installs over the old app. You are asked to accept the legal documents again (consent version 4).
- [ ] Settings, AI provider: with your hub token as the API key, a "Backup Groq key" field shows. With a gsk_ key it shows "Hub token" instead.
- [ ] Save a backup Groq key, stop the hub (or the tunnel), ask a question: Jarvis still answers (direct from Groq). Start the hub again: answers go through it again.
- [ ] Clear the hub address in Settings and use a non-gsk key: the error says it is not a Groq key and no hub is set.
- [ ] Telegram `/speak hello` while the phone is locked: the phone says it.
- [ ] Telegram: "search the news about Mars and then switch the TV to home": the news comes back, the TV action is refused with a plain explanation. Then `/tv home` on its own still works.
- [ ] Send 9 wrong tokens to the hub from another network, then use the app: the app still works.
- [ ] Hub log after start says `jarvis-hub on 127.0.0.1:<port>` and the app still reaches it through the tunnel.
- [ ] Reminder set by delay ("remind me in 2 minutes") speaks on time in the daytime. Delay reminders that fall between 22:00 and 06:35 wait until 06:35 and start with "Belated reminder".
