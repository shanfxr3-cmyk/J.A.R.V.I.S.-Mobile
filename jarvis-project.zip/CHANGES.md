# Change log

## Unreleased — God's Eye View screen (stage 3)
- New `GodsEyeScreen.kt`: full-screen God's Eye View in a WebView on `127.0.0.1:4173`. Shows a start screen (with the server log tail), an error screen (Try again, log) and a "server is off" screen. Back moves through the page's own history first. Links to other sites open in the phone's browser. The web page's own tab bar is used, so Jarvis' bottom bar is hidden on this screen.
- New `GodsEyeService`: a foreground service (type `specialUse`) that starts the server and keeps it alive while Jarvis is in the background. The notification has a Stop button. Leaving the screen does not stop the server; Stop does.
- Microphone for the globe's voice agent: asked once, only for the local page. While the page has the microphone, the "Hey Jarvis" detector is paused so the two do not fight over it, and it resumes when the screen closes.
- Voice and chat: "open God's Eye View" (also "open the globe", "open gods eye", "world map", "live map", "radar"). Home has an "Open God's Eye View" card.
- `GodsEye` now has an observable `status` and `statusMsg`; starts are guarded so two requests cannot start two servers.
- A LOG button on the globe screen shows the page's console errors, failed loads and the WebGL check.
- New permissions: `FOREGROUND_SERVICE_SPECIAL_USE`, `MODIFY_AUDIO_SETTINGS`. New icon `Ic.Globe`.

---

## God's Eye View server inside Jarvis (stage 2)
- New `GodsEye.kt`: unpacks `assets/gev/gev-bundle.zip` into app storage, starts the real God's Eye View server with the bundled Node, and checks it (health, page, API rules, every mounted route). Buttons are under Settings, About, Developer: Node runtime test.
- New `assets/gev/gev-launcher.mjs`: runs the unmodified server code (providers, MCP, Host check, response headers) without Vite and serves the built app on `127.0.0.1:4173`. Map keys entered in Provider Settings are filled in when pages are served.
- New `res/xml/network_security_config.xml`: plain HTTP is allowed only to `127.0.0.1` and `localhost`.
- The bundle is built by the new "Get God's Eye View" workflow (MIT licence, pinned to a release tag) and added to the APK by the Android build workflow.

---

## 0.9.1 — Wake word fixes
- Home sphere: the word `JARVIS` removed from the sphere (sphere size unchanged).
- New voice/chat command: "turn off wake word" (also "disable wake word", "switch off the wakeword", "stop listening"). Jarvis confirms out loud, stops the listener, clears the "wanted" flag and the watchdog, so nothing brings it back until the button in Settings is turned on by hand. Handled in `Assistant.isWakeOff`, `WakeService.turnOffByVoice` and `ChatScreen.send`.
- Far fewer false wake-ups: a detection now needs 3 of the last 5 frames above the threshold (was 1 frame), real sound above a loudness floor in the last second (`WakeWord.minLevel`), and a 1.6 s warm-up after every restart (was ~1 s), so the beep and Jarvis' own voice are not heard.
- Sensitivity curve is stricter: 50% = threshold 0.75 (was 0.70), 70% = 0.65 (was 0.50); minimum threshold 0.50 (was 0.35). Default sensitivity 70% -> 50%.
- After the wake word, results shorter than 3 characters are ignored instead of being sent as a request.
- `versionName` 0.9.0 -> 0.9.1.

---

## 0.9.0 — Home sphere redesign
- New `Sphere.kt`: 3D dot-globe (Fibonacci lattice with depth shading), front-hemisphere grid, glowing core, scanning light band, three precessing rings with satellites, HUD tick ring with a running arc. Reacts to `WakeService.state` (faster spin and a ripple while LISTENING / THINKING / SPEAKING).
- Old flat `AiSphere` removed from `HomeScreen.kt`.
- Sphere keeps its original size (radius = height / 2.7). The word `JARVIS` is centred on it and smaller (30sp -> 22sp). `AI CORE`, the version number and `AI READY` / `LOCAL MODE` removed (KEY SET / NO KEY badge in the header stays).
- Animation runs only while the app is visible (`LaunchWhileStarted`), allocation-light per frame.
- `versionName` 0.8.0 -> 0.9.0. README lists the new sphere as a feature.

---

# Patch log for 0.8.0 (from the deep code inspection)

## Batch 1: items 1-7 (broken now / wrong results)
1. Default model is now `openai/gpt-oss-120b` (fast: `openai/gpt-oss-20b`). Saved dead model ids are migrated at start; a "decommissioned" error retries once with the default. Dead models removed from the Settings list, safeguard model removed.
2. Hand model: uses the bundled `assets/hand_landmarker.task` if present, otherwise downloads it once from Google's MediaPipe storage into app storage, then starts tracking.
3. Wake word: detector reports when its thread dies (mic lost, or 25 straight inference errors); the service restarts it with backoff (2s, 4s, 8s...) and shows an error after 5 tries.
4. Voice: `speak()` return code is checked, a timeout stops a stuck utterance, and a missing TTS engine no longer waits 5 s per reply and is reported.
5. Resume notification: own LOW-importance channel, only-alert-once, silent. Settings warns when notifications are off and explains plainly that Android may block auto-restart.
6. Consent is tied to `Legal.CONSENT_VERSION` (bump only when legal text changes), not to every build. Accepting starts the listener again if it was on.
7. "Delete all app data" stops the service, resets every Settings field, deletes wake/hand models, cache, tracker prefs and the Keystore key.

## Batch 2: items 8-29 (functional bugs)
8. Voice "open X" compares against the live top of the stack (no stale closure).
9. Navigation stack is saved (`rememberSaveable`) and MainActivity handles rotation/theme/font-scale itself (`configChanges`), so it no longer resets to Home.
10. Chat keyboard gap fixed (`consumeWindowInsets`).
11. Status/navigation bar icons forced light (`SystemBarStyle.dark`).
12. Home header shows real state (key set / no key), and "DOWNLOADING" / "PAUSED" wake states.
13. Adaptive launcher icon `@mipmap/ic_jarvis` (named so it cannot clash with an icon your workflow may add) + status-bar notification icon.
14. Local commands match whole phrases only (time/date/open/tasks); curly apostrophes handled; task titles keep their original case.
15. Chat pauses the wake detector while it listens or speaks (`WakeService.hold`).
16. Sensitivity applies live when you release the slider; threshold never below 0.35.
17. Always-on switch takes/drops the wake lock immediately; the lock has an 8 h timeout renewed every 6 h.
18. Stopping during THINKING no longer reports an error or speaks after the service is off.
19. AI requests can be cancelled for real (Stop button, service shutdown).
20. Wake beep uses the notification stream (not silent at media volume 0).
21. Speech recogniser prefers offline when a pack is installed; clearer offline message.
22. Groq: retry with backoff on 429/5xx (honours Retry-After), then falls back to the lighter model; mid-stream errors surfaced; partial replies kept; `Accept-Encoding: identity`; `<think>` text removed before it is shown or spoken; safeguard model removed.
23. Fish: speech is made per sentence (starts after the first piece), failures are remembered for 5 min, old mp3s cleaned up, test file always deleted, S1 dropped and migrated, hint when the voice ID is missing.
24. Store loads each record safely (one bad record can no longer crash launch).
25. Store saves on a background thread, coalesced; a wipe cancels pending saves.
26. Keystore failures show a warning in Settings instead of silently dropping the key.
27. Wake models: size + Content-Length checks, a damaged model is deleted and re-downloaded once.
28. After 3 failed starts the watchdog stops retrying; Settings says so; turning the listener on again resets it.
29. Task ids are always unique.
BootReceiver is no longer exported (item 40).

## Batch 3: items 30-40 (lag, battery, updater, build)
30. Heavy work moved off the main thread: ONNX models load in the worker (`WakeWord.prepare()`), the hand detector is built on a worker and the camera binds afterwards, and saved data/Keystore are warmed up by `JarvisApplication`.
31. Wake word: big buffers re-used (no per-chunk allocation), audio buffer ~640 ms (was 160 ms), audio-priority thread. (Silero VAD gating not added: it needs another model download.)
32. Polling loops (Settings 2 s, Home 5 s, Holo 200/250 ms) run only while the app is visible (`LaunchWhileStarted`).
33. Holo: glow sprites use the GPU's real max point size; real 60 fps pacing on 90/120 Hz screens; hand confidence 0.5 (fewer ghost hands); PINCH readout uses the controller's thresholds; hands ordered left-to-right so crossing cannot swap slots; GPU safety net only counts visible time; system Back gesture excluded over the sphere; hand tracking and camera choice survive rotation.
34. Legal viewer merges plain lines into paragraphs (a few dozen items instead of one per line).
35. Updater: tag -> version code via `TAG_OFFSET` (default 0, see gradle.properties; VERIFY against your workflow), friendly GitHub rate-limit message, cut-off downloads rejected, already-downloaded APK reused and re-detected after a restart, package/version of the APK checked, error text no longer green.
36. `android.suppressUnsupportedCompileSdk=35` silences the AGP warning.
37. Added `.gitignore`. The Gradle wrapper and the GitHub workflow are not in the zip, so I could not touch them.
38. APK limited to arm64-v8a by default (`JARVIS_ABIS` to change).
39. onnxruntime-android 1.22.0 and mediapipe tasks-vision 0.10.26 (both documented as 16 KB-page aligned). NOT COMPILED HERE: if the build fails, revert these two lines.
40. BootReceiver not exported (done in Batch 2).

## Batch 4: items 41-44 and the polish list
41. Wording fixed everywhere (consent screen, Settings, Memory, README, privacy policy): data is stored on the device, but AI messages go to Groq, spoken replies to Fish Audio, speech may go to Google.
42. Privacy 8.1 now describes exactly what "Delete all app data" removes (and it really does that now).
Consent text in Terms 2.x, Privacy 12.x and Usage 1.1 now matches the new behaviour (re-accept only when the documents change). Dates set to 26 October 2026.
43. Added a "Name notice" (not affiliated with Marvel/Disney) to the branding rules. Renaming the app is your decision; I did not change the name.
44. OFL dashes restored in THIRD_PARTY_NOTICES.md and the bundled copy.
Polish: User-Agent shows the real version; battery shows "--" instead of a bogus number; Tools screen refreshes live and has notification + battery-saver shortcuts; more autostart pages (Oppo, OnePlus, Samsung, Asus, Honor); key fields use a password keyboard; nav glyph letters are hidden from screen readers; task titles keep their case; Fish test file always deleted; SECURITY.md reminds you to keep GitHub 2FA on.

## Not changed / needs you
- Workflow, Gradle wrapper and the release tag format are not in the zip: check `JARVIS_TAG_OFFSET` (gradle.properties) against your workflow.
- Nothing was compiled here (no Android SDK in this sandbox). Most likely first-build trouble spots: the two dependency bumps (item 39) and `systemGestureExclusion` / `LocalLifecycleOwner` imports.
- Kept as is on purpose: Silero VAD gating, exact-alarm restarts (not a verified exemption for the microphone type), pinning SHA-256 of the wake models (I cannot download them here to read the hashes).
