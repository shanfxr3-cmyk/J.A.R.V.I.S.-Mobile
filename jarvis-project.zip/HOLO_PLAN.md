# HoloCore architecture
- Phases: frame loop (LaunchWhileStarted, withFrameNanos) -> HoloTelemetry.step (in-place primitive arrays, 10 Hz data, per-frame blips) -> draw phase only reads `tel.t`/`tel.tick`. Composition runs once.
- Recomposition guards: derivedStateOf(WakeService.state -> speed target) + rememberUpdatedState; speed eased inside the frame loop, no animate*AsState.
- Draw: drawWithCache builds HoloScene (Paints, Paths, gradients, FloatArrays, text CharArrays) once per size; onDrawBehind only mutates/reads them. Trig = 2048-entry LUT; geometry loops (tick ring, Fibonacci sphere, reticle, radar blips) are explicit sin/cos.
- Batches: nativeCanvas.drawPoints/drawLines with counts; arcs/rotation via compose Canvas save/translate/rotate.
- AGSL (API 33+, plain Compose path below): (1) post RuntimeShader as graphicsLayer.renderEffect (chromatic aberration, 8-tap glow, vignette), rebuilt only on size change; (2) animated overlay RuntimeShader via ShaderBrush, BlendMode.Plus (scan band, scanlines, noise matrix, glitch bars), uniforms updated in place.
- Hub: no change needed; HUD data is local and the hub's long-poll events/tools API is untouched.
- Wiring: HomeScreen.kt now calls holo.HoloCore instead of AiSphere.
